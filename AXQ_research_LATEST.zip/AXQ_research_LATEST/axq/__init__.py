"""AXQ-Universal: research framework for RL benchmarking and architecture research.

Pure NumPy/SciPy implementation (no torch / no gymnasium dependency).
"""
__version__ = "0.1.0"
