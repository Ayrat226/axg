"""Agent package: registry + public API (contract used by other agents)."""
from ..core.agent import RandomAgent
from .a2c import A2C
from .axq import AXQ
from .common import EpsilonSchedule, ReplayBuffer
from .continual import EWCDQN, MultiHeadDQN
from .dqn import DQN
from .dyna import DynaQ
from .efe import EFEAgent
from .frame_stack import HistoryDQN
from .gru_dqn import GRUDQN
from .mbtl import MBTL
from .sf import SFGPI
from .tabular import TabularQ

AGENTS = {
    "random": RandomAgent,
    "tabular": TabularQ,
    "dqn": DQN,
    "axq": AXQ,
    "history_dqn": HistoryDQN,
    "gru_dqn": GRUDQN,
    "dqn_ewc": EWCDQN,
    "dqn_heads": MultiHeadDQN,
    "dyna": DynaQ,
    "dyna_optim": DynaQ,
    "efe": EFEAgent,
    "sf": SFGPI,
    "mbtl": MBTL,
    "a2c": A2C,
}


def make_agent(name, n_obs, obs_type, n_actions, seed=0, **params):
    """Construct an agent by registry name.

    ``"random"`` ignores ``n_obs``/``obs_type`` (and extra params) and
    returns ``RandomAgent(n_actions, seed=seed)``. All other names are
    constructed as ``cls(n_obs=..., obs_type=..., n_actions=...,
    seed=..., **params)``. Unknown names raise ``KeyError``.

    Cycle-4 aliases: ``dyna_optim`` == DynaQ with optimistic_init;
    pass ``optimistic_init=...`` via params (explicit, no hidden defaults).
    """
    if name == "random":
        return RandomAgent(int(n_actions), seed=seed)
    if name == "dyna_optim":
        name = "dyna"
    if name not in AGENTS:
        raise KeyError("unknown agent '%s'. known: %s" % (name, sorted(AGENTS)))
    return AGENTS[name](n_obs=n_obs, obs_type=obs_type,
                        n_actions=n_actions, seed=seed, **params)


__all__ = ["make_agent", "AGENTS", "TabularQ", "DQN", "AXQ", "HistoryDQN",
           "GRUDQN", "ReplayBuffer", "EpsilonSchedule", "DynaQ", "EFEAgent",
           "SFGPI"]
