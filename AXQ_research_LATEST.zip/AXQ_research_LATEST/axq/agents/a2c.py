"""A2C — episodic advantage actor-critic (H22 stretch, policy-gradient family).

Design notes (registered before runs):
* Actor: MLP -> softmax policy; Critic: separate MLP value head. Both use
  the project MLP backend (integrated Adam; backward ACCUMULATES grads,
  adam_step applies + zeroes — see core/nn/mlp.py).
* EPISODIC updates: Monte-Carlo returns G_t (bootstrap from V(s_T) on
  TRUNCATED episodes — project convention: truncation still bootstraps),
  advantage A_t = G_t - V(s_t) with per-episode normalization.
* MECHANISM PREDICTION from the cycle-4 taxonomy: softmax policies have NO
  argmax tie-breaking, so the deceptive lock-in (tie -> quit at the aliased
  hold state) should NOT occur — the stochastic policy holds with P~0.5 at
  init, completes chains stochastically, and learns. This agent is the
  direct test of the argmax-tie pathology theory (H22b).
* Entropy bonus beta=0.01.
"""
import numpy as np

from ..core.agent import AgentBase
from ..core.nn.mlp import MLP
from .common import encode_obs


def _softmax(z):
    z = z - z.max(axis=-1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=-1, keepdims=True)


class A2C(AgentBase):
    """Episodic advantage actor-critic."""

    name = "a2c"

    def __init__(self, n_obs, obs_type, n_actions, hidden=(64, 64),
                 lr=3e-3, gamma=0.99, beta_entropy=0.01, seed=0):
        self.n_obs = int(n_obs)
        self.obs_type = obs_type
        self.n_actions = int(n_actions)
        self.gamma = float(gamma)
        self.beta_entropy = float(beta_entropy)
        self.lr = float(lr)
        rng = np.random.default_rng(seed)
        self.actor = MLP([self.n_obs, *hidden, self.n_actions], rng,
                         activation="tanh")
        rng2 = np.random.default_rng(seed + 777)
        self.critic = MLP([self.n_obs, *hidden, 1], rng2, activation="tanh")
        self._traj = []          # (x, action, reward, terminated)
        self._rng = np.random.default_rng(seed + 1)

    # ------------------------------------------------------------------
    def _policy(self, obs):
        x = encode_obs(obs, self.obs_type, self.n_obs)
        logits = self.actor.forward(x)
        return x, _softmax(logits)

    def act(self, obs, greedy=False):
        _, probs = self._policy(obs)
        if greedy:
            return int(np.argmax(probs))
        return int(self._rng.choice(self.n_actions, p=probs[0]))

    def observe(self, obs, action, reward, next_obs, terminated, truncated,
                info=None):
        x = encode_obs(obs, self.obs_type, self.n_obs)
        self._traj.append((x, int(action), float(reward), bool(terminated)))
        if terminated or truncated:
            self._update()

    def _returns(self):
        """Monte-Carlo returns; truncated episodes bootstrap from V(s_T)."""
        T = len(self._traj)
        G = np.zeros(T)
        g = 0.0
        if not self._traj[-1][3]:      # truncated -> bootstrap
            g = float(self.critic.forward(self._traj[-1][0]).ravel()[0])
        for t in reversed(range(T)):
            r = self._traj[t][2]
            g = r + self.gamma * g
            G[t] = g
        return G

    def _update(self):
        if not self._traj:
            return
        T = len(self._traj)
        G = self._returns()
        xs = np.concatenate([t[0] for t in self._traj], axis=0)
        acts = np.array([t[1] for t in self._traj])
        V = self.critic.forward(xs).ravel()
        A = G - V
        sd = A.std()
        if sd > 1e-8:
            A = (A - A.mean()) / sd
        # actor grad: d/dtheta ( -log pi(a|s) * A + beta * H(pi) )
        probs = _softmax(self.actor.forward(xs))     # [T, A]
        logp = np.log(probs + 1e-12)
        ent = -(probs * logp).sum(axis=1, keepdims=True)
        dlogits = probs.copy()                        # d(log softmax)/dz
        dlogits[np.arange(T), acts] -= 1.0            # d log pi(a|s)/dz
        dlogits *= -A[:, None]
        dlogits += self.beta_entropy * probs * (logp + ent)
        self.actor.backward(dlogits)
        self.actor.adam_step(self.lr, clip_norm=5.0)
        # critic grad: MSE toward G
        dV = 2.0 * (V - G)[:, None] / max(T, 1)
        self.critic.backward(dV)
        self.critic.adam_step(self.lr, clip_norm=5.0)
        self._traj = []

    def update(self):
        return {"td_error": 0.0}

    def end_episode(self):
        if self._traj:          # safety flush (should be empty normally)
            self._update()
