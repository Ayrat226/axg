"""AXQ-6: bootstrapped ensemble DQN (Osband et al. 2016 / SUNRISE line).

K independent Q-heads with per-head target nets; action selection uses the
per-action MEDIAN across heads; exploration = epsilon-greedy plus an
ensemble-disagreement bonus (population std across heads) in the
non-random branch. Each head trains on its own random minibag subsample of
a shared replay batch (independent bootstraps of the data).
"""
import json
import os

import numpy as np

from ..core.agent import AgentBase
from ..core.nn.mlp import MLP
from .common import (EpsilonSchedule, ObsNormalizer, ReplayBuffer,
                     encode_obs, one_hot_batch)


class AXQ(AgentBase):
    """Median-of-heads ensemble DQN with disagreement-bonus exploration.

    aggregation: "median" | "mean" | "min" (action selection & diagnostics;
    "min" = Maxmin Q-learning line, Lan et al. 2020).
    use_prior: adds an UNTRAINED random prior network per head (Osband et al.
    2018): Q_k = Q_net_k + prior_k, priors are frozen. Established remedy
    for insufficient ensemble diversity in deep exploration.
    """

    name = "axq"

    def __init__(self, n_obs, obs_type, n_actions, n_heads=6,
                 head_hidden=(48, 48), lr=1e-3, gamma=0.99, buffer_size=50000,
                 batch_size=64, target_sync=1000, double=True, n_step=1,
                 eps_start=1.0, eps_end=0.05, eps_decay=10000,
                 beta_explore=1.0, minibag_frac=0.8, update_every=1,
                 warmup=1000, grad_clip=10.0, seed=0,
                 aggregation="median", use_prior=False):
        self.n_obs = int(n_obs)
        self.obs_type = str(obs_type)
        self.n_actions = int(n_actions)
        if self.obs_type not in ("discrete", "vector"):
            raise ValueError("obs_type must be 'discrete' or 'vector', got %r"
                             % (self.obs_type,))
        if int(n_heads) < 1:
            raise ValueError("n_heads must be >= 1")
        self.n_heads = int(n_heads)
        self.head_hidden = tuple(int(h) for h in head_hidden)
        self.lr = float(lr)
        self.gamma = float(gamma)
        self.batch_size = int(batch_size)
        self.target_sync = int(target_sync)
        self.double = bool(double)
        self.n_step = int(n_step)
        self.eps_start = float(eps_start)
        self.eps_end = float(eps_end)
        self.eps_decay = int(eps_decay)
        self.beta_explore = float(beta_explore)
        self.minibag_frac = float(minibag_frac)
        self.update_every = int(update_every)
        self.warmup = int(warmup)
        self.grad_clip = float(grad_clip)
        self._rng = np.random.default_rng(seed)
        self._eps = EpsilonSchedule(self.eps_start, self.eps_end, self.eps_decay)
        self.buffer = ReplayBuffer(capacity=buffer_size, n_step=self.n_step,
                                   gamma=self.gamma)
        if aggregation not in ("median", "mean", "min"):
            raise ValueError("aggregation must be median|mean|min")
        self.aggregation = aggregation
        self.use_prior = bool(use_prior)
        # Running obs normalization for vector envs — IDENTICAL mechanism to
        # DQN (train-stream-only updates, frozen during eval).
        self._norm = ObsNormalizer(self.n_obs) \
            if self.obs_type == "vector" else None
        sizes = [self.n_obs] + list(self.head_hidden) + [self.n_actions]
        self.nets = [MLP(sizes, self._rng, activation="tanh")
                     for _ in range(self.n_heads)]
        self.target_nets = [MLP(sizes, self._rng, activation="tanh")
                            for _ in range(self.n_heads)]
        self.priors = [MLP(sizes, self._rng, activation="tanh")
                       for _ in range(self.n_heads)] if self.use_prior else []
        for tgt, net in zip(self.target_nets, self.nets):
            tgt.copy_from(net)
        self._step_count = 0
        self._update_calls = 0
        self._grad_steps = 0

    # ------------------------------------------------------------------
    def _encode_single(self, obs):
        x = encode_obs(obs, self.obs_type, self.n_obs)
        if self._norm is not None:
            x = self._norm.transform(x)
        return x

    def _encode_batch(self, obs_batch):
        if self.obs_type == "discrete":
            return one_hot_batch(obs_batch, self.n_obs)
        x = np.asarray(obs_batch, dtype=np.float64)
        if self._norm is not None:
            x = self._norm.transform(x)
        return x

    def _gamma_eff(self, batch):
        n_lens = batch.get("n_lens") if isinstance(batch, dict) else None
        if n_lens is None:
            n_lens = np.full(len(batch["actions"]), self.n_step, dtype=np.int64)
        return self.gamma ** np.asarray(n_lens, dtype=np.int64)

    def _head_q(self, obs):
        """[K, n_actions] stack of per-head Q rows for one observation."""
        x = self._encode_single(obs)
        if self.use_prior:
            return np.stack([net.forward(x)[0] + pr.forward(x)[0]
                             for net, pr in zip(self.nets, self.priors)], axis=0)
        return np.stack([net.forward(x)[0] for net in self.nets], axis=0)

    def _aggregate(self, qs):
        """[K, n_actions] -> aggregated Q row (median | mean | min)."""
        if self.aggregation == "mean":
            return qs.mean(axis=0)
        if self.aggregation == "min":
            return qs.min(axis=0)
        return np.median(qs, axis=0)

    # ------------------------------------------------------------------
    # AgentBase API
    def act(self, obs, greedy=False):
        qs = self._head_q(obs)
        q_agg = self._aggregate(qs)
        if greedy:
            return int(np.argmax(q_agg))
        eps = self._eps.value(self._step_count)
        if self._rng.random() < eps:
            return int(self._rng.integers(self.n_actions))
        score = q_agg + self.beta_explore * np.std(qs, axis=0)
        return int(np.argmax(score))

    def observe(self, obs, action, reward, next_obs, terminated, truncated,
                info=None):
        self._step_count += 1
        if self._norm is not None:
            self._norm.update(obs)
        self.buffer.add(obs, action, reward, next_obs, terminated, truncated)

    def end_episode(self):
        self.buffer.end_episode()

    def reset_buffer(self):
        """Continual-learning ablation: drop ALL replay data, keep weights."""
        self.buffer = ReplayBuffer(capacity=self.buffer.capacity,
                                   n_step=self.n_step, gamma=self.gamma)

    def reset_state(self):
        pass

    def update(self):
        self._update_calls += 1
        if self._update_calls % self.update_every != 0:
            return {}
        if not self.buffer.is_ready(max(self.warmup, self.batch_size)):
            return {}
        b = self.buffer.sample(self.batch_size, self._rng)
        a_arr, r_arr, d_arr = b["actions"], b["rewards"], b["done"]
        s_mat = self._encode_batch(b["obs"])
        s2_mat = self._encode_batch(b["next_obs"])
        g_eff = self._gamma_eff(b)

        m = max(8, int(self.minibag_frac * self.batch_size))
        m = min(m, self.batch_size)
        losses, tds, qmeans = [], [], []
        for k in range(self.n_heads):
            sub = self._rng.choice(self.batch_size, size=m, replace=False)
            idx = np.arange(m)
            ak, rk, dk, gk = a_arr[sub], r_arr[sub], d_arr[sub], g_eff[sub]
            sk, s2k = s_mat[sub], s2_mat[sub]
            # S2 forward on the ONLINE net first (Double DQN selection) so
            # the head's last forward before backward() is the S minibag.
            q_tgt = self.target_nets[k].forward(s2k)
            if self.double:
                if self.use_prior:
                    a_star = np.argmax(
                        self.nets[k].forward(s2k)
                        + self.priors[k].forward(s2k), axis=1)
                else:
                    a_star = np.argmax(self.nets[k].forward(s2k), axis=1)
            q_all = self.nets[k].forward(sk)
            if self.use_prior:
                q_all = q_all + self.priors[k].forward(sk)
                q_tgt = q_tgt + self.priors[k].forward(s2k)
            q_sa = q_all[idx, ak]
            if self.double:
                next_val = q_tgt[idx, a_star]
            else:
                next_val = q_tgt.max(axis=1)
            y = rk + gk * (1.0 - dk) * next_val
            td = q_sa - y
            losses.append(float(np.mean(td * td)))
            tds.append(float(np.mean(np.abs(td))))
            qmeans.append(float(q_sa.mean()))
            grad = np.zeros_like(q_all)
            grad[idx, ak] = (2.0 / m) * td
            self.nets[k].backward(grad)
            self.nets[k].adam_step(self.lr, clip_norm=self.grad_clip)
        self._grad_steps += 1
        if self._grad_steps % self.target_sync == 0:
            for tgt, net in zip(self.target_nets, self.nets):
                tgt.copy_from(net)
        return {"loss": float(np.mean(losses)),
                "td_error_mean": float(np.mean(tds)),
                "q_mean": float(np.mean(qmeans))}

    # ------------------------------------------------------------------
    def q_diagnostics(self, obs):
        """Median and population std of head Q-values for one observation."""
        qs = self._head_q(obs)
        return {"q_median": np.median(qs, axis=0),
                "q_std": np.std(qs, axis=0)}

    # ------------------------------------------------------------------
    def _config(self):
        return {
            "cls": type(self).__name__, "name": self.name,
            "n_obs": self.n_obs, "obs_type": self.obs_type,
            "n_actions": self.n_actions, "n_heads": self.n_heads,
            "head_hidden": list(self.head_hidden), "lr": self.lr,
            "gamma": self.gamma, "buffer_size": self.buffer.capacity,
            "batch_size": self.batch_size, "target_sync": self.target_sync,
            "double": self.double, "n_step": self.n_step,
            "eps_start": self.eps_start, "eps_end": self.eps_end,
            "eps_decay": self.eps_decay, "beta_explore": self.beta_explore,
            "minibag_frac": self.minibag_frac,
            "aggregation": self.aggregation, "use_prior": self.use_prior,
            "update_every": self.update_every, "warmup": self.warmup,
            "grad_clip": self.grad_clip,
        }

    def save(self, path):
        payload = {}
        for k, net in enumerate(self.nets):
            for i, w in enumerate(net.get_weights()):
                payload["head%d_net_%d" % (k, i)] = w
        for k, net in enumerate(self.target_nets):
            for i, w in enumerate(net.get_weights()):
                payload["head%d_tgt_%d" % (k, i)] = w
        payload["config"] = np.array(json.dumps(self._config()))
        if self._norm is not None:
            st = self._norm.state()
            payload["norm_count"] = np.array(st["count"])
            payload["norm_mean"] = st["mean"]
            payload["norm_m2"] = st["m2"]
        np.savez(str(path), **payload)

    def load(self, path):
        p = str(path)
        if not os.path.exists(p) and os.path.exists(p + ".npz"):
            p = p + ".npz"
        with np.load(p, allow_pickle=False) as z:
            names = [k for k in z.files if k != "config"]

            def _order(prefix):
                return sorted((k for k in names if k.startswith(prefix)),
                              key=lambda s: (int(s.split("_")[0][4:]),
                                             int(s.split("_")[2])))

            for k, net in enumerate(self.nets):
                ws = [z[key] for key in _order("head%d_net_" % k)]
                net.set_weights(ws)
            for k, net in enumerate(self.target_nets):
                ws = [z[key] for key in _order("head%d_tgt_" % k)]
                net.set_weights(ws)
            if self._norm is not None and "norm_count" in z.files:
                self._norm.count = int(z["norm_count"])
                self._norm.mean = z["norm_mean"].copy()
                self._norm._m2 = z["norm_m2"].copy()
