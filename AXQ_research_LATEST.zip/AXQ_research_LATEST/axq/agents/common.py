"""Shared building blocks for axq.agents: replay buffer, eps schedule, encoders.

Locked RL semantics (project correctness rules):
* ``done`` stored in the buffer is ``terminated`` ONLY. A truncated
  (time-limit) episode still bootstraps from its final state.
* n-step chains: rows are ``(s_t, a_t, R_n, s_{t+n}, done_{t+n})`` with
  ``R_n = sum_{i<n} gamma^i * r_{t+i}``. Partial chains (length k < n) are
  flushed at episode end; each row carries its chain length in ``n_lens``
  so agents bootstrap with ``gamma ** k`` (identical to ``gamma ** n_step``
  for every full-length chain).
"""
from collections import deque

import numpy as np


def _pack(items):
    """List of stored obs -> batch array (int64 [B] or float64 [B, dim])."""
    if isinstance(items[0], (int, np.integer)):
        return np.asarray(items, dtype=np.int64)
    return np.asarray(items, dtype=np.float64)


def one_hot_batch(idx_array, n):
    """[B] int indices -> [B, n] float64 one-hot matrix."""
    idx = np.asarray(idx_array, dtype=np.int64).reshape(-1)
    out = np.zeros((idx.shape[0], int(n)), dtype=np.float64)
    out[np.arange(idx.shape[0]), idx] = 1.0
    return out


def encode_obs(obs, obs_type, n_obs):
    """Single observation -> [1, dim] float64 row (one-hot or raw vector)."""
    if obs_type == "discrete":
        return one_hot_batch([int(obs)], n_obs)
    return np.asarray(obs, dtype=np.float64).reshape(1, -1)


class ObsNormalizer:
    """Running mean/std observation normalizer (Welford), train-stream only.

    Updated ONLY from observe() calls (the training data stream); evaluation
    rollouts never mutate the statistics. transform() is deterministic given
    the accumulated stats. Used identically by DQN and AXQ for vector obs so
    that any performance difference is attributable to the architecture, not
    to input scaling.
    """

    def __init__(self, dim, eps=1e-6):
        self.dim = int(dim)
        self.eps = float(eps)
        self.count = 0
        self.mean = np.zeros(self.dim, dtype=np.float64)
        self._m2 = np.zeros(self.dim, dtype=np.float64)

    def update(self, x):
        x = np.asarray(x, dtype=np.float64).reshape(-1)
        self.count += 1
        delta = x - self.mean
        self.mean += delta / self.count
        self._m2 += delta * (x - self.mean)

    def transform(self, x):
        if self.count < 2:
            return np.asarray(x, dtype=np.float64)
        var = self._m2 / (self.count - 1)
        return (np.asarray(x, dtype=np.float64) - self.mean) / \
            np.sqrt(var + self.eps)

    def state(self):
        return {"count": self.count, "mean": self.mean.copy(),
                "m2": self._m2.copy()}


class EpsilonSchedule:
    """Linear decay from ``start`` to ``end`` over ``decay_steps`` steps."""

    def __init__(self, start=1.0, end=0.05, decay_steps=10000):
        self.start = float(start)
        self.end = float(end)
        self.decay_steps = int(decay_steps)
        if self.decay_steps < 1:
            raise ValueError("decay_steps must be >= 1")

    def value(self, step):
        s = max(0, int(step))
        if s >= self.decay_steps:
            return self.end
        return self.start + (self.end - self.start) * (s / self.decay_steps)


class ReplayBuffer:
    """FIFO replay buffer with n-step return aggregation.

    ``done`` is ``terminated`` only; ``truncated`` is accepted for API
    symmetry and never folded into ``done`` (time-limit bootstrapping).
    Storage is plain Python lists (ring buffer); conversion to numpy
    arrays happens lazily in :meth:`sample`, preserving obs dtype/shape
    (int64 scalars for discrete envs, float64 [dim] rows for vector envs).
    """

    def __init__(self, capacity=50000, n_step=1, gamma=0.99):
        self.capacity = int(capacity)
        self.n_step = int(n_step)
        self.gamma = float(gamma)
        if self.capacity < 1:
            raise ValueError("capacity must be >= 1")
        if self.n_step < 1:
            raise ValueError("n_step must be >= 1")
        self._obs = [None] * self.capacity
        self._act = [0] * self.capacity
        self._rew = [0.0] * self.capacity
        self._nxt = [None] * self.capacity
        self._done = [0.0] * self.capacity
        self._nlen = [1] * self.capacity
        self._n = 0          # number of valid rows
        self._w = 0          # next write slot
        self._pending = deque()   # transitions of the current n-step window

    # ------------------------------------------------------------------
    def _store(self, obs, action, reward, next_obs, done, n_len):
        i = self._w
        self._obs[i] = obs
        self._act[i] = int(action)
        self._rew[i] = float(reward)
        self._nxt[i] = next_obs
        self._done[i] = 1.0 if done else 0.0
        self._nlen[i] = int(n_len)
        self._w = (self._w + 1) % self.capacity
        if self._n < self.capacity:
            self._n += 1

    def add(self, obs, action, reward, next_obs, terminated, truncated):
        """Append one env transition. Chains never cross episode bounds."""
        term = bool(terminated)
        if self.n_step <= 1:
            self._store(obs, action, reward, next_obs, term, 1)
            return
        self._pending.append((obs, int(action), float(reward), next_obs, term))
        if term:
            # Emit every remaining chain (lengths 1..n), each ending at the
            # terminal transition -> done=True for all of them.
            self._flush_pending()
        elif len(self._pending) >= self.n_step:
            self._emit_head()

    def _emit_head(self):
        """Emit pending[0] as a full n-step chain; slide the window."""
        n = self.n_step
        chain = list(self._pending)[:n]
        r = 0.0
        for k, tr in enumerate(chain):
            r += (self.gamma ** k) * tr[2]
        first, last = chain[0], chain[-1]
        self._store(first[0], first[1], r, last[3], last[4], n)
        self._pending.popleft()

    def _flush_pending(self):
        """Emit ALL pending chains (each runs to the end of the deque).

        The final transition of every chain is the last pending entry, so
        ``done`` = that entry's ``terminated`` flag (True at termination,
        False at truncation -> the truncated rows bootstrap).
        """
        n = self.n_step
        length = len(self._pending)
        if length == 0:
            return
        last = self._pending[-1]
        for i in range(length):
            chain = list(self._pending)[i:i + n]   # capped at n; ends at deque end
            r = 0.0
            for k, tr in enumerate(chain):
                r += (self.gamma ** k) * tr[2]
            self._store(chain[0][0], chain[0][1], r, last[3], last[4],
                        len(chain))
        self._pending.clear()

    def end_episode(self):
        """Flush partial chains on truncation (done=False -> bootstrap)."""
        if self._pending:
            self._flush_pending()

    # ------------------------------------------------------------------
    def __len__(self):
        return self._n

    def is_ready(self, batch_size):
        return self._n >= int(batch_size)

    def sample(self, batch_size, rng):
        """Uniform sample (with replacement) -> dict of numpy arrays."""
        b = int(batch_size)
        if self._n == 0:
            raise ValueError("cannot sample from an empty buffer")
        idx = rng.integers(0, self._n, size=b)
        return {
            "obs": _pack([self._obs[k] for k in idx]),
            "actions": np.asarray([self._act[k] for k in idx], dtype=np.int64),
            "rewards": np.asarray([self._rew[k] for k in idx], dtype=np.float64),
            "next_obs": _pack([self._nxt[k] for k in idx]),
            "done": np.asarray([self._done[k] for k in idx], dtype=np.float64),
            "n_lens": np.asarray([self._nlen[k] for k in idx], dtype=np.int64),
        }

    def entries(self):
        """FIFO list of stored rows (obs, action, reward, next_obs, done,
        n_len). Read-only inspection helper for tests/debugging."""
        if self._n == 0:
            return []
        if self._n < self.capacity:
            order = range(self._n)
        else:
            order = [(self._w + i) % self.capacity for i in range(self.capacity)]
        return [(self._obs[i], self._act[i], self._rew[i], self._nxt[i],
                 bool(self._done[i]), self._nlen[i]) for i in order]
