"""Continual-learning DQN variants for cycle 3 (L8 flagship g1).

Agents
------
EWCDQN
    Elastic Weight Consolidation (Kirkpatrick et al. 2017) on top of DQN.
    After each task phase, ``consolidate()`` snapshots the weights
    (theta*) and estimates a diagonal Fisher information from the CURRENT
    replay buffer (per-sample squared gradients of Q(s, a_taken));
    subsequent updates add the penalty gradient
    ``lambda * F * (theta - theta*)`` (loss penalty
    ``lambda/2 * sum F (theta - theta*)^2``).
    Fisher is normalized by its mean magnitude so ``lambda`` is
    scale-free across architectures (documented practical choice;
    ``fisher_normalize=False`` gives raw EWC).
    One (Fisher, theta*) pair is kept PER FINISHED TASK (true multi-task
    EWC, not online-EWC single-slot approximation) - cheap for our nets.

MultiHeadDQN
    Task-incremental agent (task identity known at train AND eval time -
    the standard task-IL protocol, an explicitly easier setting than
    domain-IL; documented assumption): shared trunk MLP + one Q-head per
    task. Each head has its own replay slice, so heads stay task-pure;
    updates sample a task per call (``rehearsal_mix`` of updates go to
    the ACTIVE task, the rest are split over old tasks) so the trunk
    receives multi-task rehearsal.

Both subclass DQN, so eps schedule, normalizer, Double-Q semantics,
n-step chains and the buffer contract are inherited unchanged.
"""
import json
import os

import numpy as np

from .common import ReplayBuffer
from .dqn import DQN
from ..core.nn.mlp import MLP


# ===========================================================================
# EWC
# ===========================================================================
class EWCDQN(DQN):
    """DQN + per-task elastic weight consolidation."""

    name = "dqn_ewc"

    def __init__(self, *args, ewc_lambda=100.0, fisher_samples=10000,
                 fisher_normalize=True, **kw):
        super().__init__(*args, **kw)
        self.ewc_lambda = float(ewc_lambda)
        self.fisher_samples = int(fisher_samples)
        self.fisher_normalize = bool(fisher_normalize)
        self._fishers = []      # per task: arrays aligned with net.params()
        self._stars = []        # per task: weight snapshots (theta*)

    # ------------------------------------------------------------------
    def consolidate(self):
        """Snapshot theta* + diagonal Fisher from the CURRENT buffer.

        Call ONCE at the END of each task phase (after its eval, before
        switching tasks). With a persistent buffer the Fisher is estimated
        on the mixed buffer (all tasks seen so far) - a documented
        EWC-online-style variant; with a fresh buffer it is the pure
        single-task Fisher.
        """
        params = self.net.params()
        fisher = [np.zeros_like(p) for p in params]
        n = min(self.fisher_samples, len(self.buffer))
        if n > 0:
            for _ in range(n):
                b = self.buffer.sample(1, self._rng)
                s = self._encode_batch(b["obs"])
                q = self.net.forward(s)               # [1, A]
                g = np.zeros_like(q)
                g[0, int(b["actions"][0])] = 1.0      # d Q(s, a_taken)
                self.net.backward(g)
                for F, pg in zip(fisher, self.net.grads()):
                    F += pg * pg
            for F in fisher:
                F /= float(n)
            if self.fisher_normalize:
                mean_mag = float(np.mean(np.concatenate(
                    [f.ravel() for f in fisher])))
                if mean_mag > 0.0:
                    fisher = [f / mean_mag for f in fisher]
        self._fishers.append([F.copy() for F in fisher])
        self._stars.append(self.net.get_weights())

    def _apply_ewc_penalty(self):
        """Add lambda * F * (theta - theta*) to the current grads (in-place).

        Returns the penalty loss 0.5 * lambda * sum_t F_t (theta-theta*_t)^2
        (diagnostics only; Adam sees the gradient, not the loss).
        """
        if not self._fishers:
            return 0.0
        params = self.net.params()
        grads = self.net.grads()          # live references to L.dW / L.db
        acc = 0.0
        for fisher, star in zip(self._fishers, self._stars):
            for g, F, st, p in zip(grads, fisher, star, params):
                d = p - st
                g += self.ewc_lambda * F * d
                acc += float(np.sum(F * d * d))
        return 0.5 * self.ewc_lambda * acc

    # ------------------------------------------------------------------
    def update(self):
        """DQN.update with the EWC penalty injected between backward and
        adam_step. KEEP IN SYNC with DQN.update when that changes."""
        self._update_calls += 1
        if self._update_calls % self.update_every != 0:
            return {}
        if not self.buffer.is_ready(max(self.warmup, self.batch_size)):
            return {}
        b = self.buffer.sample(self.batch_size, self._rng)
        a_arr, r_arr, d_arr = b["actions"], b["rewards"], b["done"]
        s_mat = self._encode_batch(b["obs"])
        s2_mat = self._encode_batch(b["next_obs"])
        idx = np.arange(a_arr.shape[0])
        g_eff = self._gamma_eff(b)

        # Next-state values FIRST (see DQN.update: backward differentiates
        # the LAST forward call's graph, so the online net's S2 forward
        # must precede its S forward).
        q_tgt = self.target_net.forward(s2_mat)
        if self.double:
            a_star = np.argmax(self.net.forward(s2_mat), axis=1)
        q_all = self.net.forward(s_mat)
        q_sa = q_all[idx, a_arr]
        if self.double:
            next_val = q_tgt[idx, a_star]
        else:
            next_val = q_tgt.max(axis=1)
        y = r_arr + g_eff * (1.0 - d_arr) * next_val
        td = q_sa - y
        loss = float(np.mean(td * td))

        grad = np.zeros_like(q_all)
        grad[idx, a_arr] = (2.0 / a_arr.shape[0]) * td
        self.net.backward(grad)
        pen = self._apply_ewc_penalty()
        self.net.adam_step(self.lr, clip_norm=self.grad_clip)
        self._grad_steps += 1
        if self._grad_steps % self.target_sync == 0:
            self.target_net.copy_from(self.net)
        return {"loss": loss,
                "td_error_mean": float(np.mean(np.abs(td))),
                "q_mean": float(q_sa.mean()),
                "ewc_penalty": pen}

    # ------------------------------------------------------------------
    def _config(self):
        c = super()._config()
        c["ewc_lambda"] = self.ewc_lambda
        c["fisher_samples"] = self.fisher_samples
        c["fisher_normalize"] = self.fisher_normalize
        c["n_consolidated_tasks"] = len(self._fishers)
        return c

    # NOTE: EWC consolidation state (_fishers/_stars) is intentionally NOT
    # persisted: experiment runs are atomic; crash-resume granularity is
    # the per-phase JSONL produced by scripts/run_continual2.py.


# ===========================================================================
# Task-incremental multi-head DQN
# ===========================================================================
class MultiHeadDQN(DQN):
    """Shared trunk + per-task Q-heads (task-IL protocol).

    The trunk output passes through tanh BEFORE the heads (audit 9-b H2:
    a linear-linear composition would collapse the whole network to a
    single tanh layer vs two in the DQN arm), so trunk+head matches the
    DQN arm's depth: 2 tanh layers + linear head.

    ``rehearsal_mix``: fraction of update calls that train the ACTIVE
    task when it has data; the remaining calls are spread uniformly over
    the other tasks that have enough data (trunk rehearsal). With
    ``reset_buffer()`` at every phase this degrades to head-protection
    only (no trunk rehearsal).
    """

    name = "dqn_heads"

    def __init__(self, *args, rehearsal_mix=0.5, **kw):
        if float(kw.get("count_bonus", 0.0)) > 0:
            raise ValueError("count_bonus is not supported by MultiHeadDQN")
        super().__init__(*args, **kw)
        # rebuild networks as trunk-only (linear output of width hidden[-1])
        sizes = [self._input_dim()] + list(self.hidden)
        self.net = MLP(sizes, self._rng, activation="tanh")
        self.target_net = MLP(sizes, self._rng, activation="tanh")
        self.target_net.copy_from(self.net)
        self.task_id = 0
        self.rehearsal_mix = float(rehearsal_mix)
        self.heads = []            # per task: MLP([hidden[-1], n_actions])
        self.target_heads = []
        self.task_buffers = []     # per task: ReplayBuffer
        self._ensure_task(0)

    # ------------------------------------------------------------------
    def _ensure_task(self, k):
        while len(self.heads) <= int(k):
            top = self.hidden[-1]
            self.heads.append(MLP([top, self.n_actions], self._rng,
                                  activation="tanh"))
            self.target_heads.append(MLP([top, self.n_actions], self._rng,
                                         activation="tanh"))
            self.target_heads[-1].copy_from(self.heads[-1])
            self.task_buffers.append(ReplayBuffer(
                capacity=self.buffer.capacity, n_step=self.n_step,
                gamma=self.gamma))

    def set_task(self, k):
        """Route acting/observing/training to task k (grows on demand)."""
        self.task_id = int(k)
        self._ensure_task(k)

    # ------------------------------------------------------------------
    # AgentBase API
    def act(self, obs, greedy=False):
        x = self._encode_single(obs)
        h = np.tanh(self.net.forward(x))
        q = self.heads[self.task_id].forward(h)[0]
        if greedy:
            return int(np.argmax(q))
        eps = self._eps.value(self._step_count)
        if self._rng.random() < eps:
            return int(self._rng.integers(self.n_actions))
        return int(np.argmax(q))

    def observe(self, obs, action, reward, next_obs, terminated, truncated,
                info=None):
        self._step_count += 1
        if self._norm is not None:
            self._norm.update(obs)
        so, sno = self._transition(obs, action, reward, next_obs, terminated,
                                   truncated)
        self.task_buffers[self.task_id].add(so, action, reward, sno,
                                            terminated, truncated)

    def end_episode(self):
        for buf in self.task_buffers:
            buf.end_episode()

    def reset_buffer(self):
        """Fresh-buffer mode: drop ALL per-task replay data, keep weights
        (trunk + heads). Isolates head-protection from trunk rehearsal."""
        self.task_buffers = [ReplayBuffer(capacity=self.buffer.capacity,
                                          n_step=self.n_step,
                                          gamma=self.gamma)
                             for _ in self.task_buffers]

    def reset_state(self):
        pass

    # ------------------------------------------------------------------
    def _pick_task(self, ready):
        k = self.task_id
        if len(ready) == 1:
            return ready[0]
        if k in ready and self._rng.random() < self.rehearsal_mix:
            return k
        others = [t for t in ready if t != k] or ready
        return int(self._rng.choice(others))

    def update(self):
        self._update_calls += 1
        if self._update_calls % self.update_every != 0:
            return {}
        need = max(self.warmup, self.batch_size)
        ready = [t for t, buf in enumerate(self.task_buffers)
                 if buf.is_ready(need)]
        if not ready:
            return {}
        t = self._pick_task(ready)
        b = self.task_buffers[t].sample(self.batch_size, self._rng)
        a_arr, r_arr, d_arr = b["actions"], b["rewards"], b["done"]
        s_mat = self._encode_batch(b["obs"])
        s2_mat = self._encode_batch(b["next_obs"])
        idx = np.arange(a_arr.shape[0])
        g_eff = self._gamma_eff(b)

        # Trunk output passes through tanh BEFORE the heads (audit 9-b H2:
        # linear-linear composition would collapse the network to one
        # tanh layer vs two in the DQN arm).
        # Target values: target trunk + target head_t (no backward through).
        h2_tgt = np.tanh(self.target_net.forward(s2_mat))
        q_tgt = self.target_heads[t].forward(h2_tgt)
        if self.double:
            h2_on = np.tanh(self.net.forward(s2_mat))
            a_star = np.argmax(self.heads[t].forward(h2_on), axis=1)
        # Online graph order (see DQN.update): the trunk's LAST forward must
        # be on s, the head's LAST forward must be on h(s) = tanh(z(s)).
        z_s = self.net.forward(s_mat)
        h_s = np.tanh(z_s)
        q_all = self.heads[t].forward(h_s)
        q_sa = q_all[idx, a_arr]
        if self.double:
            next_val = q_tgt[idx, a_star]
        else:
            next_val = q_tgt.max(axis=1)
        y = r_arr + g_eff * (1.0 - d_arr) * next_val
        td = q_sa - y
        loss = float(np.mean(td * td))

        grad = np.zeros_like(q_all)
        grad[idx, a_arr] = (2.0 / a_arr.shape[0]) * td
        g_h = self.heads[t].backward(grad)     # head graph: h(s)    ✓
        # through the trunk's tanh: dL/dz = dL/dh * (1 - h^2)
        self.net.backward(g_h * (1.0 - h_s * h_s))   # trunk graph: s ✓
        self.heads[t].adam_step(self.lr, clip_norm=self.grad_clip)
        self.net.adam_step(self.lr, clip_norm=self.grad_clip)
        self._grad_steps += 1
        if self._grad_steps % self.target_sync == 0:
            self.target_net.copy_from(self.net)
            for hd, th in zip(self.heads, self.target_heads):
                th.copy_from(hd)
        return {"loss": loss,
                "td_error_mean": float(np.mean(np.abs(td))),
                "q_mean": float(q_sa.mean()),
                "task": t}

    # ------------------------------------------------------------------
    def _config(self):
        c = super()._config()
        c["trunk"] = list(self.hidden)
        c["rehearsal_mix"] = self.rehearsal_mix
        c["n_tasks"] = len(self.heads)
        return c

    def save(self, path):
        payload = {}
        for i, w in enumerate(self.net.get_weights()):
            payload["net_%d" % i] = w
        for i, w in enumerate(self.target_net.get_weights()):
            payload["target_%d" % i] = w
        for k, (hd, th) in enumerate(zip(self.heads, self.target_heads)):
            for i, w in enumerate(hd.get_weights()):
                payload["head%d_%d" % (k, i)] = w
            for i, w in enumerate(th.get_weights()):
                payload["thead%d_%d" % (k, i)] = w
        payload["config"] = np.array(json.dumps(self._config()))
        np.savez(str(path), **payload)

    def load(self, path):
        p = str(path)
        if not os.path.exists(p) and os.path.exists(p + ".npz"):
            p = p + ".npz"
        with np.load(p, allow_pickle=False) as z:
            kmax = -1
            for k in z.files:
                if k.startswith("head") and "_" in k:
                    kmax = max(kmax, int(k[4:].split("_")[0]))
            for t in range(kmax + 1):
                self._ensure_task(t)
            net_names = sorted((k for k in z.files if k.startswith("net_")),
                               key=lambda s: int(s.split("_")[1]))
            tgt_names = sorted(
                (k for k in z.files if k.startswith("target_")),
                key=lambda s: int(s.split("_")[1]))
            self.net.set_weights([z[k] for k in net_names])
            self.target_net.set_weights([z[k] for k in tgt_names])
            for t in range(kmax + 1):
                hn = sorted((k for k in z.files
                             if k.startswith("head%d_" % t)),
                            key=lambda s: int(s.split("_")[1]))
                tn = sorted((k for k in z.files
                             if k.startswith("thead%d_" % t)),
                            key=lambda s: int(s.split("_")[1]))
                self.heads[t].set_weights([z[k] for k in hn])
                self.target_heads[t].set_weights([z[k] for k in tn])
