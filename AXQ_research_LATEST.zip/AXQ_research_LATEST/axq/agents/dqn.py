"""Double DQN agent (van Hasselt et al. 2015) with n-step returns.

Locked RL semantics:
* Bootstrap uses ``terminated`` only; truncated episodes bootstrap from
  their final state (the buffer stores done = terminated).
* Each replay row carries its chain length; the effective bootstrap
  discount is ``gamma ** n_lens`` per sample (== gamma ** n_step for all
  full-length chains).
"""
import json
import os

import numpy as np

from ..core.agent import AgentBase
from ..core.nn.mlp import MLP
from .common import (EpsilonSchedule, ObsNormalizer, ReplayBuffer,
                     encode_obs, one_hot_batch)


class DQN(AgentBase):
    """Epsilon-greedy Double DQN: online net + periodic-copied target net."""

    name = "dqn"

    def __init__(self, n_obs, obs_type, n_actions, hidden=(64, 64), lr=1e-3,
                 gamma=0.99, buffer_size=50000, batch_size=64,
                 target_sync=1000, double=True, n_step=1, eps_start=1.0,
                 eps_end=0.05, eps_decay=10000, update_every=1, warmup=1000,
                 grad_clip=10.0, seed=0, count_bonus=0.0):
        self.n_obs = int(n_obs)
        self.obs_type = str(obs_type)
        self.n_actions = int(n_actions)
        if self.obs_type not in ("discrete", "vector"):
            raise ValueError("obs_type must be 'discrete' or 'vector', got %r"
                             % (self.obs_type,))
        if self.n_obs < 1 or self.n_actions < 1:
            raise ValueError("n_obs and n_actions must be >= 1")
        if int(n_step) < 1:
            raise ValueError("n_step must be >= 1")
        self.hidden = tuple(int(h) for h in hidden)
        self.lr = float(lr)
        self.gamma = float(gamma)
        self.batch_size = int(batch_size)
        self.target_sync = int(target_sync)
        self.double = bool(double)
        self.n_step = int(n_step)
        self.eps_start = float(eps_start)
        self.eps_end = float(eps_end)
        self.eps_decay = int(eps_decay)
        self.update_every = int(update_every)
        self.warmup = int(warmup)
        self.grad_clip = float(grad_clip)
        self.count_bonus = float(count_bonus)
        if self.count_bonus > 0 and self.obs_type != "discrete":
            raise ValueError("count_bonus requires discrete obs (exact counts)")
        self._counts = np.zeros((self.n_obs, self.n_actions)) \
            if self.count_bonus > 0 else None
        self._rng = np.random.default_rng(seed)
        self._eps = EpsilonSchedule(self.eps_start, self.eps_end, self.eps_decay)
        self.buffer = ReplayBuffer(capacity=buffer_size, n_step=self.n_step,
                                   gamma=self.gamma)
        # Running obs normalization for vector envs (identical mechanism in
        # AXQ; updated from the TRAIN stream only, frozen during eval).
        self._norm = ObsNormalizer(self.n_obs) \
            if self.obs_type == "vector" else None
        sizes = [self._input_dim()] + list(self.hidden) + [self.n_actions]
        self.net = MLP(sizes, self._rng, activation="tanh")
        self.target_net = MLP(sizes, self._rng, activation="tanh")
        self.target_net.copy_from(self.net)
        self._step_count = 0     # env transitions observed (drives eps schedule)
        self._update_calls = 0
        self._grad_steps = 0

    # ------------------------------------------------------------------
    # overridable hooks (see HistoryDQN)
    def _input_dim(self):
        # one-hot discrete dim == n_obs; vector obs dim == n_obs as well.
        return self.n_obs

    def _encode_single(self, obs):
        x = encode_obs(obs, self.obs_type, self.n_obs)
        if self._norm is not None:
            x = self._norm.transform(x)
        return x

    def _encode_batch(self, obs_batch):
        if self.obs_type == "discrete":
            return one_hot_batch(obs_batch, self.n_obs)
        x = np.asarray(obs_batch, dtype=np.float64)
        if self._norm is not None:
            x = self._norm.transform(x)
        return x

    def _transition(self, obs, action, reward, next_obs, terminated, truncated):
        """(obs, next_obs) pair to store for this step (override to stack)."""
        return obs, next_obs

    def _gamma_eff(self, batch):
        """Per-sample bootstrap discount gamma ** chain_length."""
        n_lens = batch.get("n_lens") if isinstance(batch, dict) else None
        if n_lens is None:
            n_lens = np.full(len(batch["actions"]), self.n_step, dtype=np.int64)
        return self.gamma ** np.asarray(n_lens, dtype=np.int64)

    def _config(self):
        return {
            "cls": type(self).__name__, "name": self.name,
            "n_obs": self.n_obs, "obs_type": self.obs_type,
            "n_actions": self.n_actions, "hidden": list(self.hidden),
            "lr": self.lr, "gamma": self.gamma,
            "buffer_size": self.buffer.capacity,
            "batch_size": self.batch_size, "target_sync": self.target_sync,
            "double": self.double, "n_step": self.n_step,
            "eps_start": self.eps_start, "eps_end": self.eps_end,
            "eps_decay": self.eps_decay, "update_every": self.update_every,
            "warmup": self.warmup, "grad_clip": self.grad_clip,
            "count_bonus": self.count_bonus,
        }

    # ------------------------------------------------------------------
    # AgentBase API
    def act(self, obs, greedy=False):
        q = self.net.forward(self._encode_single(obs))[0]
        if greedy:
            return int(np.argmax(q))
        eps = self._eps.value(self._step_count)
        if self._rng.random() < eps:
            return int(self._rng.integers(self.n_actions))
        if self._counts is not None:
            # MBIE-style exploration bonus (Strehl & Littman 2008):
            # bonus ~ 1/sqrt(N(s,a)) on EXACT (s,a) counts, discrete obs only.
            q = q + self.count_bonus / np.sqrt(1.0 + self._counts[int(obs)])
        return int(np.argmax(q))

    def observe(self, obs, action, reward, next_obs, terminated, truncated,
                info=None):
        self._step_count += 1
        if self._norm is not None:
            self._norm.update(obs)
        so, sno = self._transition(obs, action, reward, next_obs, terminated,
                                   truncated)
        self.buffer.add(so, action, reward, sno, terminated, truncated)
        if self._counts is not None:
            self._counts[int(obs), int(action)] += 1

    def end_episode(self):
        self.buffer.end_episode()   # flush partial n-step chains on truncation

    def reset_buffer(self):
        """Continual-learning ablation: drop ALL replay data, keep weights.
        (Fresh-buffer mode isolates the effect of rehearsal.)"""
        self.buffer = ReplayBuffer(capacity=self.buffer.capacity,
                                   n_step=self.n_step, gamma=self.gamma)

    def reset_state(self):
        pass   # value function and buffer persist across episodes

    def update(self):
        self._update_calls += 1
        if self._update_calls % self.update_every != 0:
            return {}
        if not self.buffer.is_ready(max(self.warmup, self.batch_size)):
            return {}
        b = self.buffer.sample(self.batch_size, self._rng)
        a_arr, r_arr, d_arr = b["actions"], b["rewards"], b["done"]
        s_mat = self._encode_batch(b["obs"])
        s2_mat = self._encode_batch(b["next_obs"])
        idx = np.arange(a_arr.shape[0])
        g_eff = self._gamma_eff(b)

        # Next-state values FIRST: the online net's S2 forward (Double DQN
        # action selection) must precede the main S forward, because
        # MLP.backward differentiates the LAST forward call's graph.
        q_tgt = self.target_net.forward(s2_mat)
        if self.double:
            a_star = np.argmax(self.net.forward(s2_mat), axis=1)
        q_all = self.net.forward(s_mat)
        q_sa = q_all[idx, a_arr]
        if self.double:
            next_val = q_tgt[idx, a_star]
        else:
            next_val = q_tgt.max(axis=1)
        y = r_arr + g_eff * (1.0 - d_arr) * next_val
        td = q_sa - y
        loss = float(np.mean(td * td))

        grad = np.zeros_like(q_all)
        grad[idx, a_arr] = (2.0 / a_arr.shape[0]) * td
        self.net.backward(grad)
        self.net.adam_step(self.lr, clip_norm=self.grad_clip)
        self._grad_steps += 1
        if self._grad_steps % self.target_sync == 0:
            self.target_net.copy_from(self.net)
        return {"loss": loss,
                "td_error_mean": float(np.mean(np.abs(td))),
                "q_mean": float(q_sa.mean())}

    # ------------------------------------------------------------------
    # persistence (weights + config only; the buffer is never saved)
    def save(self, path):
        payload = {}
        for i, w in enumerate(self.net.get_weights()):
            payload["net_%d" % i] = w
        for i, w in enumerate(self.target_net.get_weights()):
            payload["target_%d" % i] = w
        payload["config"] = np.array(json.dumps(self._config()))
        if self._norm is not None:
            st = self._norm.state()
            payload["norm_count"] = np.array(st["count"])
            payload["norm_mean"] = st["mean"]
            payload["norm_m2"] = st["m2"]
        np.savez(str(path), **payload)

    def load(self, path):
        p = str(path)
        if not os.path.exists(p) and os.path.exists(p + ".npz"):
            p = p + ".npz"
        with np.load(p, allow_pickle=False) as z:
            names = [k for k in z.files if k != "config"]
            net_names = sorted((k for k in names if k.startswith("net_")),
                               key=lambda s: int(s.split("_")[1]))
            tgt_names = sorted((k for k in names if k.startswith("target_")),
                               key=lambda s: int(s.split("_")[1]))
            self.net.set_weights([z[k] for k in net_names])
            self.target_net.set_weights([z[k] for k in tgt_names])
            if self._norm is not None and "norm_count" in z.files:
                self._norm.count = int(z["norm_count"])
                self._norm.mean = z["norm_mean"].copy()
                self._norm._m2 = z["norm_m2"].copy()
