"""Dyna-Q agent: tabular Q-learning + model-based planning sweeps (H20).

Design (preregistered, PREREG_CYCLE4.md#H20):
* Deterministic transition model T[s,a] = (s', r, terminated) — exact after
  one visit in deterministic envs; in stochastic envs (e.g. slip) the stored
  LAST outcome is an approximation (registered limitation, interesting
  sensitivity axis).
* Per real step: ``k`` planning sweeps over UNIFORMLY sampled seen (s,a)
  pairs (classic Dyna-Q, Sutton 1991; no prioritization — honest simple
  version).
* Planning TD updates touch Q ONLY: they never advance the eps schedule
  (``_step_count``), never touch ``visits`` (count-bonus integrity), never
  touch the model. Real steps behave exactly like TabularQ (inherited).
* Same eps schedule / optimistic init / count bonus options as TabularQ =>
  paired comparability with all tabular arms.
"""
import numpy as np

from .tabular import TabularQ


class DynaQ(TabularQ):
    """TabularQ + k model-based planning sweeps per real environment step."""

    name = "dyna"

    def __init__(self, *args, k_plan=20, **kwargs):
        super().__init__(*args, **kwargs)
        self.k_plan = int(k_plan)
        self._model = {}          # (s, a) -> (s2, r, term)
        self._keys = []
        self._keys_set = set()
        # planning RNG: FIXED seed, independent of the exploration stream
        # (planning must not perturb action randomness; full reproducibility)
        self._plan_rng = np.random.default_rng(12345)

    def observe(self, obs, action, reward, next_obs, terminated, truncated,
                info=None):
        s, a = int(obs), int(action)
        # model update (deterministic env => exact; stochastic => last outcome)
        if (s, a) not in self._keys_set:
            self._keys.append((s, a))
            self._keys_set.add((s, a))
        self._model[(s, a)] = (int(next_obs), float(reward),
                               bool(terminated))
        super().observe(obs, action, reward, next_obs, terminated, truncated,
                        info)

    def _td_update(self, s, a, r, s2, term):
        """The TabularQ update rule, isolated (no visits/step_count side
        effects) — used for planning sweeps. Mirrors observe() exactly."""
        boot = 0.0 if term else self.gamma
        target = r + boot * float(self.Q[s2].max())
        self.Q[s, a] += self.alpha * (target - self.Q[s, a])

    def update(self):
        if self._keys and self.k_plan > 0:
            n = len(self._keys)
            idx = self._plan_rng.integers(0, n, size=self.k_plan)
            for i in idx:
                s, a = self._keys[i]
                s2, r, term = self._model[(s, a)]
                self._td_update(s, a, r, s2, term)
        return {"td_error": abs(self._last_td)}
