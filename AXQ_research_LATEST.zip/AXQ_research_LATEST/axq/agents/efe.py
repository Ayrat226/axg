"""Active-Inference-style agent: expected free energy action selection (H21).

Honest framing (preregistered): in tabular MDPs with an uncertainty-driven
epistemic term, 1-step expected free energy scoring reduces EXACTLY to
Q-learning + count-based exploration bonus with a fixed coefficient:

    -G(s, a) = Q(s, a) + tau_e / sqrt(1 + N(s, a))        [+ eps-noise]

The unit test (test_new_agents.py::test_efe_reduction) proves the reduction
against TabularQ(count_bonus=tau_e) on a random-MDP battery. What Active
Inference contributes here is NOT performance but PARAMETER STRUCTURE: the
epistemic term auto-anneals as counts grow, so ONE parameter (tau_e) replaces
the three-parameter eps schedule (start, end, decay). The agent has NO eps
parameter and takes NO uniformly random actions; exploration is directed
toward uncounted state-actions (greedy uncertainty), including during
evaluation (there is no exploit-only mode in active inference; the bonus
vanishes on well-counted pairs, so converged behavior equals greedy).

H21 primary endpoint: performance VARIANCE across tau_e grid vs eps-family
variance across (eps_end, eps_decay) grid — the claimed advantage is
robustness, not superiority.
"""
import numpy as np

from .tabular import TabularQ


class EFEAgent(TabularQ):
    """TabularQ TD updates + expected-free-energy action scoring (no eps)."""

    name = "efe"

    def __init__(self, *args, tau_e=0.5, **kwargs):
        # eps parameters are ACCEPTED for API compatibility but IGNORED
        # (registered: no uniform-random exploration in this agent).
        super().__init__(*args, **kwargs)
        self.tau_e = float(tau_e)

    def act(self, obs, greedy=False):
        s = int(obs)
        # epistemic term: auto-annealing count bonus; identical in train and
        # eval modes (active inference has no exploit-only mode; the bonus
        # vanishes as N(s,a) grows)
        bonus = self.tau_e / np.sqrt(1.0 + self.visits[s])
        return int(np.argmax(self.Q[s] + bonus))
