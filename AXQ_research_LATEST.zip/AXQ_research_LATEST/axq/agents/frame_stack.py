"""Frame-stacking DQN for POMDPs with discrete observations."""
from collections import deque

import numpy as np

from .common import one_hot_batch
from .dqn import DQN


class HistoryDQN(DQN):
    """DQN over a sliding window of the last ``history_len`` observations.

    Net input = concat of one-hots, OLDEST first: dim = history_len * n_obs.
    At the first ``act`` after ``reset_state`` the whole window is filled
    with the current observation (standard burn-in convention). The replay
    buffer stores ready-made stacked rows ``(H_t, H_{t+1})`` built from the
    agent's window, so sampled batches need no further encoding.
    """

    name = "history_dqn"

    def __init__(self, n_obs, obs_type, n_actions, history_len=8,
                 **dqn_kwargs):
        if obs_type != "discrete":
            raise ValueError("HistoryDQN requires obs_type == 'discrete', "
                             "got %r" % (obs_type,))
        if int(history_len) < 1:
            raise ValueError("history_len must be >= 1")
        self.history_len = int(history_len)
        super().__init__(n_obs, obs_type, n_actions, **dqn_kwargs)
        self._history = deque()
        self._fresh = True

    # ------------------------------------------------------------------
    # DQN hooks
    def _input_dim(self):
        return self.history_len * self.n_obs

    def _stack_input(self, seq):
        """Sequence of obs (oldest first) -> [1, history_len * n_obs]."""
        oh = one_hot_batch(np.asarray(seq, dtype=np.int64), self.n_obs)
        return oh.reshape(1, -1)

    def _encode_single(self, obs):
        o = int(obs)
        if self._fresh or not self._history:
            # first act after reset: fill the entire window with obs
            self._history.extend([o] * self.history_len)
            self._fresh = False
        else:
            self._history.append(o)
            while len(self._history) > self.history_len:
                self._history.popleft()
        return self._stack_input(self._history)

    def _encode_batch(self, obs_batch):
        # Buffer stores ready-made stacked rows [B, history_len * n_obs].
        return np.asarray(obs_batch, dtype=np.float64)

    def _transition(self, obs, action, reward, next_obs, terminated, truncated):
        # self._history currently holds H_t (the window used by the act()
        # that chose this action); H_{t+1} = window shifted by one + next obs.
        hist = list(self._history)
        if not hist:                      # defensive: observe before any act
            hist = [int(obs)] * self.history_len
        while len(hist) < self.history_len:
            hist.insert(0, hist[0])
        h_next = hist[1:] + [int(next_obs)]
        return self._stack_input(hist)[0], self._stack_input(h_next)[0]

    def reset_state(self):
        self._history.clear()
        self._fresh = True

    def _config(self):
        cfg = super()._config()
        cfg["history_len"] = self.history_len
        return cfg
