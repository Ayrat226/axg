"""GRU-DQN: recurrent DQN with episode replay and exact full-sequence BPTT.

Design (scoped for short episodes, 2..~110 steps — our memory tasks):
* Episode replay: whole episodes are stored; training replays the FULL
  episode from h0 = 0. This eliminates R2D2's recurrent-state staleness
  problem entirely (hidden states are recomputed exactly, not restored),
  and gives exact gradients through time for the whole episode.
* Architecture: obs encoding x_t -> GRU(H) -> g_t -> Linear head -> Q row.
* Double DQN within the sequence: selection from the online forward at
  t+1, evaluation from the target-net forward at t+1.
* One gradient step per `update_every` env steps; target sync every
  `target_sync` gradient steps.
* Gradient correctness is verified by finite-difference checks over the
  full sequence loss (tests/test_gru.py) — the strongest available check.
"""
import json
import os

import numpy as np

from ..core.agent import AgentBase
from .common import EpsilonSchedule, one_hot_batch


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


class AdamOptimizer:
    """Adam over an explicit list of (param, grad) array pairs."""

    def __init__(self, params, lr=1e-3, b1=0.9, b2=0.999, eps=1e-8):
        self.params = params
        self.lr = float(lr)
        self.b1, self.b2, self.eps = b1, b2, eps
        self.m = [np.zeros_like(p) for p in params]
        self.v = [np.zeros_like(p) for p in params]
        self.t = 0

    def step(self, grads, clip_norm=None):
        if clip_norm is not None:
            total = np.sqrt(sum(float(np.sum(g * g)) for g in grads))
            if total > clip_norm and total > 0:
                s = clip_norm / total
                grads = [g * s for g in grads]
        self.t += 1
        bc1 = 1.0 - self.b1 ** self.t
        bc2 = 1.0 - self.b2 ** self.t
        for p, g, m, v in zip(self.params, grads, self.m, self.v):
            m *= self.b1
            m += (1 - self.b1) * g
            v *= self.b2
            v += (1 - self.b2) * (g * g)
            p -= self.lr * (m / bc1) / (np.sqrt(v / bc2) + self.eps)


class GRUWeights:
    """Parameter container + exact forward/backward through time.

    Conventions: x_t [B, D], h_t [B, H].
      r_t = sig(x Wr + h Ur + br)
      z_t = sig(x Wz + h Uz + bz)
      n_t = tanh(x Wn + (r*h) Un + bn)
      h_{t+1} = (1-z) n + z h
    Q head: q_t = g_t @ Wq + bq   (applied to h_{t+1})
    """

    def __init__(self, n_in, n_hidden, n_out, rng, scale=0.1):
        H, D = n_hidden, n_in
        s = lambda a, b: np.sqrt(2.0 / (a + b))
        self.Wr, self.Ur, self.br = rng.normal(0, s(D, H), (D, H)), \
            rng.normal(0, s(H, H), (H, H)), np.zeros(H)
        self.Wz, self.Uz, self.bz = rng.normal(0, s(D, H), (D, H)), \
            rng.normal(0, s(H, H), (H, H)), np.zeros(H)
        self.Wn, self.Un, self.bn = rng.normal(0, s(D, H), (D, H)), \
            rng.normal(0, s(H, H), (H, H)), np.zeros(H)
        self.Wq, self.bq = rng.normal(0, s(H, n_out), (H, n_out)), \
            np.zeros(n_out)
        self.H = H

    def params(self):
        return [self.Wr, self.Ur, self.br, self.Wz, self.Uz, self.bz,
                self.Wn, self.Un, self.bn, self.Wq, self.bq]

    def forward_seq(self, xs, h0=None):
        """xs: [T, B, D] -> qs [T, B, A], hs [T+1, B, H] (hs[0]=h0), caches."""
        T, B, D = xs.shape
        H = self.H
        if h0 is None:
            h0 = np.zeros((B, H))
        hs = [h0]
        rs, zs, ns, xs_l, hs_in = [], [], [], [], []
        qs = np.zeros((T, B, self.Wq.shape[1]))
        h = h0
        for t in range(T):
            x = xs[t]
            ar = x @ self.Wr + h @ self.Ur + self.br
            az = x @ self.Wz + h @ self.Uz + self.bz
            r = _sigmoid(ar)
            z = _sigmoid(az)
            an = x @ self.Wn + (r * h) @ self.Un + self.bn
            n = np.tanh(an)
            h_new = (1 - z) * n + z * h
            q = h_new @ self.Wq + self.bq
            qs[t] = q
            rs.append(r); zs.append(z); ns.append(n)
            xs_l.append(x); hs_in.append(h)
            h = h_new
            hs.append(h)
        cache = {"rs": rs, "zs": zs, "ns": ns, "xs": xs_l, "hs_in": hs_in,
                 "hs_out": hs}
        return qs, hs, cache

    def backward_seq(self, dqs, cache):
        """dqs: [T, B, A] grads wrt Q at each step (h0 grad not returned).
        Returns grads in params() order. Exact BPTT through the whole seq."""
        T = len(dqs)
        B = dqs[0].shape[0]
        H = self.H
        gWq = np.zeros_like(self.Wq)
        gbq = np.zeros_like(self.bq)
        gWr = np.zeros_like(self.Wr)
        gUr = np.zeros_like(self.Ur)
        gbr = np.zeros_like(self.br)
        gWz = np.zeros_like(self.Wz)
        gUz = np.zeros_like(self.Uz)
        gbz = np.zeros_like(self.bz)
        gWn = np.zeros_like(self.Wn)
        gUn = np.zeros_like(self.Un)
        gbn = np.zeros_like(self.bn)
        dh_next = np.zeros((B, H))
        for t in range(T - 1, -1, -1):
            q_grad = dqs[t]
            h_out = cache["hs_out"][t + 1]
            gWq += h_out.T @ q_grad
            gbq += q_grad.sum(axis=0)
            dh = q_grad @ self.Wq.T + dh_next
            h_in = cache["hs_in"][t]
            z = cache["zs"][t]
            r = cache["rs"][t]
            n = cache["ns"][t]
            x = cache["xs"][t]
            # h_new = (1-z)*n + z*h_in
            dz = dh * (h_in - n)
            dn = dh * (1 - z)
            dh_in_direct = dh * z
            # n = tanh(an): dn/dan = 1 - n^2
            dan = dn * (1 - n * n)
            gWn += x.T @ dan
            gUn += (r * h_in).T @ dan
            gbn += dan.sum(axis=0)
            dr = (dan @ self.Un.T) * h_in
            # z = sig(az), r = sig(ar)
            daz = dz * z * (1 - z)
            dar = dr * r * (1 - r)
            gWz += x.T @ daz
            gUz += h_in.T @ daz
            gbz += daz.sum(axis=0)
            gWr += x.T @ dar
            gUr += h_in.T @ dar
            gbr += dar.sum(axis=0)
            dh_next = dh_in_direct + (dar @ self.Ur.T) + \
                (daz @ self.Uz.T) + ((dan @ self.Un.T) * r)
        return [gWr, gUr, gbr, gWz, gUz, gbz, gWn, gUn, gbn, gWq, gbq]

    def copy_from(self, other):
        for a, b in zip(self.params(), other.params()):
            a[...] = b


class EpisodeBuffer:
    """Stores whole episodes of (obs, action, reward, next_obs, terminated).

    Capacity is in transitions. Sampling returns full episodes.
    """

    def __init__(self, capacity=100000):
        self.capacity = int(capacity)
        self.episodes = []
        self._n = 0
        self._cur = []

    def start_episode(self):
        self._cur = []

    def add(self, obs, action, reward, next_obs, terminated):
        self._cur.append((obs, int(action), float(reward), next_obs,
                          bool(terminated)))

    def end_episode(self):
        if not self._cur:
            return
        self.episodes.append(self._cur)
        self._n += len(self._cur)
        while self._n > self.capacity and len(self.episodes) > 1:
            dropped = self.episodes.pop(0)
            self._n -= len(dropped)

    def __len__(self):
        return self._n

    def n_episodes(self):
        return len(self.episodes)

    def sample(self, batch, rng):
        idx = rng.integers(0, len(self.episodes), size=batch)
        return [self.episodes[i] for i in idx]


class GRUDQN(AgentBase):
    """Recurrent DQN (episode replay, full-episode BPTT)."""

    name = "gru_dqn"

    def __init__(self, n_obs, obs_type, n_actions, hidden=64, lr=1e-3,
                 gamma=0.99, buffer_size=100000, batch_size=8,
                 target_sync=500, eps_start=1.0, eps_end=0.05,
                 eps_decay=10000, update_every=2, warmup=2000,
                 grad_clip=10.0, seed=0):
        self.n_obs = int(n_obs)
        self.obs_type = str(obs_type)
        self.n_actions = int(n_actions)
        if self.obs_type != "discrete":
            raise ValueError("GRUDQN currently supports discrete obs only "
                             "(one-hot encoding); got %r" % (self.obs_type,))
        self.hidden = int(hidden)
        self.lr = float(lr)
        self.gamma = float(gamma)
        self.batch_size = int(batch_size)
        self.target_sync = int(target_sync)
        self.eps_start = float(eps_start)
        self.eps_end = float(eps_end)
        self.eps_decay = int(eps_decay)
        self.update_every = int(update_every)
        self.warmup = int(warmup)
        self.grad_clip = float(grad_clip)
        self._rng = np.random.default_rng(seed)
        self._eps = EpsilonSchedule(self.eps_start, self.eps_end, self.eps_decay)
        self.net = GRUWeights(self.n_obs, self.hidden, self.n_actions,
                              self._rng)
        self.target_net = GRUWeights(self.n_obs, self.hidden, self.n_actions,
                                     self._rng)
        self.target_net.copy_from(self.net)
        self.opt = AdamOptimizer(self.net.params(), lr=self.lr)
        self.buffer = EpisodeBuffer(capacity=buffer_size)
        self._h = None
        self._step_count = 0
        self._update_calls = 0
        self._grad_steps = 0

    # ------------------------------------------------------------------
    def _encode(self, obs):
        return one_hot_batch([int(obs)], self.n_obs)[0]     # [1, D]

    def reset_state(self):
        self._h = None
        self.buffer.start_episode()   # episode boundary: new transition list

    def act(self, obs, greedy=False):
        x = one_hot_batch([int(obs)], self.n_obs)         # [1, D]
        h0 = self._h if self._h is not None else np.zeros((1, self.hidden))
        qs, hs, _ = self.net.forward_seq(x[None, :, :], h0=h0)  # [1,1,D]
        self._h = hs[-1]
        if not greedy:
            eps = self._eps.value(self._step_count)
            if self._rng.random() < eps:
                return int(self._rng.integers(self.n_actions))
        return int(np.argmax(qs[-1, 0]))

    def observe(self, obs, action, reward, next_obs, terminated, truncated,
                info=None):
        self._step_count += 1
        self.buffer.add(obs, action, reward, next_obs, terminated)

    def end_episode(self):
        self.buffer.end_episode()

    def reset_buffer(self):
        self.buffer = EpisodeBuffer(capacity=self.buffer.capacity)

    # ------------------------------------------------------------------
    def _episode_tensors(self, ep):
        T = len(ep)
        xs = np.zeros((T, 1, self.n_obs))
        acts = np.zeros(T, dtype=np.int64)
        rews = np.zeros(T)
        dones = np.zeros(T)
        for t, (o, a, r, o2, term) in enumerate(ep):
            xs[t, 0, int(o)] = 1.0
            acts[t] = a
            rews[t] = r
            dones[t] = 1.0 if term else 0.0
        return xs, acts, rews, dones

    def update(self):
        self._update_calls += 1
        if self._update_calls % self.update_every != 0:
            return {}
        if len(self.buffer) < max(self.warmup, self.batch_size * 4):
            return {}
        eps = self.buffer.sample(self.batch_size, self._rng)
        # Each episode contributes L TD steps over xs of length L+1:
        # xs = [obs_0 .. obs_{L-1}, next_obs_{L-1}]. The appended next obs
        # provides the bootstrap value for the LAST step of truncated
        # episodes (gradient through the target is stopped: dqs=0 there).
        Lmax = max(len(e) for e in eps)
        T = Lmax + 1
        B = len(eps)
        xs = np.zeros((T, B, self.n_obs))
        acts = np.zeros((T, B), dtype=np.int64)
        rews = np.zeros((T, B))
        dones = np.zeros((T, B))
        mask = np.zeros((T, B))
        for b, ep in enumerate(eps):
            L = len(ep)
            for t, (o, a, r, o2, term) in enumerate(ep):
                xs[t, b, int(o)] = 1.0
                acts[t, b] = a
                rews[t, b] = r
                dones[t, b] = 1.0 if term else 0.0
                mask[t, b] = 1.0
            xs[L, b, int(ep[-1][3])] = 1.0   # appended next obs of last step
        qs_on, _, cache = self.net.forward_seq(xs)
        qs_tg, _, _ = self.target_net.forward_seq(xs)
        # Double DQN: selection at t+1 from online, evaluation from target.
        a_star = np.argmax(qs_on, axis=2)                  # [T, B]
        nxt_val = np.take_along_axis(
            qs_tg, a_star[:, :, None], axis=2)[:, :, 0]    # [T, B]
        nv = np.zeros_like(nxt_val)
        nv[:-1] = nxt_val[1:]          # value of step t's successor state
        y = rews + self.gamma * (1.0 - dones) * nv
        qa = np.take_along_axis(qs_on, acts[:, :, None], axis=2)[:, :, 0]
        td = (qa - y) * mask
        denom = max(mask.sum(), 1.0)
        loss = float((td * td).sum() / denom)
        grad_q = np.zeros_like(qs_on)
        onehot = (acts[:, :, None] == np.arange(self.n_actions)[None, None, :])
        grad_q += (2.0 / denom) * td[:, :, None] * onehot
        grads = self.net.backward_seq(grad_q, cache)
        self.opt.step(grads, clip_norm=self.grad_clip)
        self._grad_steps += 1
        if self._grad_steps % self.target_sync == 0:
            self.target_net.copy_from(self.net)
        return {"loss": loss, "td_error_mean": float(np.abs(td).sum() / denom)}

    # ------------------------------------------------------------------
    def _config(self):
        return {"cls": "GRUDQN", "hidden": self.hidden, "lr": self.lr,
                "gamma": self.gamma, "buffer_size": self.buffer.capacity,
                "batch_size": self.batch_size, "target_sync": self.target_sync,
                "eps_decay": self.eps_decay, "update_every": self.update_every,
                "warmup": self.warmup}

    def save(self, path):
        payload = {"config": np.array(json.dumps(self._config()))}
        for i, p in enumerate(self.net.params()):
            payload[f"net_{i}"] = p
        for i, p in enumerate(self.target_net.params()):
            payload[f"tgt_{i}"] = p
        np.savez(str(path), **payload)

    def load(self, path):
        p = str(path)
        if not os.path.exists(p) and os.path.exists(p + ".npz"):
            p = p + ".npz"
        with np.load(p, allow_pickle=False) as z:
            for i, q in enumerate(self.net.params()):
                q[...] = z[f"net_{i}"]
            for i, q in enumerate(self.target_net.params()):
                q[...] = z[f"tgt_{i}"]
