"""MBTL — Model-Based Task Library agent (H23, cycle-4 capstone hybrid).

Motivation (all cycle-4 empirical facts):
* Dyna's model transfers perfectly across same-dynamics tasks (acquisition
  1.000) but its Q is a single task-specific structure (retention 0.000).
* SF/GPI freezes per-task structures (retention without relearning) but
  its psi-policies are approximations -> k-shot identification stalls
  (retention 0.312, bimodal), and passive identification does not scale
  with episode budget (k=10 == k=3 bit-for-bit: deterministic repeats).

Mechanism: keep the Dyna model; represent each task by its reward vector
w (r(s,a,s') = w[s'], exact for the suite); freeze w into a library on
reward mismatch; at eval run k-shot BELIEF inference where the policy for
hypothesis h is EXACT value iteration on the learned model with w_h
(belief-GPI = walk to the NEAREST hypothesized goal -> test -> eliminate
-> next: ACTIVE identification); after identification, act by VI(model,
w_identified).

Training behavior is plain DynaQ (model + k_plan sweeps) on eps-greedy of
the learned Q — proven acquisition 1.000 on this suite.
"""
import numpy as np

from .dyna import DynaQ
from .tabular import TabularQ


def _vi_q(model, w, n_obs, n_actions, gamma, n_iter=200, tol=1e-10):
    """Exact VI on the learned deterministic model with reward vector w.

    model: {(s, a): (s2, r_observed, term)}  (r_observed IGNORED — the
    hypothesis supplies the reward: r = w[s2]).
    Unvisited (s, a): self-loop with reward w[s] (conservative default).
    Returns Q [S, A].
    """
    Q = np.zeros((n_obs, n_actions))
    for _ in range(int(n_iter)):
        Q_new = np.empty_like(Q)
        delta = 0.0
        for s in range(n_obs):
            for a in range(n_actions):
                if (s, a) in model:
                    s2, _, term = model[(s, a)]
                    r = w[s2]
                    boot = 0.0 if term else gamma * float(Q[s2].max())
                    Q_new[s, a] = r + boot
                else:
                    Q_new[s, a] = w[s] + gamma * float(Q[s].max())
            d = float(np.abs(Q_new[s] - Q[s]).max())
            delta = max(delta, d)
        Q = Q_new
        if delta < tol:
            break
    return Q


class MBTL(DynaQ):
    """DynaQ + frozen task-reward library + VI-planning task inference."""

    name = "mbtl"

    def __init__(self, *args, tol_switch=0.25, vi_refresh=2000,
                 max_library=64, **kwargs):
        super().__init__(*args, **kwargs)
        self.tol_switch = float(tol_switch)
        self.vi_refresh = int(vi_refresh)
        self.max_library = int(max_library)
        self._w = np.zeros(self.n_obs)          # current-task reward vector
        self._library = []                      # frozen w vectors
        self._task_switches = 0
        self._reward_events = 0
        self._steps_since_vi = 0
        self._vi_cache = {}                     # w-hash -> (Q, model-size)
        self.infer_mode = False
        self._belief = None
        self._w_active = None                   # w used for greedy actions

    # ------------------------------------------------------------------
    def _maybe_switch(self, s2, r):
        if abs(r - self._w[s2]) <= self.tol_switch:
            return
        if np.abs(self._w).max() <= 0:
            return
        if len(self._library) < self.max_library:
            self._library.append(self._w.copy())
        self._w = np.zeros_like(self._w)
        self._task_switches += 1
        self._vi_cache = {}

    def _vi(self, w):
        """VI on the current model with reward vector w (cached)."""
        key = (w.tobytes(), len(self._model))
        hit = self._vi_cache.get(key)
        if hit is not None:
            return hit
        Q = _vi_q(self._model, w, self.n_obs, self.n_actions, self.gamma)
        if len(self._vi_cache) > 4 * self.max_library:
            self._vi_cache = {}
        self._vi_cache[key] = Q
        return Q

    def observe(self, obs, action, reward, next_obs, terminated, truncated,
                info=None):
        s2 = int(next_obs)
        r = float(reward)
        if self.infer_mode:
            # k-shot inference: belief elimination + w-only update
            self._eliminate(s2, r)
            if not self._belief:
                self._maybe_switch(s2, r)
                self._belief = [-1]
                self._w_active = self._w
            if r != 0.0:
                self._w[s2] = r
                self._w_active = self._w
            return
        self._maybe_switch(s2, r)
        if r != 0.0:
            self._reward_events += 1
            self._w[s2] = r
            self._vi_cache = {}
        super().observe(obs, action, reward, next_obs, terminated,
                        truncated, info)

    def _eliminate(self, s2, r):
        if self._belief is None:
            return
        kept = []
        for h in self._belief:
            w_h = self._w if h == -1 else self._library[h]
            if abs(r - w_h[s2]) <= self.tol_switch:
                kept.append(h)
        self._belief = kept

    # ------------------------------------------------------------------
    def act(self, obs, greedy=False):
        s = int(obs)
        if self.infer_mode and self._belief is not None:
            q = self._vi(self._w_active if self._w_active is not None
                         else self._w)[s].copy()
            for h in self._belief:
                if h == -1:
                    continue
                np.maximum(q, self._vi(self._library[h])[s], out=q)
            return int(np.argmax(q))
        if greedy:
            # exact planning on the learned model with the current w
            return int(np.argmax(self._vi(self._w)[s]))
        eps = self._eps.value(self._step_count)
        if self._rng.random() < eps:
            return int(self._rng.integers(self.n_actions))
        if self.count_bonus > 0.0:
            return int(np.argmax(
                self.Q[s] + self.count_bonus / np.sqrt(1.0 + self.visits[s])))
        return int(np.argmax(self.Q[s]))

    # ------------------------------------------------------------------
    def begin_inference(self):
        self.infer_mode = True
        self._belief = list(range(len(self._library))) + [-1]
        self._w_active = self._w.copy()

    def end_inference(self):
        self.infer_mode = False
        self._belief = None
        self._w_active = None

    def diagnostics(self):
        return {"task_switches": self._task_switches,
                "library_size": len(self._library),
                "reward_events": self._reward_events,
                "model_size": len(self._model)}
