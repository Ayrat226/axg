"""Successor-Features Q-learning agent with task library + GPI (H19).

Mechanism (Barreto et al. 2017, adapted to discrete one-hot features):

    psi_pi(s, a) = E[ sum_t gamma^t phi(s_t) | s_0=s, a_0=a, pi ]
    r(s, a, s') = w . phi(s'),  phi(s') = one-hot(s')  (F = n_obs)

* psi is learned by TD under the CURRENT task's greedy policy (SFQL
  projection: a* = argmax_a psi(s', a) . w_cur). psi is task-AGNOSTIC in the
  sense that it depends on the POLICY, not on rewards; each library entry
  (psi_m, w_m) captures one policy's discounted state-occupancy.
* w is inferred EXACTLY from one-hot rewards: any transition into s' reveals
  w[s'] = r (valid for the suite: reward is a pure function of the target
  cell; registered assumption).
* Task switch detection (domain-IL without oracle): prediction error
  |r - w_hat[s']| > tol => the reward structure changed => freeze (psi_cur,
  w_hat) into the library, zero w_hat and psi_cur, continue with GPI over
  the frozen policies.
* Action value: Q(s, a) = max_m psi_m(s, a) . w_cur   (GPI; current task's
  psi is the last library entry).
* Exploration: eps-greedy on Q + count-bonus optimism (registered
  "optimistic_init=1.0" implemented as bonus 1.0/sqrt(1+N(s,a)); eval is
  PURE argmax Q — the bonus shapes discovery only).

Retention mechanism: old tasks' (psi_m, w_m) are FROZEN — later phases
cannot overwrite them; re-inference of w_m from a few reward samples
restores the old task's policy through GPI with zero weight drift.
"""
import numpy as np

from ..core.agent import AgentBase
from .common import EpsilonSchedule


class SFGPI(AgentBase):
    """SFQL + GPI agent for discrete envs with one-hot reward features."""

    name = "sf"

    def __init__(self, n_obs, obs_type, n_actions, alpha=0.1, gamma=0.99,
                 eps_start=1.0, eps_end=0.05, eps_decay=20000,
                 bonus=1.0, tol_switch=0.25, max_library=32, seed=0):
        if obs_type != "discrete":
            raise ValueError("SFGPI requires discrete obs (one-hot phi)")
        self.n_obs = int(n_obs)
        self.obs_type = obs_type
        self.n_actions = int(n_actions)
        self.alpha = float(alpha)
        self.gamma = float(gamma)
        self.bonus = float(bonus)
        self.tol_switch = float(tol_switch)
        self.max_library = int(max_library)
        self.F = self.n_obs
        # library of (psi [S,A,F], w [F]) — frozen tasks + current entry
        self._psi = np.zeros((self.n_obs, self.n_actions, self.F))
        self._w = np.zeros(self.F)
        self._library = []            # list of (psi, w) frozen entries
        self._task_switches = 0
        self._reward_events = 0
        self.infer_mode = False       # k-shot protocol: w-only updates
        self._belief = None           # inference-time hypothesis mask
        self.visits = np.zeros((self.n_obs, self.n_actions), dtype=np.int64)
        self._rng = np.random.default_rng(seed)
        self._eps = EpsilonSchedule(eps_start, eps_end, eps_decay)
        self._step_count = 0

    # ------------------------------------------------------------------
    def _phi(self, s):
        v = np.zeros(self.F)
        v[int(s)] = 1.0
        return v

    def q_gpi(self, s):
        """Q(s, a) = max_m psi_m(s,a) . w_cur for every a (vector [A])."""
        q = self._psi[s] @ self._w                      # current entry
        for psi_m, w_m in self._library:
            np.maximum(q, psi_m[s] @ self._w, out=q)    # GPI over frozen
        return q

    def act(self, obs, greedy=False):
        s = int(obs)
        if self.infer_mode and self._belief is not None:
            return self._act_belief(s)
        if greedy:
            return int(np.argmax(self.q_gpi(s)))
        eps = self._eps.value(self._step_count)
        if self._rng.random() < eps:
            return int(self._rng.integers(self.n_actions))
        q = self.q_gpi(s)
        if self.bonus > 0.0:
            q = q + self.bonus / np.sqrt(1.0 + self.visits[s])
        return int(np.argmax(q))

    def _act_belief(self, s):
        """Inference-time action selection: GPI over BELIEVED tasks only.

        q(s, a) = max over hypotheses h in belief of psi_h(s, a) . w_h
        (current entry participates with its online-inferred w_cur).
        """
        q = self._psi[s] @ self._w
        for h in self._belief:
            if h == -1:
                continue
            psi_m, w_m = self._library[h]
            np.maximum(q, psi_m[s] @ w_m, out=q)
        return int(np.argmax(q))

    def observe(self, obs, action, reward, next_obs, terminated, truncated,
                info=None):
        s, a = int(obs), int(action)
        s2 = int(next_obs)
        r = float(reward)
        if self.infer_mode:
            # k-shot task inference (registered protocol amendment, H19):
            # (1) eliminate belief hypotheses contradicted by the reward;
            # (2) if no library hypothesis survives, freeze + zero (new task);
            # (3) w-only update (no psi TD, no visits, no schedule).
            self._eliminate(s2, r)
            if not self._belief:
                self._maybe_switch(s2, r)   # freeze + zero (v1 semantics)
                self._belief = [-1]
            if r != 0.0:
                self._w[s2] = r
            return
        self.visits[s, a] += 1
        self._step_count += 1
        # ---- task-switch detection (BEFORE overwriting w_hat[s2]) ----
        self._maybe_switch(s2, r)
        # ---- exact w inference from one-hot features ----
        if r != 0.0:
            self._reward_events += 1
            self._w[s2] = r
        # ---- SFQL psi TD update ----
        if terminated:
            target = self._phi(s2)
        else:
            a_star = int(np.argmax(self._psi[s2] @ self._w))
            target = self._phi(s2) + self.gamma * self._psi[s2, a_star]
        self._psi[s, a] += self.alpha * (target - self._psi[s, a])

    def _maybe_switch(self, s2, r):
        """Freeze the current (psi, w) when rewards contradict w_hat.

        Guard: only when the current entry has an IDENTIFIED reward
        structure (|w| > 0) — psi is non-zero from the very first TD update,
        so the old psi-based guard froze spuriously on the first reward.
        """
        if abs(r - self._w[s2]) <= self.tol_switch:
            return
        if np.abs(self._w).max() <= 0:
            return
        if len(self._library) < self.max_library:
            self._library.append((self._psi.copy(), self._w.copy()))
        self._psi = np.zeros_like(self._psi)
        self._w = np.zeros_like(self._w)
        self._task_switches += 1

    def _eliminate(self, s2, r):
        """Bayesian hypothesis elimination during inference.

        Hypothesis h (library task m or the current entry -1) is eliminated
        when the observed reward at s2 contradicts its prediction w_h[s2].
        """
        if self._belief is None:
            return
        kept = []
        for h in self._belief:
            w_h = self._w if h == -1 else self._library[h][1]
            if abs(r - w_h[s2]) <= self.tol_switch:
                kept.append(h)
        self._belief = kept

    def update(self):
        return {"td_error": 0.0}

    def begin_inference(self):
        """Enter k-shot task-inference mode.

        Belief = all library tasks + the current entry (-1 sentinel).
        Actions use belief-masked GPI; observations eliminate contradicted
        hypotheses; no psi/visits/schedule updates (w-only).
        """
        self.infer_mode = True
        self._belief = list(range(len(self._library))) + [-1]

    def end_inference(self):
        self.infer_mode = False
        self._belief = None

    # ------------------------------------------------------------------
    def diagnostics(self):
        return {"task_switches": self._task_switches,
                "library_size": len(self._library),
                "reward_events": self._reward_events}
