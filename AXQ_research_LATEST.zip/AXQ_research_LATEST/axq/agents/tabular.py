"""Tabular Q-learning agent (discrete observations only)."""
import numpy as np

from ..core.agent import AgentBase
from .common import EpsilonSchedule


class TabularQ(AgentBase):
    """Online tabular Q-learning with epsilon-greedy exploration.

    * Deterministic update in ``observe`` (1-step TD, bootstrap on
      ``terminated`` only -- truncated episodes still bootstrap).
    * ``greedy=True`` returns the pure argmax of Q (no exploration bonus),
      so ``evaluate()`` measures the actual greedy policy; the count bonus
      only shapes the training-time deterministic branch.
    * ``count_bonus`` adds ``count_bonus / sqrt(1 + visits[s, a])`` to the
      deterministic branch during training (poorly-visited (s, a) pairs
      are preferred); visits are counted in ``observe``.
    """

    name = "tabular"

    def __init__(self, n_obs, obs_type, n_actions, alpha=0.1, gamma=0.99,
                 eps_start=1.0, eps_end=0.05, eps_decay=20000,
                 optimistic_init=0.0, count_bonus=0.0, seed=0):
        if obs_type != "discrete":
            raise ValueError(
                "TabularQ requires obs_type == 'discrete', got %r" % (obs_type,))
        self.n_obs = int(n_obs)
        self.obs_type = obs_type
        self.n_actions = int(n_actions)
        if self.n_obs < 1 or self.n_actions < 1:
            raise ValueError("n_obs and n_actions must be >= 1")
        self.alpha = float(alpha)
        self.gamma = float(gamma)
        self.count_bonus = float(count_bonus)
        self.Q = np.full((self.n_obs, self.n_actions),
                         float(optimistic_init), dtype=np.float64)
        self.visits = np.zeros((self.n_obs, self.n_actions), dtype=np.int64)
        self._rng = np.random.default_rng(seed)
        self._eps = EpsilonSchedule(eps_start, eps_end, eps_decay)
        self._step_count = 0
        self._last_td = 0.0

    # ------------------------------------------------------------------
    def act(self, obs, greedy=False):
        s = int(obs)
        if greedy:
            return int(np.argmax(self.Q[s]))
        eps = self._eps.value(self._step_count)
        if self._rng.random() < eps:
            return int(self._rng.integers(self.n_actions))
        if self.count_bonus > 0.0:
            bonus = self.count_bonus / np.sqrt(1.0 + self.visits[s])
            return int(np.argmax(self.Q[s] + bonus))
        return int(np.argmax(self.Q[s]))

    def observe(self, obs, action, reward, next_obs, terminated, truncated,
                info=None):
        s, a = int(obs), int(action)
        s2 = int(next_obs)
        self.visits[s, a] += 1
        self._step_count += 1
        boot = 0.0 if terminated else self.gamma
        target = float(reward) + boot * float(self.Q[s2].max())
        td = target - self.Q[s, a]
        self.Q[s, a] += self.alpha * td
        self._last_td = float(td)

    def update(self):
        """No-op computation; returns the last TD error (update lives in observe)."""
        return {"td_error": abs(self._last_td)}
