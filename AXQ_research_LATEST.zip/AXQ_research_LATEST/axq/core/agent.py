"""Agent interface contract.

Lifecycle within an episode (see axq/core/runner.py):
    agent.reset_state()                 # at episode start
    a = agent.act(obs, greedy=False)    # per step
    agent.observe(s, a, r, s', term, trunc, info)
    agent.update()                      # per step (may internally skip)
    agent.end_episode()                 # at episode end
During evaluation runner calls only reset_state/act(greedy=True).
"""
import numpy as np


class AgentBase:
    name = "base"

    def act(self, obs, greedy=False):
        raise NotImplementedError

    def observe(self, obs, action, reward, next_obs, terminated, truncated, info=None):
        pass

    def update(self):
        return {}

    def end_episode(self):
        pass

    def reset_state(self):
        pass


class RandomAgent(AgentBase):
    """Uniform random policy. Universal lower baseline."""
    name = "random"

    def __init__(self, n_actions, seed=0):
        self.n_actions = n_actions
        self._rng = np.random.default_rng(seed)

    def act(self, obs, greedy=False):
        return int(self._rng.integers(self.n_actions))
