"""Core environment interface (Gymnasium-like, dependency-free).

Conventions
-----------
* ``obs_type == "discrete"``: ``reset``/``step`` return an int observation index
  in ``[0, n_obs)``. Agents one-hot encode it.
* ``obs_type == "vector"``: observations are 1-D float arrays of length ``n_obs``.
* ``reset(seed)`` seeds the env RNG; all subsequent randomness must come from
  ``self._rng``. Two episodes driven with identical seeds and identical action
  sequences MUST be identical (checked by ``axq.testing.check_env``).
* ``step`` returns ``(obs, reward, terminated, truncated, info)``.
* Episode-level diagnostics (unique states visited, regret, dead-ends, ...)
  must be placed in the ``info`` dict of the FINAL step of the episode.
* Truncation at ``max_episode_steps`` is handled centrally by ``EnvBase.step``.
* Invalid actions raise ``ValueError`` (centralised in ``EnvBase.step``).
"""
import numpy as np


class EnvBase:
    obs_type = "vector"     # "discrete" | "vector"
    n_obs: int = 0          # discrete: #distinct obs; vector: obs dimension
    n_actions: int = 2
    max_episode_steps: int = 100

    def reset(self, seed=None):
        """Reset env. If seed is None, keep existing RNG (or create one)."""
        if seed is not None:
            self._rng = np.random.default_rng(seed)
        elif not hasattr(self, "_rng") or self._rng is None:
            self._rng = np.random.default_rng()
        self._steps = 0
        return self._reset()

    def step(self, action):
        a = int(action)
        if not (0 <= a < self.n_actions):
            raise ValueError(f"action {a} out of range [0, {self.n_actions})")
        if not hasattr(self, "_rng") or self._rng is None:
            self._rng = np.random.default_rng()
        self._steps += 1
        obs, r, term, trunc, info = self._step(a)
        if self._steps >= self.max_episode_steps:
            trunc = True
        return obs, float(r), bool(term), bool(trunc), dict(info)

    # ------------------------------------------------------------------
    # subclasses implement these two
    def _reset(self):
        raise NotImplementedError

    def _step(self, action):
        raise NotImplementedError

    # ------------------------------------------------------------------
    @property
    def elapsed_steps(self):
        return getattr(self, "_steps", 0)

    @property
    def unwrapped(self):
        return self

    def render_ascii(self):
        """Optional pretty-print for debugging; default: no-op."""
        return None
