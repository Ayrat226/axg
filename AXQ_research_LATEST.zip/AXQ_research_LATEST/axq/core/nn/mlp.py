"""Minimal, correct NumPy neural network library (MLP + Adam).

Correctness is verified by finite-difference gradient checks in
tests/test_core.py — any change MUST keep those tests green.

Design: float64 everywhere (numerically stable, small nets are cheap),
Xavier init, tanh or relu hidden activations, linear output.
"""
import numpy as np


class Linear:
    """Fully connected layer with manual backprop."""

    def __init__(self, n_in, n_out, rng):
        s = np.sqrt(2.0 / (n_in + n_out))   # Xavier/Glorot
        self.W = rng.normal(0.0, s, size=(n_in, n_out))
        self.b = np.zeros(n_out)
        self.dW = np.zeros_like(self.W)
        self.db = np.zeros_like(self.b)
        self._x = None

    def forward(self, x):
        self._x = x
        return x @ self.W + self.b

    def backward(self, grad_out):
        self.dW = self._x.T @ grad_out
        self.db = grad_out.sum(axis=0)
        return grad_out @ self.W.T

    def params(self):
        return [self.W, self.b]

    def grads(self):
        return [self.dW, self.db]


def _act(x, kind):
    if kind == "tanh":
        return np.tanh(x)
    return np.maximum(x, 0.0)


def _dact(x, kind):
    """Derivative factor given PRE-activation x."""
    if kind == "tanh":
        return 1.0 - np.tanh(x) ** 2
    return (x > 0).astype(x.dtype)


class MLP:
    """MLP: sizes=[in, h1, ..., out]; hidden activation tanh|relu; linear out."""

    def __init__(self, sizes, rng, activation="tanh"):
        assert activation in ("tanh", "relu"), activation
        assert len(sizes) >= 2 and all(int(s) > 0 for s in sizes)
        self.activation = activation
        self.sizes = list(map(int, sizes))
        self.layers = [Linear(a, b, rng) for a, b in
                       zip(self.sizes[:-1], self.sizes[1:])]
        self._cache = []          # pre-activations of hidden layers
        self._adam_m = None
        self._adam_v = None
        self._adam_t = 0

    # ------------------------------------------------------------------
    def forward(self, x):
        """x: [B, D] (1-D input is promoted to [1, D]). Returns [B, out]."""
        h = np.atleast_2d(np.asarray(x, dtype=np.float64))
        if h.shape[1] != self.sizes[0]:
            raise ValueError(f"input dim {h.shape[1]} != {self.sizes[0]}")
        self._cache = []
        for i, layer in enumerate(self.layers):
            z = layer.forward(h)
            if i < len(self.layers) - 1:
                self._cache.append(z)
                h = _act(z, self.activation)
            else:
                h = z
        return h

    def backward(self, grad_out):
        """grad_out: [B, out] = dLoss/dOutput. Sets (overwrites) param grads
        for the LAST forward call. Must be called after forward() on the same
        batch."""
        g = np.atleast_2d(np.asarray(grad_out, dtype=np.float64))
        for i in range(len(self.layers) - 1, -1, -1):
            g = self.layers[i].backward(g)      # now g = dL/dh_{i-1}
            if i > 0:
                g = g * _dact(self._cache[i - 1], self.activation)
        return g

    # ------------------------------------------------------------------
    def zero_grad(self):
        for L in self.layers:
            L.dW = np.zeros_like(L.W)
            L.db = np.zeros_like(L.b)

    def params(self):
        out = []
        for L in self.layers:
            out.extend(L.params())
        return out

    def grads(self):
        out = []
        for L in self.layers:
            out.extend(L.grads())
        return out

    def _flat(self, arrays):
        return np.concatenate([a.ravel() for a in arrays])

    def grad_norm(self):
        return float(np.linalg.norm(self._flat(self.grads())))

    def adam_step(self, lr=1e-3, beta1=0.9, beta2=0.999, eps=1e-8,
                  clip_norm=None):
        """One Adam step using currently accumulated grads (then zeroes them)."""
        params = self.params()
        grads = self.grads()
        if clip_norm is not None:
            total = np.sqrt(sum(float(np.sum(g * g)) for g in grads))
            if total > clip_norm and total > 0:
                scale = clip_norm / total
                grads = [g * scale for g in grads]
        if self._adam_m is None:
            self._adam_m = [np.zeros_like(p) for p in params]
            self._adam_v = [np.zeros_like(p) for p in params]
        self._adam_t += 1
        bc1 = 1.0 - beta1 ** self._adam_t
        bc2 = 1.0 - beta2 ** self._adam_t
        for p, g, m, v in zip(params, grads, self._adam_m, self._adam_v):
            m *= beta1
            m += (1 - beta1) * g
            v *= beta2
            v += (1 - beta2) * (g * g)
            p -= lr * (m / bc1) / (np.sqrt(v / bc2) + eps)
        self.zero_grad()

    # ------------------------------------------------------------------
    def copy_from(self, other):
        assert isinstance(other, MLP) and other.sizes == self.sizes
        for a, b in zip(self.layers, other.layers):
            a.W[...] = b.W
            a.b[...] = b.b

    def soft_update(self, other, tau):
        """Polyak: self <- (1 - tau) * self + tau * other."""
        assert isinstance(other, MLP) and other.sizes == self.sizes
        for a, b in zip(self.layers, other.layers):
            a.W *= (1.0 - tau)
            a.W += tau * b.W
            a.b *= (1.0 - tau)
            a.b += tau * b.b

    # ------------------------------------------------------------------
    def get_weights(self):
        return [p.copy() for p in self.params()]

    def set_weights(self, weights):
        params = self.params()
        assert len(weights) == len(params)
        for p, w in zip(params, weights):
            assert p.shape == np.asarray(w).shape
            p[...] = w

    @property
    def n_params(self):
        return int(sum(p.size for p in self.params()))
