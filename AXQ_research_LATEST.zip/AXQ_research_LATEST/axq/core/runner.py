"""Training / evaluation loops with timing.

Key design decisions
--------------------
* ``train`` uses a FIXED evaluation seed set (``eval_base_seed``), so learning
  curves are directly comparable across algorithms, seeds and time.
* Eval never updates learning agents. Caveat: ``RandomAgent.act`` consumes its
  own RNG even when greedy (harmless: eval itself stays deterministic).
* ``run_episode`` may slightly overshoot ``total_steps`` at episode end
  (documented behaviour; budgets compare equal because all algorithms use the
  same episode-based loop).
"""
import time
import numpy as np


def run_episode(env, agent, greedy=False, learn=True, seed=None):
    """Run one episode. Returns (total_reward, steps, last_info).

    Convention: envs that track episode diagnostics must include them in the
    info dict of the FINAL step of the episode.
    """
    obs = env.reset(seed)
    agent.reset_state()
    total = 0.0
    steps = 0
    info = {}
    while True:
        a = agent.act(obs, greedy=greedy)
        nobs, r, term, trunc, info = env.step(a)
        if learn:
            agent.observe(obs, a, r, nobs, term, trunc, info)
            agent.update()
        total += r
        steps += 1
        obs = nobs
        if term or trunc:
            break
    if learn:
        agent.end_episode()
    return total, steps, info


def evaluate(agent, env, episodes=20, base_seed=123456, greedy=True):
    """Deterministic evaluation: episode i uses reset seed base_seed+i."""
    rewards, lengths = [], []
    for i in range(episodes):
        r, n, _ = run_episode(env, agent, greedy=greedy, learn=False,
                              seed=base_seed + i)
        rewards.append(r)
        lengths.append(n)
    arr = np.asarray(rewards, dtype=np.float64)
    return {"mean": float(arr.mean()), "std": float(arr.std()),
            "min": float(arr.min()), "max": float(arr.max()),
            "rewards": rewards, "lengths": lengths}


def train(agent, env, total_steps, eval_interval=5000, eval_env=None,
          eval_episodes=20, seed=0, eval_base_seed=987654):
    """Train agent on env for (approximately) total_steps env steps.

    Returns dict:
      curve       : list of (step, eval_mean) tuples
      final_eval  : evaluate() dict at end (if eval_env is not None)
      steps_per_sec, wall_time_s, episodes, total_steps
    """
    step = 0
    episodes = 0
    curve = []
    next_eval = eval_interval
    t0 = time.perf_counter()
    first = True
    while step < total_steps:
        s = seed if first else None
        _, n, _ = run_episode(env, agent, learn=True, seed=s)
        first = False
        step += n
        episodes += 1
        while eval_env is not None and step >= next_eval:
            ev = evaluate(agent, eval_env, episodes=eval_episodes,
                          base_seed=eval_base_seed)
            curve.append((next_eval, ev["mean"]))
            next_eval += eval_interval
    wall = time.perf_counter() - t0
    out = {"curve": curve, "episodes": episodes,
           "steps_per_sec": step / max(wall, 1e-9),
           "wall_time_s": wall, "total_steps": step}
    if eval_env is not None:
        out["final_eval"] = evaluate(agent, eval_env, episodes=eval_episodes,
                                     base_seed=eval_base_seed)
    return out
