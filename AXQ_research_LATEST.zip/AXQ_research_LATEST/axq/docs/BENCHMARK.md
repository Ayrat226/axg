# AXQ-Universal Benchmark

Способностная лестница RL-бенчмарков. Все среды — чистый NumPy, детерминированные
по seed, проверяются контрактом `check_env` + семантическими тестами
(решаемость value iteration / scripted-политиками).

## Карта уровней → среды (38 зарегистрированных сред)

| Уровень | Способность | Среды | Проверяется |
|---|---|---|---|
| L0 | базовая оценка ценности | one_step_bandit, multi_armed_bandit, contextual_bandit | выбор лучшего действия, exploration/exploitation, использование состояния (regret в info) |
| L0 | простое планирование | gridworld_dense (4×4), frozenlake_4x4 | плотный сигнал, короткий горизонт |
| L1 | управление | cartpole, mountaincar, acrobot, pendulum_discrete | стабилизация, последовательности действий, delayed planning (физика Sutton&Barto/Gymnasium) |
| L1 | generalization в управлении | cartpole_vstart (train/test стартовые распределения) | перенос на unseen старты |
| L2 | exploration при разреженном вознаграждении | gridworld_sparse (8×8) | чистый тест exploration при полной наблюдаемости |
| L2 | in-episode исследование | maze_random, keys_doors, deadend_maze, dynamic_obstacles, frozenlake_slippery | ⚠️ POMDP: layout меняется каждый эпизод, стены не видны в obs — реактивные агенты тут в принципе ограничены (докм. в NEGATIVE_RESULTS) |
| L3 | память | memory_corridor_{8,16,32,64}, delayed_match_{10_50, 50_100}, hidden_state | POMDP по построению: реактивный потолок 0.5 (проверено тестом 200 случайных реактивных политик) |
| L4 | долгосрочный credit assignment | chain_{5,10,20,50} | цепочки до 50 действий; ε-greedy теоретически требует ~2^N эпизодов (Osband et al. 2016) |
| L5 | deceptive rewards | deceptive_{5,10,25,50,100}, credit_assignment | малое сейчас vs большое потом; задержка как параметр |
| L5 | антитест reward hacking | gridworld_decoy (ловушка +0.5 терминальная vs цель +1) | выявляет близорукость: info["trap_taken"] |
| L6 | обобщение | room_nav_gen (100 train карт / 1000 test карт, obs включает локальные стены) + sweep {5,25,100} train-карт | generalization gap = train − test |
| L7 | робастность | обёртки над trained-чекпойнтами cartpole: ObsNoise, ActionDelay {1,2,5}, StickyActions, ObsDropout, ActionPermutation | robustness curve |
| L8 | continual | continual_gridworlds (5 layouts последовательно), continual_cartpole (3 варианта) | forgetting matrix, режимы persist/fresh buffer |
| L9 | self-play / противники | tictactoe_vs_{random, heuristic, minimax} + SelfPlaySession | win/draw/loss vs боты, self-play популяция |

## Роли агентов

| Агент | Описание | Параметры (пример) |
|---|---|---|
| random | нижняя граница | — |
| tabular | точный Q-learning + count-bonus опция | верхняя граница на малых дискретных задачах |
| dqn | Double DQN (van Hasselt 2015), n-step, target net, running obs-normalization (для vector) | 64×64 tanh, lr 1e-3, Adam |
| axq | AXQ-6: 6-головый ансамбль, median-агрегация, disagreement-бонус, minibag 0.8, опции aggregation={mean,min}, use_prior (Osband 2018) | 6×(48×48) |
| history_dqn | DQN над окном последних k one-hot наблюдений | k настраивается ≥ длины коридора |
| gru_dqn | GRU + Q-head, episode replay, точный full-episode BPTT (проверен finite-difference) | H=32/64 |

## Известные дизайн-решения и ограничения

1. **maze_random / keys_doors / deadend_maze / dynamic_obstacles — POMDP с меняющимся layout**: агент видит только позицию (+флаг ключа), стены не наблюдаемы. Реактивные агенты не могут решить их надёжно (tabular → 0.000, DQN → 0.000, AXQ → 0.02 на maze). Это осознанный «слепой» класс задач: он измеряет **in-episode адаптацию**, которой у реактивных агентов нет. Урок дизайна: наблюдаемость (room_nav_gen с wall-bits) определяет, что вообще выучиваемо. Данные среды сохранены как hard-задачи для будущих memory-агентов.
2. **Коридоры памяти**: n_obs = 2S+L; выбор происходит при неразличимом obs → реактивный потолок 0.5 по построению (тест: max из 200 случайных реактивных политик < 0.65).
3. **Control-конфигурация** (честная для обоих): n_step=3 + running-нормализация наблюдений, откалибрована на cartpole seed 0 ДО сравнительных прогонов. Без неё DQN нестабилен на cartpole (448→43→126 при n_step=1).
4. **Бюджеты** (env-шагов на seed): L0 10k; L1 60k; L2 100k; L3 60–100k; L4/L5 60k; L6 100k; continual 20k/фаза. Одинаковы для всех агентов в сравнении.
5. **Сиды**: парные сравнения по seed (одни и те же сиды env/agent для обоих методов); eval — фиксированный набор сидов, общий для всех.

## Антитесты и проверки честности

- gridworld_decoy (ловушка): tabular ловится (0.490 = ловушка), VI-политика не ловится (тест).
- ActionPermutationWrapper: фиксированная биекция на train/eval — проверка отсутствия утечки индексов действий.
- Реактивный потолок памяти: тест, что никакая реактивная политика не превышает 0.5.
- Сплиты train/test карт room_nav_gen разделены непересекающимися диапазонами seed (тест).
- Статистика: Wilcoxon парный + bootstrap CI + effect size; Holm-поправка внутри среды; n=5 → «suggestive only» (мин. p = 0.0625), n=8 для headline-утверждений.
