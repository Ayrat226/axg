# PRE-REGISTRATION — Cycle 4 (independent replication + sensitivity + new architectures)

Registered in KB (hypotheses + this file) BEFORE any cycle-4 run.
Author: orchestrator. Date: 2026-10-09T13:45Z. Immutable after first run.

## Motivation (user critique, 2026-10-09)

1. Re-running the same code is NOT independent confirmation: implementation or
   design errors survive re-runs. Required: pre-fixed protocol, NEW seeds
   (disjoint from 0-7, 100-101), raw per-seed results saved and published.
2. Deceptive-family claims ("AXQ +50 in 3/3, tabular fails 3/3") may depend on
   exploration schedule, delay length, action count, stochasticity, reward
   structure. Tabular implementation must be PROVEN correct and given a
   comparable exploration budget; 60k-step failure = failure under these
   conditions, not mathematical inability.
3. n=3/5/8 samples and 8/8, 5/5 ceilings: need larger n, paired seeds,
   uncertainty intervals, sample size chosen by power, not leftover time.
4. Statistical reporting: raw p vs Holm-adjusted p, hypothesis family,
   full list of tested hypotheses, per-seed raw values, effect sizes, CIs.

## Confound found during pre-registration audit (before any run)

EpsilonSchedule is linear start->end over decay_steps. Defaults:
tabular eps_decay=20000; dqn/axq eps_decay=10000. Original e5 runs used
defaults => tabular annealed 2x SLOWER (more exploration per step) yet failed;
NN agents passed with 2x faster anneal. Direction favors the published claim,
but matched-schedule arms are added to deconfound (H14 arm M).

## Families and multiplicity

* Family R (replication confirmatory, Holm m=3):
    R1 = H14 primary test (matched-schedule deceptive separation),
    R2 = H15 primary test (sparse AUC edge, paired, n=12),
    R3 = H16 primary test (g1 retention, paired, n=8).
  All other reported comparisons in Family R arms are secondary/descriptive.
* Family S (sensitivity grid): EXPLORATORY, direction-predictions registered
  below; no confirmatory p-values will be claimed; findings feed H17/H18
  mechanism model. Multiplicity controlled by pre-registered predictions.
* Family N (new architectures, Holm m=3 primary endpoints):
    N1 = H19 SF/GPI retention on shared-layout suite (n=8, paired vs heads),
    N2 = H20 Dyna-Q sparse AUC vs AXQ (n=8 paired on seeds 0-7),
    N3 = H21 EFE parameter-robustness (variance ratio across tau grids).
* Verification tests (H17a off-policy convergence, unit reductions): binary
  pass/fail, no p-values.

## Power analysis (chosen BEFORE runs, drives n)

Exact Wilcoxon signed-rank two-sided min-p: n=5 -> 0.0625 (floor),
n=6 -> 0.03125, n=7 -> 0.0156, n=8 -> 0.0078, n=10 -> 0.0020, n=12 -> 0.00049.
Holm-3 at alpha=0.05 requires raw p < 0.0167 => n >= 7.
* R2 (H15): assume dz >= 0.8 (conservative; original 1.32). n=12 ->
  power ~0.91. SEEDS 200-211.
* R3 (H16): dz = 1.14 (original). n=8 -> power ~0.77 (budget-constrained;
  direction + magnitude-within-CI registered as co-criteria). SEEDS 200-207.
* N2 (H20): dz unknown, assume 0.9. n=8 -> ~0.80. SEEDS 0-7 (paired with
  existing e3-sparse results, same seeds, same configs).
* N1 (H19): dz assume 1.0 vs heads retention. n=8 -> ~0.80. SEEDS 0-7
  paired with existing g1 heads runs (same suite shape, shared-layout suite).
* Binomial pass rates: n=12, Clopper-Pearson 95% CI for 12/12 = [0.74; 1.00].

## H14 — Independent replication of deceptive separation (Family R1)

Design: envs {deceptive_50, credit_assignment, gridworld_decoy} x agents
{tabular, dqn, axq} x seeds 200-211 (n=12), budget 60k, eval 10k / 50 eps.
Arms: (O) original configs verbatim (incl. eps_decay mismatch);
(M1) ALL agents eps_decay=10000; (M2) ALL agents eps_decay=20000.
tabular only for O+M1+M2 (cheap); dqn/axq for O + M1 (M2 for dqn only).

Primary test R1: under arm M1 (matched schedule), pass rates:
tabular pass <= 3/12 AND (dqn pass >= 9/12) on each of the 3 envs,
where pass = final greedy eval return >= 0.9 * V*(env) (V* from value
iteration, per config; for original deterministic envs V* = optimal return:
deceptive_50 10.0, credit 50.0, decoy 0.755 registered).

Predictions: (a) tabular fails everywhere (<= small reward + 5%) in all arms;
(b) dqn/axq pass >= 10/12 in arm O; (c) schedule matching does not flip any
agent's outcome class; (d) dqn pass rate on credit_assignment >= 10/12.

Kill criteria: tabular passes any env in >= 3/12 seeds under ALL arms ->
"deterministic eps-greedy lock-in" reframe fails; dqn fails credit in >= 3/12
-> NN-pass claim becomes env-fragile, downgrade H5.

## H15 — Replication of AXQ AUC edge on gridworld_sparse (Family R2)

Design: axq vs dqn, paired seeds 200-211 (n=12), exact e3 config (budget 60k,
eval_interval 5000, 20 eval episodes, agent defaults as e3).
Primary endpoint: AUC (mean over eval checkpoints, normalized area).
Prediction: paired diff (axq - dqn) > 0; dz >= 0.8; exact Wilcoxon two-sided
p < 0.05 raw. Secondary: final mean, 8/8-style reliability (last-3-checkpoint
mean >= 0.9 criterion).
Kill: diff <= 0 -> headline NOT replicated, downgrade H1 to non-robust;
0 < dz < 0.5 -> direction replicates, magnitude shrinks (report honestly).

## H16 — Replication of g1 retention (task-IL heads) (Family R3)

Design: dqn-persist vs dqn-heads-persist, seeds 200-207 (n=8), 30k/phase,
5 phases, exact g1 agent configs (incl. lambda not applicable to these arms,
rehearsal_mix 0.5 for heads, buffer 200k).
Primary endpoint: retention (mean final-row eval on tasks 0..T-2 as g1).
Prediction: paired diff > 0 (original +0.469, d=1.14, CI [0.19;0.72]);
direction in >= 6/8 pairs.
Kill: diff <= 0 or raw p > 0.05 -> "not replicated at n=8"; report both
raw and Holm-3 adjusted p in Family R regardless of outcome.

## H17 — Tabular correctness + failure-boundary localization (verification)

(a) OFF-POLICY CONVERGENCE (binary): uniform-random behavior policy + the
agent's own observe() TD update, 500k steps, alpha=0.1 => ||Q - Q*||_inf <=
1% of max|Q*| on deceptive_50 and credit_assignment; <= 5% on gridworld_decoy
(larger state space; if 5% fails, registered fallback: alpha=alpha0/N(s,a)^0.3
schedule, 500k steps, same tolerance). Q* from value_iteration on exact MDP
models. PASS proves the update rule is a correct Q-learning implementation;
the e5 failure is behavioral (exploration), not a learning-rule bug.

(b) EXPLORATION BUDGET AUDIT (instrumentation, descriptive): for each agent x
env x arm (O/M1/M2): fraction of random actions by training quartile; count
of large-reward events during training; visits of critical (s,a) pairs
[(state1, hold) chains; decoy goal-region entries]. Answers "comparable
exploration budget?" quantitatively.

(c) RESCUE ARMS (pre-registered mechanism predictions):
  * tab-optim: optimistic_init = 2 * large_reward => PASSES all 3 envs
    (>= 10/12 seeds each). Mechanism: quit/small Q collapse on first visit
    makes unseen high-init actions greedy.
  * tab-count: count_bonus = 0.5 * small_reward => PASSES deceptive_50 and
    credit (>= 10/12); decoy uncertain (larger space, bonus too local) —
    registered as uncertain (50/50), to be measured.
  * tab-floor: eps_end=0.3 (decay 20k) => chain-completion probability
    (eps/2)^(delay+1) per episode with delay=20: (0.15)^21 ~ 0 -> FAILS
    credit; delay=5 deceptive_5: (0.15)^6 = 1.1e-5/episode x ~30k episodes
    ~ 0.34 expected events -> MARGINAL (register: fails or passes by luck,
    informative either way).
  * tab-longdecay: eps_decay=200k (never anneals within 60k, avg eps ~0.55)
    => (0.275)^(delay+1): delay=20 -> 0; delay=5 -> 4.2e-4/episode ->
    ~5-10 expected events -> PASSES deceptive_5, FAILS credit.
Claim under test: "tabular failure = property of eps-greedy with low floor +
argmax-tie toward quit, NOT of tabularity or the TD update".
Kill: tab-optim fails credit_assignment => lock-in is deeper (bootstrap
chain), reframe to "optimism insufficient without directed exploration".

## H18 — Factorial sensitivity of the deceptive family (Family S, exploratory)

Phase A (tabular family, full factorial, 60k steps, n=5 seeds 0-4):
  delay {5,10,20} x ratio {2,5,10} (small=1, large=ratio) x n_noise_actions
  {0,2} x slip {0, 0.2} x agent {tab-eps, tab-optim, tab-count, tab-floor,
  tab-longdecay} => 3*3*2*2*5*5 = 900 runs (~1.6 s each ~ 24 min).
Phase B (NN + model-based, reduced grid): delay {5,10,20} x ratio {10} x
  noise {0,2} x slip {0,0.2} x agent {dqn, dyna-eps, dyna-optim} n=5;
  axq spot-check: delay {10,20} x noise {2} x slip {0} n=5.
Phase C (decoy reward structure): trap_reward {0.3,0.5,0.7} x agent
  {tab-eps, tab-optim, tab-count} n=5 + dqn x 3 trap levels n=3.

slip semantics (new env param): in hold phase, each hold action terminates
the episode with reward 0 with prob=slip (accident), else advances normally.
V* recomputed per config via value iteration on exact model; PASS = final
greedy return >= 0.9 * V*.

Registered direction-predictions:
  S1: tab-eps fails for ALL ratios >= 2 (tie-lock at floor is ratio-blind).
  S2: rescue-arm delay-dependence as in H17c (floor/longdecay only delay<=5).
  S3: noise actions (2 irrelevant actions) do not change any agent's pass
      class (they only dilute random-draw probability uniformly).
  S4: slip=0.2 x delay=10 x ratio=10: V*(hold-chain) = 0.99^10 * 0.8^10 * 10
      = 0.97 < 1.0 => optimal flips to "take small". Prediction: tab-eps
      "accidentally optimal"; dqn tracks the flip in >= 3/5 seeds (chain
      experience rarer); tab-optim also tracks (values, not optimism, decide
      once both branches experienced).
  S5: decoy: tab-eps fails all trap levels in {0.3,0.5,0.7} (mechanism:
      bootstrap distance, not reward size); tab-optim passes all.
  S6: dyna-eps fails deceptive like tab-eps (model has no unexperienced
      transitions to plan through); dyna-optim passes.

## H19 — Successor Features + GPI agent (NEW ARCHITECTURE #1, Family N1)

Motivation: #1 documented bottleneck = continual without task-ID oracle;
SF/GPI (Barreto 2017) is the canonical mechanism for exactly this: dynamics-
shared tasks differing in reward. New suite continual_gridworlds_shared:
ONE fixed wall layout (layout_seed=201, 8x8, 25% walls, reachability-checked),
goals [(7,7),(7,0),(0,7),(3,4),(5,2)] (order gw1s..gw5s), 30k/phase, 5 phases.

Agent (tabular SFQL): features phi(s') = one-hot 64; reward model r = w.phi;
w inferred online from observed (phi(s'), r) — one-hot => any reward reveals
w[goal]; task-switch detection: prediction error |r - w_hat.phi(s')| > tol =>
re-infer w from subsequent samples (domain-IL without oracle).
Per-task psi_m learned by TD following greedy-w policy; library frozen after
phase; action value on task k: Q(s,a) = max_m psi_m(s,a).w_k (GPI) incl.
current-task online psi_k. Exploration: eps-greedy SAME schedule as tabular
baseline + optimistic_init=1.0 registered (SF arm needs goal discovery).

Primary endpoint N1: retention (g1 metric) on shared suite, n=8 seeds 0-7,
paired vs g1 heads-persist retention on the LAYOUT-VARYING suite is NOT
paired-compared (different suites) — instead registered absolute criteria:
SF retention >= 0.8 AND acquisition >= 0.4. Secondary: comparison arm
dqn-persist run on the SAME shared suite (n=8, paired exact Wilcoxon vs SF).
Predictions: SF retention >= 0.8 (psi frozen => no forgetting; w re-inferred
within 1-2 goal episodes via GPI-guided policies); SF acquisition >= 0.4;
SF beats dqn-persist on shared suite retention (paired, p < 0.05 raw).
Negative control: SF on EXISTING layout-varying suite => retention <= 0.15
(dynamics change invalidates psi transfer; w-inference alone insufficient).
Kill: SF retention < dqn-persist level (0.094-0.10) on shared suite =>
mechanism falsified at this budget; acquisition < 0.2 => budget boundary,
report as negative with curves.

## H20 — Dyna-Q model-based planner (NEW ARCHITECTURE #2, Family N2)

Agent: tabular Q-learning + deterministic transition model T[s,a]=(s',r)
(1 visit => exact in deterministic envs) + k=20 uniformly-sampled planning
sweeps per real step (Dyna-Q, Sutton 1991; no prioritization, honest simple
version). Arms: dyna-eps (same eps schedule as tabular), dyna-optim.

Primary endpoint N2: gridworld_sparse AUC, seeds 0-7 (n=8), paired exact
Wilcoxon vs EXISTING axq results (same seeds/configs/budget 60k).
Prediction: dyna AUC > axq AUC, dz >= 0.9 (first-goal propagation => jump to
near-optimal within ~1-2 eval intervals) at ~20x less compute than axq
(measured steps/s registered). If confirmed => sample-efficiency headline
transfers from "ensemble" to "model-based planning" (architectural
implication documented; AXQ remains the better model-free NN baseline).
Secondary: dyna on deceptive (S6 predictions), dyna on shared continual
suite (model accumulates across tasks => retention >= 0.8 registered).
Kill: dyna AUC <= axq AUC (paired p >= 0.05 or direction negative) =>
model-based advantage not realized at this scale; report as negative.

## H21 — Active Inference / EFE agent (NEW PARADIGM #3, Family N3)

Agent (tabular, discrete): empirical model P_hat, R_hat from counts;
1-step expected free energy action scoring:
  -G(s,a) = R_hat(s,a) + gamma * V_hat(s')_expected - risk + tau_e * Epi(s,a)
  Epi(s,a) = 1/sqrt(1+N(s,a)) epistemic term (uncertainty), auto-annealing.
Unit test (verification, binary): with risk=0 and tau_e=c, greedy(-G) is
IDENTICAL to tabular-count argmax(Q + c/sqrt(1+N)) on a random MDP battery
=> documented reduction: tabular EFE = Q-learning + count-bonus with
principled 1-parameter auto-annealing schedule (Millidge 2021 line).

Primary endpoint N3 (parameter-robustness claim): performance variance of
EFE across tau_e grid {0.05,0.1,0.25,0.5,1.0} x 5 seeds on {deceptive_5,
deceptive_10, gridworld_sparse AUC, chain_10} vs eps-family variance across
eps_end {0.05,0.1,0.2,0.3} x eps_decay {5k,20k,60k} (12 configs) x 5 seeds
same envs, normalized per env (range of mean score / |max score|).
Prediction: EFE relative range <= 50% of eps-family relative range
(parameter-freeness advantage is the ONLY claimed EFE benefit; no performance
superiority claimed — honest framing).
Secondary: EFE passes all 3 deceptive envs (inherits count-bonus mechanics).
Kill: EFE tau-grid variance >= eps-grid variance => no robustness advantage;
report EFE as theoretically-interesting-but-not-practical at this scale.

## H22 — A2C actor-critic (stretch, only if time remains; no Family)

Policy-gradient family coverage check on control suite; parity expectation;
registered to avoid post-hoc cherry-picking. NOT part of confirmatory
families.

## Raw data policy

Every run writes per-seed JSON + per-checkpoint JSONL (existing driver
pattern). STATS_REGISTRY.md (Task 19) publishes verbatim per-seed raw values
for all Family R and N endpoints: per-seed AUC/final/retention, paired diffs,
raw p, Holm-adjusted p, dz, bootstrap CI, family membership, and the FULL
list of all hypotheses ever tested in the project (multiplicity audit).

## Execution order (dependencies)

1. H17a off-policy verification (blocks nothing, proves correctness first).
2. H14/H15/H16 replication runs (new seeds; the sooner started the better;
   chunked resumable, 2 workers).
3. H17b audit + H17c rescue arms (cheap, tabular only).
4. H18 Phase A (tabular factorial) -> Phase B/C.
5. New agents implementation + unit tests (SF, Dyna, EFE) — in parallel with
   long runs where CPU allows.
6. H19/H20/H21 experiments.
7. Task 19 stats registry, docs, zip refresh at every final milestone.
