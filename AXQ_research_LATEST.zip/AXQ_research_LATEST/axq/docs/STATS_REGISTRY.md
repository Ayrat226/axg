# STATISTICAL REGISTRY — AXQ-Universal (cycles 1–4)

Single source of truth for EVERY hypothesis tested in the project, with
family structure, raw per-seed values, uncorrected and Holm-adjusted
p-values, effect sizes, CIs, and power notes. Compiled 2026-10-09 after
cycle-4 close. Raw data: axq/results/** (per-seed JSON + JSONL training
curves); every number below is reproducible from those files.

## 1. Multiplicity policy

* Confirmatory families (Holm-corrected within family):
  - **Family R** (cycle-4 independent replication, preregistered KB
    25e3df387463): R2 (sparse AUC edge), R3 (g1 retention). R1 (deceptive
    separation) is a consistency criterion (deterministic effect), no
    p-value by prereg.
  - **Family N** (new architectures): N1 (SF retention vs dqn-persist),
    N2 (dyna AUC vs axq), N3 (EFE tau-robustness — criterion, no p).
* Exploratory (descriptive, direction-predictions registered, NO
  confirmatory claims): Family S (H17c, H18 factorial S1–S6).
* Historic cycle-1/2/3 results were NOT part of a preregistered family
  structure; their headline p-values are reported RAW with the caveat that
  approximately 20 comparisons were examined across cycles 1–3 (see §5);
  the cycle-4 Family R replications are the confirmatory tests of the
  survivors.

## 2. Family R — independent replication (seeds 200–211 / 200–207, NEW,
## preregistered before any cycle-4 run)

### R1 — Deceptive separation (H14) — CONSISTENCY CRITERION: REPLICATED
Arms: O (original configs), M1 (all eps_decay=10000), M2 (all 20000).
n=12 seeds 200–211 per env per arm; pass = final >= 0.9 * V*(exact model).

| env | arm:agent | pass k/n [CP95] | final/seed (raw) |
|---|---|---|---|
| deceptive_50 | O:tab | 0/12 [0.00, 0.27] | 1.0 x12 |
| deceptive_50 | O:dqn (=M1) | 12/12 [0.73, 1.00] | 10.0 x12 |
| deceptive_50 | O:axq | 12/12 [0.73, 1.00] | 10.0 x12 |
| deceptive_50 | M1:tab | 0/12 [0.00, 0.27] | 1.0 x12 |
| deceptive_50 | M2:dqn | 11/12 [0.61, 1.00] | 10.0 x11, 1.0 x1 |
| credit_assignment | O:tab | 0/12 | 5.0 x12 |
| credit_assignment | O:dqn | 12/12 | 50.0 x12 |
| credit_assignment | O:axq | 12/12 | 50.0 x12 |
| credit_assignment | M1:tab | 0/12 | 5.0 x12 |
| credit_assignment | M2:dqn | 12/12 | 50.0 x12 |
| gridworld_decoy | O:tab | 0/12 | 0.49 x12 |
| gridworld_decoy | O:dqn | 12/12 | 0.87 x12 |
| gridworld_decoy | O:axq | 12/12 | 0.87 x12 |
| gridworld_decoy | M1:tab | 0/12 | 0.49 x12 |
| gridworld_decoy | M2:dqn | 11/12 | 0.87 x11, -2.56 x1 |

Primary R1 (M1 arm): tab <= 3/12 AND dqn >= 9/12 on EACH env -> PASS 3/3.
Instrumentation: tab large-events 0 (all envs, 60k steps); dqn 289–1668;
axq 376–2994. Schedule matching flips nobody's class -> the e5
eps_decay confound (tab 20k vs nn 10k) does not explain the separation.

### R2 — Sparse AUC edge (H15) — REPLICATED IN DIRECTION, MAGNITUDE SHRANK
axq-vs-dqn paired AUC, seeds 200–211 (n=12), exact e3 config (100k steps).

raw per-seed AUC:
  axq [0.75, 0.85, 0.90, 0.85, 0.85, 0.85, 0.80, 0.90, 0.75, 0.85, 0.85, 0.85]
  dqn [0.75, 0.85, 0.70, 0.85, 0.75, 0.75, 0.75, 0.75, 0.85, 0.85, 0.75, 0.65]
  diff [0.00, 0.00, 0.20, 0.00, 0.10, 0.10, 0.05, 0.15, -0.10, 0.00, 0.10, 0.20]
mean diff +0.0667 | dz 0.730 | exact Wilcoxon p = 0.04688 (6+/1-/5=0)
bootstrap CI95 mean [0.017, 0.117]
original (seeds 0–7): +0.100, dz 1.32, p 0.031 — effect estimate SHRANK
~33% (mean) / ~45% (dz); original likely upward-biased (seed-family luck).
Holm-2 (family R): adj p = 0.094 -> NOT significant after correction.
Verdict: direction robust (13/20 paired seeds positive across both
families, 0 negative in original; 1 negative in replication), magnitude
honestly d~0.7, confirmatory status: suggestive.

### R3 — g1 task-IL retention (H16) — REPLICATED AND STRENGTHENED
dqn-heads-persist vs dqn-persist, seeds 200–207 (n=8), 30k/phase x 5.

raw per-seed retention:
  heads  [0.25, 0.25, 0.50, 0.25, 0.25, 0.75, 0.50, 0.50]  mean 0.406
  persist[0.25, 0.00, 0.25, 0.00, 0.00, 0.00, 0.00, 0.00]  mean 0.063
  diff   [+0.00, +0.25, +0.25, +0.25, +0.25, +0.75, +0.50, +0.50]
mean diff +0.344 | dz 1.501 | exact Wilcoxon p = 0.01562 (7+/0-/1=0)
bootstrap CI95 [0.218, 0.500] | rank-biserial 1.0
original (seeds 0–7 + 5–7 ext): +0.469, dz 1.14, p 0.03125, CI [0.19,0.72].
Holm-2 (family R): adj p = 0.031 -> SIGNIFICANT after correction.
Verdict: the most robust comparative finding of the project. Heads-arm
caveats unchanged (oracle task-ID; shared-obs conflict 28–62%).

## 3. Family N — new architectures (preregistered)

### N1 — SF/GPI without oracle (H19) — PARTIAL, IDENTIFICATION-LIMITED
Suite continual_gridworlds_shared (same walls, 5 goals), 30k x 5, n=8.
sf retention/seed [0.0, 0.75, 0.0, 0.0, 0.75, 0.0, 0.25, 0.75] mean 0.312
dqn-persist (same suite) [0.25, 0.25, 0.0, 0.25, 0.25, 0.25, 0.0, 0.0] m 0.156
paired diff +0.156, p = 0.281, dz 0.39, CI [-0.09, 0.41] — ns at n=8.
acquisition: sf 0.525 (>= 0.4 criterion MET); dqn-persist 0.325.
negative control sf-varying (layout changes): retention 0.125 (mechanism
boundary confirmed — psi does not transfer across dynamics).
bimodal pattern (3x0.75 / 4x0.0): retention is high WHEN k-shot
identification (3 inference episodes, belief-GPI + hypothesis elimination)
succeeds; identification is the bottleneck, not psi quality.
Kill criterion (retention < 0.10) NOT fired; prediction (>= 0.8) NOT met.
Verdict: mechanism real, identification-limited; heads (oracle) remains
the upper bound (0.406–0.562).

### N2 — Dyna-Q sample efficiency (H20) — CONFIRMED (raw), 8/8 SEEDS
gridworld_sparse AUC, seeds 0–7 paired with existing e3 results:
  dyna [0.90 x8] (zero variance)
  axq  [0.90, 0.85, 0.85, 0.75, 0.90, 0.85, 0.85, 0.85] mean 0.850
  dqn  [0.85, 0.75, 0.65, 0.75, 0.75, 0.70, 0.70, 0.85] mean 0.750
dyna vs axq: diff +0.050, exact p = 0.03125, dz 1.08, CI [0.025, 0.081].
dyna vs dqn: diff +0.150, exact p = 0.00781, dz 2.12, CI [0.106, 0.194].
Holm-3 (family N: N1 0.281, N2 0.031, N3 criterion-failed=1.0):
adj p(N2) = 0.094 -> not Holm-robust; but 8/8 paired wins, zero variance,
and 20x less compute (tabular model vs 6-head MLP ensemble).
Verdict: dyna > axq > dqn sample-efficiency hierarchy at this benchmark;
new sample-efficiency leader = model-based planning, not ensembling.
Deceptive family: dyna-eps fails (1.0/5.0 lock-in), dyna-optim passes all
(10.0/50.0/0.87 x8 seeds).

### N3 — EFE parameter-robustness (H21) — NOT SUPPORTED (negative)
Registered claim: EFE tau-grid range <= 0.5 x eps-family range. Result:
  chain_10: EFE norm-range 0.90 vs eps 0.00 (eps INVARIANT: 0.833 across
    all 12 configs) -> claim FALSE
  gridworld_sparse: EFE 0.944 vs eps 1.00 -> claim FALSE
  deceptive_5: both 0 (trivial)
EFE tau-curve (chain_10 AUC): 0.833 (tau<=1) -> 0.667 (2) -> 0.5 (4) ->
0.083 (8): high tau destroys performance (over-exploration).
Verdict: 1-step EFE == count-bonus (reduction proven, 200 random MDPs);
inherits count-bonus scale-sensitivity; NO robustness advantage over the
eps family. Active-inference framing adds no practical value at this
scale. Documented as NEGATIVE_RESULTS entry.

## 4. Family S — sensitivity (exploratory, direction-predictions)

Mechanism taxonomy (all cells n=5 seeds, 60k steps, pass = 0.9 V*):

| mechanism | deceptive (aliased chain) | decoy (open grid, far goal) |
|---|---|---|
| eps-greedy (any schedule tested) | FAIL (luck only delay<=~8) | FAIL (0.49) |
| count-bonus / EFE 1-step | FAIL (bonus decay + tie->quit) | FAIL (0.49) |
| optimism (value prior) alone | PASS d20/d50 (5/5, 5/5) | FAIL (-2.56 at any scale) |
| planning (Dyna k=20) alone | FAIL (1.0/5.0) | PASS (0.87 x8) |
| optimism + planning | PASS (10/50 x8) | PASS (0.87 x8) |
| NN function approx (DQN/AXQ) | PASS (12/12 x3 envs) | PASS (12/12) |

Delay regimes (tab family, ratio 10): d<=5 anneal-luck (>=1 event/seed
during eps anneal, ~47 expected events at d=5) -> all variants pass;
d=10 marginal luck (0.4 pass, diluted to 0.0 by noise actions — S3
FALSIFIED); d>=20 no luck -> only structural mechanisms pass.
Slip=0.2 flips the optimum to take-small at d=10/r=10 (V*=1.0): tab-eps
then "accidentally optimal" (pass 1.0) — S4 CONFIRMED.
Registered prediction scoreboard (H18): S2 CONFIRMED (floor/longdecay
d5-pass/d20-fail), S6 CONFIRMED (dyna-optim all-pass), S1 FALSIFIED
(not ratio-blind — delay-driven luck), S3 FALSIFIED (noise dilution
flips d=10), S5 FALSIFIED-ILLUMINATING (tab passes at trap=0.7 — the
trap becomes near-optimal; myopia penalty shrinks with trap value).
tab-optim catastrophic on decoy at ANY tested init (2.0 and 20.0):
optimism decay too slow without planning (planning accelerates visited-
pair decay 20x — why dyna-optim succeeds where tab-optim fails).

## 5. Historic results (cycles 1–3) — multiplicity audit

Approximately 20 comparisons were examined in cycles 1–3 (H1–H13 + g1
arms x metrics); the confirmatory status of survivors is carried by the
cycle-4 Family R replications above, NOT by the original p-values.
Original headline numbers (raw, uncorrected, for the record):
* H1 AUC edge: +0.100, p 0.031, dz 1.32 (n=8) -> replicated R2: dz 0.73.
* H9b heads retention: +0.469, p 0.03125, dz 1.14 (n=8) -> replicated R3:
  +0.344, p 0.0156, dz 1.50.
* H5 deceptive separation: deterministic, 3–5 seeds -> replicated R1 with
  n=12 + matched schedules + instrumentation.
* Negative/inconclusive historic findings (count-bonus artifact, chains
  ns, perm-test invalid, H9a not-supported, H9c EWC cliff, H9d not-
  supported) are unchanged; see NEGATIVE_RESULTS.md and HYPOTHESES.md.

## 6. Power reference (exact Wilcoxon signed-rank, two-sided)

min p = 2/2^n: n=5 -> 0.0625 (floor), n=8 -> 0.0078, n=12 -> 0.00049.
Holm-2 at alpha .05 needs raw < 0.025; Holm-3 needs raw < 0.0167 (n >= 7).
Chosen n: R2=12 (dz>=0.8 -> power ~0.91), R3=8 (dz 1.14 -> ~0.77),
N1/N2=8 (dz 0.9-1.0 -> ~0.80). Binomial CP95: 12/12 -> [0.74, 1.00].

## 7. Data provenance

Every per-seed number above is stored verbatim in:
axq/results/c4repl/** (H14/H15, + ANALYSIS.json), axq/results/g1repl/**
(H16), axq/results/h18sens/** (H17c/H18 + ANALYSIS.json),
axq/results/h17c/h17c_rescue.json, axq/results/h19/** (+ANALYSIS.json),
axq/results/h20h21/** (+ANALYSIS.json), axq/results/h17a_tabular_
verification.json. Code fingerprint per run in ExperimentJournal records.
Cycle-4 preregistration: axq/docs/PREREG_CYCLE4.md + KB 25e3df387463;
amendments (all BEFORE the affected runs): KB e349e51be77e (EFE/count
deceptive falsification, tau rescale), VARIANTS bugfix note (dyna-optim
Phase B re-run, affected cells deleted).

## 3b. Family N addendum — MBTL (H23, capstone hybrid, prereg KB 7ee39337a91c)

Registered BEFORE implementation/runs. Mechanism: Dyna model (transfers
perfectly, acquisition 1.000) + frozen task-reward library + k-shot belief
inference with EXACT VI policies (active identification: belief-GPI walks
to the nearest hypothesized goal, tests, eliminates) + VI planning on the
identified task. Same protocol as SF (k=3 inference episodes).

raw per-seed (shared suite, seeds 0-7):
  retention [1.0, 0.25, 1.0, 0.25, 0.25, 1.0, 1.0, 0.25] mean 0.625
  acquisition [1.0 x8] mean 1.000
vs dqn-persist (same suite): paired diff +0.469, 5+/0-/3=0,
  exact p = 0.0625 (raw), dz 1.31
vs SF (same suite): 0.625 vs 0.312, 6+/2-/0, p = 0.289 (raw)
Kill criteria: retention < 0.312 — NOT fired; acquisition < 0.6 — NOT
fired. Prediction retention >= 0.5: MET (0.625).
Structure: phases 3-4 rows mostly perfect [1,1,1,1,1] (3-4 hypotheses —
identification succeeds); final-phase failures [0,0,0,1,1] on 4/8 seeds =
identification timeout with 5 hypotheses in 3 episodes — same k-shot
bottleneck as SF, but post-identification policies are EXACT (VI), hence
retention is binary {0.25, 1.0} instead of SF's noisy partial values.
Verdict: best no-oracle continual agent tested in the project; exceeds
the ORACLE heads arm level (0.406-0.562, different suite — qualitative
comparison only, registered caveat). Follow-up: inference budget scaling
(active identification should scale unlike passive: distinct mechanism).
