"""Environment package: auto-imports every env module present on disk.

Only imports modules that actually exist (phased development); ImportErrors
raised INSIDE a module are real bugs and must surface, so they are not caught.
"""
import importlib
import pathlib
from .registry import make, register, REGISTRY, catalog, envs_at_level, envs_with_cap

for _p in sorted(pathlib.Path(__file__).parent.glob("*.py")):
    if _p.stem in ("__init__", "registry"):
        continue
    importlib.import_module(f"{__name__}.{_p.stem}")
