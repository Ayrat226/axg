"""L0 reference environments: bandits (one-step, multi-armed, contextual).

This module is the REFERENCE PATTERN for all other env modules:
subclass EnvBase, implement _reset/_step, register at module bottom.
"""
import numpy as np
from ..core.env import EnvBase
from .registry import register


class OneStepBandit(EnvBase):
    """Single action per episode; reward ~ N(mu[a], 0.1).

    The agent must identify the best arm from very few samples; measures
    basic value estimation. ``info['optimal_mean']`` = max mu.
    """
    obs_type = "discrete"
    n_obs = 1
    max_episode_steps = 1

    def __init__(self, n_arms=10, seed_means=7):
        self.n_actions = int(n_arms)
        rng = np.random.default_rng(seed_means)
        self._mu = rng.normal(0.0, 1.0, size=self.n_actions)

    def _reset(self):
        return 0

    def _step(self, action):
        r = self._mu[action] + self._rng.normal(0.0, 0.1)
        return 0, r, True, False, {"optimal_mean": float(self._mu.max()),
                                   "arm_means": self._mu.copy()}


class MultiArmedBandit(EnvBase):
    """Horizon-100 repeated pulls; obs = index of last arm pulled (0 = start).

    Cumulative regret vs best arm is reported in the final info dict.
    """
    obs_type = "discrete"
    n_obs = 11
    max_episode_steps = 100

    def __init__(self, n_arms=10, horizon=100, seed_means=7):
        self.n_actions = int(n_arms)
        self.max_episode_steps = int(horizon)
        self.n_obs = int(n_arms) + 1
        rng = np.random.default_rng(seed_means)
        self._mu = rng.normal(0.0, 1.0, size=self.n_actions)
        self._regret = 0.0

    def _reset(self):
        self._regret = 0.0
        return 0

    def _step(self, action):
        r = self._mu[action] + self._rng.normal(0.0, 0.1)
        self._regret += float(self._mu.max() - self._mu[action])
        info = {"instant_regret": float(self._mu.max() - self._mu[action])}
        if self._steps >= self.max_episode_steps:
            info["regret"] = self._regret
        return action + 1, r, False, False, info


class ContextualBandit(EnvBase):
    """Context c in [0, C); reward ~ Bernoulli(p[c, a]). One step per episode.

    The context fully determines the best arm: measures whether the agent
    actually uses its observation (a context-blind agent scores <= 0.5-ish).
    """
    obs_type = "discrete"
    n_obs = 8
    max_episode_steps = 1

    def __init__(self, n_contexts=8, n_arms=5, seed_means=11):
        self.n_actions = int(n_arms)
        self.n_obs = int(n_contexts)
        rng = np.random.default_rng(seed_means)
        self._p = rng.uniform(0.1, 0.9, size=(self.n_obs, self.n_actions))

    def _reset(self):
        self._ctx = int(self._rng.integers(self.n_obs))
        return self._ctx

    def _step(self, action):
        p = self._p[self._ctx, action]
        r = 1.0 if self._rng.random() < p else 0.0
        return self._ctx, r, True, False, {
            "optimal_p": float(self._p[self._ctx].max())}


# ---------------------------------------------------------------------------
register("one_step_bandit", level=0, caps=("exploration",),
         factory=OneStepBandit,
         description="1 pull/episode, N(mu_a, 0.1); basic value estimation")
register("multi_armed_bandit", level=0, caps=("exploration",),
         factory=MultiArmedBandit,
         description="100 pulls/episode; exploration/exploitation, regret")
register("contextual_bandit", level=0, caps=("exploration",),
         factory=ContextualBandit,
         description="context determines best arm; state usage")
