"""L4/L5 long-horizon chains and deceptive-reward envs.

These isolate credit assignment: the reward arrives only at the end of a long
action sequence, and (for the deceptive family) a small immediate reward
competes with a larger delayed one.
"""
import numpy as np

from ..core.env import EnvBase
from .registry import register


class ChainEnv(EnvBase):
    """Advance L times for a single terminal +1; every wrong step restarts.

    obs = state index in [0, L]; actions: 0 = advance, 1 = fall back to 0.
    Advancing from state L-1 reaches the goal: reward +1.0, terminated.
    max_episode_steps = 4L (allows retries after falling back).
    """

    obs_type = "discrete"
    n_actions = 2

    def __init__(self, length=10):
        if length < 1:
            raise ValueError("length must be >= 1")
        self.length = int(length)
        self.n_obs = self.length + 1
        self.max_episode_steps = 4 * self.length

    def _reset(self):
        self._state = 0
        self._falls = 0
        return 0

    def _step(self, action):
        if action == 0:                       # advance
            self._state += 1
            reached = self._state >= self.length
        else:                                 # fall back to the start
            self._state = 0
            self._falls += 1
            reached = False
        reward = 1.0 if reached else 0.0
        terminated = reached
        info = {}
        if terminated or self._steps >= self.max_episode_steps:
            info["reached_goal"] = reached
            info["falls"] = self._falls
        return self._state, reward, terminated, False, info


class DeceptiveChoice(EnvBase):
    """Small immediate reward vs. larger delayed reward (deceptive trap).

    t=0, obs=0 (decision): action 0 -> +small_reward, terminated;
    action 1 -> hold phase (obs=1).  In the hold phase each action 1 ("hold")
    continues with reward 0 (after `delay` holds: +large_reward, terminated);
    action 0 ("quit") terminates with reward 0.

    Cycle-4 factorial extensions (H18, preregistered):
    * ``n_noise_actions``: extra no-op actions (stay, r=0) in both phases --
      pure exploration dilution (registered S3).
    * ``slip``: in the hold phase, each hold action terminates the episode
      with reward 0 ("accident") with prob=slip before advancing -- reward-
      structure stochasticity axis (registered S4).
    * ``mdp_model(gamma)``: exact model over the TRUE (unaliased) state space
      s=0 (decision), s=1+k (hold, count k=0..delay-1), s=delay+1 (absorbing
      terminal).  The agent still observes the ALIASED obs in {0,1} (POMDP by
      construction); V* from this model is the memory-augmented oracle bound.

    Backward compatibility: with defaults (n_noise_actions=0, slip=0.0) the
    dynamics are byte-identical to the pre-cycle-4 env (golden test).
    """

    obs_type = "discrete"
    n_obs = 2

    def __init__(self, delay=10, small_reward=1.0, large_reward=10.0,
                 n_noise_actions=0, slip=0.0):
        if delay < 1:
            raise ValueError("delay must be >= 1")
        if not (0.0 <= float(slip) < 1.0):
            raise ValueError("slip must be in [0, 1)")
        if int(n_noise_actions) < 0:
            raise ValueError("n_noise_actions must be >= 0")
        self.delay = int(delay)
        self.small_reward = float(small_reward)
        self.large_reward = float(large_reward)
        self.n_noise_actions = int(n_noise_actions)
        self.slip = float(slip)
        self.n_actions = 2 + self.n_noise_actions
        self.max_episode_steps = self.delay + 2

    def _reset(self):
        self._holds = 0
        self._in_hold = False
        return 0

    def _step(self, action):
        if action >= 2:                     # noise action: costly no-op
            return (self._in_hold and 1 or 0), 0.0, False, False, {}
        if not self._in_hold:
            if action == 0:                   # take the small reward now
                return 0, self.small_reward, True, False, {"outcome": "small"}
            self._in_hold = True              # enter the hold phase
            return 1, 0.0, False, False, {}
        if action == 1:                       # hold
            if self.slip > 0.0 and self._rng.random() < self.slip:
                return 1, 0.0, True, False, {"outcome": "accident"}
            self._holds += 1
            if self._holds >= self.delay:
                return 1, self.large_reward, True, False, {"outcome": "large"}
            return 1, 0.0, False, False, {}
        return 1, 0.0, True, False, {"outcome": "quit"}

    def mdp_model(self, gamma):
        """Exact model over the TRUE unaliased state space (see class doc).

        State layout: 0=decision; 1+k = hold with count k (k=0..delay-1);
        delay+1 = absorbing terminal. Returns (P, R) arrays [S, A, S'].
        """
        S = self.delay + 2
        A = self.n_actions
        T = self.delay + 1
        P = np.zeros((S, A, S))
        R = np.zeros((S, A, S))
        for a in range(A):
            P[T, a, T] = 1.0                       # absorbing terminal
        # decision state 0
        P[0, 0, T] = 1.0
        R[0, 0, T] = self.small_reward
        P[0, 1, 1] = 1.0
        for a in range(2, A):                      # noise no-ops
            P[0, a, 0] = 1.0
        # hold states 1+k, k = 0..delay-1
        for k in range(self.delay):
            s = 1 + k
            P[s, 0, T] = 1.0                       # quit -> 0 reward terminal
            if self.slip > 0.0:
                P[s, 1, T] = self.slip             # accident
                if k + 1 >= self.delay:
                    P[s, 1, T] += 1.0 - self.slip   # final hold completes
                    R[s, 1, T] = ((1.0 - self.slip) * self.large_reward)
                else:
                    P[s, 1, 2 + k] = 1.0 - self.slip
            else:
                if k + 1 >= self.delay:
                    P[s, 1, T] = 1.0
                    R[s, 1, T] = self.large_reward
                else:
                    P[s, 1, 2 + k] = 1.0
            for a in range(2, A):
                P[s, a, s] = 1.0
        return P, R


class CreditAssignmentTask(DeceptiveChoice):
    """DeceptiveChoice with small=5 vs large=50 after 20 holds (L4 variant)."""

    def __init__(self, small=5.0, large=50.0, delay=20):
        super().__init__(delay=delay, small_reward=small, large_reward=large)


# ---------------------------------------------------------------------------
register("chain_5", level=4, caps=("credit_assignment", "sparse"),
         factory=lambda **kw: ChainEnv(length=5, **kw),
         description="5-step chain, single terminal +1, 4L step budget")
register("chain_10", level=4, caps=("credit_assignment", "sparse"),
         factory=lambda **kw: ChainEnv(length=10, **kw),
         description="10-step chain, single terminal +1")
register("chain_20", level=4, caps=("credit_assignment", "sparse"),
         factory=lambda **kw: ChainEnv(length=20, **kw),
         description="20-step chain, single terminal +1")
register("chain_50", level=4, caps=("credit_assignment", "sparse"),
         factory=lambda **kw: ChainEnv(length=50, **kw),
         description="50-step chain, single terminal +1")
register("deceptive_5", level=5, caps=("deceptive", "credit_assignment"),
         factory=lambda **kw: DeceptiveChoice(delay=5, **kw),
         description="1 now vs 10 after 5 hold steps")
register("deceptive_10", level=5, caps=("deceptive", "credit_assignment"),
         factory=lambda **kw: DeceptiveChoice(delay=10, **kw),
         description="1 now vs 10 after 10 hold steps")
register("deceptive_25", level=5, caps=("deceptive", "credit_assignment"),
         factory=lambda **kw: DeceptiveChoice(delay=25, **kw),
         description="1 now vs 10 after 25 hold steps")
register("deceptive_50", level=5, caps=("deceptive", "credit_assignment"),
         factory=lambda **kw: DeceptiveChoice(delay=50, **kw),
         description="1 now vs 10 after 50 hold steps")
register("deceptive_100", level=5, caps=("deceptive", "credit_assignment"),
         factory=lambda **kw: DeceptiveChoice(delay=100, **kw),
         description="1 now vs 10 after 100 hold steps")
register("credit_assignment", level=4, caps=("credit_assignment", "deceptive"),
         factory=lambda **kw: CreditAssignmentTask(**kw),
         description="5 now vs 50 after 20 hold steps")
register("deceptive_param", level=5, caps=("deceptive", "credit_assignment"),
         factory=lambda **kw: DeceptiveChoice(**kw),
         description="parametric DeceptiveChoice: delay/small/large/"
                     "n_noise_actions/slip (cycle-4 factorial, H18)")
