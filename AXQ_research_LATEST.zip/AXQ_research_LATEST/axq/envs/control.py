"""L1 classic control environments: exact standard physics, vector obs.

Equations and parameters follow the canonical references — Barto, Sutton &
Anderson (1983) CartPole; Moore (1990) MountainCar; Sutton (1996) Acrobot;
Gymnasium Pendulum — with the standard Gymnasium defaults.  All envs are
deterministic given ``reset(seed)``; episode diagnostics are attached to the
info dict of the FINAL step of an episode (core convention).

Note on the Acrobot angle convention (identical to Gymnasium): ``theta = 0``
is the hanging (down) configuration and ``theta2`` is the *relative* elbow
angle; the goal is to raise the tip of the second link above the line where
``-cos(theta1) - cos(theta1 + theta2) > 1``.
"""
import numpy as np

from ..core.env import EnvBase
from .registry import register


def _wrap_angle(x):
    """Wrap an angle to [-pi, pi)."""
    return (x + np.pi) % (2.0 * np.pi) - np.pi


class CartPole(EnvBase):
    """Classic cart-pole balancing (Barto, Sutton & Anderson 1983).

    State ``[x, x_dot, theta, theta_dot]``; +1 reward per step (including the
    terminal step); terminated when ``|x| > 2.4`` or ``|theta| > 0.2095`` rad.
    Dynamics and parameters are the Gymnasium standard (Euler, tau=0.02).
    """

    obs_type = "vector"
    n_obs = 4
    n_actions = 2
    max_episode_steps = 500

    gravity = 9.8
    masscart = 1.0
    masspole = 0.1
    total_mass = masscart + masspole          # 1.1
    length = 0.5                              # half the pole's length
    polemass_length = masspole * length       # 0.05
    force_mag = 10.0
    tau = 0.02                                # seconds between state updates
    x_threshold = 2.4
    theta_threshold = 0.2095                  # ~12 degrees

    def _reset(self):
        self._state = self._rng.uniform(-0.05, 0.05, size=(4,))
        return self._state.copy()

    def _step(self, action):
        x, x_dot, theta, theta_dot = self._state
        force = self.force_mag if action == 1 else -self.force_mag
        costheta = np.cos(theta)
        sintheta = np.sin(theta)
        # standard cart-pole equations (Gymnasium CartPole-v1)
        temp = (force + self.polemass_length * theta_dot ** 2 * sintheta) / self.total_mass
        thetaacc = (self.gravity * sintheta - costheta * temp) / (
            self.length * (4.0 / 3.0 - self.masspole * costheta ** 2 / self.total_mass))
        xacc = temp - self.polemass_length * thetaacc * costheta / self.total_mass
        # Euler integration
        x = x + self.tau * x_dot
        x_dot = x_dot + self.tau * xacc
        theta = theta + self.tau * theta_dot
        theta_dot = theta_dot + self.tau * thetaacc
        self._state = np.array([x, x_dot, theta, theta_dot], dtype=np.float64)
        terminated = bool(
            x < -self.x_threshold or x > self.x_threshold
            or theta < -self.theta_threshold or theta > self.theta_threshold)
        info = {}
        if terminated or self._steps >= self.max_episode_steps:
            info["fell"] = terminated
            info["episode_steps"] = self._steps
        return self._state.copy(), 1.0, terminated, False, info


class CartPoleVStart(CartPole):
    """CartPole with a train/test reset-distribution shift (generalization).

    ``reset_dist="train"``: standard ``U(-0.05, 0.05)`` on all four dims.
    ``reset_dist="test"``: wider, unseen distribution
    ``x~U(-1.5,1.5), x_dot~U(-1,1), theta~U(-0.15,0.15), theta_dot~U(-1,1)``.
    """

    def __init__(self, reset_dist="train"):
        if reset_dist not in ("train", "test"):
            raise ValueError(f"reset_dist must be 'train' or 'test', got {reset_dist!r}")
        self.reset_dist = reset_dist

    def _reset(self):
        if self.reset_dist == "train":
            self._state = self._rng.uniform(-0.05, 0.05, size=(4,))
        else:
            self._state = np.array([
                self._rng.uniform(-1.5, 1.5),
                self._rng.uniform(-1.0, 1.0),
                self._rng.uniform(-0.15, 0.15),
                self._rng.uniform(-1.0, 1.0)], dtype=np.float64)
        return self._state.copy()


class MountainCar(EnvBase):
    """Moore's mountain car (Gymnasium MountainCar-v0 dynamics).

    State ``[position, velocity]``; -1 reward per step; terminated when
    ``position >= 0.5``.  The car's engine is too weak to climb directly:
    energy pumping (accelerating along the current velocity) is required.
    """

    obs_type = "vector"
    n_obs = 2
    n_actions = 3          # 0: force -1, 1: coast, 2: force +1
    max_episode_steps = 200

    min_position = -1.2
    max_position = 0.6
    max_speed = 0.07
    goal_position = 0.5
    power = 0.001
    gravity = 0.0025

    def _reset(self):
        self._pos = float(self._rng.uniform(-0.6, -0.4))
        self._vel = 0.0
        return self._obs()

    def _obs(self):
        return np.array([self._pos, self._vel], dtype=np.float64)

    def _step(self, action):
        force = action - 1                       # {0, 1, 2} -> {-1, 0, +1}
        self._vel += force * self.power + np.cos(3.0 * self._pos) * (-self.gravity)
        self._vel = min(max(self._vel, -self.max_speed), self.max_speed)
        self._pos += self._vel
        if self._pos < self.min_position:
            self._pos = self.min_position
            if self._vel < 0:
                self._vel = 0.0                  # stop at the left wall
        elif self._pos > self.max_position:
            self._pos = self.max_position
        terminated = bool(self._pos >= self.goal_position)
        info = {}
        if terminated or self._steps >= self.max_episode_steps:
            info["goal_reached"] = terminated
            info["final_position"] = self._pos
        return self._obs(), -1.0, terminated, False, info


class Acrobot(EnvBase):
    """Acrobot swing-up (Sutton 1996) with Gymnasium parameters.

    State ``[theta1, theta2, theta1_dot, theta2_dot]``; -1 reward per step;
    terminated when the tip of the second link reaches above the goal line:
    ``-cos(theta1) - cos(theta1 + theta2) > 1.0``.  Angles are wrapped to
    ``[-pi, pi)``; velocities are bounded to ``+-4*pi`` / ``+-9*pi``.
    Integration is semi-implicit (Verlet-style) Euler with ``dt = 0.2``.
    """

    obs_type = "vector"
    n_obs = 4
    n_actions = 3          # torques {-1, 0, +1} applied at the elbow
    max_episode_steps = 500

    l1 = 1.0
    l2 = 1.0
    m1 = 1.0
    m2 = 1.0
    lc1 = 0.5
    lc2 = 0.5
    I1 = 1.0
    I2 = 1.0
    g = 9.8
    dt = 0.2
    max_vel_1 = 4.0 * np.pi
    max_vel_2 = 9.0 * np.pi

    def _reset(self):
        self._s = self._rng.uniform(-0.1, 0.1, size=(4,))
        return self._s.copy()

    def _accel(self, th1, th2, dth1, dth2, torque):
        """Joint accelerations from the standard Acrobot equations of motion.

        ``phi1``/``phi2`` follow the classic (Gymnasium) formulation; the
        resulting linear system ``M(q) qddot = rhs`` is solved exactly.
        """
        m1, m2 = self.m1, self.m2
        l1, lc1, lc2 = self.l1, self.lc1, self.lc2
        I1, I2, g = self.I1, self.I2, self.g
        d1 = (m1 * lc1 ** 2
              + m2 * (l1 ** 2 + lc2 ** 2 + 2.0 * l1 * lc2 * np.cos(th2))
              + I1 + I2)
        d2 = m2 * (lc2 ** 2 + l1 * lc2 * np.cos(th2)) + I2
        phi2 = m2 * lc2 * g * np.cos(th1 + th2 - np.pi / 2.0)
        phi1 = (-m2 * l1 * lc2 * (dth2 ** 2 + 2.0 * dth1 * dth2) * np.sin(th2)
                + (m1 * lc1 + m2 * l1) * g * np.cos(th1 - np.pi / 2.0) + phi2)
        d22 = m2 * lc2 ** 2 + I2
        th2_ddot = ((torque + (d2 / d1) * phi1 - phi2
                     - m2 * l1 * lc2 * dth1 ** 2 * np.sin(th2))
                    / (d22 - d2 ** 2 / d1))
        th1_ddot = -(phi1 + d2 * th2_ddot) / d1
        return th1_ddot, th2_ddot

    def _step(self, action):
        torque = float(action) - 1.0
        th1, th2, dth1, dth2 = self._s
        th1_dd, th2_dd = self._accel(th1, th2, dth1, dth2, torque)
        # semi-implicit ("Verlet-style") Euler: velocities first, then angles
        dth1 = float(np.clip(dth1 + self.dt * th1_dd, -self.max_vel_1, self.max_vel_1))
        dth2 = float(np.clip(dth2 + self.dt * th2_dd, -self.max_vel_2, self.max_vel_2))
        th1 = _wrap_angle(th1 + self.dt * dth1)
        th2 = _wrap_angle(th2 + self.dt * dth2)
        self._s = np.array([th1, th2, dth1, dth2], dtype=np.float64)
        terminated = bool(-np.cos(th1) - np.cos(th1 + th2) > 1.0)
        info = {}
        if terminated or self._steps >= self.max_episode_steps:
            info["goal_reached"] = terminated
        return self._s.copy(), -1.0, terminated, False, info


class PendulumDiscrete(EnvBase):
    """Gymnasium Pendulum-v1 with a discretized torque (9 actions).

    State obs ``[cos(theta), sin(theta), theta_dot]``; torque grid
    ``linspace(-2, 2, 9)``; ``theta_dot`` clamped to ``[-8, 8]``; reward
    ``-(theta^2 + 0.1*theta_dot^2 + 0.001*torque^2)`` with theta wrapped to
    ``[-pi, pi]``.  Continuing task (truncates at 200 steps).
    """

    obs_type = "vector"
    n_obs = 3
    n_actions = 9
    max_episode_steps = 200

    g = 10.0
    m = 1.0
    l = 1.0
    dt = 0.05
    max_speed = 8.0

    def __init__(self):
        self._torques = np.linspace(-2.0, 2.0, self.n_actions)

    def _reset(self):
        self._th = float(self._rng.uniform(-np.pi, np.pi))
        self._thd = float(self._rng.uniform(-3.0, 3.0))
        return self._obs()

    def _obs(self):
        return np.array([np.cos(self._th), np.sin(self._th), self._thd],
                        dtype=np.float64)

    def _step(self, action):
        u = float(self._torques[action])
        thdot = self._thd + (-3.0 * self.g / (2.0 * self.l) * np.sin(self._th + np.pi)
                             + 3.0 / (self.m * self.l ** 2) * u) * self.dt
        thdot = float(np.clip(thdot, -self.max_speed, self.max_speed))
        self._th = _wrap_angle(self._th + self.dt * thdot)
        self._thd = thdot
        theta_norm = float(np.arctan2(np.sin(self._th), np.cos(self._th)))
        reward = -(theta_norm ** 2 + 0.1 * self._thd ** 2 + 0.001 * u ** 2)
        info = {}
        if self._steps >= self.max_episode_steps:
            info["final_theta"] = theta_norm
            info["final_theta_dot"] = self._thd
        return self._obs(), float(reward), False, False, info


# ---------------------------------------------------------------------------
register("cartpole", level=1, caps=("control",), factory=CartPole,
         description="Barto/Sutton cart-pole, +1/step, Euler physics (v1 limits)")
register("cartpole_vstart", level=1, caps=("control", "generalization"),
         factory=CartPoleVStart,
         description="cart-pole with train/test reset-distribution shift "
                     "(factory kwarg reset_dist)")
register("mountaincar", level=1, caps=("control", "credit_assignment"),
         factory=MountainCar,
         description="Moore mountain car; energy pumping required to reach 0.5")
register("acrobot", level=1, caps=("control", "credit_assignment"),
         factory=Acrobot,
         description="two-link underactuated swing-up; -1/step until tip is up")
register("pendulum_discrete", level=1, caps=("control",), factory=PendulumDiscrete,
         description="pendulum swing-up with 9 discrete torques; quadratic costs")
