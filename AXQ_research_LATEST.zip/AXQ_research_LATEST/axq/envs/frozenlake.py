"""Classic 4x4 FrozenLake with configurable slip probability (task 1-a).

Map: S start, F frozen, H hole (terminal, reward 0), G goal (terminal,
reward +1). With probability ``slip_prob`` the executed direction is
replaced by a uniformly random perpendicular direction. Moving out of
bounds keeps the agent in place. Step reward is 0.
"""
import numpy as np

from ..core.env import EnvBase
from .registry import register


class FrozenLake(EnvBase):
    """4x4 frozen lake; obs = r*4+c; 4 actions (0=up,1=right,2=down,3=left)."""

    obs_type = "discrete"
    n_actions = 4
    MOVES = ((-1, 0), (0, 1), (1, 0), (0, -1))
    DEFAULT_MAP = ("SFFF", "FHFH", "FFFH", "HFFG")

    def __init__(self, slip_prob=0.0, map=None, step_reward=0.0,
                 goal_reward=1.0, hole_reward=0.0, max_episode_steps=200):
        self.map = tuple(self.DEFAULT_MAP if map is None else map)
        self.rows = len(self.map)
        self.cols = len(self.map[0])
        self.slip_prob = float(slip_prob)
        self.step_reward = float(step_reward)
        self.goal_reward = float(goal_reward)
        self.hole_reward = float(hole_reward)
        self.max_episode_steps = int(max_episode_steps)
        self.n_obs = self.rows * self.cols
        self.holes = set()
        for r, row in enumerate(self.map):
            for c, ch in enumerate(row):
                if ch == "S":
                    self.start = (r, c)
                elif ch == "H":
                    self.holes.add((r, c))
                elif ch == "G":
                    self.goal = (r, c)

    # ------------------------------------------------------------------
    def _obs(self):
        return self._pos[0] * self.cols + self._pos[1]

    def _episode_diagnostics(self):
        return {"unique_states": len(self._visited),
                "success": self._pos == self.goal,
                "steps": self._steps}

    def _dir_probs(self, action):
        """(direction, prob) pairs of the EXECUTED direction."""
        if self.slip_prob <= 0.0:
            return ((action, 1.0),)
        p = self.slip_prob
        return ((action, 1.0 - p),
                ((action + 1) % 4, p / 2.0),
                ((action + 3) % 4, p / 2.0))

    def _exec_dir(self, action):
        """Sample the executed direction from self._rng (slip model)."""
        if self._rng.random() < self.slip_prob:
            action = (action + 1 + 2 * int(self._rng.integers(2))) % 4
        return action

    # ------------------------------------------------------------------
    def _reset(self):
        self._pos = tuple(self.start)
        self._visited = {self._pos}
        return self._obs()

    def _step(self, action):
        if self._pos == self.goal or self._pos in self.holes:
            return self._obs(), 0.0, True, False, self._episode_diagnostics()
        d = self._exec_dir(action)
        dr, dc = self.MOVES[d]
        r, c = self._pos
        nxt = (r + dr, c + dc)
        if not (0 <= nxt[0] < self.rows and 0 <= nxt[1] < self.cols):
            nxt = (r, c)
        self._pos = nxt
        self._visited.add(nxt)
        term = False
        reward = self.step_reward
        if nxt == self.goal:
            reward = self.goal_reward
            term = True
        elif nxt in self.holes:
            reward = self.hole_reward
            term = True
        info = (self._episode_diagnostics()
                if term or self._steps >= self.max_episode_steps else {})
        return self._obs(), reward, term, False, info

    # ------------------------------------------------------------------
    def mdp_model(self, gamma):
        """Exact stochastic model including the slip probabilities.

        P, R have shape [n_obs, n_actions, n_obs]; holes and the goal are
        absorbing with 0 reward. `gamma` is accepted for interface
        uniformity (the model is undiscounted).
        """
        S, A = self.n_obs, self.n_actions
        P = np.zeros((S, A, S))
        R = np.zeros((S, A, S))
        for r in range(self.rows):
            for c in range(self.cols):
                s = r * self.cols + c
                if (r, c) == self.goal or (r, c) in self.holes:
                    for a in range(A):
                        P[s, a, s] = 1.0
                    continue
                for a in range(A):
                    for d, p in self._dir_probs(a):
                        dr, dc = self.MOVES[d]
                        nr, nc = r + dr, c + dc
                        if not (0 <= nr < self.rows and 0 <= nc < self.cols):
                            nr, nc = r, c
                        ns = nr * self.cols + nc
                        P[s, a, ns] += p
                        if (nr, nc) == self.goal:
                            R[s, a, ns] = self.goal_reward
                        elif (nr, nc) in self.holes:
                            R[s, a, ns] = self.hole_reward
                        else:
                            R[s, a, ns] = self.step_reward
        return P, R


# ---------------------------------------------------------------------------
register("frozenlake_4x4", level=0, caps=("planning",),
         factory=lambda: FrozenLake(slip_prob=0.0, max_episode_steps=200),
         description="4x4 frozen lake, deterministic moves, +1 at the goal")

register("frozenlake_slippery", level=2, caps=("planning", "robustness"),
         factory=lambda: FrozenLake(slip_prob=0.3, max_episode_steps=200),
         description="4x4 lake; with p=0.3 the move slips to a random "
                     "perpendicular direction")
