"""L9/L10 self-play environments: tic-tac-toe vs scripted opponents.

Single-agent view (runner-compatible): the agent is always X and moves
first; after each agent move the opponent (a bot, an ``AgentBase`` or a
callable) replies as O.  Both players see the board from their own
perspective (own marks = 1, opponent marks = 2, encoded base-3), so agents
trained via ``SelfPlaySession`` transfer directly into the env.
"""
import numpy as np

from ..core.agent import AgentBase
from ..core.env import EnvBase
from .registry import register

X, O = 1, 2
EMPTY = 0

_WIN_LINES = ((0, 1, 2), (3, 4, 5), (6, 7, 8),
              (0, 3, 6), (1, 4, 7), (2, 5, 8),
              (0, 4, 8), (2, 4, 6))


def winner(cells):
    """1 if X owns a line, 2 if O does, else 0."""
    for a, b, c in _WIN_LINES:
        if cells[a] != 0 and cells[a] == cells[b] == cells[c]:
            return cells[a]
    return 0


def encode(cells, me):
    """Base-3 obs id from `me`'s perspective (own marks = 1, opponent = 2)."""
    opp = 3 - me
    v = 0
    for i in range(9):
        if cells[i] == me:
            v += 3 ** i
        elif cells[i] == opp:
            v += 2 * 3 ** i
    return v


def decode(obs):
    """Base-3 id -> 9-tuple of cells (own = 1, opponent = 2 for the viewer)."""
    v = int(obs)
    return tuple((v // 3 ** i) % 3 for i in range(9))


def _completing_cell(cells, player):
    """Cell that finishes a line for `player`, or -1."""
    for a, b, c in _WIN_LINES:
        line = (cells[a], cells[b], cells[c])
        if line.count(player) == 2 and line.count(0) == 1:
            return (a, b, c)[line.index(0)]
    return -1


# ---------------------------------------------------------------- bots
def bot_random(cells, mover, rng):
    """Uniform over legal moves."""
    legal = [i for i in range(9) if cells[i] == 0]
    return int(legal[int(rng.integers(len(legal)))])


def bot_heuristic(cells, mover, rng):
    """1) win 2) block 3) center 4) corner 5) random legal."""
    win = _completing_cell(cells, mover)
    if win >= 0:
        return win
    block = _completing_cell(cells, 3 - mover)
    if block >= 0:
        return block
    if cells[4] == 0:
        return 4
    for corner in (0, 2, 6, 8):
        if cells[corner] == 0:
            return corner
    return bot_random(cells, mover, rng)


_MM = {}          # module-level memo: cells tuple -> negamax value for mover


def _minimax_value(cells):
    """Exact game value for the player to move (+1 win, 0 draw, -1 loss).

    The mover is inferred from mark counts (X moves on even plies).  Memoized;
    values are tie-break independent, hence safe to share across instances.
    """
    val = _MM.get(cells)
    if val is not None:
        return val
    w = winner(cells)
    if w != 0:
        val = -1                       # the player to move has already lost
    elif 0 not in cells:
        val = 0
    else:
        mover = X if cells.count(X) == cells.count(O) else O
        best = -2
        for i in range(9):
            if cells[i] == 0:
                nxt = cells[:i] + (mover,) + cells[i + 1:]
                v = -_minimax_value(nxt)
                if v > best:
                    best = v
        val = best
    _MM[cells] = val
    return val


def bot_minimax(cells, mover, rng):
    """Perfect play; random tie-break among equally optimal moves."""
    best_v, best_moves = -2, []
    for i in range(9):
        if cells[i] == 0:
            nxt = cells[:i] + (mover,) + cells[i + 1:]
            v = -_minimax_value(nxt)   # value from `mover`'s perspective
            if v > best_v:
                best_v, best_moves = v, [i]
            elif v == best_v:
                best_moves.append(i)
    return int(best_moves[int(rng.integers(len(best_moves)))])


_BOTS = {"random": bot_random, "heuristic": bot_heuristic, "minimax": bot_minimax}


class TicTacToeVsOpponent(EnvBase):
    """Tic-tac-toe, agent = X (moves first) vs an opponent O.

    obs = base-3 board id from the agent's perspective (0 empty, 1 X, 2 O),
    n_obs = 3**9, n_actions = 9 (cell index).  Illegal move (occupied cell):
    reward -1.0, forfeit.  Win +1.0 / draw 0.0 / loss -1.0, delivered on the
    step that ends the game (an opponent winning move ends the episode and
    the agent gets -1 at that step).  A scripted opponent (AgentBase or
    callable) that returns an illegal cell forfeits: the agent wins +1.
    """

    obs_type = "discrete"
    n_obs = 3 ** 9
    n_actions = 9
    max_episode_steps = 9

    def __init__(self, opponent="random"):
        if isinstance(opponent, str):
            if opponent not in _BOTS:
                raise ValueError(f"unknown bot {opponent!r}; "
                                 f"choose from {sorted(_BOTS)}")
            self.opponent_kind = opponent
            self._opponent = None
        else:
            if not callable(opponent):
                raise ValueError("opponent must be a bot name, a callable "
                                 "or an AgentBase")
            self.opponent_kind = "external"
            self._opponent = opponent

    def _bot_action(self):
        """Opponent move; string bots draw from the env RNG (determinism)."""
        if self._opponent is None:
            return _BOTS[self.opponent_kind](self._cells, O, self._rng)
        obs_o = encode(self._cells, O)      # O's perspective: O = 1, X = 2
        if isinstance(self._opponent, AgentBase):
            return int(self._opponent.act(obs_o))
        return int(self._opponent(obs_o))

    def _reset(self):
        self._cells = (0,) * 9
        return encode(self._cells, X)

    def _step(self, action):
        if self._cells[action] != 0:
            return encode(self._cells, X), -1.0, True, False, {"result": "forfeit"}
        self._cells = self._cells[:action] + (X,) + self._cells[action + 1:]
        if winner(self._cells) == X:
            return encode(self._cells, X), 1.0, True, False, {"result": "win"}
        if 0 not in self._cells:
            return encode(self._cells, X), 0.0, True, False, {"result": "draw"}
        oa = self._bot_action()
        if not (0 <= oa < 9) or self._cells[oa] != 0:
            return encode(self._cells, X), 1.0, True, False, \
                {"result": "opponent_forfeit"}
        self._cells = self._cells[:oa] + (O,) + self._cells[oa + 1:]
        if winner(self._cells) == O:
            return encode(self._cells, X), -1.0, True, False, {"result": "loss"}
        if 0 not in self._cells:
            return encode(self._cells, X), 0.0, True, False, {"result": "draw"}
        return encode(self._cells, X), 0.0, False, False, {}


class BotAgent(AgentBase):
    """Wrap a scripted bot as an AgentBase (plays from its own perspective)."""

    def __init__(self, kind, seed=0, mover=X):
        if kind not in _BOTS:
            raise ValueError(f"unknown bot {kind!r}")
        self.kind = kind
        self.mover = mover
        self._rng = np.random.default_rng(seed)

    def act(self, obs, greedy=False):
        persp = decode(obs)                       # 1 = self, 2 = opponent
        me, opp = self.mover, 3 - self.mover
        cells = tuple(me if v == 1 else (opp if v == 2 else 0) for v in persp)
        return _BOTS[self.kind](cells, me, self._rng)


class SelfPlaySession:
    """Self-play training/eval loop for two agents on tic-tac-toe.

    ``play_game`` runs both agents on a shared board; each sees the board
    from its own perspective (own marks = 1).  Transitions are collected for
    both agents and flushed with the final reward on each agent's last move
    (intermediate moves earn 0).  Illegal move = forfeit (consistent with
    ``TicTacToeVsOpponent``).  Per-game stochasticity comes from the agents'
    own RNGs; ``rng_seed`` is carried in the record for provenance.
    """

    _RESULTS = {"x_win": (1.0, -1.0), "o_win": (-1.0, 1.0), "draw": (0.0, 0.0),
                "x_forfeit": (-1.0, 1.0), "o_forfeit": (1.0, -1.0)}

    def __init__(self, agent_x, agent_o):
        self.agent_x = agent_x
        self.agent_o = agent_o

    def play_game(self, agent_x, agent_o, rng_seed=0):
        """Play one full game, training both agents. Returns a record dict."""
        cells = (0,) * 9
        agents = {X: agent_x, O: agent_o}
        for ag in agents.values():
            ag.reset_state()
        trans = {X: [], O: []}
        result = None
        mover = X
        while True:
            agent = agents[mover]
            obs = encode(cells, mover)
            a = int(agent.act(obs))
            if not (0 <= a < 9) or cells[a] != 0:
                result = "x_forfeit" if mover == X else "o_forfeit"
                trans[mover].append((obs, a, obs))   # illegal move learns -1
                break
            cells = cells[:a] + (mover,) + cells[a + 1:]
            trans[mover].append((obs, a, encode(cells, mover)))
            if winner(cells) == mover:
                result = "x_win" if mover == X else "o_win"
                break
            if 0 not in cells:
                result = "draw"
                break
            mover = 3 - mover
        rx, ro = self._RESULTS[result]
        self._flush(agent_x, trans[X], rx)
        self._flush(agent_o, trans[O], ro)
        for ag in agents.values():
            ag.end_episode()
        return {"result": result, "x_reward": rx, "o_reward": ro,
                "rng_seed": int(rng_seed),
                "n_moves": len(trans[X]) + len(trans[O])}

    @staticmethod
    def _flush(agent, transitions, final_reward):
        """Deliver each transition; the agent's last move earns final_reward."""
        n = len(transitions)
        for k, (s, a, s2) in enumerate(transitions):
            last = (k == n - 1)
            reward = final_reward if last else 0.0
            agent.observe(s, a, reward, s2, last, False, {})
            agent.update()

    def play_and_train(self, n_games, base_seed=0):
        """Play n games, alternating which agent plays X. Returns a summary."""
        n_x = n_o = draws = 0
        for i in range(n_games):
            if i % 2 == 0:
                rec = self.play_game(self.agent_x, self.agent_o, base_seed + i)
                rx = rec["x_reward"]
            else:
                rec = self.play_game(self.agent_o, self.agent_x, base_seed + i)
                rx = rec["o_reward"]           # reward of self.agent_x
            if rx > 0:
                n_x += 1
            elif rx < 0:
                n_o += 1
            else:
                draws += 1
        return {"games": n_games,
                "agent_x_win_rate": n_x / n_games,
                "agent_o_win_rate": n_o / n_games,
                "draw_rate": draws / n_games}

    def eval_vs_bot(self, agent, bot_kind, n_games=100, base_seed=0, greedy=True):
        """Evaluate `agent` (as X, moving first) vs a scripted bot.

        Returns {"win", "draw", "loss"} rates plus raw counts.
        """
        if bot_kind not in _BOTS:
            raise ValueError(f"unknown bot {bot_kind!r}")
        bot = _BOTS[bot_kind]
        counts = {"win": 0, "draw": 0, "loss": 0}
        for i in range(n_games):
            rng = np.random.default_rng(base_seed + i)
            cells = (0,) * 9
            agent.reset_state()
            outcome = None
            while True:
                a = int(agent.act(encode(cells, X), greedy=greedy))
                if not (0 <= a < 9) or cells[a] != 0:
                    outcome = "loss"           # agent forfeits
                    break
                cells = cells[:a] + (X,) + cells[a + 1:]
                if winner(cells) == X:
                    outcome = "win"
                    break
                if 0 not in cells:
                    outcome = "draw"
                    break
                oa = bot(cells, O, rng)
                if not (0 <= oa < 9) or cells[oa] != 0:
                    outcome = "win"            # bot forfeits
                    break
                cells = cells[:oa] + (O,) + cells[oa + 1:]
                if winner(cells) == O:
                    outcome = "loss"
                    break
                if 0 not in cells:
                    outcome = "draw"
                    break
            counts[outcome] += 1
        return {"win": counts["win"] / n_games,
                "draw": counts["draw"] / n_games,
                "loss": counts["loss"] / n_games,
                "wins": counts["win"], "draws": counts["draw"],
                "losses": counts["loss"]}


# ---------------------------------------------------------------------------
register("tictactoe_vs_random", level=9, caps=("selfplay",),
         factory=lambda **kw: TicTacToeVsOpponent(opponent="random", **kw),
         description="tic-tac-toe vs uniform-random legal mover")
register("tictactoe_vs_heuristic", level=9, caps=("selfplay",),
         factory=lambda **kw: TicTacToeVsOpponent(opponent="heuristic", **kw),
         description="tic-tac-toe vs win/block/center/corner heuristic")
register("tictactoe_vs_minimax", level=9, caps=("selfplay",),
         factory=lambda **kw: TicTacToeVsOpponent(opponent="minimax", **kw),
         description="tic-tac-toe vs perfect (memoized minimax) opponent")
