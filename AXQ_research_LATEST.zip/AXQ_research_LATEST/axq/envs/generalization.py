"""Procedural room navigation with train/test map splits (task 1-a).

This is the L6 generalization test. Each reset samples a map seed
uniformly from the split's pool; the map (walls + far-apart start/goal,
BFS-valid) is generated DETERMINISTICALLY from that seed with a separate
``np.random.default_rng(map_seed + offset)`` stream, so test maps are
never seen during training (disjoint seed ranges).

obs = (r*size + c)*16 + wallbits, where wallbits encodes the walls around
the agent's cell (bit0=up, bit1=right, bit2=down, bit3=left; the grid
border counts as a wall). Local wall visibility is what makes
generalization across unseen layouts possible for memory-free agents.
"""
import numpy as np

from .gridworld import GridWorld
from .registry import register


class RoomNav(GridWorld):
    """Procedural rooms; train/test pools are disjoint by construction."""

    def __init__(self, split="train", n_train_maps=100, n_test_maps=1000,
                 size=8, wall_density=0.15, train_seed_base=10_000_000,
                 test_seed_base=20_000_000, step_reward=-0.01,
                 goal_reward=1.0, max_episode_steps=256, seed=None):
        super().__init__(size=size, walls=None, start=(0, 0),
                         goal=(size - 1, size - 1),
                         step_reward=step_reward, goal_reward=goal_reward,
                         max_episode_steps=max_episode_steps)
        if split not in ("train", "test"):
            raise ValueError(f"split must be 'train' or 'test', got {split!r}")
        self.split = split
        self.n_train_maps = int(n_train_maps)
        self.n_test_maps = int(n_test_maps)
        self.wall_density = float(wall_density)
        self.train_seed_base = int(train_seed_base)
        self.test_seed_base = int(test_seed_base)
        self.n_obs = size * size * 16
        self.current_map_seed = None

    # ------------------------------------------------------------------
    def _sample_map_seed(self):
        if self.split == "train":
            return self.train_seed_base + int(
                self._rng.integers(self.n_train_maps))
        return self.test_seed_base + int(self._rng.integers(self.n_test_maps))

    def _generate_map(self, map_seed):
        """Deterministic map from `map_seed`; retries with +1 offsets."""
        size, dens = self.size, self.wall_density
        for offset in range(1000):
            rng = np.random.default_rng(map_seed + offset)
            mask = rng.random((size, size)) < dens
            walls = {(r, c) for r in range(size) for c in range(size)
                     if mask[r, c]}
            free = sorted((r, c) for r in range(size) for c in range(size)
                          if (r, c) not in walls)
            if len(free) < 2:
                continue
            start = free[int(rng.integers(len(free)))]
            goal = free[int(rng.integers(len(free)))]
            if start == goal:
                continue
            if (abs(start[0] - goal[0]) + abs(start[1] - goal[1])) < size:
                continue                       # start/goal must be far apart
            if self.bfs_path(start, goal, walls) is None:
                continue                       # not connected -> regenerate
            self.walls = walls
            self.start = start
            self.goal = goal
            return
        raise RuntimeError("room_nav: failed to generate a valid map")

    def _reset(self):
        self.current_map_seed = self._sample_map_seed()
        self._generate_map(self.current_map_seed)
        return super()._reset()

    # ------------------------------------------------------------------
    def _obs(self):
        """Position index *16 + local wall bits (border counts as wall)."""
        r, c = self._pos
        size = self.size
        bits = 0
        if r == 0 or (r - 1, c) in self.walls:
            bits |= 1                           # wall up
        if c == size - 1 or (r, c + 1) in self.walls:
            bits |= 2                           # wall right
        if r == size - 1 or (r + 1, c) in self.walls:
            bits |= 4                           # wall down
        if c == 0 or (r, c - 1) in self.walls:
            bits |= 8                           # wall left
        return (r * size + c) * 16 + bits

    def current_map_signature(self):
        """Hashable full-layout signature (map seed, start, goal, walls)."""
        return (int(self.current_map_seed), tuple(self.start),
                tuple(self.goal), tuple(sorted(self.walls)))


# ---------------------------------------------------------------------------
register("room_nav_gen", level=6, caps=("generalization", "exploration"),
         factory=lambda **kwargs: RoomNav(**kwargs),
         description="procedural rooms, disjoint train/test map pools; obs "
                     "carries local wall bits for cross-layout transfer")
