"""GridWorld environment family (task 1-a).

Deterministic grid navigation with 4 actions (0=up, 1=right, 2=down,
3=left). Moving into a wall or out of bounds leaves the agent in place.
Episode diagnostics ("unique_states", "success", "steps") are reported in
the info dict of the FINAL step of an episode (terminated or truncated).

Registered variants: gridworld_dense, gridworld_sparse, maze_random,
keys_doors, deadend_maze, dynamic_obstacles.

Interpretation notes (documented deviations are also reported in the
worklog):
* keys_doors: start/goal were unspecified; we use (0,0)/(7,7) which lie in
  opposite halves so the locked door is mandatory. The boundary column
  size//2 - 1 is fully walled and contains exactly one door cell with a
  free neighbour on each side; the key always spawns in the start half
  (otherwise the task would be unsolvable).
* deadend_maze: in a 9x9 odd-cell perfect maze, walls between rooms are one
  cell thick, so a carved bait corridor may not touch ANY free cell except
  its branch point (otherwise it would create a shortcut, not a dead end).
  True dead-end corridors of length >= 3 therefore only exist along the
  outer border ring; we place up to 3 (length target 3-5, geometrically
  3-4), branching off the solution path first, then off free cells
  adjacent to the path. At least two corridors (at the start and goal
  corner rooms) are always placeable.
"""
import numpy as np
from collections import deque

from ..core.env import EnvBase
from .registry import register


def generate_maze(rng, size):
    """Perfect maze via randomized DFS on odd cells.

    Rooms live at odd (r, c); the carved passages form a spanning tree, so
    every free cell is reachable from every other free cell. Returns the
    set of WALL cells (everything not carved).
    """
    n_rooms = (size - 1) // 2
    walls = {(r, c) for r in range(size) for c in range(size)}
    seen = [[False] * n_rooms for _ in range(n_rooms)]
    seen[0][0] = True
    walls.discard((1, 1))
    stack = [(0, 0)]
    while stack:
        i, j = stack[-1]
        nbrs = []
        for di, dj in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            ni, nj = i + di, j + dj
            if 0 <= ni < n_rooms and 0 <= nj < n_rooms and not seen[ni][nj]:
                nbrs.append((ni, nj))
        if not nbrs:
            stack.pop()
            continue
        ni, nj = nbrs[int(rng.integers(len(nbrs)))]
        seen[ni][nj] = True
        # carve the wall between the two rooms, then the room cell itself
        walls.discard((2 * i + 1 + (ni - i), 2 * j + 1 + (nj - j)))
        walls.discard((2 * ni + 1, 2 * nj + 1))
        stack.append((ni, nj))
    return walls


class GridWorld(EnvBase):
    """Deterministic grid navigation with exact tabular model.

    obs = r*size + c (discrete). Reaching the goal terminates with
    goal_reward; every other step pays step_reward. ``mdp_model(gamma)``
    returns the exact (P, R) arrays of the CURRENT layout with the goal as
    an absorbing self-loop (0 reward).
    """

    obs_type = "discrete"
    n_actions = 4
    MOVES = ((-1, 0), (0, 1), (1, 0), (0, -1))   # 0=up 1=right 2=down 3=left

    def __init__(self, size=8, walls=None, start=(0, 0), goal=(7, 7),
                 step_reward=-0.01, goal_reward=1.0, max_episode_steps=256,
                 seed=None):
        self.size = int(size)
        self.walls = set(map(tuple, walls)) if walls is not None else set()
        self.start = tuple(start)
        self.goal = tuple(goal)
        self.step_reward = float(step_reward)
        self.goal_reward = float(goal_reward)
        self.max_episode_steps = int(max_episode_steps)
        self.n_obs = self.size * self.size
        # `seed` is intentionally ignored: envs are seeded via reset(seed).

    # ------------------------------------------------------------------
    # helpers (also used by subclasses / tests)
    def _obs(self):
        return self._pos[0] * self.size + self._pos[1]

    def _in_bounds(self, r, c):
        return 0 <= r < self.size and 0 <= c < self.size

    def _blocked(self, cell):
        """True if `cell` cannot be entered (outside or wall)."""
        return (not self._in_bounds(cell[0], cell[1])) or cell in self.walls

    def _episode_diagnostics(self):
        return {"unique_states": len(self._visited),
                "success": self._pos == self.goal,
                "steps": self._steps}

    def _after_move(self, prev_pos):
        """Hook for subclasses; called after every position update."""

    def bfs_path(self, start=None, goal=None, blocked=None):
        """BFS shortest path (list of cells incl. endpoints) or None."""
        start = tuple(self.start if start is None else start)
        goal = tuple(self.goal if goal is None else goal)
        blocked = self.walls if blocked is None else set(blocked)
        if start in blocked or goal in blocked:
            return None
        prev = {start: None}
        q = deque([start])
        while q:
            cur = q.popleft()
            if cur == goal:
                break
            for dr, dc in self.MOVES:
                n = (cur[0] + dr, cur[1] + dc)
                if (self._in_bounds(*n) and n not in blocked
                        and n not in prev):
                    prev[n] = cur
                    q.append(n)
        if goal not in prev:
            return None
        path, cur = [], goal
        while cur is not None:
            path.append(cur)
            cur = prev[cur]
        return path[::-1]

    def reachable(self, start=None, goal=None, blocked=None):
        """True if `goal` is reachable from `start` given the walls."""
        return self.bfs_path(start, goal, blocked) is not None

    # ------------------------------------------------------------------
    # EnvBase API
    def _reset(self):
        self._pos = tuple(self.start)
        self._visited = {self._pos}
        return self._obs()

    def _step(self, action):
        if self._pos == self.goal:          # absorbing after termination
            return self._obs(), 0.0, True, False, self._episode_diagnostics()
        dr, dc = self.MOVES[action]
        prev = self._pos
        nxt = (prev[0] + dr, prev[1] + dc)
        if self._blocked(nxt):
            nxt = prev
        self._pos = nxt
        self._visited.add(nxt)
        self._after_move(prev)
        term = nxt == self.goal
        reward = self.goal_reward if term else self.step_reward
        if term or self._steps >= self.max_episode_steps:
            info = self._episode_diagnostics()
        else:
            info = {}
        return self._obs(), reward, term, False, info

    # ------------------------------------------------------------------
    def mdp_model(self, gamma):
        """Exact tabular model (P, R) of the current layout.

        Shapes [n_obs, n_actions, n_obs]; deterministic transitions,
        including step costs; the goal is absorbing with 0 reward. `gamma`
        is accepted for interface uniformity (the model is undiscounted).
        """
        S = self.n_obs
        P = np.zeros((S, self.n_actions, S))
        R = np.zeros((S, self.n_actions, S))
        for r in range(self.size):
            for c in range(self.size):
                s = r * self.size + c
                if (r, c) == self.goal:
                    for a in range(self.n_actions):
                        P[s, a, s] = 1.0
                    continue
                for a, (dr, dc) in enumerate(self.MOVES):
                    nxt = (r + dr, c + dc)
                    if self._blocked(nxt):
                        nxt = (r, c)
                    ns = nxt[0] * self.size + nxt[1]
                    P[s, a, ns] = 1.0
                    R[s, a, ns] = (self.goal_reward if nxt == self.goal
                                   else self.step_reward)
        return P, R


class MazeRandom(GridWorld):
    """Perfect maze regenerated from the env RNG on every reset."""

    def __init__(self, size=9, start=(1, 1), goal=(7, 7), step_reward=0.0,
                 goal_reward=1.0, max_episode_steps=400, seed=None):
        super().__init__(size=size, walls=None, start=start, goal=goal,
                         step_reward=step_reward, goal_reward=goal_reward,
                         max_episode_steps=max_episode_steps)

    def _reset(self):
        self._regenerate_layout()
        return super()._reset()

    def _regenerate_layout(self):
        self.walls = generate_maze(self._rng, self.size)


class DeadendMaze(MazeRandom):
    """maze_random layout plus dead-end bait corridors off the solution path.

    Corridors are carved so that they are TRUE dead ends: no corridor cell
    touches any free cell except its branch point (see module docstring for
    the geometry note). ``dead_end_visits`` in the final-step info counts
    how many steps the agent spent on bait corridor cells.
    """

    def __init__(self, size=9, start=(1, 1), goal=(7, 7), n_corridors=3,
                 step_reward=0.0, goal_reward=1.0, max_episode_steps=400,
                 seed=None):
        super().__init__(size=size, start=start, goal=goal,
                         step_reward=step_reward, goal_reward=goal_reward,
                         max_episode_steps=max_episode_steps)
        self.n_corridors = int(n_corridors)
        self._dead_end_cells = set()
        self._dead_end_visits = 0
        self._bait_corridors = []

    def _regenerate_layout(self):
        super()._regenerate_layout()
        self._dead_end_cells = set()
        self._dead_end_visits = 0
        path = self.bfs_path(self.start, self.goal)
        if path is not None:
            self._place_bait_corridors(path)

    def _after_move(self, prev_pos):
        if self._pos in self._dead_end_cells:
            self._dead_end_visits += 1

    def _episode_diagnostics(self):
        info = super()._episode_diagnostics()
        info["dead_end_visits"] = int(self._dead_end_visits)
        return info

    def _place_bait_corridors(self, path):
        """Carve up to ``n_corridors`` dead-end bait corridors.

        A corridor is a chain of currently-wall cells starting next to a
        branch cell; each new cell may not touch any free cell except the
        branch (and its own chain). Branch cells are drawn from the
        solution path first, then from free cells adjacent to the path.
        """
        rng = self._rng
        free = ({(r, c) for r in range(self.size) for c in range(self.size)}
                - self.walls)
        placed = 0
        self._bait_corridors = []

        def cell_ok(cell, branch, chain):
            if not self._in_bounds(*cell) or cell not in self.walls:
                return False
            for dr, dc in self.MOVES:
                n = (cell[0] + dr, cell[1] + dc)
                if n in free and n != branch and n not in chain:
                    return False
            return True

        def try_corridor(branch):
            for a0 in rng.permutation(4):
                target = 3 + int(rng.integers(3))            # length 3..5
                chain = []
                d = int(a0)
                while len(chain) < target:
                    base = branch if not chain else chain[-1]
                    if chain:
                        cands = [d] + [x for x in rng.permutation(4)
                                       if x != d]
                    else:
                        cands = [d]
                    for x in cands:
                        cell = (base[0] + self.MOVES[x][0],
                                base[1] + self.MOVES[x][1])
                        if cell_ok(cell, branch, chain):
                            chain.append(cell)
                            d = x
                            break
                    else:
                        break                               # cannot extend
                if len(chain) >= 3:
                    return chain
            return None

        def attempt(branches):
            nonlocal placed
            for k in rng.permutation(len(branches)):
                if placed >= self.n_corridors:
                    return
                branch = tuple(branches[int(k)])
                chain = try_corridor(branch)
                if chain is None:
                    continue
                for cell in chain:
                    self.walls.discard(cell)
                    free.add(cell)
                self._dead_end_cells.update(chain)
                self._bait_corridors.append((branch, tuple(chain)))
                placed += 1

        attempt(list(path))
        if placed < self.n_corridors:
            near = set()
            for p in path:
                for dr, dc in self.MOVES:
                    n = (p[0] + dr, p[1] + dc)
                    if self._in_bounds(*n) and n not in self.walls:
                        near.add(n)
            near -= set(path)
            attempt(sorted(near))


class KeysDoors(GridWorld):
    """Fetch-the-key gridworld with a locked door between grid halves.

    Layout (regenerated each reset): random walls (density 0.15, layout
    regenerated until valid); the boundary column ``size//2 - 1`` is fully
    walled except for one DOOR cell chosen among wall cells with a free
    neighbour on each side. The door is impassable without the key. Start
    (0,0) and goal (7,7) are in opposite halves; the key spawns at a random
    free cell of the start half. obs = pos*2 + has_key (n_obs = 2*S).
    """

    def __init__(self, size=8, start=(0, 0), goal=(7, 7), wall_density=0.15,
                 step_reward=0.0, goal_reward=1.0, max_episode_steps=256,
                 seed=None):
        super().__init__(size=size, walls=None, start=start, goal=goal,
                         step_reward=step_reward, goal_reward=goal_reward,
                         max_episode_steps=max_episode_steps)
        bcol = self.size // 2 - 1
        if start[1] == bcol or goal[1] == bcol:
            raise ValueError("start/goal must not lie on the boundary column")
        self.wall_density = float(wall_density)
        self.n_obs = 2 * self.size * self.size
        self.door_cell = None
        self.key_cell = None
        self._has_key = False

    # -- layout -----------------------------------------------------------
    def _generate_layout(self):
        size, rng = self.size, self._rng
        bcol = size // 2 - 1
        for _ in range(1000):
            mask = rng.random((size, size)) < self.wall_density
            walls = {(r, c) for r in range(size) for c in range(size)
                     if mask[r, c]}
            walls.update((r, bcol) for r in range(size))    # seal boundary
            walls.discard(self.start)
            walls.discard(self.goal)
            free = ({(r, c) for r in range(size) for c in range(size)}
                    - walls)
            # door: boundary wall cell with a free neighbour on each side
            cands = [r for r in range(size)
                     if (r, bcol - 1) in free and (r, bcol + 1) in free]
            if not cands:
                continue
            door = (int(cands[int(rng.integers(len(cands)))]), bcol)
            # key: random free cell of the start half (else unsolvable)
            left = sorted(c for c in free if c[1] < bcol and c != self.start)
            if not left:
                continue
            key = left[int(rng.integers(len(left)))]
            # solvability: door closed -> start reaches key and the door's
            # left neighbour; the door's right neighbour reaches the goal
            sealed = walls | {door}
            if self.bfs_path(self.start, key, sealed) is None:
                continue
            if self.bfs_path(self.start, (door[0], bcol - 1), sealed) is None:
                continue
            if self.bfs_path((door[0], bcol + 1), self.goal, sealed) is None:
                continue
            self.walls = walls
            self.door_cell = door
            self.key_cell = key
            return
        raise RuntimeError("keys_doors: failed to generate a valid layout")

    # -- GridWorld extension points ---------------------------------------
    def _blocked(self, cell):
        if not self._in_bounds(cell[0], cell[1]):
            return True
        if cell in self.walls:
            return not (cell == self.door_cell and self._has_key)
        return False

    def _obs(self):
        return (self._pos[0] * self.size + self._pos[1]) * 2 + int(self._has_key)

    def _reset(self):
        self._generate_layout()
        self._has_key = False
        return super()._reset()

    def _final_info(self):
        info = self._episode_diagnostics()
        info["got_key"] = bool(self._has_key)
        return info

    def _step(self, action):
        if self._pos == self.goal:          # absorbing after termination
            return self._obs(), 0.0, True, False, self._final_info()
        dr, dc = self.MOVES[action]
        prev = self._pos
        nxt = (prev[0] + dr, prev[1] + dc)
        if self._blocked(nxt):
            nxt = prev
        self._pos = nxt
        self._visited.add(nxt)
        if not self._has_key and nxt == self.key_cell:
            self._has_key = True            # auto-pickup, no extra reward
        term = nxt == self.goal
        reward = self.goal_reward if term else self.step_reward
        info = self._final_info() if term or self._steps >= self.max_episode_steps else {}
        return self._obs(), reward, term, False, info

    def mdp_model(self, gamma):
        """Exact model over the augmented space s = pos*2 + has_key."""
        S, A = self.n_obs, self.n_actions
        P = np.zeros((S, A, S))
        R = np.zeros((S, A, S))
        size = self.size
        for r in range(size):
            for c in range(size):
                for k in (0, 1):
                    s = (r * size + c) * 2 + k
                    if (r, c) == self.goal:
                        for a in range(A):
                            P[s, a, s] = 1.0
                        continue
                    for a, (dr, dc) in enumerate(self.MOVES):
                        nxt = (r + dr, c + dc)
                        blocked = (not self._in_bounds(*nxt)) or (
                            nxt in self.walls
                            and not (nxt == self.door_cell and k == 1))
                        if blocked:
                            nxt = (r, c)
                        nk = 1 if (k == 1 or nxt == self.key_cell) else 0
                        ns = (nxt[0] * size + nxt[1]) * 2 + nk
                        P[s, a, ns] = 1.0
                        R[s, a, ns] = (self.goal_reward if nxt == self.goal
                                       else self.step_reward)
        return P, R


class DynamicObstacles(GridWorld):
    """Open grid with randomly walking, UNOBSERVED obstacles.

    Each step every obstacle performs a lazy random walk: it stays put or
    moves to a uniformly random valid neighbour (inside the grid, never
    onto the start or goal cells). If the agent steps onto an obstacle or
    an obstacle steps onto the agent, the episode terminates with reward
    -1; reaching the goal terminates with +1. Obstacles are not part of
    the observation: the task tests robustness to hidden stochastic
    dynamics.

    Documented deviations from the task spec (tuned so that the spec's own
    "beeline succeeds > 0.3" requirement holds with margin): obstacles may
    STAY as a random-walk move, and they spawn at Manhattan distance >= 3
    from the start and >= 2 from the goal (avoids unfair spawn-adjacent
    collisions). Measured beeline success ~0.40, random-walk-with-always-
    move obstacles + uniform spawn ~0.35.

    Note: the inherited ``mdp_model`` models the agent-only chain and
    IGNORES the obstacles; value iteration on it yields the obstacle-blind
    beeline policy.
    """

    def __init__(self, size=8, n_obstacles=4, start=(0, 0), goal=(7, 7),
                 step_reward=0.0, goal_reward=1.0, collision_reward=-1.0,
                 spawn_min_start_dist=3, spawn_min_goal_dist=2,
                 max_episode_steps=256, seed=None):
        super().__init__(size=size, walls=None, start=start, goal=goal,
                         step_reward=step_reward, goal_reward=goal_reward,
                         max_episode_steps=max_episode_steps)
        self.n_obstacles = int(n_obstacles)
        self.collision_reward = float(collision_reward)
        self.spawn_min_start_dist = int(spawn_min_start_dist)
        self.spawn_min_goal_dist = int(spawn_min_goal_dist)

    def _reset(self):
        rng = self._rng
        s, g = self.start, self.goal
        cells = [(r, c) for r in range(self.size) for c in range(self.size)
                 if (r, c) != s and (r, c) != g
                 and abs(r - s[0]) + abs(c - s[1]) >= self.spawn_min_start_dist
                 and abs(r - g[0]) + abs(c - g[1]) >= self.spawn_min_goal_dist]
        picks = rng.choice(len(cells), size=self.n_obstacles, replace=False)
        self._obstacles = tuple(cells[int(i)] for i in picks)
        self._collision = False
        return super()._reset()

    def _episode_diagnostics(self):
        info = super()._episode_diagnostics()
        info["collision"] = bool(self._collision)
        return info

    def _step(self, action):
        dr, dc = self.MOVES[action]
        prev = self._pos
        nxt = (prev[0] + dr, prev[1] + dc)
        if not self._in_bounds(*nxt):
            nxt = prev
        self._pos = nxt
        self._visited.add(nxt)
        if nxt == self.goal:
            return self._obs(), self.goal_reward, True, False, \
                self._episode_diagnostics()
        if nxt in self._obstacles:          # agent lands on an obstacle
            self._collision = True
            return self._obs(), self.collision_reward, True, False, \
                self._episode_diagnostics()
        # obstacles random-walk (lazy: staying put is a valid move; never
        # onto start/goal)
        moved = []
        for (orr, occ) in self._obstacles:
            opts = [(orr, occ)]
            for dr2, dc2 in self.MOVES:
                t = (orr + dr2, occ + dc2)
                if (self._in_bounds(*t) and t != self.goal
                        and t != self.start):
                    opts.append(t)
            moved.append(opts[int(self._rng.integers(len(opts)))])
        self._obstacles = tuple(moved)
        if self._pos in self._obstacles:    # obstacle lands on the agent
            self._collision = True
            return self._obs(), self.collision_reward, True, False, \
                self._episode_diagnostics()
        info = (self._episode_diagnostics()
                if self._steps >= self.max_episode_steps else {})
        return self._obs(), self.step_reward, False, False, info


# ---------------------------------------------------------------------------
# registrations
# ---------------------------------------------------------------------------
register("gridworld_dense", level=0, caps=("exploration",),
         factory=lambda: GridWorld(size=4, start=(0, 0), goal=(3, 3),
                                   step_reward=-0.01, goal_reward=1.0,
                                   max_episode_steps=100),
         description="4x4 gridworld, -0.01/step; shortest-path navigation")

# NOTE (documented deviation): the spec prescribed max_episode_steps=256
# for gridworld_sparse, but an exact computation shows a uniform random walk
# then reaches the goal with probability 0.501, violating the spec's own
# "random success < 0.35" hardness requirement. At 96 steps the exact hit
# probability is 0.160 while the optimal policy still needs only 14 steps.
register("gridworld_sparse", level=2, caps=("sparse", "exploration"),
         factory=lambda: GridWorld(size=8, start=(0, 0), goal=(7, 7),
                                   step_reward=0.0, goal_reward=1.0,
                                   max_episode_steps=96),
         description="8x8 open grid, reward only at the far-corner goal")

# NOTE (documented deviation): spec max_episode_steps=400 gives random-policy
# success ~0.38 (n=500), violating the spec's own "random success < 0.2"
# requirement; at 160 steps it is ~0.11.
register("maze_random", level=2, caps=("sparse", "exploration", "planning"),
         factory=lambda: MazeRandom(max_episode_steps=160),
         description="9x9 perfect maze (DFS on odd cells) regenerated each "
                     "reset; reward only at the goal")

# NOTE (documented deviation): spec max_episode_steps=256 gives random-policy
# success ~0.15, right AT the spec's own "random success < 0.15" bound; at
# 160 steps it is ~0.07 and the optimal key->door->goal path needs ~30.
register("keys_doors", level=2, caps=("sparse", "exploration", "planning"),
         factory=lambda: KeysDoors(max_episode_steps=160),
         description="fetch the key, pass the locked door between grid "
                     "halves, reach the far-corner goal")

# NOTE (documented deviation): 200 steps (not the inherited 400) so that the
# random-policy success stays low (~0.08, n=1000) like the other L2 envs.
register("deadend_maze", level=2, caps=("sparse", "exploration"),
         factory=lambda: DeadendMaze(max_episode_steps=200),
         description="perfect maze plus dead-end bait corridors branching "
                     "off the solution path")

register("dynamic_obstacles", level=2, caps=("exploration", "robustness"),
         factory=lambda: DynamicObstacles(),
         description="open grid with 4 unobserved random-walking obstacles; "
                     "collision terminates with -1")
