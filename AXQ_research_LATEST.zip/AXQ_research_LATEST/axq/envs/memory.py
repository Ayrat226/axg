"""L3 memory environments: POMDPs that REQUIRE carrying information forward.

A memoryless (reactive) policy conditions only on the current observation.
By construction the choice-time observation carries no symbol information, so
reactive policies cap at chance level (1/n_symbols); a policy that stores the
early symbol and emits it at the choice step scores 1.0.
"""
import numpy as np

from ..core.env import EnvBase
from .registry import register


class MemoryCorridor(EnvBase):
    """Show a symbol, walk a corridor of uninformative steps, pick the door.

    Timeline (corridor_len=L, n_symbols=S):
      t=0        obs = symbol s in [0, S)
      t=1..L     obs = S + (t-1)   corridor phases, NO symbol information
      t=L+1      obs = S + L       choice marker (identical for all symbols)
      t=L+2      action = door; +1 if a == s else 0.0; terminated
    ``info['correct']`` (bool) is set on the final step.  Reactive policies
    cap at 1/S because the choice-phase observation is symbol-independent.
    """

    obs_type = "discrete"

    def __init__(self, corridor_len=8, n_symbols=2):
        if n_symbols < 2:
            raise ValueError("n_symbols must be >= 2")
        self.corridor_len = int(corridor_len)
        self.n_symbols = int(n_symbols)
        self.n_obs = 2 * self.n_symbols + self.corridor_len
        self.n_actions = self.n_symbols
        self.max_episode_steps = self.corridor_len + 2

    @property
    def marker_obs(self):
        """Observation id of the choice marker."""
        return self.n_symbols + self.corridor_len

    def _reset(self):
        self._symbol = int(self._rng.integers(self.n_symbols))
        return self._symbol

    def _step(self, action):
        k = self._steps                     # 1-based step index
        s, ell = self.n_symbols, self.corridor_len
        if k <= ell:                        # corridor phases
            return s + (k - 1), 0.0, False, False, {}
        if k == ell + 1:                    # choice marker
            return self.marker_obs, 0.0, False, False, {}
        correct = bool(int(action) == self._symbol)
        return self.marker_obs, (1.0 if correct else 0.0), True, False, \
            {"correct": correct}


class DelayedMatch(EnvBase):
    """Delayed match-to-sample with a RANDOM delay length.

    t=0: obs = symbol; then N ~ randint[delay_min, delay_max] (inclusive)
    filler steps with obs = n_symbols (no information); then the choice
    marker obs = n_symbols + 1; the matching symbol earns +1, else 0.
    """

    obs_type = "discrete"

    def __init__(self, delay_min=10, delay_max=50, n_symbols=2):
        if not 0 < delay_min <= delay_max:
            raise ValueError("need 0 < delay_min <= delay_max")
        self.delay_min = int(delay_min)
        self.delay_max = int(delay_max)
        self.n_symbols = int(n_symbols)
        self.n_obs = self.n_symbols + 2
        self.n_actions = self.n_symbols
        self.max_episode_steps = self.delay_max + 2

    @property
    def marker_obs(self):
        return self.n_symbols + 1

    def _reset(self):
        self._symbol = int(self._rng.integers(self.n_symbols))
        self._n = int(self._rng.integers(self.delay_min, self.delay_max + 1))
        return self._symbol

    def _step(self, action):
        k = self._steps
        s = self.n_symbols
        if k <= self._n:                    # filler steps
            return s, 0.0, False, False, {}
        if k == self._n + 1:                # choice marker
            return self.marker_obs, 0.0, False, False, {}
        correct = bool(int(action) == self._symbol)
        return self.marker_obs, (1.0 if correct else 0.0), True, False, \
            {"correct": correct, "delay": self._n}


class HiddenStateTask(EnvBase):
    """One hidden bit, then n_phases identical rooms; the correct action is b.

    t=0: obs = hidden bit b in {0, 1}; each of the n_phases rooms shows
    obs = 2 (identical).  In every room action == b earns +0.25 (continue),
    any other action earns 0.0 and terminates.  All rooms passed: total
    reward n_phases * 0.25 = 1.0.  ``info['score']`` = phases passed.
    """

    obs_type = "discrete"
    n_obs = 3
    n_actions = 2

    def __init__(self, n_phases=4):
        if n_phases < 1:
            raise ValueError("n_phases must be >= 1")
        self.n_phases = int(n_phases)
        self.max_episode_steps = self.n_phases + 1

    def _reset(self):
        self._bit = int(self._rng.integers(2))
        self._passed = 0
        return self._bit

    def _step(self, action):
        correct = bool(int(action) == self._bit)
        if correct:
            self._passed += 1
            terminated = self._passed >= self.n_phases
            reward = 0.25
        else:
            terminated = True
            reward = 0.0
        info = {}
        if terminated or self._steps >= self.max_episode_steps:
            info["score"] = self._passed
        return 2, float(reward), terminated, False, info


# ---------------------------------------------------------------------------
register("memory_corridor_8", level=3, caps=("memory",),
         factory=lambda **kw: MemoryCorridor(corridor_len=8, **kw),
         description="remember a symbol across 8 blank steps, then match it")
register("memory_corridor_16", level=3, caps=("memory",),
         factory=lambda **kw: MemoryCorridor(corridor_len=16, **kw),
         description="remember a symbol across 16 blank steps, then match it")
register("memory_corridor_32", level=3, caps=("memory",),
         factory=lambda **kw: MemoryCorridor(corridor_len=32, **kw),
         description="remember a symbol across 32 blank steps, then match it")
register("memory_corridor_64", level=3, caps=("memory",),
         factory=lambda **kw: MemoryCorridor(corridor_len=64, **kw),
         description="remember a symbol across 64 blank steps, then match it")
register("delayed_match_10_50", level=3, caps=("memory",),
         factory=lambda **kw: DelayedMatch(delay_min=10, delay_max=50, **kw),
         description="match-to-sample with a random 10..50 step delay")
register("delayed_match_50_100", level=3, caps=("memory",),
         factory=lambda **kw: DelayedMatch(delay_min=50, delay_max=100, **kw),
         description="match-to-sample with a random 50..100 step delay")
register("hidden_state", level=3, caps=("memory",),
         factory=lambda **kw: HiddenStateTask(n_phases=4, **kw),
         description="one hidden bit governs 4 identical rooms (+0.25 each)")
