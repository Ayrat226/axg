"""L8 multitask / continual-learning protocol helpers.

Provides task suites (name, env_factory) pairs), a sequential train/eval
protocol (``run_task_sequence``) and a forgetting metric.  Suite envs reuse
``GridWorld`` from ``axq.envs.gridworld`` (Subagent A) and the control envs
from ``axq.envs.control``.
"""
import numpy as np

from ..core.runner import train, evaluate
from .control import CartPole
from .gridworld import GridWorld


class SparseGridLayoutEnv(GridWorld):
    """8x8 sparse gridworld with a FIXED wall layout (continual-suite task).

    ~25% of interior cells become walls, generated deterministically from
    ``layout_seed`` (start (0,0) / goal (7,7) always kept clear) and re-rolled
    until the goal is reachable.  Sparse reward: +1 at the goal, 0 otherwise
    (``step_reward=0``); 150-step episodes.  Inherits the exact tabular
    ``mdp_model`` from GridWorld.

    Cycle-4 addition: ``goal_override`` moves the goal cell (same walls /
    same dynamics) — used by the SF/GPI shared-layout suite (H19).
    """

    def __init__(self, layout_seed=101, wall_prob=0.25, size=8,
                 goal_override=None):
        # Phase 1: wall roll with the DEFAULT goal — byte-identical to the
        # pre-cycle-4 code path for every layout_seed (g1 reproducibility;
        # the rng draw sequence must not depend on the goal position).
        rng = np.random.default_rng(int(layout_seed))
        start, default_goal = (0, 0), (size - 1, size - 1)
        probe = GridWorld(size=size)             # only for its BFS helper
        while True:
            walls = set()
            for r in range(size):
                for c in range(size):
                    if (r, c) not in (start, default_goal) \
                            and rng.random() < wall_prob:
                        walls.add((r, c))
            if probe.reachable(start=start, goal=default_goal,
                               blocked=walls):
                break
        # Phase 2: goal override REUSES the same walls (shared dynamics);
        # reachability of the overridden goal is enforced here.
        goal = default_goal
        if goal_override is not None:
            goal = tuple(int(x) for x in goal_override)
            if not (0 <= goal[0] < size and 0 <= goal[1] < size):
                raise ValueError("goal_override out of grid")
            if not probe.reachable(start=start, goal=goal, blocked=walls):
                raise ValueError(
                    "goal_override %r unreachable with layout_seed=%d"
                    % (goal, int(layout_seed)))
        super().__init__(size=size, walls=walls, start=start, goal=goal,
                         step_reward=0.0, goal_reward=1.0,
                         max_episode_steps=150)


class CartPoleWideStart(CartPole):
    """CartPole reset at U(-0.3, 0.3) in all four dims (distribution shift)."""

    def _reset(self):
        self._state = self._rng.uniform(-0.3, 0.3, size=(4,))
        return self._state.copy()


class TaskSequenceSuite:
    """Ordered suite of (task_name, env_factory) pairs for continual learning."""

    def __init__(self, name, tasks):
        self.name = str(name)
        self.tasks = [(str(n), f) for (n, f) in tasks]

    def __len__(self):
        return len(self.tasks)

    def names(self):
        return [n for n, _ in self.tasks]


SUITES = {
    "continual_gridworlds": TaskSequenceSuite("continual_gridworlds", [
        ("gw1", lambda: SparseGridLayoutEnv(layout_seed=101)),
        ("gw2", lambda: SparseGridLayoutEnv(layout_seed=102)),
        ("gw3", lambda: SparseGridLayoutEnv(layout_seed=103)),
        ("gw4", lambda: SparseGridLayoutEnv(layout_seed=104)),
        ("gw5", lambda: SparseGridLayoutEnv(layout_seed=105)),
    ]),
    # H19 (cycle 4): SHARED-layout suite — identical walls/dynamics across
    # tasks, only the goal cell moves. This is the canonical SF/GPI setting
    # (same transitions, different rewards); the layout-varying suite above
    # serves as the SF negative control (dynamics change => psi invalid).
    "continual_gridworlds_shared": TaskSequenceSuite(
        "continual_gridworlds_shared", [
            ("sg1", lambda: SparseGridLayoutEnv(layout_seed=202,
                                                 goal_override=(7, 7))),
            ("sg2", lambda: SparseGridLayoutEnv(layout_seed=202,
                                                 goal_override=(7, 0))),
            ("sg3", lambda: SparseGridLayoutEnv(layout_seed=202,
                                                 goal_override=(0, 7))),
            ("sg4", lambda: SparseGridLayoutEnv(layout_seed=202,
                                                 goal_override=(3, 4))),
            ("sg5", lambda: SparseGridLayoutEnv(layout_seed=202,
                                                 goal_override=(5, 2))),
        ]),
    "continual_cartpole": TaskSequenceSuite("continual_cartpole", [
        ("cp_normal", CartPole),
        ("cp_wide", CartPoleWideStart),
        ("cp_normal2", CartPole),
    ]),
}


def run_task_sequence(agent_factory, suite_name, phase_steps, eval_episodes=20,
                      seed=0, eval_base_seed=555555):
    """Train ONE agent sequentially over a suite; evaluate on all tasks/phase.

    The agent persists across phases (continual learning).  Phase i trains on
    task i for ``phase_steps`` env steps (``axq.core.runner.train`` with
    ``eval_env=None``); after each phase the agent is evaluated greedily on
    every suite task with held-out eval seeds (``eval_base_seed + 1009*j``).

    Returns ``{"phases": [task names],
               "matrix": matrix[i][j] = mean eval reward on task j after
                                        training phase i}``.
    """
    suite = SUITES[suite_name]
    agent = agent_factory(seed)
    matrix = []
    for i, (_, factory) in enumerate(suite.tasks):
        env = factory()
        train(agent, env, total_steps=phase_steps, eval_env=None, seed=seed + i)
        row = []
        for j, (_, eval_factory) in enumerate(suite.tasks):
            ev = evaluate(agent, eval_factory(), episodes=eval_episodes,
                          base_seed=eval_base_seed + 1009 * j, greedy=True)
            row.append(ev["mean"])
        matrix.append(row)
    return {"phases": suite.names(), "matrix": matrix}


def forgetting(matrix, phases, tasks):
    """Per-task forgetting: score right after a task's own phase - final score.

    Assumes task j was trained in phase j (aligned name lists, as produced by
    ``run_task_sequence``).  Returns {task_name: forgetting}.
    """
    if len(matrix) != len(phases):
        raise ValueError("matrix rows must match phases")
    if len(tasks) > len(phases):
        raise ValueError("more tasks than phases")
    last = len(matrix) - 1
    out = {}
    for j, name in enumerate(tasks):
        after_own_phase = matrix[j][j]
        final = matrix[last][j]
        out[name] = float(after_own_phase - final)
    return out
