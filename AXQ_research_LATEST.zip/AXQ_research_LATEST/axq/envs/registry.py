"""Environment registry with capability tags and level metadata.

Capability vocabulary (fixed set):
  exploration, memory, planning, credit_assignment, control, generalization,
  robustness, deceptive, selfplay, multitask, sparse

Levels follow the user's capability ladder L0..L10 (see docs/BENCHMARK.md).
"""
REGISTRY = {}


def register(env_id, level, caps, factory, description=""):
    if env_id in REGISTRY:
        raise ValueError(f"duplicate env id: {env_id}")
    REGISTRY[env_id] = {
        "env_id": env_id,
        "level": int(level),
        "caps": tuple(caps),
        "factory": factory,
        "description": description,
    }
    return REGISTRY[env_id]


def make(env_id, **kwargs):
    import axq.envs  # noqa: F401  (triggers registration)
    if env_id not in REGISTRY:
        raise KeyError(f"unknown env '{env_id}'. known: {sorted(REGISTRY)}")
    return REGISTRY[env_id]["factory"](**kwargs)


def envs_at_level(level):
    import axq.envs  # noqa: F401
    return sorted(k for k, v in REGISTRY.items() if v["level"] == level)


def envs_with_cap(cap):
    import axq.envs  # noqa: F401
    return sorted(k for k, v in REGISTRY.items() if cap in v["caps"])


def catalog():
    import axq.envs  # noqa: F401
    return {k: {kk: vv for kk, vv in v.items() if kk != "factory"}
            for k, v in sorted(REGISTRY.items())}
