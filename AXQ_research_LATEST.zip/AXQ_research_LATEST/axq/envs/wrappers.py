"""L7 robustness wrappers: applied at evaluation time on trained agents.

Each wrapper subclasses EnvBase, delegates obs_type/n_obs/n_actions/
max_episode_steps from the inner env, and owns a separate RNG stream
``self._wrng = np.random.default_rng([seed, 7919])`` derived from the reset
seed (so wrapper noise never collides with the inner env's noise stream).
"""
from collections import deque

import numpy as np

from ..core.env import EnvBase


class Wrapper(EnvBase):
    """Base wrapper: delegates the env contract, keeps a private RNG stream."""

    def __init__(self, env):
        self.env = env
        self.obs_type = env.obs_type
        self.n_obs = env.n_obs
        self.n_actions = env.n_actions
        self.max_episode_steps = env.max_episode_steps
        self._wrng = np.random.default_rng([0, 7919])
        self._seed = None

    def reset(self, seed=None):
        """Reset wrapper + inner env; re-derive the wrapper RNG when seeded."""
        if seed is not None:
            self._wrng = np.random.default_rng([seed, 7919])
        self._seed = seed
        return super().reset(seed)

    def _reset(self):
        return self.env.reset(self._seed)

    @property
    def unwrapped(self):
        return self.env.unwrapped


class ObsNoiseWrapper(Wrapper):
    """Observation noise.

    Vector envs: ``obs' = obs + N(0, sigma * std_i)`` where ``std_i`` is the
    per-dimension std measured from a 200-step random-rollout calibration
    (computed lazily on the first reset, cached per instance).
    Discrete envs: with probability ``sigma`` the obs index is replaced by a
    uniformly random index.
    """

    def __init__(self, env, sigma=0.1):
        super().__init__(env)
        if sigma < 0:
            raise ValueError("sigma must be >= 0")
        self.sigma = float(sigma)
        self._std = None if env.obs_type == "vector" else "discrete"

    def _calibrate(self):
        """Measure per-dim obs stds via a random rollout (deterministic)."""
        rng = np.random.default_rng(4242)          # calibration action stream
        samples = []
        obs = self.env.reset(999983)               # calibration seeds; irrelevant
        samples.append(np.asarray(obs, dtype=np.float64))
        for _ in range(200):
            a = int(rng.integers(self.env.n_actions))
            obs, _, term, trunc, _ = self.env.step(a)
            samples.append(np.asarray(obs, dtype=np.float64))
            if term or trunc:
                obs = self.env.reset(999983 + len(samples))
                samples.append(np.asarray(obs, dtype=np.float64))
        std = np.stack(samples).std(axis=0)
        self._std = np.maximum(std, 1e-8)          # floor for constant dims

    def _perturb(self, obs):
        if self.obs_type == "vector":
            if self.sigma == 0.0:
                return obs
            return (np.asarray(obs, dtype=np.float64)
                    + self._wrng.normal(0.0, self.sigma * self._std))
        if self.sigma == 0.0:
            return obs
        if self._wrng.random() < self.sigma:
            return int(self._wrng.integers(self.n_obs))
        return obs

    def _reset(self):
        if self._std is None:
            self._calibrate()
        return self._perturb(self.env.reset(self._seed))

    def _step(self, action):
        obs, r, term, trunc, info = self.env.step(int(action))
        return self._perturb(obs), r, term, trunc, info


class ActionDelayWrapper(Wrapper):
    """The executed action is a stale one from a FIFO queue of length `delay`.

    The queue starts filled with action 0; on each step the chosen action is
    pushed and the oldest queued action is executed.
    """

    def __init__(self, env, delay=1):
        super().__init__(env)
        if int(delay) < 1:
            raise ValueError("delay must be >= 1")
        self.delay = int(delay)

    def _reset(self):
        self._queue = deque([0] * self.delay)
        return self.env.reset(self._seed)

    def _step(self, action):
        self._queue.append(int(action))
        executed = self._queue.popleft()
        return self.env.step(executed)


class StickyActionsWrapper(Wrapper):
    """With probability p the previous executed action is repeated instead."""

    def __init__(self, env, p=0.2):
        super().__init__(env)
        if not 0.0 <= p <= 1.0:
            raise ValueError("p must be in [0, 1]")
        self.p = float(p)

    def _reset(self):
        self._prev = 0
        return self.env.reset(self._seed)

    def _step(self, action):
        if self._wrng.random() < self.p:
            executed = self._prev
        else:
            executed = int(action)
        self._prev = executed
        return self.env.step(executed)


class ObsDropoutWrapper(Wrapper):
    """With probability p the observation is replaced by a blank.

    Vector envs: all-zeros vector; discrete envs: index 0.
    """

    def __init__(self, env, p=0.1):
        super().__init__(env)
        if not 0.0 <= p <= 1.0:
            raise ValueError("p must be in [0, 1]")
        self.p = float(p)

    def _drop(self, obs):
        if self._wrng.random() < self.p:
            if self.obs_type == "vector":
                return np.zeros(self.n_obs, dtype=np.float64)
            return 0
        return obs

    def _reset(self):
        return self._drop(self.env.reset(self._seed))

    def _step(self, action):
        obs, r, term, trunc, info = self.env.step(int(action))
        return self._drop(obs), r, term, trunc, info


class ActionPermutationWrapper(Wrapper):
    """Fixed random permutation pi of action ids; chosen action a executes pi[a]."""

    def __init__(self, env, perm_seed=0):
        super().__init__(env)
        self.perm_seed = int(perm_seed)
        self._perm = np.random.default_rng(self.perm_seed).permutation(self.n_actions)

    @property
    def permutation(self):
        """The fixed bijection (a -> permutation[a])."""
        return self._perm.copy()

    def _step(self, action):
        return self.env.step(int(self._perm[int(action)]))
