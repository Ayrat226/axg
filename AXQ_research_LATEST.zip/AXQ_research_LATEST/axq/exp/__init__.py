"""Experiment infrastructure: rigorous statistics, provenance journal,
unified experiment protocol, and learning-curve analysis.

This package is the trust anchor for all experimental claims: every method
comparison goes through :mod:`axq.exp.stats`, every run is journaled with a
code fingerprint via :mod:`axq.exp.journal`, execution follows the unified
protocol in :mod:`axq.exp.protocol`, and metrics are computed by
:mod:`axq.exp.analysis`.
"""
from . import analysis, journal, protocol, stats
from .analysis import (auc, forgetting_matrix, generalization_gap,
                       robustness_curve, sample_efficiency,
                       steps_to_threshold)
from .journal import ExperimentJournal, code_fingerprint, to_jsonable
from .protocol import (LEVEL_BUDGETS, ExperimentConfig, compare_runs,
                       run_experiment)
from .stats import (bootstrap_ci, fdr_bh, holm, independent_compare,
                    min_detectable_note, paired_compare, summarize)

__all__ = [
    "analysis", "journal", "protocol", "stats",
    "auc", "forgetting_matrix", "generalization_gap", "robustness_curve",
    "sample_efficiency", "steps_to_threshold",
    "ExperimentJournal", "code_fingerprint", "to_jsonable",
    "LEVEL_BUDGETS", "ExperimentConfig", "compare_runs", "run_experiment",
    "bootstrap_ci", "fdr_bh", "holm", "independent_compare",
    "min_detectable_note", "paired_compare", "summarize",
]
