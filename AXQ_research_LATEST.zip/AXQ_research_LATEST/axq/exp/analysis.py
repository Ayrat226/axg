"""Learning-curve and benchmark analysis metrics.

All functions are pure (no I/O) and verify on hand-computable synthetic data
(see tests/test_stats.py). Curves are lists of ``(step, score)`` tuples.
"""
from __future__ import annotations

import numpy as np

__all__ = [
    "steps_to_threshold",
    "sample_efficiency",
    "auc",
    "forgetting_matrix",
    "generalization_gap",
    "robustness_curve",
]


def _as_curve(curve):
    """Split a curve into (xs, ys) sorted by step."""
    pts = sorted(((float(s), float(v)) for s, v in curve), key=lambda p: p[0])
    return [p[0] for p in pts], [p[1] for p in pts]


def steps_to_threshold(curve, threshold):
    """First step at which the curve reaches ``threshold``; None if never.

    Linear interpolation between the surrounding eval points. If the very
    first recorded point is already >= threshold, the first step is returned
    (crossing happened before the first measurement -- lower bound).
    """
    if curve is None or len(curve) == 0:
        return None
    xs, ys = _as_curve(curve)
    if ys[0] >= threshold:
        return xs[0]
    for i in range(1, len(xs)):
        if ys[i] >= threshold:
            t = (threshold - ys[i - 1]) / (ys[i] - ys[i - 1])
            return xs[i - 1] + t * (xs[i] - xs[i - 1])
    return None


def sample_efficiency(runs, reference, fracs=(0.5, 0.7, 0.9, 0.95)):
    """Steps needed to reach fractions of a reference score, per run.

    For each fraction: ``median_steps`` over the runs that reached it
    (None if none did) and ``success_rate`` over all runs. Runs that never
    reach the target count as failures in ``success_rate`` but do not poison
    the median with infinities.
    """
    runs = list(runs)
    if not runs:
        raise ValueError("sample_efficiency needs at least one run")
    out = {}
    for frac in fracs:
        target = float(reference) * float(frac)
        reached = []
        for curve in runs:
            st = steps_to_threshold(curve, target)
            if st is not None:
                reached.append(st)
        out[float(frac)] = {
            "target_score": target,
            "median_steps": float(np.median(reached)) if reached else None,
            "success_rate": len(reached) / len(runs),
            "n_reached": len(reached),
            "n_runs": len(runs),
        }
    return out


def auc(curve, budget):
    """Normalized area under the learning curve (trapezoid, x/budget).

    A curve that sits flat at value v across [0, budget] has AUC v; a curve
    that ramps linearly 0 -> v has AUC v/2. Single-point curves return that
    point's score; empty curves return None.
    """
    if curve is None or len(curve) == 0:
        return None
    if budget <= 0:
        raise ValueError("budget must be positive")
    xs, ys = _as_curve(curve)
    if len(xs) == 1:
        return float(ys[0])
    return float(np.trapezoid(ys, xs) / float(budget))


def forgetting_matrix(matrix, task_names):
    """Continual-learning diagnostics from a phase x task score matrix.

    ``matrix[i][j]`` = score on task j measured after training phase i
    (phase i trains task i). Definitions:
      forgetting_j   = matrix[j][j] - matrix[-1][j]
                       (own-phase score minus final score; >= 0 means the
                       agent forgot task j during later phases)
      positive_transfer_j = matrix[-1][j] > matrix[0][j]
                       (final score beats the earliest measurement of task j,
                       i.e. the whole task sequence helped beyond what was
                       transferred/measured right after phase 0)
    """
    m = np.asarray(matrix, dtype=np.float64)
    names = list(task_names)
    if m.ndim != 2 or m.shape[0] != m.shape[1]:
        raise ValueError("matrix must be square (phases x tasks)")
    if len(names) != m.shape[0]:
        raise ValueError("task_names length must match matrix size")
    t = m.shape[0]
    forgetting = {names[j]: float(m[j, j] - m[-1, j]) for j in range(t)}
    positive = {names[j]: bool(m[-1, j] > m[0, j]) for j in range(t)}
    return {
        "task_names": names,
        "forgetting": forgetting,
        "mean_forgetting": float(np.mean([forgetting[n] for n in names])),
        "positive_transfer": positive,
        "n_tasks": t,
    }


def generalization_gap(train_score, test_score):
    """train - test score (>= 0 typically). Sequences are averaged first."""
    def _mean(v):
        arr = np.asarray(v, dtype=np.float64)
        if arr.size == 0:
            raise ValueError("empty score input")
        return float(arr.mean())

    return _mean(train_score) - _mean(test_score)


def robustness_curve(scores_by_level):
    """Robustness summary over perturbation levels.

    ``scores_by_level`` maps level (numeric key) to a score or a sequence of
    scores (averaged). Returns the sorted levels/scores, the linear-fit slope
    (negative = performance degrades with perturbation strength), and the
    trapezoid area over the level axis normalized by the level span (equal to
    the plain mean for unit-spaced levels).
    """
    if not scores_by_level:
        raise ValueError("empty scores_by_level")
    levels, scores = [], []
    for k, v in scores_by_level.items():
        arr = np.asarray(v, dtype=np.float64)
        if arr.size == 0:
            raise ValueError(f"no scores for level {k!r}")
        levels.append(float(k))
        scores.append(float(arr.mean()))
    order = np.argsort(levels)
    lv = np.asarray(levels, dtype=np.float64)[order]
    sc = np.asarray(scores, dtype=np.float64)[order]
    if lv.size >= 2:
        slope, intercept = np.polyfit(lv, sc, 1)
        slope, intercept = float(slope), float(intercept)
        span = float(lv[-1] - lv[0])
        area = float(np.trapezoid(sc, lv) / span) if span > 0 else float(sc.mean())
    else:
        slope, intercept = 0.0, float(sc[0])
        area = float(sc[0])
    return {
        "levels": [float(x) for x in lv],
        "scores": [float(x) for x in sc],
        "slope": slope,
        "intercept": intercept,
        "area": area,
        "mean": float(sc.mean()),
    }
