"""Experiment journal: append-only JSONL records with code provenance.

Every experiment appends one record containing all REQUIRED fields plus an
automatic UTC timestamp and a sha256 fingerprint of the axq source tree, so
any result can later be traced to the exact code that produced it.
"""
from __future__ import annotations

import dataclasses
import datetime as _dt
import hashlib
import json
import pathlib

import numpy as np

__all__ = ["ExperimentJournal", "code_fingerprint", "to_jsonable"]

_FINGERPRINT_HEADER = b"axq-code-fingerprint-v1"


def code_fingerprint(root: str = "/home/z/my-project/axq") -> str:
    """sha256 hex over the experiment-relevant source, sorted by path.

    Tracked (audit 9-b M1): all ``axq/**/*.py`` EXCEPT ``axq/kb/`` (the
    knowledge-base tooling is not experiment code) PLUS every
    ``scripts/*.py`` experiment driver. Unrelated files (tests, results,
    notes) never affect it. Stable across calls for an unchanged tree;
    changes whenever any tracked file is added, removed, renamed, edited.
    """
    root = pathlib.Path(root)
    if not root.is_dir():
        raise FileNotFoundError(f"fingerprint root not found: {root}")
    tracked = []
    for p in root.rglob("*.py"):
        if not p.is_file():
            continue
        rel = p.relative_to(root)
        if rel.parts and rel.parts[0] == "kb":
            continue                      # KB tooling: not experiment code
        tracked.append((rel.as_posix(), p))
    scripts = pathlib.Path("/home/z/my-project/scripts")
    if scripts.is_dir():
        for p in scripts.glob("*.py"):
            if p.is_file():
                tracked.append(("__scripts__/" + p.name, p))
    tracked.sort(key=lambda t: t[0])
    h = hashlib.sha256()
    h.update(_FINGERPRINT_HEADER)
    h.update(f"nfiles={len(tracked)}".encode("utf-8"))
    for rel, p in tracked:
        h.update(rel.encode("utf-8"))
        h.update(b"\x00")
        h.update(p.read_bytes())
        h.update(b"\x00")
    return h.hexdigest()


def to_jsonable(o):
    """Best-effort conversion of numpy / dataclass / set / Path objects."""
    if isinstance(o, np.generic):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    if dataclasses.is_dataclass(o) and not isinstance(o, type):
        return dataclasses.asdict(o)
    if isinstance(o, (set, frozenset)):
        return sorted(o)
    if isinstance(o, pathlib.Path):
        return str(o)
    if isinstance(o, (bytes, bytearray)):
        return o.decode("utf-8", "replace")
    return str(o)


class ExperimentJournal:
    """Append-only JSONL experiment journal with schema validation.

    One JSON object per line; ``ts`` (UTC ISO) and ``code_version``
    (code fingerprint) are stamped automatically on every append.
    """

    REQUIRED = ("exp_id", "ts", "code_version", "hypothesis_id", "env",
                "agent", "config", "seeds", "budget_steps", "status")

    def __init__(self, path):
        self.path = pathlib.Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.touch()
        self._counter = 0

    def next_id(self, prefix: str = "exp") -> str:
        """New id ``{prefix}-{YYYYmmdd-HHMMSS}-{counter:03d}`` (UTC time).

        The counter is per journal instance; a uniqueness check against the
        existing records guards against collisions after reloads.
        """
        existing = {rec.get("exp_id") for rec in self.load()}
        while True:
            self._counter += 1
            ts = _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%d-%H%M%S")
            candidate = f"{prefix}-{ts}-{self._counter:03d}"
            if candidate not in existing:
                return candidate

    def append(self, record: dict) -> dict:
        """Validate and append one record; auto-stamps ts and code_version.

        Raises ValueError listing all missing REQUIRED fields.
        """
        if not isinstance(record, dict):
            raise TypeError("journal record must be a dict")
        rec = dict(record)
        rec["ts"] = _dt.datetime.now(_dt.timezone.utc).isoformat()
        rec["code_version"] = code_fingerprint()
        missing = [f for f in self.REQUIRED if f not in rec]
        if missing:
            raise ValueError(f"journal record missing required fields: {missing}")
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, default=to_jsonable) + "\n")
        return rec

    def load(self) -> list:
        """All records as dicts, in append order."""
        out = []
        for i, line in enumerate(
                self.path.read_text(encoding="utf-8").splitlines(), 1):
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"corrupt journal line {i}: {exc}") from exc
        return out
