"""Unified experiment protocol: config, execution, persistence, comparison.

Protocol guarantees:
* every seed gets a FRESH train env and a FRESH eval env (identical params),
  an agent seeded with the run seed, and train()'s FIXED eval seed set, so
  curves are comparable across algorithms / seeds / time;
* per-seed JSON records plus an aggregate summary.json under
  ``results_dir/<exp_id>/`` (curves, final evals, timing, config, code
  fingerprint);
* optional ExperimentJournal record with all REQUIRED provenance fields;
* comparisons always PAIRED BY SEED through axq.exp.stats.paired_compare.
"""
from __future__ import annotations

import datetime as _dt
import json
import pathlib
from dataclasses import asdict, dataclass, field

import numpy as np

from .analysis import auc
from .journal import code_fingerprint, to_jsonable
from .stats import paired_compare, summarize

__all__ = ["LEVEL_BUDGETS", "ExperimentConfig", "run_experiment", "compare_runs"]

#: Default interaction budgets per capability level (env steps per seed).
LEVEL_BUDGETS = {0: 10000, 1: 60000, 2: 100000, 3: 100000, 4: 60000,
                 5: 60000, 6: 100000, 9: 60000}


@dataclass
class ExperimentConfig:
    """Specification of one experiment run.

    Required entries (agent_name, agent_params, env_id, seeds, budget_steps)
    are keyword-only so the optional bookkeeping fields can keep their
    declared order.
    """

    exp_id: str = ""
    hypothesis_id: str = ""
    agent_name: str = field(kw_only=True)
    agent_params: dict = field(kw_only=True)
    env_id: str = field(kw_only=True)
    seeds: list = field(kw_only=True)
    budget_steps: int = field(kw_only=True)
    env_params: dict = field(default_factory=dict)
    eval_interval: int = 5000
    eval_episodes: int = 20
    reference_score: float | None = None   # failure-rate / normalization ref
    tags: list = field(default_factory=list)
    notes: str = ""

    def __post_init__(self):
        self.seeds = [int(s) for s in self.seeds]
        self.budget_steps = int(self.budget_steps)
        self.eval_interval = int(self.eval_interval)
        self.eval_episodes = int(self.eval_episodes)
        self.agent_params = dict(self.agent_params)
        self.env_params = dict(self.env_params)
        self.tags = list(self.tags)
        if not self.seeds:
            raise ValueError("ExperimentConfig.seeds must be non-empty")
        if len(set(self.seeds)) != len(self.seeds):
            raise ValueError("ExperimentConfig.seeds must be unique "
                             "(paired statistics require distinct seeds)")
        if self.budget_steps <= 0 or self.eval_interval <= 0 \
                or self.eval_episodes <= 0:
            raise ValueError("budget_steps/eval_interval/eval_episodes "
                             "must be positive")
        if self.reference_score is not None:
            self.reference_score = float(self.reference_score)

    def to_dict(self) -> dict:
        """JSON-ready copy of the full config."""
        return asdict(self)


def _resolve_make_agent():
    """Return ``axq.agents.make_agent`` if available, else a 'random'-only
    fallback built on axq.core.agent.RandomAgent.

    The fallback keeps the protocol runnable while the agents package is
    still under construction; once axq.agents exports make_agent, the real
    registry is used automatically.
    """
    try:
        from axq.agents import make_agent  # type: ignore
        return make_agent
    except ImportError:
        pass
    from axq.core.agent import RandomAgent

    def make_agent_fallback(name, n_obs, obs_type, n_actions, seed=0, **params):
        if name == "random":
            return RandomAgent(int(n_actions), seed=seed)
        raise ImportError('axq.agents unavailable; only agent_name="random" '
                          "is supported by the fallback factory")

    return make_agent_fallback


def _write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, default=to_jsonable) + "\n",
                    encoding="utf-8")


def _read_json(path):
    return json.loads(pathlib.Path(path).read_text(encoding="utf-8"))


def run_experiment(cfg, results_dir, journal=None, save_agents=False) -> dict:
    """Run one experiment (all seeds) and persist everything; returns summary.

    Per seed: ``results_dir/<exp_id>/seed_<s>.json`` with the learning curve,
    final eval stats, per-episode rewards, timing. Aggregate:
    ``summary.json`` with per-seed final means, summarize() of them, AUCs,
    failure info vs reference_score (if set), the config dump and the code
    fingerprint. If ``journal`` is given, one REQUIRED-schema record is
    appended. If ``save_agents`` is True, per-seed agent checkpoints are
    written to ``results_dir/<exp_id>/agent_<name>_seed<s>.npz`` (weights
    only, no buffer) for downstream robustness/antitest evaluation.
    """
    from axq.envs import make                      # lazy per spec
    from axq.core.runner import train              # lazy per spec
    make_agent = _resolve_make_agent()

    if not isinstance(cfg, ExperimentConfig):
        raise TypeError("run_experiment expects an ExperimentConfig")
    if cfg.exp_id == "":
        cfg.exp_id = ("exp-" + _dt.datetime.now(_dt.timezone.utc)
                      .strftime("%Y%m%d-%H%M%S-%f"))

    out_dir = pathlib.Path(results_dir) / cfg.exp_id
    out_dir.mkdir(parents=True, exist_ok=True)

    finals, aucs, total_wall = [], [], 0.0
    for seed in cfg.seeds:
        env = make(cfg.env_id, **cfg.env_params)
        eval_env = make(cfg.env_id, **cfg.env_params)   # fresh; fixed eval seeds
        agent = make_agent(cfg.agent_name, n_obs=env.n_obs,
                           obs_type=env.obs_type, n_actions=env.n_actions,
                           seed=seed, **cfg.agent_params)
        res = train(agent, env, total_steps=cfg.budget_steps,
                    eval_interval=cfg.eval_interval, eval_env=eval_env,
                    eval_episodes=cfg.eval_episodes, seed=seed)
        if save_agents and hasattr(agent, "save"):
            agent.save(out_dir / f"agent_{cfg.agent_name}_seed{seed}.npz")
        fe = res["final_eval"]
        seed_rec = {
            "seed": int(seed),
            "curve": [[int(s), float(v)] for s, v in res["curve"]],
            "final_eval": {k: v for k, v in fe.items() if k != "rewards"},
            "rewards": [float(r) for r in fe["rewards"]],
            "episodes": int(res["episodes"]),
            "total_steps": int(res["total_steps"]),
            "steps_per_sec": float(res["steps_per_sec"]),
            "wall_time_s": float(res["wall_time_s"]),
        }
        _write_json(out_dir / f"seed_{seed}.json", seed_rec)
        finals.append(float(fe["mean"]))
        aucs.append(auc(res["curve"], cfg.budget_steps))
        total_wall += float(res["wall_time_s"])

    summary = {
        "exp_id": cfg.exp_id,
        "hypothesis_id": cfg.hypothesis_id,
        "env": cfg.env_id,
        "agent": cfg.agent_name,
        "seeds": list(cfg.seeds),
        "budget_steps": int(cfg.budget_steps),
        "eval_interval": int(cfg.eval_interval),
        "eval_episodes": int(cfg.eval_episodes),
        "final_mean_per_seed": finals,
        "final_mean_summary": summarize(finals),
        "auc_per_seed": aucs,
        "auc_summary": (summarize(aucs)
                        if aucs and all(a is not None for a in aucs) else None),
        "total_wall_time_s": total_wall,
        "config": cfg.to_dict(),
        "code_version": code_fingerprint(),
    }
    if cfg.reference_score is not None:
        fails = [f < cfg.reference_score for f in finals]
        summary["reference_score"] = float(cfg.reference_score)
        summary["failures_per_seed"] = [bool(f) for f in fails]
        summary["failure_rate"] = float(np.mean(fails))

    _write_json(out_dir / "summary.json", summary)

    if journal is not None:
        journal.append({
            "exp_id": cfg.exp_id,
            "hypothesis_id": cfg.hypothesis_id,
            "env": cfg.env_id,
            "agent": cfg.agent_name,
            "config": cfg.to_dict(),
            "seeds": list(cfg.seeds),
            "budget_steps": int(cfg.budget_steps),
            "status": "completed",
            "results_dir": str(out_dir),
            "metrics": {
                "final_mean_per_seed": finals,
                "final_mean_summary": summary["final_mean_summary"],
                "failure_rate": summary.get("failure_rate"),
            },
        })
    return summary


def compare_runs(results_dir, exp_id_a, exp_id_b, metric="final_mean",
                 journal=None) -> dict:
    """Paired-by-seed comparison of two completed experiments.

    Loads both summary.json files, intersects the seed lists (>= 2 common
    seeds required), aligns the per-seed metrics by seed and runs
    ``stats.paired_compare``. ``metric`` is "final_mean" or "auc".
    """
    root = pathlib.Path(results_dir)
    if metric == "final_mean":
        key = "final_mean_per_seed"
    elif metric == "auc":
        key = "auc_per_seed"
    else:
        raise ValueError('metric must be "final_mean" or "auc"')
    sa = _read_json(root / exp_id_a / "summary.json")
    sb = _read_json(root / exp_id_b / "summary.json")
    for name, s in ((exp_id_a, sa), (exp_id_b, sb)):
        if len(set(s["seeds"])) != len(s["seeds"]):
            raise ValueError(f"duplicate seeds in {name} summary")
    common = sorted(set(sa["seeds"]) & set(sb["seeds"]))
    if len(common) < 2:
        raise ValueError("paired comparison needs >= 2 common seeds, "
                         f"got {common}")
    va = dict(zip(sa["seeds"], sa[key]))
    vb = dict(zip(sb["seeds"], sb[key]))
    if any(va[s] is None or vb[s] is None for s in common):
        raise ValueError(f"metric {metric!r} unavailable (None values in "
                         "one of the runs)")
    a = [float(va[s]) for s in common]
    b = [float(vb[s]) for s in common]

    out = paired_compare(a, b)
    out.update({"exp_id_a": exp_id_a, "exp_id_b": exp_id_b,
                "metric": metric, "seeds": [int(s) for s in common]})

    if journal is not None:
        journal.append({
            "exp_id": f"cmp-{exp_id_a}-vs-{exp_id_b}",
            "hypothesis_id": f"compare:{exp_id_a}:{exp_id_b}",
            "env": str(sa.get("env", "")),
            "agent": f"{sa.get('agent', '?')} vs {sb.get('agent', '?')}",
            "config": {"metric": metric, "exp_id_a": exp_id_a,
                       "exp_id_b": exp_id_b},
            "seeds": [int(s) for s in common],
            "budget_steps": int(sa.get("budget_steps", 0)),
            "status": "comparison",
            "results_dir": str(root),
            "metrics": {"wilcoxon_p": out["wilcoxon_p"],
                        "mean_diff": out["mean_diff"],
                        "significant_005": out["significant_005"]},
        })
    return out
