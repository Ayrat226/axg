"""Rigorous paired statistics for algorithm comparison (project trust anchor).

Protocol decisions (documented, per project spec):
* All method comparisons are PAIRED BY SEED: both algorithms run on identical
  seeds, so ``paired_compare`` is the default analysis. ``independent_compare``
  exists only for genuinely unpaired data.
* Significance at alpha=0.05 requires BOTH (a) Wilcoxon signed-rank p < 0.05
  AND (b) the 95% percentile bootstrap CI of the mean difference excluding 0.
  A single significant test is never sufficient.
* p >= 0.05 means "insufficient evidence of difference" -- it is NEVER
  evidence of equality (no equivalence testing here).
* Bootstrap resamples PAIR indices with replacement (preserves pairing),
  B=10000 by default, seeded Generator => fully deterministic.
* Multiple comparisons: Holm step-down (family-wise error) and
  Benjamini-Hochberg (false discovery rate).
"""
from __future__ import annotations

import math

import numpy as np
from scipy import stats as _sstats

__all__ = [
    "summarize",
    "paired_compare",
    "independent_compare",
    "holm",
    "fdr_bh",
    "bootstrap_ci",
    "min_detectable_note",
]

_ALTERNATIVES = ("two-sided", "greater", "less")
_MAX_BOOT_ELEMS = 2_000_000  # chunk bootstrap resamples above this many elements


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _check_alternative(alternative):
    if alternative not in _ALTERNATIVES:
        raise ValueError(
            f"alternative must be one of {_ALTERNATIVES}, got {alternative!r}")


def _boot_rows(rng, n, rows):
    """Row indices of `rows` bootstrap resamples of range(n)."""
    return rng.integers(0, n, size=(rows, n))


def _paired_bootstrap(d, B, rng):
    """Bootstrap mean and median of the paired differences `d` (resample
    PAIR indices). Returns (means, medians), each length B."""
    n = d.size
    means = np.empty(B, dtype=np.float64)
    medians = np.empty(B, dtype=np.float64)
    chunk = max(1, min(B, _MAX_BOOT_ELEMS // max(n, 1)))
    done = 0
    while done < B:
        rows = min(chunk, B - done)
        samp = d[_boot_rows(rng, n, rows)]
        means[done:done + rows] = samp.mean(axis=1)
        medians[done:done + rows] = np.median(samp, axis=1)
        done += rows
    return means, medians


def _boot_stat(x, stat, B, rng):
    """Bootstrap distribution of `stat` (callable over (samples, axis)) of x."""
    n = x.size
    out = np.empty(B, dtype=np.float64)
    chunk = max(1, min(B, _MAX_BOOT_ELEMS // max(n, 1)))
    done = 0
    while done < B:
        rows = min(chunk, B - done)
        samp = x[_boot_rows(rng, n, rows)]
        out[done:done + rows] = stat(samp, axis=1)
        done += rows
    return out


def _insufficient_note(p):
    if p >= 0.05:
        return "insufficient evidence of difference (do NOT conclude equality)"
    return ""


# ---------------------------------------------------------------------------
# descriptive
# ---------------------------------------------------------------------------
def _exact_wilcoxon_p(nz, alternative="two-sided"):
    """Exact Wilcoxon signed-rank p-value by full sign-flip distribution.

    ``nz``: NONZERO paired differences (zeros already dropped). Ranks are
    AVERAGE ranks over |nz| (ties share the mean rank; x2 to integers).
    The null distribution of W = sum_i sign_i * rank_i is computed EXACTLY
    by DP over achievable signed sums - equivalent to brute-force
    enumeration of all 2^n sign assignments (verified against enumeration
    in tests). Convention since audit 4-final; reproduces the published
    e3-sparse AUC p = 0.03125 (scipy method="exact" gives 0.0260 there
    because its tie-adjusted conditional distribution differs).
    """
    ranks = _sstats.rankdata(np.abs(nz)) * 2.0
    r = np.rint(ranks).astype(np.int64)      # exact: halves become ints
    w_obs = int(np.sum(np.sign(nz) * r))
    total = int(r.sum())
    cur = np.zeros(2 * total + 1, dtype=np.float64)  # exact up to 2^53
    cur[total] = 1.0                          # idx = signed_sum + total
    for ri in r:
        nxt = np.zeros_like(cur)
        nxt[ri:] += cur[:-ri]                 # +ri
        nxt[:-ri] += cur[ri:]                 # -ri
        cur = nxt
    denom = float(cur.sum())                  # == 2 ** n
    if alternative == "two-sided":
        w = abs(w_obs)
        if w == 0:
            return 1.0
        hi = float(cur[total + w:].sum())     # W >= +w
        lo = float(cur[: total - w + 1].sum())  # W <= -w
        return float(min((hi + lo) / denom, 1.0))
    if alternative == "greater":
        return float(min(float(cur[total + w_obs:].sum()) / denom, 1.0))
    # alternative == "less"
    return float(min(float(cur[: total + w_obs + 1].sum()) / denom, 1.0))


def summarize(x) -> dict:
    """Descriptive summary: n, mean, median, std (POPULATION, ddof=0), min, max."""
    arr = np.asarray(x, dtype=np.float64).ravel()
    if arr.size == 0:
        raise ValueError("summarize of empty input")
    return {
        "n": int(arr.size),
        "mean": float(arr.mean()),
        "median": float(np.median(arr)),
        "std": float(arr.std()),
        "min": float(arr.min()),
        "max": float(arr.max()),
    }


# ---------------------------------------------------------------------------
# paired comparison (the default analysis)
# ---------------------------------------------------------------------------
def paired_compare(a, b, n_bootstrap=10000, seed=0, alternative="two-sided"):
    """Compare two methods run on IDENTICAL seeds (paired by seed).

    Returns dict with keys:
      n, mean_diff, median_diff, wilcoxon_p, cohen_d_paired, rank_biserial,
      bootstrap_ci95_mean_diff [lo, hi], bootstrap_ci95_median_diff [lo, hi],
      significant_005 (bool), note (str).

    * Wilcoxon signed-rank test (scipy, exact for n<=25, `alternative`
      pass-through). All-zero differences => p = 1.0 by convention.
    * cohen_d_paired = mean(diff)/std(diff, ddof=1); std==0 => inf if the
      mean is nonzero else 0.
    * rank_biserial (matched pairs) = (R+ - R-)/(R+ + R-) over ranks of
      |diff| with zero differences excluded and average ranks for ties.
    * Bootstrap: resample PAIR indices, B percentile CIs [2.5, 97.5] for the
      mean and the median of the differences.
    * significant_005 = (wilcoxon_p < 0.05) AND (0 outside the mean-diff CI).
    """
    _check_alternative(alternative)
    a = np.asarray(a, dtype=np.float64).ravel()
    b = np.asarray(b, dtype=np.float64).ravel()
    if a.size != b.size:
        raise ValueError(
            f"paired arrays must have equal length, got {a.size} vs {b.size}")
    n = a.size
    if n < 2:
        raise ValueError("paired_compare requires n >= 2 pairs")
    d = a - b
    mean_diff = float(d.mean())
    median_diff = float(np.median(d))

    # Wilcoxon signed-rank - EXACT sign-flip enumeration with AVERAGE ranks
    # over NONZERO differences (project convention since 4-final; zero
    # differences dropped before the test, 'wilcox' style). Rationale
    # (audits 9-b + re-analysis 9-c, 2026-10-09): scipy's method="exact"
    # applies a tie-adjusted conditional distribution that differs from
    # plain sign-flip enumeration on tied data (e3-sparse AUC: scipy 0.0260
    # vs convention 0.03125), so we enumerate ourselves via DP (O(n^3),
    # exact); more than 25 nonzero pairs falls back to scipy asymptotic.
    nz = d[d != 0.0]
    n_eff = int(nz.size)
    if n_eff == 0:
        p = 1.0          # all differences are exactly zero
    elif n_eff <= 25:
        p = _exact_wilcoxon_p(nz, alternative)
    else:
        wres = _sstats.wilcoxon(a, b, alternative=alternative,
                                method="auto")
        p = float(wres.pvalue)

    # Paired Cohen's d with zero-variance guard.
    sd = float(np.std(d, ddof=1))
    if sd == 0.0:
        cohen_d = math.inf if mean_diff != 0.0 else 0.0
    else:
        cohen_d = mean_diff / sd

    # Matched-pairs rank-biserial correlation.
    nz = d[d != 0.0]
    if nz.size == 0:
        rank_biserial = 0.0
    else:
        ranks = _sstats.rankdata(np.abs(nz))  # average ranks for ties
        r_plus = float(ranks[nz > 0].sum())
        r_minus = float(ranks[nz < 0].sum())
        rank_biserial = (r_plus - r_minus) / (r_plus + r_minus)

    # Paired bootstrap over resampled pair indices.
    rng = np.random.default_rng(seed)
    means, medians = _paired_bootstrap(d, int(n_bootstrap), rng)
    ci_mean = [float(v) for v in np.percentile(means, [2.5, 97.5])]
    ci_median = [float(v) for v in np.percentile(medians, [2.5, 97.5])]

    significant = bool(p < 0.05 and (ci_mean[0] > 0.0 or ci_mean[1] < 0.0))

    notes = []
    if n < 6:
        n_eff_disp = max(n_eff, 1)
        notes.append(
            f"n<6: minimum achievable two-sided p at n_eff={n_eff_disp} "
            f"nonzero pairs is {2.0 ** (1 - n_eff_disp):.4f} -- treat as "
            f"suggestive only")
    note = _insufficient_note(p)
    if note:
        notes.append(note)
    return {
        "n": int(n),
        "mean_diff": mean_diff,
        "median_diff": median_diff,
        "wilcoxon_p": p,
        "cohen_d_paired": float(cohen_d),
        "rank_biserial": float(rank_biserial),
        "bootstrap_ci95_mean_diff": ci_mean,
        "bootstrap_ci95_median_diff": ci_median,
        "significant_005": significant,
        "note": "; ".join(notes),
    }


# ---------------------------------------------------------------------------
# unpaired comparison (only for data that cannot be paired)
# ---------------------------------------------------------------------------
def independent_compare(a, b, n_bootstrap=10000, seed=0, alternative="two-sided"):
    """Mann-Whitney U comparison of two INDEPENDENT samples (unpaired).

    Same reporting conventions as ``paired_compare``; the bootstrap resamples
    each group separately and the CI is for mean(a) - mean(b).
    """
    _check_alternative(alternative)
    a = np.asarray(a, dtype=np.float64).ravel()
    b = np.asarray(b, dtype=np.float64).ravel()
    if a.size < 2 or b.size < 2:
        raise ValueError("independent_compare requires >= 2 samples per group")
    mean_diff = float(a.mean() - b.mean())
    median_diff = float(np.median(a) - np.median(b))
    try:
        ures = _sstats.mannwhitneyu(a, b, alternative=alternative)
        u = float(ures.statistic)
        p = float(ures.pvalue)
    except ValueError as exc:
        if "identical" in str(exc).lower() or "zero" in str(exc).lower():
            u, p = float(a.size * b.size / 2.0), 1.0
        else:
            raise
    rank_biserial = 2.0 * u / (a.size * b.size) - 1.0

    rng = np.random.default_rng(seed)
    boot_a = _boot_stat(a, lambda s, axis: s.mean(axis=axis), int(n_bootstrap), rng)
    boot_b = _boot_stat(b, lambda s, axis: s.mean(axis=axis), int(n_bootstrap), rng)
    diffs = boot_a - boot_b
    ci_mean = [float(v) for v in np.percentile(diffs, [2.5, 97.5])]

    significant = bool(p < 0.05 and (ci_mean[0] > 0.0 or ci_mean[1] < 0.0))
    notes = []
    if min(a.size, b.size) < 4:
        notes.append("tiny group size: Mann-Whitney resolution is very coarse")
    note = _insufficient_note(p)
    if note:
        notes.append(note)
    return {
        "n_a": int(a.size),
        "n_b": int(b.size),
        "mean_diff": mean_diff,
        "median_diff": median_diff,
        "mannwhitney_u": u,
        "mannwhitney_p": p,
        "rank_biserial": float(rank_biserial),
        "bootstrap_ci95_mean_diff": ci_mean,
        "significant_005": significant,
        "note": "; ".join(notes),
    }


# ---------------------------------------------------------------------------
# multiple comparisons
# ---------------------------------------------------------------------------
def holm(pvals, alpha=0.05):
    """Holm step-down adjustment (family-wise error rate control).

    Returns {"adjusted": [...], "rejected": [...bool]} in input order.
    Step-down: sorted p_(i) is rejected while (m - i) * p_(i) <= alpha
    (0-based i); the first failure stops the family.
    """
    p = np.asarray(pvals, dtype=np.float64).ravel()
    if p.size == 0:
        return {"adjusted": [], "rejected": []}
    if np.any((p < 0.0) | (p > 1.0)) or np.any(np.isnan(p)):
        raise ValueError("p-values must lie in [0, 1]")
    m = p.size
    order = np.argsort(p, kind="stable")
    sp = p[order]
    mult = m - np.arange(m)                    # m, m-1, ..., 1
    raw = np.minimum(sp * mult, 1.0)
    adj_sorted = np.maximum.accumulate(raw)    # monotone step-down p-values
    adjusted = np.empty(m, dtype=np.float64)
    adjusted[order] = adj_sorted
    rejected_sorted = np.zeros(m, dtype=bool)
    for i in range(m):
        if sp[i] * mult[i] <= alpha:
            rejected_sorted[i] = True
        else:
            break
    rejected = np.empty(m, dtype=bool)
    rejected[order] = rejected_sorted
    return {"adjusted": [float(v) for v in adjusted],
            "rejected": [bool(v) for v in rejected]}


def fdr_bh(pvals, alpha=0.05):
    """Benjamini-Hochberg step-up adjustment (false discovery rate control).

    Rejects H_(1..k) for the largest k with p_(k) <= (k/m) * alpha.
    Adjusted p-values are the step-up (reverse-running-min) quantities.
    """
    p = np.asarray(pvals, dtype=np.float64).ravel()
    if p.size == 0:
        return {"adjusted": [], "rejected": []}
    if np.any((p < 0.0) | (p > 1.0)) or np.any(np.isnan(p)):
        raise ValueError("p-values must lie in [0, 1]")
    m = p.size
    order = np.argsort(p, kind="stable")
    sp = p[order]
    q = np.minimum(sp * m / np.arange(1, m + 1), 1.0)
    adj_sorted = np.minimum.accumulate(q[::-1])[::-1]
    adjusted = np.empty(m, dtype=np.float64)
    adjusted[order] = adj_sorted
    thresh = np.arange(1, m + 1) / m * alpha
    below = np.nonzero(sp <= thresh)[0]
    rejected_sorted = np.zeros(m, dtype=bool)
    if below.size:
        rejected_sorted[: below[-1] + 1] = True
    rejected = np.empty(m, dtype=bool)
    rejected[order] = rejected_sorted
    return {"adjusted": [float(v) for v in adjusted],
            "rejected": [bool(v) for v in rejected]}


# ---------------------------------------------------------------------------
# bootstrap CI
# ---------------------------------------------------------------------------
def bootstrap_ci(x, stat="mean", B=10000, ci=95.0, seed=0):
    """Percentile bootstrap CI [lo, hi] of `stat` over resamples of x.

    `stat` is "mean", "median" or a callable ``f(samples, axis)``.
    Deterministic given `seed`.
    """
    x = np.asarray(x, dtype=np.float64).ravel()
    if x.size == 0:
        raise ValueError("bootstrap_ci of empty input")
    B = int(B)
    if B < 1:
        raise ValueError("B must be >= 1")
    if not 0.0 < ci < 100.0:
        raise ValueError("ci must be in (0, 100)")
    if callable(stat):
        fn = stat
    elif stat == "mean":
        fn = lambda s, axis: s.mean(axis=axis)  # noqa: E731
    elif stat == "median":
        fn = lambda s, axis: np.median(s, axis=axis)  # noqa: E731
    else:
        raise ValueError(f"unknown stat {stat!r} (use 'mean', 'median' or callable)")
    rng = np.random.default_rng(seed)
    vals = _boot_stat(x, fn, B, rng)
    lo_q = (100.0 - ci) / 2.0
    lo, hi = np.percentile(vals, [lo_q, 100.0 - lo_q])
    return [float(lo), float(hi)]


# ---------------------------------------------------------------------------
# documentation helper
# ---------------------------------------------------------------------------
def min_detectable_note(n) -> str:
    """Document the minimum achievable two-sided Wilcoxon p at sample size n.

    Best case (all differences same sign): p_min = 2 * (1/2)^n = 2^(1-n).
    Two-sided significance at alpha=0.05 becomes possible from n = 6 on.
    """
    n = int(n)
    if n < 2:
        return ("n<2: the Wilcoxon signed-rank test is undefined; "
                "collect at least 2 (ideally >= 10) seeds")
    p_min = 2.0 ** (1 - n)
    if p_min >= 0.05:
        return (f"n={n}: minimum achievable two-sided Wilcoxon p is {p_min:.4g} "
                f"(>= 0.05) -- significance is IMPOSSIBLE at this sample size; "
                f"the smallest n that can reach p < 0.05 is n>=6")
    return (f"n={n}: minimum achievable two-sided Wilcoxon p is {p_min:.4g} "
            f"(< 0.05) -- significance achievable in the best case")
