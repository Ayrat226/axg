"""11-a adversarial edge-case checks (read-only w.r.t. project code)."""
import importlib.util, json, os, sys, itertools
sys.path.insert(0, "/home/z/my-project")
import numpy as np

spec = importlib.util.spec_from_file_location(
    "run_continual2", "/home/z/my-project/scripts/run_continual2.py")
rc2 = importlib.util.module_from_spec(spec); spec.loader.exec_module(rc2)
TMP = "/tmp/11a_edge"; os.makedirs(TMP, exist_ok=True)

def w(name, rows):
    p = os.path.join(TMP, name)
    with open(p, "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")
    return p

def row(phase, run_id=None, ts=None, lam=3.0):
    r = {"arm": "x", "seed": 0, "phase": phase, "task": "t%d" % phase,
         "row": [float(phase)] * 3, "phase_steps": 30000, "ewc_lambda": lam,
         "n_tasks": 3}
    if run_id is not None: r["run_id"] = run_id
    if ts is not None: r["ts"] = ts
    return r

print("== 1. empty file ==")
p = w("empty.jsonl", [])
print("  _complete_matrix ->", rc2._complete_matrix(p, 3))

print("== 2. torn line ==")
p = os.path.join(TMP, "torn.jsonl")
with open(p, "w") as f:
    f.write(json.dumps(row(0, "aaa", "2026-10-09T10:00:00")) + "\n")
    f.write('{"arm": "x", "seed": 0, "pha')   # torn tail
try:
    print("  _complete_matrix ->", rc2._complete_matrix(p, 3))
except Exception as e:
    print("  RAISED:", type(e).__name__, str(e)[:60])

print("== 3. legacy rows (no run_id): two attempts mixed ==")
p = w("legacy.jsonl", [
    row(0, ts="2026-10-09T10:00:00"), row(1, ts="2026-10-09T10:01:00"),
    row(2, ts="2026-10-09T10:02:00"),           # attempt A: phases 0-2
    row(0, ts="2026-10-09T11:00:00"), row(1, ts="2026-10-09T11:01:00"),
    # attempt B (restart): only 0-1 -- must NOT beat A
])
print("  matrix ->", rc2._complete_matrix(p, 3))

print("== 4. tie: equal phase count, later ts wins ==")
p = w("tie.jsonl", [
    row(0, "old", "2026-10-09T10:00:00"), row(1, "old", "2026-10-09T10:01:00"),
    row(2, "old", "2026-10-09T10:02:00"),
    row(0, "new", "2026-10-09T11:00:00"), row(1, "new", "2026-10-09T11:01:00"),
    row(2, "new", "2026-10-09T11:02:00"),
])
m = rc2._complete_matrix(p, 3)
print("  best run rows (new=ts11h) ->", m[0][:1], "expect row from 'new' (row=[2,2,2] both; check by ts below)")

# distinguish by row values
p = w("tie2.jsonl", [
    dict(row(0, "old", "2026-10-09T10:00:00"), row=[10.0]*3),
    dict(row(1, "old", "2026-10-09T10:01:00"), row=[10.0]*3),
    dict(row(0, "new", "2026-10-09T11:00:00"), row=[20.0]*3),
    dict(row(1, "new", "2026-10-09T11:01:00"), row=[20.0]*3),
])
# n_tasks=2: both complete; tie on len -> ts decides (new later)
m = rc2._complete_matrix(p, 2)
print("  tie2 ->", m, "(expect [[20.0..],[20.0..]] = 'new')")

print("== 5. duplicate phase inside one run_id (dict last-wins) ==")
p = w("dup.jsonl", [
    dict(row(0, "r1", "2026-10-09T10:00:00"), row=[1.0]*3),
    dict(row(1, "r1", "2026-10-09T10:01:00"), row=[1.0]*3),
    dict(row(1, "r1", "2026-10-09T10:05:00"), row=[9.0]*3),  # dup phase
])
print("  ->", rc2._complete_matrix(p, 2), "(expect phase1 row=[9...]: last wins)")

print("== 6. chunk stripe coverage ==")
for nw in (2, 3):
    jobs = [(a, s) for a in rc2.ARMS for s in range(5)]
    cov = [j for wk in range(nw)
           for j in [(a, s) for i, (a, s) in enumerate(jobs)
                     if i % nw == wk]]
    print(f"  n_workers={nw}: covered={len(cov)}, unique={len(set(cov))}, "
          f"all={set(cov) == set(jobs)}")

print("== 7. summarize expected-anchor (seed0 incomplete, seed1 complete) ==")
d = os.path.join(TMP, "sum"); os.makedirs(d, exist_ok=True)
def wr(seed, rows):
    with open(os.path.join(d, f"arm-seed{seed}.jsonl"), "w") as f:
        for r in rows: f.write(json.dumps(r) + "\n")
# seed0: best run 3 contiguous phases (crashed); seed1: complete 5 phases
wr(0, [dict(row(p, "s0run", "2026-10-09T10:0%d:00" % p), row=[float(p)]*5,
            n_tasks=5) for p in range(3)])
wr(1, [dict(row(p, "s1run", "2026-10-09T11:0%d:00" % p), row=[float(p)]*5,
            n_tasks=5) for p in range(5)])
try:
    s = rc2.summarize("arm", results_dir=d)
    print("  n_seeds =", s["n_seeds"], "per-seed phases:",
          [len(x["matrix"]) for x in s["per_seed"]])
except SystemExit as e:
    print("  SystemExit:", e)
