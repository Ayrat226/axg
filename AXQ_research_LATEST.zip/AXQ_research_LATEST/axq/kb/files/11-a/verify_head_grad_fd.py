"""11-a: FD check of MultiHeadDQN update()-path gradients (adversarial).

Verifies the (1 - h^2) tanh-chain factor placement and the forward/backward
graph order (a_star s2-forward BEFORE the s-forward) against finite
differences, for ALL parameter groups incl. the trunk layer feeding the
external tanh. Result: PASS (max rel err 1.1e-6 = FD truncation noise).
Run: python3 kb/files/11-a/verify_head_grad_fd.py
"""
import sys
sys.path.insert(0, "/home/z/my-project")
import numpy as np
from axq.agents.continual import MultiHeadDQN
from axq.agents.dqn import DQN
from axq.agents.common import one_hot_batch

ag = MultiHeadDQN(n_obs=8, obs_type="discrete", n_actions=3, hidden=(8, 8),
                  batch_size=4, warmup=4, seed=0, double=True)
ag.set_task(0)
rng = np.random.default_rng(11)
for _ in range(60):
    ag.observe(int(rng.integers(0, 8)), int(rng.integers(0, 3)),
               float(rng.normal()), int(rng.integers(0, 8)),
               rng.random() < 0.1, False)
b = ag.task_buffers[0].sample(4, np.random.default_rng(99))
A, R, D = b["actions"], b["rewards"], b["done"]
S = one_hot_batch([int(x) for x in b["obs"]], 8)
S2 = one_hot_batch([int(x) for x in b["next_obs"]], 8)
g_eff = ag._gamma_eff(b)
idx = np.arange(4)

def q_path():
    h2_tgt = np.tanh(ag.target_net.forward(S2))
    q_tgt = ag.target_heads[0].forward(h2_tgt)
    h2_on = np.tanh(ag.net.forward(S2))
    a_star = np.argmax(ag.heads[0].forward(h2_on), axis=1)
    z_s = ag.net.forward(S)          # trunk LAST forward = s (graph for backward)
    h_s = np.tanh(z_s)
    q_all = ag.heads[0].forward(h_s)  # head LAST forward = h_s
    return q_tgt, a_star, q_all, h_s

def loss_val():
    q_tgt, a_star, q_all, _ = q_path()
    y = R + g_eff * (1.0 - D) * q_tgt[idx, a_star]
    td = q_all[idx, A] - y
    return float(np.mean(td * td))

q_tgt, a_star, q_all, h_s = q_path()
y = R + g_eff * (1.0 - D) * q_tgt[idx, a_star]
td = q_all[idx, A] - y
grad = np.zeros_like(q_all)
grad[idx, A] = (2.0 / 4) * td
g_h = ag.heads[0].backward(grad)
ag.net.backward(g_h * (1.0 - h_s * h_s))     # the fixed line under test

checks = [("trunk W0", ag.net.layers[0].W, ag.net.layers[0].dW.copy()),
          ("trunk b0", ag.net.layers[0].b, ag.net.layers[0].db.copy()),
          ("trunk W1 (pre-ext-tanh)", ag.net.layers[1].W, ag.net.layers[1].dW.copy()),
          ("trunk b1 (pre-ext-tanh)", ag.net.layers[1].b, ag.net.layers[1].db.copy()),
          ("head W", ag.heads[0].layers[0].W, ag.heads[0].layers[0].dW.copy()),
          ("head b", ag.heads[0].layers[0].b, ag.heads[0].layers[0].db.copy())]
eps, ok = 1e-6, True
def pts(a):
    return [(0,), (a.size // 2,), (a.size - 1,)] if a.ndim == 1 else \
        [(0, 0), (a.shape[0] // 2, a.shape[1] // 2),
         (a.shape[0] - 1, a.shape[1] - 1)]
for name, arr, g in checks:
    errs = []
    for pt in pts(arr):
        old = arr[pt]
        arr[pt] = old + eps; lp = loss_val()
        arr[pt] = old - eps; lm = loss_val()
        arr[pt] = old
        errs.append(abs((lp - lm) / (2 * eps) - g[pt]) / (abs((lp - lm) / (2 * eps)) + 1e-12))
    ok &= max(errs) < 1e-4
    print(f"{name:26s} {'OK' if max(errs) < 1e-4 else 'FAIL'} max_rel_err={max(errs):.2e}")
print("FD verdict:", "PASS" if ok else "FAIL")

d = DQN(n_obs=8, obs_type="discrete", n_actions=3, hidden=(8, 8), seed=0)
mh = MultiHeadDQN(n_obs=8, obs_type="discrete", n_actions=3, hidden=(8, 8), seed=0)
print("DQN sizes:", d.net.sizes, "n_params:", d.net.n_params,
      "| MH trunk:", mh.net.sizes, "+ head:", mh.heads[0].sizes,
      "n_params:", mh.net.n_params + mh.heads[0].n_params)
assert d.net.n_params == mh.net.n_params + mh.heads[0].n_params
