"""11-a: independent brute-force check of axq.exp.stats._exact_wilcoxon_p.

300 random datasets (n=1..8, deliberate ties) x 3 alternatives vs full 2^n
sign-flip enumeration -> 0/900 mismatches. Also: w_obs=0 cases and the
n=25 float64-exactness check (p = 2/2^25 exactly).
Run: python3 kb/files/11-a/verify_wilcoxon_bruteforce.py
"""
import sys, itertools
sys.path.insert(0, "/home/z/my-project")
import numpy as np
from scipy import stats as ss
from axq.exp.stats import _exact_wilcoxon_p

rng = np.random.default_rng(42)
bad = 0
for trial in range(300):
    n = int(rng.integers(1, 9))
    nz = np.round(rng.normal(0, 1, n), 1)
    nz = nz[nz != 0]
    if nz.size == 0:
        continue
    if trial % 3 == 0 and nz.size >= 2:
        nz[1] = abs(nz[0])
    r = np.rint(ss.rankdata(np.abs(nz)) * 2.0).astype(np.int64)
    sums = np.array([sum(s * ri for s, ri in zip(signs, r))
                     for signs in itertools.product((1, -1), repeat=nz.size)],
                    dtype=np.int64)
    w_obs = int(np.sum(np.sign(nz) * r))
    for alt, bf in (("two-sided", np.mean(np.abs(sums) >= abs(w_obs))),
                    ("greater", np.mean(sums >= w_obs)),
                    ("less", np.mean(sums <= w_obs))):
        dp = _exact_wilcoxon_p(nz, alt)
        if abs(dp - float(bf)) > 1e-12:
            bad += 1
            print("MISMATCH", alt, nz, dp, bf)
print("brute-force mismatches:", bad, "/ 900 checks")
print("w_obs=0 two-sided:", _exact_wilcoxon_p(np.array([1.0, -1.0]), "two-sided"))
print("w_obs=0 greater:  ", _exact_wilcoxon_p(np.array([1.0, -1.0]), "greater"))
print("n=25 all-positive:", _exact_wilcoxon_p(np.arange(1, 26, dtype=float),
                                              "two-sided"), "== 2/2^25:",
      2.0 / 2**25)
assert bad == 0
