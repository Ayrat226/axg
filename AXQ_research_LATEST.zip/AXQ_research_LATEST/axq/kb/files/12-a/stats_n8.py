#!/usr/bin/env python3
"""Red-team 12-a: statistics — n=8 extension of the top pair + power math."""
import json, sys
from collections import defaultdict

import numpy as np

sys.path.insert(0, "/home/z/my-project")
from axq.exp.stats import paired_compare, holm

R = "/home/z/my-project/axq/results/g1"

def load(arm, seed):
    runs = defaultdict(dict)
    for ln in open(f"{R}/{arm}_seed{seed}.jsonl"):
        ln = ln.strip()
        if not ln:
            continue
        r = json.loads(ln)
        runs[r["run_id"]][r["phase"]] = r["row"]
    best = max(runs.values(), key=lambda ph: (len(ph), max(ph)))
    return [best[i] for i in range(5)]

def met(M):
    M = np.asarray(M, dtype=float)
    return dict(acquisition=float(np.mean(np.diag(M))),
                final_avg=float(M[-1].mean()),
                retention=float(M[-1, :-1].mean()),
                avg_forgetting=float(np.mean([M[j, j] - M[-1, j]
                                              for j in range(4)])))

arms = ["dqn-persist", "dqn-fresh", "dqn-ewc-fresh", "dqn-ewc-persist",
        "dqn-heads-persist"]
M = {}
for a in arms:
    seeds = range(8) if a in ("dqn-persist", "dqn-heads-persist") else range(5)
    M[a] = {s: met(load(a, s)) for s in seeds}

print("=== n=8 extension matrices (top pair) ===")
for a in ("dqn-persist", "dqn-heads-persist"):
    for s in range(5, 8):
        rows = load(a, s)
        print(f"{a} seed{s}:")
        for i, r in enumerate(rows):
            print(f"   phase {i}: {r}")

print("\n=== per-seed metrics, top pair, n=8 ===")
for a in ("dqn-persist", "dqn-heads-persist"):
    for s in range(8):
        m = M[a][s]
        print(f"{a:20s} s{s}: acq={m['acquisition']:.2f} "
              f"ret={m['retention']:.2f} fa={m['final_avg']:.2f} "
              f"forg={m['avg_forgetting']:+.2f}")

print("\n=== paired comparisons, n=8 (top pair), project stats module ===")
for metname in ("retention", "acquisition", "final_avg"):
    a = [M["dqn-heads-persist"][s][metname] for s in range(8)]
    b = [M["dqn-persist"][s][metname] for s in range(8)]
    r = paired_compare(a, b)
    print(f"heads_vs_persist:{metname}: diffs={[round(x-y,3) for x,y in zip(a,b)]}")
    print(f"   mean_diff={r['mean_diff']:+.3f} p={r['wilcoxon_p']:.5f} "
          f"d={r['cohen_d_paired']:+.2f} ci={r['bootstrap_ci95_mean_diff']} "
          f"note={r['note'][:80]}")

# Holm for the 3-metric top-pair family at n=8
pv = []
for metname in ("retention", "acquisition", "final_avg"):
    a = [M["dqn-heads-persist"][s][metname] for s in range(8)]
    b = [M["dqn-persist"][s][metname] for s in range(8)]
    pv.append(paired_compare(a, b)["wilcoxon_p"])
h = holm(pv)
print(f"\nHolm (family=3, top pair, n=8): raw={[round(p,5) for p in pv]} "
      f"adj={[round(x,5) for x in h['adjusted']]} rej={h['rejected']}")

print("\n=== kept/acquired (tasks 0..3) at n=8, top pair ===")
for a in ("dqn-persist", "dqn-heads-persist"):
    kept = acq = 0
    late = 0
    for s in range(8):
        rows = np.asarray(load(a, s))
        for j in range(4):
            if rows[j, j] > 0:
                acq += 1
                kept += int(rows[-1, j] > 0)
            elif rows[-1, j] > 0:
                late += 1
    print(f"{a:20s}: kept/acquired={kept}/{acq} late_acquired={late}")

print("\n=== H9a detail: persist vs fresh, retention, n=5 ===")
for s in range(5):
    d = M["dqn-persist"][s]["retention"] - M["dqn-fresh"][s]["retention"]
    print(f"seed{s}: persist={M['dqn-persist'][s]['retention']:.2f} "
          f"fresh={M['dqn-fresh'][s]['retention']:.2f} diff={d:+.2f}")

print("\n=== power / Holm feasibility math ===")
for n in (5, 8, 9, 10, 12):
    minp = 2.0 / 2**n
    print(f"n_eff={n}: min two-sided sign-flip p = {minp:.5f}; "
          f"Holm rank-1 threshold m=12: {0.05/12:.5f} "
          f"{'SURVIVES' if minp <= 0.05/12 else 'cannot'}; "
          f"m=3: {0.05/3:.5f} {'SURVIVES' if minp <= 0.05/3 else 'cannot'}; "
          f"m=1: 0.05 {'SURVIVES' if minp <= 0.05 else 'cannot'}")

print("\n=== EWC acquisition stop: first phase where diag=0 for tasks 1..4 ===")
for a in ("dqn-ewc-fresh", "dqn-ewc-persist"):
    for s in range(5):
        rows = np.asarray(load(a, s))
        diag = [rows[j, j] for j in range(5)]
        print(f"{a} s{s}: diag={diag}")
