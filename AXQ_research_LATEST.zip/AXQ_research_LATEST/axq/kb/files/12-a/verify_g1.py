#!/usr/bin/env python3
"""Red-team 12-a: integrity + recompute of g1 results from raw jsonl.

Checks:
 A. jsonl integrity: run_id per (arm,seed), contiguous phases, budgets,
    torn lines, legacy rows.
 B. summary_<arm>.json == recomputed metrics from best jsonl run.
 C. cross-arm determinism: phase-0 rows identical across DQN-family arms
    per seed (same agent seed, same env, no arm-specific mechanism yet).
 D. retention-on-acquired-tasks analysis (diag>0 among tasks 0..3).
 E. per-task acquisition rates; gw3 solvability (BFS on layouts).
 F. n=8 extension status (seeds 5-7 for the top pair).
"""
import json, os, sys
from collections import defaultdict, deque

import numpy as np

sys.path.insert(0, "/home/z/my-project")
from axq.envs.multitask import SUITES
from axq.envs.gridworld import GridWorld

R = "/home/z/my-project/axq/results/g1"
ARMS = ["dqn-persist", "dqn-fresh", "dqn-ewc-fresh", "dqn-ewc-persist",
        "dqn-heads-persist"]

def load_jsonl(path):
    rows, bad = [], 0
    if not os.path.exists(path):
        return rows, bad
    with open(path) as f:
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            try:
                rows.append(json.loads(ln))
            except json.JSONDecodeError:
                bad += 1
    return rows, bad

def best_run(rows):
    runs = defaultdict(dict)
    for r in rows:
        runs[str(r.get("run_id", "legacy"))][r["phase"]] = r
    best, key = None, (-1, "")
    for rid, ph in runs.items():
        ts = max((x.get("ts", "") for x in ph.values()), default="")
        if (len(ph), ts) > key:
            best, key = (rid, ph), (len(ph), ts)
    return best

def metrics(M):
    M = np.asarray(M, dtype=float)
    T = M.shape[0]
    return {
        "acquisition": float(np.mean(np.diag(M))),
        "final_avg": float(M[-1].mean()),
        "retention": float(M[-1, :-1].mean()),
        "avg_forgetting": float(np.mean([M[j, j] - M[-1, j]
                                         for j in range(T - 1)])),
        "bwt": float(np.mean(M[-1, :-1] - np.diag(M)[:-1])),
        "fwt": float(M[0, 1:].mean()),
    }

print("=" * 70)
print("A+B. jsonl integrity & summary cross-check")
print("=" * 70)
data = {}          # (arm, seed) -> matrix of best complete run
anomalies = []
for arm in ARMS:
    for seed in range(8):
        p = f"{R}/{arm}_seed{seed}.jsonl"
        rows, bad = load_jsonl(p)
        if not rows and not os.path.exists(p):
            continue
        br = best_run(rows)
        rid, ph = br
        phases = sorted(ph)
        n_runs = len({r.get("run_id") for r in rows})
        budgets = {r.get("phase_steps") for r in rows}
        lam = {r.get("ewc_lambda") for r in rows}
        complete = phases == list(range(5))
        print(f"{arm:20s} seed{seed}: rows={len(rows):2d} runs={n_runs} "
              f"phases={phases} complete={complete} torn={bad} "
              f"budget={budgets} lam={lam}")
        if bad:
            anomalies.append(f"{arm} seed{seed}: {bad} torn lines")
        if budgets != {30000}:
            anomalies.append(f"{arm} seed{seed}: budgets {budgets} != 30000")
        if arm.startswith("dqn-ewc") and lam != {3.0}:
            anomalies.append(f"{arm} seed{seed}: lambda {lam} != 3.0")
        if complete:
            M = [ph[i]["row"] for i in range(5)]
            data[(arm, seed)] = M
        if len(ph) != 5 and len(ph) > 0:
            anomalies.append(f"{arm} seed{seed}: incomplete best run "
                             f"({len(ph)} phases)")

for arm in ARMS:
    sp = f"{R}/summary_{arm}.json"
    if not os.path.exists(sp):
        continue
    S = json.load(open(sp))
    for s in S["per_seed"]:
        k = (arm, s["seed"])
        if k not in data:
            anomalies.append(f"summary {k}: no complete jsonl run")
            continue
        M = np.array(data[k])
        if not np.allclose(M, np.array(s["matrix"])):
            anomalies.append(f"summary {k}: matrix != jsonl best-run matrix")
        rec = metrics(M)
        for met, v in rec.items():
            if abs(v - s[met]) > 1e-9:
                anomalies.append(
                    f"summary {k}: {met} {s[met]} != recomputed {v:.4f}")

print("\n--- anomalies ---")
print("\n".join(anomalies) if anomalies else "NONE: jsonl/summary consistent")

print()
print("=" * 70)
print("C. phase-0 row identity across DQN-family arms (same seed)")
print("=" * 70)
fam = ["dqn-persist", "dqn-fresh", "dqn-ewc-fresh", "dqn-ewc-persist"]
for seed in range(8):
    rows0 = {a: data.get((a, seed), [[None]])[0] for a in fam}
    vals = {a: tuple(r) for a, r in rows0.items() if r[0] is not None}
    uniq = set(vals.values())
    heads0 = data.get(("dqn-heads-persist", seed), [[None]])[0]
    print(f"seed{seed}: DQN-family phase0 unique={len(uniq)} "
          f"{list(uniq)[:1]} heads_phase0={heads0 if heads0[0] is not None else '-'}")

print()
print("=" * 70)
print("D+E. per-task acquisition & retention-on-acquired (tasks 0..3)")
print("=" * 70)
hdr = f"{'arm':20s} " + " ".join(f"gw{j+1}_acq" for j in range(5)) + \
      " | kept/acq  ret_all ret_excl_gw3"
print(hdr)
for arm in ARMS:
    acq_rate = [0] * 5
    kept = acquired = 0
    ret_all, ret_ex = [], []
    for seed in range(5):
        if (arm, seed) not in data:
            continue
        M = np.array(data[(arm, seed)])
        for j in range(5):
            acq_rate[j] += int(M[j, j] > 0)
        for j in range(4):
            if M[j, j] > 0:
                acquired += 1
                kept += int(M[-1, j] > 0)
        ret_all.append(M[-1, :-1].mean())
        ret_ex.append(M[-1, [0, 1, 3]].mean())
    n = sum(1 for s in range(5) if (arm, s) in data)
    print(f"{arm:20s} " + " ".join(f"{a}/{n}  " for a in acq_rate) +
          f" | {kept}/{acquired} ({kept/max(acquired,1):.2f}) "
          f"{np.mean(ret_all):.3f}  {np.mean(ret_ex):.3f}")

print()
print("--- per-seed detail: retention on acquired tasks (tasks 0..3) ---")
for arm in ARMS:
    for seed in range(5):
        if (arm, seed) not in data:
            continue
        M = np.array(data[(arm, seed)])
        acq_t = [j for j in range(4) if M[j, j] > 0]
        kept_t = [j for j in acq_t if M[-1, j] > 0]
        late = [j for j in range(4) if M[j, j] == 0 and M[-1, j] > 0]
        lost = [j for j in acq_t if M[-1, j] == 0]
        print(f"{arm:20s} s{seed}: acq={acq_t} kept={kept_t} lost={lost} "
              f"late(final>0,diag=0)={late}")

print()
print("=" * 70)
print("E2. gw layout hardness (BFS shortest path, free cells)")
print("=" * 70)
for name, factory in SUITES["continual_gridworlds"].tasks:
    env = factory()
    q = deque([(env.start, 0)])
    seen = {env.start}
    dist = None
    while q:
        (r, c), d = q.popleft()
        if (r, c) == env.goal:
            dist = d
            break
        for (dr, dc) in ((-1, 0), (0, 1), (1, 0), (0, -1)):
            nr, nc = r + dr, c + dc
            if 0 <= nr < 8 and 0 <= nc < 8 and (nr, nc) not in env.walls \
                    and (nr, nc) not in seen:
                seen.add((nr, nc))
                q.append(((nr, nc), d + 1))
    print(f"{name}: walls={len(env.walls)} free={64 - len(env.walls)} "
          f"shortest_path={dist} reachable_from_start={len(seen)}")

print()
print("=" * 70)
print("F. n=8 extension status (top pair)")
print("=" * 70)
for arm in ["dqn-persist", "dqn-heads-persist"]:
    for seed in range(5, 8):
        p = f"{R}/{arm}_seed{seed}.jsonl"
        rows, bad = load_jsonl(p)
        br = best_run(rows) if rows else None
        n_ph = len(br[1]) if br else 0
        print(f"{arm:20s} seed{seed}: exists={os.path.exists(p)} "
              f"rows={len(rows)} best_run_phases={n_ph} complete={n_ph == 5}")
