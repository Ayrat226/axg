# Top-5 идей для цикла 4 (subagent 9-a «Idea Scout», 2026-10-09)

Контекст: цикл 3 (g1: EWC / MultiHead / full-rehearsal vs fresh, 30k×5 фаз,
acquisition+retention+BWT) уже реализуется оркестратором — НЕ дублируется.
Ниже — отобранные идеи для цикла 4: 19 записей в коллекции `ideas` (15
собственных + 4 scouted), отбор top-5 по критерию
**Score = ожидаемый эффект (1–5) × P(успеха) / стоимость (S=1, M=2, L=3)**.

Все идеи прошли фильтр: (a) ≤ ~60 мин CPU на руку при 5–8 сидах
(калибровка: DQN ≈ 42–95 с / 100k шагов на gridworld-семействе, AXQ ≈ 300 с;
см. bench.json и SECONDS_PER_100K в run_suite.py); (b) не дублируют
NEGATIVE_RESULTS (count-bonus/Mbie, median-агрегация, rehearsal@20k) и
цикл-3 набор; (c) предсказания количественные и привязаны к среде/метрике.

## 0. Таблица скоринга (все 19)

| # | Идея (id в KB) | Узкое место | E | P | C | Score |
|---|---|---|---|---|---|---|
| 1 | Optimistic init (`c216d3b1d3a5`) | exploration | 4.0 | 0.65 | 1 | **2.60** |
| 2 | PackNet маски (`9998ff6fdd1a`) | continual | 4.0 | 0.60 | 1 | **2.40** |
| 3 | Bootstrapped-commit (`877ef65f3904`) | exploration | 4.0 | 0.45 | 1 | **1.80** |
| 4 | Task-inference domain-IL (`98f4ebc5dd2f`) | continual | 4.5 | 0.55 | 1.5 | **1.65** |
| 5 | D4-аугментация (`6b9153040e79`) | generalization | 5.0 | 0.45–0.50 | 2 | **1.25*** |
| 6 | RND-бонус (`9fd51a165dcd`) | exploration | 3.5 | 0.40 | 1 | 1.40 |
| 7 | Epistemic VF, scouted (`307dbda594cf`) | exploration | 3.5 | 0.40 | 1 | 1.40 |
| 8 | Structured featurization (`1657d9900bae`) | generalization | 5.0 | 0.50 | 2 | 1.38 |
| 9 | LwF-дистилляция (`13b6caf9c63a`) | continual | 3.0 | 0.45 | 1 | 1.35 |
| 10 | Procgen-gap диагностика, scouted (`dfed05e17b8e`) | generalization (метод) | 2.0 | 0.60 | 1 | 1.20 |
| 11 | Curriculum по картам (`5c3483b3e769`) | generalization | 3.0 | 0.35 | 1 | 1.05 |
| 12 | AXQ на room_nav (`027ac63bb511`) | generalization | 3.0 | 0.35 | 1 | 1.05 |
| 13 | Weight decay + dropout (`63825b16ec84`) | generalization | 2.5 | 0.40 | 1 | 1.00 |
| 14 | Pseudo-replay модель (`a25111793f94`) | continual | 3.0 | 0.50 | 2 | 0.75 |
| 15 | World-model warm-start, scouted (`57b9ecfa9be4`) | continual | 3.0 | 0.50 | 2 | 0.75 |
| 16 | OGD-lite (`4fde435b8e11`) | continual | 3.5 | 0.40 | 2 | 0.70 |
| 17 | Dyna-lite планирование (`d0e350a7d80f`) | exploration | 3.5 | 0.40 | 2 | 0.70 |
| 18 | Variance-head UCB (`f7e6b15bd736`) | exploration | 3.0 | 0.35 | 1.5 | 0.70 |
| 19 | Contextual inference, scouted (`957ea657aec5`) | continual | см. #4 | — | — | дубль-поддержка |

\* Пятое место — портфельное решение (задокументировано в decisions):
generalization — единственный подтверждённый bottleneck без представителя в
top-5, а exploration уже имеет 2 слота и 3 «выстрела» по chains50. RND и
epistemic-VF (1.40) — первые fallback-кандидаты, если OptInit/Commit
откажут. Featurization (1.38) — обязательный companion-arm к D4 (та же
среда, общий harness, +~40% LOC): у неё выше P, но claim слабее (меняет
датчики, а не обучение).

---

## 1. Optimistic initialization (exploration; S; ~130 LOC)

**Идея KB:** `c216d3b1d3a5`. Точечное лечение ДОКУМЕНТИРОВАННОГО провала:
tabular 0 раз получил большую награду за 60k шагов (NEGATIVE_RESULTS §2,
exploration lock-in через точные Q-tie). Механизм: нетронутые (s,a) держат
завышенное Q → систематическое директивное исследование.

### Файлы
- `axq/agents/tabular.py`: параметр `q_init` (инициализация таблицы).
- `axq/agents/dqn.py`: параметр `optimism_bias` — инициализация последнего
  слоя `W ~ N(0, 1e-3)`, `b = optimism_bias` (малый шум ломает tie-симметрию,
  константа держит optimism).
- `scripts/run_optimism.py` (новый, ~60 LOC) по образцу f-сьютов.
- `tests/test_optimism.py` (~40 LOC).

### Алгоритм
1. Tabular: `Q = np.full((n_obs, n_actions), q_init)`; для env с max-return
   R_max использовать `q_init = R_max` (deceptive_50 → 10.0,
   credit_assignment → 50.0).
2. DQN: в конструкторе после построения `net` — переинициализация
   выходного слоя (W std=1e-3, bias=const). Target-сетку — копией.
3. Всё остальное (eps-greedy, Double, n-step) — без изменений.

### План эксперимента
- Руки: `tabular` vs `tabular-optinit` на `deceptive_50`,
  `credit_assignment` (60k шагов, eval каждые 10k, 50 эп/eval);
  контроль-антитест `gridworld_decoy`.
- `dqn` vs `dqn-optinit` на `chain_50` (60k, n=8 сидов — headline-правило
  проекта), контроль `chain_20` и `gridworld_decoy` (n=5).
- Инструментация из red-team-цикла: счётчик «большая награда получена
  хотя бы раз» (логировать по 10k-чанкам).
- Статистика: paired exact Wilcoxon по final/mean-of-last-2-evals;
  решённость (solve rate) с точным биномиальным CI.
- Wall-clock: tabular ≈ 12 с/100k → минуты; DQN chain_50 ≈ 25 с/сид × 8 ≈
  ~4 мин/руку. Итого ≤ 15 мин на весь блок.

### Ожидаемые цифры
- deceptive_50 tabular: 1.0 → **10.0** (≥5/8 сидов), большая награда
  получена ≥1 раза в первые ~200 эпизодов.
- credit_assignment tabular: 5.0 → **50.0**.
- chain_50 dqn-optinit: 0/5 → **≥3/8** solve (eval mean ≥ 0.9).
- Контроли без деградации: decoy ≥ 0.7, chain_20 parity.

### Kill-criteria
tabular не проходит deceptive_50 (< 10.0 в ≥3/8 сидов) ИЛИ chain_50 NN
≤ 1/8 ИЛИ деградация на любом контрольном антитесте (decoy < 0.7).

### Риск / заметки
Optimism в NN вымывается первыми ~1000 апдейтами (для цепи длины 50 может
не хватить — тогда честный негатив: «в функциональной аппроксимации
optimism-инициализации недостаточно»); q_init для tabular должен быть
привязан к R_max среды (передавать из runner по реестру env-параметров).

---

## 2. PackNet: итеративные weight-маски (continual; S; ~230 LOC)

**Идея KB:** `9998ff6fdd1a`. Защита весов старых задач абсолютная
(маски), rehearsal не нужен вовсе — прямое расширение g1-флагмана на
четвёртую ось (после penalty=EWC, heads, rehearsal).

### Файлы
- `axq/agents/continual.py`: класс `PackNetDQN(DQN)` (~120 LOC).
- `scripts/run_continual2.py`: рука `dqn-packnet` (fresh-буфер, без EWC) —
  ~10 LOC; вызвать `agent.on_task_end()` в конце фазы (аналог consolidate).
- `tests/test_packnet.py` (~80 LOC: маски не меняют старые веса после
  фазы; capacity-тест).

### Алгоритм
1. Состояние: `frozen` (list[bool-массивы по параметрам]) = False на фазе 0.
2. `update()`: после `net.backward(grad)` — `grad *= ~frozen` (по слоям).
3. КРИТИЧНО (Adam-моменты двигают веса даже с нулевым градиентом): после
   `adam_step` восстановить замороженные значения из снапшота
   `theta_frozen[frozen]` (2 строки, гарантирует корректность).
4. `on_task_end()`: среди незамороженных весов взять top-`freeze_frac`
   по |w| (например 0.4) → добавить в `frozen`; сохранить значения.
   Свободная ёмкость на задачу 5 ≈ 8580 × (1−0.4)⁴ ≈ 1100 весов —
   для 64-состоянийного gridworld достаточно (проверить capacity-тестом).
5. Буфер: fresh (replay-free ось изолирована).

### План эксперимента
- Точно протокол g1: `continual_gridworlds`, 30k/фаза × 5 задач, сиды
  0–4 (n=5; сиды общие с g1-руками → paired Wilcoxon против
  dqn-ewc-fresh / dqn-heads-persist / dqn-persist).
- Метрики: acquisition (diag), retention (final row, задачи 0..3),
  final_avg, BWT + доп. диагностическая: норма изменения весов старых
  задач по фазам (проверка масок).
- Wall-clock: ≈ как DQN-руки g1 (150k шагов/сид × 5) ≈ 10–20 мин/руку.

### Ожидаемые цифры
- retention **≥ 0.7** И acquisition **≥ 0.8**;
- retention выше dqn-persist (полный rehearsal), если rehearsal в g1
  окажется мягким (ожидание: 0.3–0.6).

### Kill-criteria
retention < 0.4 ИЛИ acquisition < 0.5 (маски либо не защищают, либо душат).

### Риск / заметки
Танх-сеть 64×64 может упереться в capacity к задаче 5 → ablation
`freeze_frac ∈ {0.25, 0.4}`; PackNet — task-IL по весам, но НЕ требует
task-ID на act (в отличие от heads): сеть одна, головы нет — это честный
domain-IL-совместимый механизм, указать в выводах.

---

## 3. Bootstrapped-commit: покомитный выбор головы (exploration; S; ~140 LOC)

**Идея KB:** `877ef65f3904`. Osband-режим агрегации, которого у нас НЕТ:
сейчас AXQ усредняет Q шести голов на каждом шаге (median — отвергнута
как не дающая робастности; это другой режим). Коммит головы на эпизод
даёт временную согласованность исследования: одна голова методично идёт
вглубь цепи 200 шагов.

### Файлы
- `axq/agents/axq.py`: параметр `agg_mode="pool"|"commit"`; в `act()`
  при commit — использовать `self._committed_head` (int); выбор головы в
  `reset_state()` (runner зовёт её на старте эпизода) — равномерно, или
  softmax по скользящему среднему return головы (параметр
  `commit_softmax_tau`, default = uniform). ~70 LOC.
- `scripts/run_commit.py` или расширение существующего f-раннера.
- `tests/test_axq_commit.py` (~40 LOC: детерминизм коммита на сиде;
  каждая голова выбирается с частотой ~1/6).

### Алгоритм
1. `reset_state()`: `self._committed_head = rng.integers(6)` (uniform).
2. `act()`: если commit-режим — `q = heads[self._committed_head](x)`
   (+ random prior этой головы, как в pool-режиме).
3. `observe()/update()` — БЕЗ изменений (все головы обучаются на общем
   буфере; это bootstrapped-DQN-схема с общим буфером — упрощение против
   Osband 2016 с раздельными масками буфера, честно зафиксировать).

### План эксперимента
- `chain_50`: axq-pool vs axq-commit vs dqn (60k, n=8, solve-rate).
- `gridworld_sparse`: контроль на AUC/надёжности (n=5 при 100k — фильтр
  wall-clock: AXQ ≈ 300 с/100k → 25 мин/руку/среду; chain_50 60k×8 ≈
  24 мин).
- `deceptive_50` (n=5): контроль антитестов (коммит-голова не должна
  ловиться на ловушку).
- Статистика: точный биномиальный CI на solve-rate; Wilcoxon по AUC.

### Ожидаемые цифры
- chain_50: axq-commit solve **≥ 5/8** (vs pool 3/5 n.s., dqn 0/5);
- sparse: надёжность ≥ 7/8 (не хуже pool), AUC в пределах −0.02..+0.10.

### Kill-criteria
chain_50 ≤ 2/8 ИЛИ надёжность на sparse < 6/8 ИЛИ deceptive-антитест
падает (score < 9.0).

### Риск / заметки
Плохие головы получают 1/6 эпизодов — на коротких эпизодах много потерь;
fallback-вариант `commit_softmax_tau>0` (soft-приоритизация по return).

---

## 4. Task-inference gating: MultiHead без task-ID (continual; S–M; ~270 LOC)

**Идея KB:** `98f4ebc5dd2f` + scouted-поддержка `957ea657aec5` (Same
State, Different Task). Закрывает ГЛАВНОЕ ограничение g1: MultiHead —
task-IL (task-ID известен на eval). Domain-IL-версия: агент сам выводит
задачу из потока наблюдений.

### Файлы
- `axq/agents/continual.py`: `TaskInferMultiHeadDQN(MultiHeadDQN)`
  (~150 LOC).
- `axq/envs/multitask.py`: `run_task_sequence_domain_il(...)` — как
  `run_task_sequence`, но на eval НЕ вызывает `set_task`; протокол
  инференса: в начале каждого eval-эпизода окно 50 шагов «разведки»
  (epsilon=0.2, голова по тек. прототипу), затем коммит головы до конца
  эпизода (~60 LOC).
- `scripts/run_continual2.py`: рука `dqn-heads-infer`.
- `tests/test_task_inference.py` (~60 LOC: синтетические задачи с разными
  посещаемостями → точность инференса > 0.9).

### Алгоритм
1. Во время фазы k: `occupancy[k]` — гистограмма посещённых obs
   (обновляется в `observe()`, O(1); для discrete — вектор n_obs).
2. Прототип `P_k = normalize(occupancy[k] + alpha)` (сглаживание).
3. На инференсе: гистограмма окна `W` (последние 200 obs,
   EMA-обновление); `head = argmax_k cosine(W, P_k)`.
4. Коммит на эпизод: после 50 шагов разведки зафиксировать голову.
5. Доп. признак (fallback при сливающихся прототипах): средняя награда
   окна как 1-мерная фича, конкатенированная с гистограммой.

### План эксперимента
- `continual_gridworlds`, 30k/фаза × 5, сиды 0–4 (общие с g1).
- Метрики: (а) inference accuracy (доля eval-эпизодов, маршрутизированных
  в правильную голову — ground truth известен раннеру, но НЕ агенту);
  (б) retention/final_avg/BWT в domain-IL-протоколе; (в) сравнение с
  task-IL оракулом (g1 dqn-heads-persist, те же сиды) и dqn-persist.
- Wall-clock: ≈ руки g1 + overhead инференса (<5%) ≈ 15–25 мин.

### Ожидаемые цифры
- inference accuracy **≥ 80%** (chance 20%);
- domain-IL retention ≥ oracle − 0.1; final_avg **≥ 0.4**.

### Kill-criteria
accuracy < 60% ИЛИ retention < oracle − 0.3 (инференс сливаёт задачи).

### Риск / заметки
5 sparse-гридов похожи (все: старт → цель сквозь стены) — гистограммы
могут совпадать в зоне «коридора» решений; mitigation: alpha-сглаживание,
признак награды, и/или прототип по посещаемости ДО первого достижения
цели (ранняя фаза фазы). Если слияние — честный негатив: «occupancy
недостаточно для инференса, нужны функциональные эмбеддинги».

---

## 5. D4-аугментация: 8 симметрий сетки (generalization; M; ~300 LOC)

**Идея KB:** `6b9153040e79`. Прямая атака на подтверждённый overfit
(e6-n5: train 0.926 vs test −2.53, ~0/250 OOD-успехов). Gridworld-семейство
ТОЧНО инвариантно диэдральной группе D4; трансформации в replay дают
8× эффективное разнообразие карт бесплатно.

### Файлы
- `axq/agents/augment.py` (новый, ~120 LOC): `D4Augmenter(env_family,
  size)` — таблицы `T_g[obs]→obs` (8 × n_obs) и `A_g[action]→action`
  (8 × 4); для RoomNav дополнительно перестановка битов стен
  (bit0=up..bit3=left → по g). Для GridWallEnv (obs = r*size+c) — только
  позиция.
- `axq/agents/dqn.py`: параметр `augmenter=None`; в `update()` после
  `buffer.sample()` — поэлементно (векторизованно) применить случайное
  g∈D4 к `obs`, `next_obs`, `actions` каждого сэмпла (~30 LOC; reward/done
  инвариантны).
- `scripts/run_d4aug.py` (~50 LOC): e6-протокол room_nav_gen.
- `tests/test_d4_augment.py` (~100 LOC): КРИТИЧЕСКИЙ тест инвариантности
  на уровне среды: для случайной карты M и g: step-env с картой g(M) из
  g(s) действием g(a) даёт reward r и состояние g(s') (строим
  преобразованный env и сверяем переходы); + тест TD-целей: bootstrap
  сэмпла корректен (индексы согласованы).

### Алгоритм
1. При создании агента для gridworld-семейства — построить 8 пар таблиц
   (obs, action). Поворот 90°: (r,c)→(c, size−1−r), биты: up→right и т.д.;
   отражения аналогично (перестановка [0,1,2,3] → ф-я от g).
2. В `update()`: `g_idx = rng.integers(0, 8, size=B)`; для one-hot:
   преобразовать индекс obs → one-hot(g∘obs); action: `A_g[a]`.
3. Greedy-eval БЕЗ аугментации.

### План эксперимента
- `room_nav_gen` n_train=5, 100k шагов, сиды 0–4: dqn vs dqn-d4aug
  (paired, одинаковые eval- сиды как в e6); метрики: test mean return
  (50 эп), test success rate, train return/AUC.
- Контроль безвредности: `gridworld_sparse` (n=5, 60k) — AUC не хуже
  −0.02.
- Companion-arm (рекомендуется): featurization (`1657d9900bae`) — тот же
  harness, отдельный агент; итоговая таблица: dqn / dqn-d4 / dqn-feat /
  dqn-d4+feat (комбинация — 1 доп. строка).
- Wall-clock: DQN на room_nav ≈ 42–95 с/100k → ~5–8 мин/руку/5 сидов.
- Статистика: paired exact Wilcoxon на test-return; успех как биномиальная
  метрика.

### Ожидаемые цифры
- test mean return: −2.53 → **> 0.0**; test success **≥ 0.3** (≥75/250);
- train ≥ 0.7; paired Δtest > 1.5 (Wilcoxon n=5).

### Kill-criteria
test mean return ≤ −1.0 (нет значимого сдвига) ИЛИ train < 0.5.

### Риск / заметки
Таблицы для RoomNav должны переставлять биты стен СОГЛАСОВАННО с
действиями (юнит-тест обязателен — ошибка даст тихо неверную модель);
аугментация может замедлить acquisition на 5 картах (батчи менее
согласованные) — контроль по train-AUC. Применимо и к continual-сьюту
(улучшение acquisition не ожидается, но не проверять — вне скоупа).

---

## Приоритет запуска и бюджет цикла 4 (ориентир)

| Порядок | Блок | Wall-clock суммарно | Зависимости |
|---|---|---|---|
| 1 | OptInit (табулярные антитесты + chain50) | ~15 мин | нет; быстрейший сигнал |
| 2 | D4-aug (+ companion featurization) | ~15–25 мин | e6-протокол |
| 3 | PackNet рука в g1-протоколе | ~15 мин | после стабилизации g1 |
| 4 | Task-inference (domain-IL) | ~20 мин | g1 dqn-heads как оракул |
| 5 | Bootstrapped-commit | ~50–60 мин | axq-инфраструктура |

Все блоки укладываются в суммарный бюджет ≤ ~2.5 часов чистых CPU и
могут исполняться возобновляемыми 10-мин чанками (существующий планировщик).

## Fallback-иерархия (если top-5 отказывает)
- chains50 остаётся 0-решаемым после OptInit+Commit → RND (`9fd51a165dcd`),
  затем epistemic-VF (`307dbda594cf`), затем Dyna-lite (`d0e350a7d80f`).
- continual: если PackNet упирается в capacity → LwF (`13b6caf9c63a`)
  как penalty-функциональная ось; если g1-rehearsal доминирует всё →
  pseudo-replay (`a25111793f94`) для memory-эффективности.
- generalization: если D4 и featurization обе дают test ≤ −1.0 →
  диагностика gap (`dfed05e17b8e`) перед любыми новыми агентами
  (возможно, среда требует memory — тогда GRU-варианты).

## Чего сознательно НЕТ в топ-5 (и почему — см. decisions)
- SI и Progressive nets — оси, покрытые g1 (EWC, heads).
- Auto-augmentation policy search (RA2-линия) — L-стоимость на 2 CPU.
- ε-restart / cyclical annealing — не даёт направленного исследования
  (анализ механизма chains50).
- Hypernetwork-heads — вычислительно дороже task-inference при том же
  claim.
