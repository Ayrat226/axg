# Cycle-3 Code Audit Report (Task 9-b, adversarial)

Дата: 2026-02-05 · Агент: code-auditor (9-b) · Метод: построчное чтение 9 файлов
+ целевые числопроверки (без обучения) в `axq/kb/files/9-b/`
(`verify_nstep.py`, `verify_stats_mlp.py`, `verify_env.py`).

Код НЕ модифицировался (read-only). Все находки продублированы в KB
(`reviews`, task 9-b).

---

## 1. Вердикты по 9 файлам

| # | Файл | Вердикт | Главное |
|---|------|---------|---------|
| 1 | `axq/agents/dqn.py` | **sound** | Double-DQN порядок forward/backward корректен (S2 → S → backward; проверено численно, что backward дифференцирует граф ПОСЛЕДНЕГО forward). Target hard-sync ок. MSE-градиент `2/B·td` ок. Note: `load()` — eval-only (не восстанавливает `_step_count`/Adam/буфер/counts; сейчас безопасно — никто не продолжает обучение после load). |
| 2 | `axq/agents/common.py` | **sound** | n-step chains сверены с brute-force (n_step 1/3/5; терминал, трункейт, короткие эпизоды; скидонтирование частичных цепочек `gamma^k`; flush на границе эпизода; цепочки не пересекают эпизоды при вызванном `end_episode` — контракт runner выполняется). FIFO-ring корректен как реализация — но см. находку H1: его взаимодействие с capacity=50000 в e8 сделало rehearsal частичным. `ObsNormalizer` (Welford, count<2 → identity) ок. `EpsilonSchedule` ок. |
| 3 | `axq/core/nn/mlp.py` | **sound** | Finite-difference gradcheck: max err 7e-11 (tanh-MLP). «LAST forward call's graph»-семантика подтверждена. Adam + bias correction ок, глобальный clip-norm ок, Xavier ок. Внимание: активация НЕ применяется к последнему слою — это корректно для DQN, но стало источником H2 в `continual.py`. |
| 4 | `axq/core/runner.py` | **sound-with-notes** | `end_episode()` вызывается на каждом конце эпизода (и term, и trunc) — буферные цепочки не протекают. Eval greedy не мутирует ни агента, ни нормализатор. Note (L3): бюджет `train()` выходит за `total_steps` на до одного эпизода → у разных агентов фактические бюджеты отличаются до `max_episode_steps−1` шагов/апдейтов (≤1.3% на 20k) — смещение в пользу слабого агента, заявленное «равенство бюджетов» — структурное, не численное. |
| 5 | `axq/envs/multitask.py` | **sound-with-notes** | `SparseGridLayoutEnv` детерминирован от `layout_seed`: стены идентичны между конструкциями (проверено; e8 и g1 гоняют одни и те же 5 карт, 41–55 свободных клеток). Метрика `forgetting` слепа к провалам acquisition (уже известно). Note (L2): eval-сиды для gridworld-сьюты «вакуусны» — env не имеет случайности в reset, все 20 эпизодов идентичны, матрица бинарна. |
| 6 | `scripts/run_continual.py` | **sound-with-notes** | Драйвер корректен (агент персистит между фазами; fresh сбрасывает только буфер; eval по всем задачам с сидами 555555+1009j — дизъюнктными между собой, с train-сидами и с runner-сидами 987654). Notes: H1 (partial rehearsal — конфигурация e8), L1 (fresh-warmup асимметрия), L5 (дублирование `run_task_sequence`). |
| 7 | `axq/exp/stats.py` | **sound** | Exact Wilcoxon (scipy 1.14.1, `method="exact"`) при ties ЧИСЛЕННО совпал с полным sign-flip перечислением на 4 кейсах (ratio 1.000) — решение статистика 4-final валидно; all-zero diffs → p=1.0 (конвенция работает); n=5 all-positive → 0.0625 not-sig, n=6 → 0.03125 sig. `holm`/`fdr_bh` совпали с эталонными значениями R `p.adjust` на тест-векторе и прошли 200 property-тестов (монотонность, Holm≥BH). Bootstrap детерминирован. Единственный нит (L4): текст note при n<5 занижает минимально достижимый p (константа 0.0625 верна только при n=5; при n=4 — 0.125, n=3 — 0.25, n=2 — 0.5). |
| 8 | `axq/exp/journal.py` | **needs-fix** | M1: `code_fingerprint` хэширует только `axq/**/*.py`: (а) ВСЕ драйверы экспериментов (`scripts/*.py`, включая `run_continual2.py`) НЕ входят — правка скрипта не меняет `code_version`; (б) `axq/kb/kb_tool.py` (неэкспериментальный код) ВХОДИТ — правки KB паразитно меняют фингерпринт. До g1: включить scripts/, исключить kb/. |
| 9 | `axq/envs/gridworld.py` | **sound** | Трункейт централизован в `EnvBase.step` (длина эпизода ровно max_steps, term при шаге=max даёт term+trunc — буфер хранит только terminated → корректный time-limit bootstrap). Goal absorbing с 0 наградой; `mdp_model` согласован с `_step` (проверено чтением); maze/keys/deadend/dynamic — все рандомные решения детерминированы (sorted-итерации, только membership-использование set-ов). Документированные отклонения (max_steps) честно помечены. |

### Дополнительное покрытие (вне 9 файлов, критично для g1)

| Файл | Вердикт | Главное |
|------|---------|---------|
| `axq/agents/continual.py` | **needs-fix** | **H2**: trunk `MultiHeadDQN` = MLP([64,64,64]) с LINEAR выходом + линейные головы → линейно-линейная композиция схлопывается: вся сеть — ОДИН tanh-слой (у DQN — два). Arm `dqn-heads-persist` архитектурно слабее остальных arms. EWC-часть: инъекция штрафа между `backward` и `adam_step` на живых ссылках grads — корректна; Fisher из буфера; порядок консолидации (после eval фазы) корректен. |
| `scripts/run_continual2.py` | **sound-with-notes** | BUFFER=200k ≥ 150k — full rehearsal (e8-ловушка H1 не воспроизводится, и это задокументировано). Crash-safe пофазовая запись. Notes: M2 (рестарт упавшего сида смешивает строки матрицы из разных попыток; частичные матрицы суммаризируются как полные), L6 (fwt — нестандартное определение), L1 (fresh-warmup). |
| `scripts/calibrate_ewc.py` | **sound-with-notes** | Сиды 100/101 дизъюнктны от g1 (0–4) — гигиена ок; правило выбора lambda прегегистрировано. Наследует L1/L2. Caveat: lambda калибруется в fresh-режиме 2×15k, применяется и к persist-arm — перенос между режимами предположение (задокументировать). |
| `axq/agents/axq.py`, `gru_dqn.py` (spot-check) | **sound** | Порядок forward/backward при двойном использовании MLP — тот же корректный паттерн (S2 → S → backward). |

---

## 2. Суммарная таблица находок

| Severity | Count | Найти (KB reviews, task 9-b) |
|----------|-------|------------------------------|
| CRITICAL | 0 | — |
| HIGH | 2 | H1 e8 partial rehearsal (309619a78616); H2 MultiHeadDQN trunk collapse (625ef3253d43 + amend 77698c7893b8) |
| MEDIUM | 3 | M1 code_fingerprint scope (e93eb879f5fa); M2 g1 restart/summarize mixing (f52c1bb133fd); M3 eps без re-anneal между фазами (5a8e0afb0e9b) |
| LOW | 7 | L1 fresh-warmup асимметрия (844015862a0e); L2 вырожденный eval gridworld-сьюты (bac1390b5afc); L3 budget overshoot train() (3df352d4f64d); L4 note n<6 (58a13d732e09); L5 дублирование протокольного кода (e484debab37d); L6 fwt-метрика (6034e6e6be1e); L7 load() eval-only (68c0586e9c1a) |

Позитивные верификации (что НЕ сломано) — KB notes f20450fa642f: n-step
chains, Double-DQN порядок (все агенты), MLP gradcheck, exact Wilcoxon
(вкл. ties и all-zero), Holm/BH vs R, bootstrap-детерминизм, layout-детерминизм,
eval/train-сид гигиена, межпрогоновый детерминизм.

---

## 3. Топ-3 must-fix до запуска цикла-3 флагмана (g1)

1. **H2 — MultiHeadDQN trunk (continual.py:186-197).** Применить tanh к
   выходу trunk перед головами (или `out_activation` в MLP), иначе arm
   `dqn-heads-persist` — эффективно однослойная сеть, и любой вывод
   «головы помогают/не помогают» сконфаундирован архитектурой. Если
   оставить как есть — переименовать arm и явно задокументировать пониженную
   ёмкость.
2. **M2 — restart-устойчивость run_continual2.summarize.** До запуска
   (3.75M шагов — падения вероятны): (а) отбрасывать/помечать сиды с
   n_phases < n_tasks; (б) писать `run_id` в каждую строку jsonl и
   собирать матрицу только из последней попытки. Иначе упавший и
   перезапущенный сид молча даст смешанную матрицу.
3. **M1 — code_fingerprint.** Включить `scripts/*.py` в хэш (или отдельное
   поле `script_version` в journal-записи) и исключить `axq/kb/`. Без этого
   g1-результаты нельзя будет трассировать к точной версии драйвера —
   ровно та проблема, которая уже зафиксирована в worklog для прошлых
   циклов.

**Не блокирует запуск, но сделать до подведения итогов g1:**
- H1-рефрейминг документов e8 (FINAL_REPORT §2.2, HYPOTHESES H8,
  NEGATIVE_RESULTS): «persistent replay» → «частичный rehearsal (FIFO 50k из
  100k; gw1/gw2 вытеснены к концу)»; валидный сегмент с полным rehearsal —
  эрозия gw2 1.0→0.67 в фазе 3 и gw4 1.0→0.33 (полный rehearsal до конца);
  g1-числа с e8 несравнимы (уже задокументировано в run_continual2).
- M3 — решение по eps-политике (константный 0.05 после фазы 1 vs
  пере-аннелинг) зафиксировать в pre-registered протоколе g1, чтобы
  различия acquisition не были объяснимы отсутствием исследования.

---

## 4. Вердикт о готовности кода к флагману g1

**Условно готов.** Ядро RL-семантики (n-step, Double-DQN, bootstrap,
буфер, runner-контракты, статистика) — sound и подтверждено численными
проверками; e8-ловушка с буфером в g1 уже обойдена (200k). Но до запуска
нужно закрыть топ-3: архитектурная честность heads-arm, restart-устойчивость
сборки результатов, трассируемость кода. Все три — дешёвые правки (суммарно
< 1 часа работы + тесты). Без них валидность ключевых сравнений g1
(особенно heads-vs-persist и любых выводов при падении процесса) под
угрозой.

Ничего не сломано необратимо; прошлые результаты e1–e8 затронуты только на
уровне интерпретации e8 (рефрейминг, не переворот).
