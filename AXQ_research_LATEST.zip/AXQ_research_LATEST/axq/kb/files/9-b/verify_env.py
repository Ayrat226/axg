# 9-b numeric verification 3: SparseGridLayoutEnv determinism + degenerate eval.
import sys
sys.path.insert(0, "/home/z/my-project")
import numpy as np
from axq.envs.multitask import SparseGridLayoutEnv, SUITES

# 1) identical walls across constructions of the same layout_seed
for seed in (101, 102, 103, 104, 105):
    e1 = SparseGridLayoutEnv(layout_seed=seed)
    e2 = SparseGridLayoutEnv(layout_seed=seed)
    same = e1.walls == e2.walls
    n_free = 64 - len(e1.walls)
    print(f"layout_seed={seed}: walls identical across constructions={same}, "
          f"free cells={n_free}, start={e1.start}, goal={e1.goal}, "
          f"max_steps={e1.max_episode_steps}")

# 2) suite task factories == direct construction (e8 vs g1 same maps)
s = SUITES["continual_gridworlds"]
for name, fac in s.tasks:
    e = fac()
    print(f"task {name}: n_obs={e.n_obs} n_actions={e.n_actions} "
          f"step_r={e.step_reward} goal_r={e.goal_reward}")

# 3) degenerate eval: deterministic greedy agent -> all 20 episodes identical
class FixedAgent:
    name = "fixed"
    def reset_state(self): pass
    def act(self, obs, greedy=False): return int(obs) % 4
env = SparseGridLayoutEnv(layout_seed=101)
rewards = []
obs = env.reset(555555)
for ep in range(20):
    env.reset(555555 + ep)
    tot, steps = 0.0, 0
    while True:
        a = FixedAgent.act(None, obs)
        obs, r, term, trunc, info = env.step(a)
        tot += r; steps += 1
        if term or trunc:
            break
    rewards.append((tot, steps))
uniq = set(rewards)
print("20 eval episodes with distinct seeds -> distinct (reward,steps) "
      f"outcomes: {len(uniq)} -> {sorted(uniq)[:3]}...")
print("=> seed value has NO effect on this env (fixed start/goal/layout, "
      "deterministic dynamics): eval_episodes collapses to 1 sample for "
      "greedy deterministic agents")
