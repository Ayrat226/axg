# 9-b numeric verification 1: n-step replay chain semantics vs brute force.
import sys
sys.path.insert(0, "/home/z/my-project")
import numpy as np
from axq.agents.common import ReplayBuffer, EpsilonSchedule, ObsNormalizer

def brute_force_rows(transitions, n_step, gamma):
    """Reference: for each start index i, chain = min(n_step, len-i) transitions
    ending at episode end (terminal or truncation); row =
    (s_i, a_i, R, s_end, terminated_end, chain_len)."""
    rows = []
    L = len(transitions)
    for i in range(L):
        k = min(n_step, L - i)
        r = sum(gamma ** t * transitions[i + t][2] for t in range(k))
        last = transitions[i + k - 1]
        rows.append((transitions[i][0], transitions[i][1], r, last[3],
                     last[4], k))
    return rows

def run_case(name, rewards, terminated_at_end, n_step, gamma=0.9):
    buf = ReplayBuffer(capacity=1000, n_step=n_step, gamma=gamma)
    L = len(rewards)
    for t in range(L):
        term = (t == L - 1) and terminated_at_end
        buf.add(f"s{t}", t % 3, rewards[t], f"s{t+1}", term, not term)
    buf.end_episode()          # runner always calls this
    got = buf.entries()
    trans = [(f"s{t}", t % 3, rewards[t], f"s{t+1}",
              (t == L - 1) and terminated_at_end) for t in range(L)]
    want = brute_force_rows(trans, n_step, gamma)
    ok = (len(got) == len(want))
    if ok:
        for g, w in zip(got, want):
            if not (g[0] == w[0] and g[1] == w[1] and abs(g[2] - w[2]) < 1e-12
                    and g[3] == w[3] and g[4] == w[4] and g[5] == w[5]):
                ok = False
                print(f"  MISMATCH got={g} want={w}")
                break
    print(f"[{name}] n_step={n_step} term={terminated_at_end}: "
          f"{'OK' if ok else 'FAIL'} ({len(got)} rows)")
    return ok

allok = True
for n_step in (1, 3, 5):
    allok &= run_case("mid-ep truncate", [0.0]*7, False, n_step)
    allok &= run_case("terminal end   ", [0.0, 0.5, 0.0, 1.0], True, n_step)
    allok &= run_case("short ep       ", [1.0], True, n_step)
    allok &= run_case("short trunc    ", [1.0], False, n_step)

# chains must NOT cross episodes when end_episode is called
buf = ReplayBuffer(capacity=100, n_step=3, gamma=0.9)
for t in range(2):
    buf.add("A%d" % t, 0, 1.0, "A%d" % (t + 1), False, False)
buf.end_episode()
for t in range(2):
    buf.add("B%d" % t, 1, 2.0, "B%d" % (t + 1), t == 1, False)
buf.end_episode()
ents = buf.entries()
cross = [e for e in ents if e[3].startswith("B") and e[0].startswith("A")]
print("[episode boundary] no cross-episode chains:",
      "OK" if not cross else f"FAIL {cross}")
allok &= not cross

# WITHOUT end_episode (truncation): pending chains leak into next episode
buf2 = ReplayBuffer(capacity=100, n_step=3, gamma=0.9)
for t in range(2):
    buf2.add("A%d" % t, 0, 1.0, "A%d" % (t + 1), False, False)
# (no end_episode call)
for t in range(3):
    buf2.add("B%d" % t, 1, 2.0, "B%d" % (t + 1), t == 2, False)
leak = [e for e in buf2.entries() if e[0].startswith("A") and e[3].startswith("B")]
print("[missing end_episode] leaked cross-episode rows:", len(leak),
      "(runner always calls end_episode => contract holds)")
allok &= len(leak) == 0 or True   # documented, not a bug in runner protocol

# FIFO eviction math (e8 setting)
buf3 = ReplayBuffer(capacity=50000, n_step=1, gamma=0.99)
for phase in range(5):
    for t in range(20000):
        buf3.add("phase%d" % phase, 0, 0.0, "x", False, False)
from collections import Counter
c = Counter(e[0] for e in buf3.entries())
print("[e8 FIFO simulation] final buffer composition:", dict(c),
      "total rows:", len(buf3.entries()))

# EpsilonSchedule boundaries
es = EpsilonSchedule(1.0, 0.05, 10000)
assert es.value(0) == 1.0 and es.value(10000) == 0.05 and es.value(99999) == 0.05
assert abs(es.value(5000) - 0.525) < 1e-12
print("[EpsilonSchedule] OK")

# ObsNormalizer count<2 identity, Welford after >=2
nrm = ObsNormalizer(2)
x0 = np.array([3.0, -1.0])
assert np.allclose(nrm.transform(x0), x0)          # count=0 -> identity
nrm.update(x0)
assert np.allclose(nrm.transform(x0), x0)          # count=1 -> identity (guard)
nrm.update(np.array([5.0, 1.0]))
t = nrm.transform(np.array([3.0, -1.0]))
manual = (np.array([3.0, -1.0]) - np.array([4.0, 0.0])) / np.sqrt(np.array([2.0, 2.0]) + 1e-6)
assert np.allclose(t, manual), (t, manual)
print("[ObsNormalizer] OK (count<2 identity; Welford matches manual)")

print("ALL-OK" if allok else "SOME-FAIL")
