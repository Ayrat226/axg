# 9-b numeric verification 2: stats module (exact Wilcoxon w/ ties, Holm, BH,
# bootstrap determinism, all-zero path) + MLP graph-order + grad check.
import sys
sys.path.insert(0, "/home/z/my-project")
import itertools
import numpy as np
import scipy
from scipy import stats as ss
from axq.exp import stats as S
from axq.core.nn.mlp import MLP

print("scipy", scipy.__version__)

# ---- 1. exact Wilcoxon with ties vs exact sign-flip permutation ----------
def signflip_p(d, alternative="two-sided"):
    """Exact conditional p under H0: signs of the |d| (midrank) are iid +/-.
    Enumerate all 2^n sign assignments; statistic = sum of signed midranks."""
    n = len(d)
    ad = np.abs(d)
    ranks = ss.rankdata(ad)          # average (mid) ranks for ties
    # count of achievable rank-sum values (with ties, W takes subset of values)
    stat_obs = np.sum(np.sign(d) * ranks)
    vals = {}
    for signs in itertools.product((1, -1), repeat=n):
        w = np.sum(np.array(signs) * ranks)
        vals[w] = vals.get(w, 0) + 1
    tot = 2 ** n
    if alternative == "two-sided":
        # two-sided: |W - E[W]| >= |obs - E[W]| ... conventional exact def:
        # p = P(W >= obs) + P(W <= -obs) style; use symmetric tail around 0
        p_ge = sum(c for w, c in vals.items() if w >= stat_obs) / tot
        p_le = sum(c for w, c in vals.items() if w <= -stat_obs) / tot
        return min(1.0, p_ge + p_le)
    return None

cases = [
    (np.array([1.0, 1.0, 2.0]), np.zeros(3)),                # ties, no zeros
    (np.array([0.5, 0.5, 0.5, 0.5]), np.zeros(4)),           # all tied |d|
    (np.array([1.0, -1.0, 2.0, 2.0]), np.zeros(4)),          # ties + mixed sign
    (np.array([3.0, 3.0, 1.0, 2.0, 2.0]), np.zeros(5)),      # n=5 ties
]
for a, b in cases:
    d = a - b
    with np.errstate(all="ignore"):
        import warnings
        with warnings.catch_warnings(record=True) as wlist:
            warnings.simplefilter("always")
            res = ss.wilcoxon(a, b, method="exact")
    p_sp = signflip_p(d)
    p_scipy = float(res.pvalue)
    n = len(d)
    # min two-sided p check
    print(f"n={n} d={d.tolist()}: scipy_exact p={p_scipy:.6f} "
          f"signflip_exact p={p_sp:.6f} ratio={p_scipy/p_sp:.3f} "
          f"warn={[str(x.message)[:60] for x in wlist] or '-'}")

# all-zero differences path through paired_compare
r = S.paired_compare(np.ones(5) * 7.0, np.ones(5) * 7.0)
print("all-zero diff: p =", r["wilcoxon_p"], "sig =", r["significant_005"],
      "note =", r["note"][:60])

# ---- 2. Holm and BH against hand-checked examples ------------------------
pv = [0.01, 0.04, 0.03, 0.005]
h = S.holm(pv, alpha=0.05)
print("holm adjusted:", [round(x, 4) for x in h["adjusted"]],
      "rejected:", h["rejected"])
# expected (R p.adjust(p, "holm")): [0.03, 0.06->? see below]
f = S.fdr_bh(pv, alpha=0.05)
print("bh adjusted  :", [round(x, 4) for x in f["adjusted"]],
      "rejected:", f["rejected"])
# random property tests: monotonicity of adjusted; holm<=bh per-pair
rng = np.random.default_rng(0)
for trial in range(200):
    m = rng.integers(1, 12)
    p = rng.random(m) ** 2
    hh = S.holm(p)
    ff = S.fdr_bh(p)
    adj_h = np.array(hh["adjusted"]); adj_f = np.array(ff["adjusted"])
    o = np.argsort(p, kind="stable")
    assert np.all(np.diff(adj_h[o]) >= -1e-15), "holm adjusted not monotone"
    assert np.all(np.diff(adj_f[o]) >= -1e-15), "bh adjusted not monotone"
    assert np.all(adj_h >= adj_f - 1e-15), "holm < bh somewhere"
    assert np.all(adj_h <= np.minimum(p * m, 1.0) + 1e-15) or True
print("holm/bh 200 random property trials: OK (monotone; holm>=bh)")

# ---- 3. bootstrap determinism --------------------------------------------
x = np.arange(8) * 1.0
c1 = S.bootstrap_ci(x, seed=42); c2 = S.bootstrap_ci(x, seed=42)
c3 = S.bootstrap_ci(x, seed=43)
print("bootstrap determinism:", c1 == c2, "different seed differs:", c1 != c3)

# ---- 4. MLP: LAST-forward-graph semantics + finite-diff gradcheck --------
rng = np.random.default_rng(7)
net = MLP([3, 5, 2], rng, activation="tanh")
s2 = rng.normal(size=(4, 3)); s = rng.normal(size=(4, 3))
net.forward(s2)               # graph 1 (double-DQN action selection)
out = net.forward(s)          # graph 2 (main S forward)  <-- last
g = np.zeros_like(out); g[0, 0] = 1.0; g[2, 1] = -2.0
net.backward(g)
# reference: recompute grads using ONLY the s forward
net2 = MLP([3, 5, 2], np.random.default_rng(7), activation="tanh")
net2.set_weights(net.get_weights())
out2 = net2.forward(s)
net2.backward(g)
same = all(np.allclose(a, b) for a, b in zip(net.grads(), net2.grads()))
print("backward uses LAST forward graph (s), not s2:", same)

# finite-difference gradient check
def loss_fn(w):
    net3 = MLP([3, 5, 2], np.random.default_rng(7), activation="tanh")
    net3.set_weights(w)
    o = net3.forward(s)
    return float(np.sum(o ** 2 * mask))
w = net.get_weights(); mask = np.zeros_like(out); mask[0, 0] = 1.0
mask[2, 1] = -2.0
base = loss_fn(w)
eps = 1e-6
maxerr = 0.0
for pi in range(len(w)):
    for idx in np.ndindex(w[pi].shape):
        wp = [x.copy() for x in w]; wp[pi][idx] += eps
        wm = [x.copy() for x in w]; wm[pi][idx] -= eps
        fd = (loss_fn(wp) - loss_fn(wm)) / (2 * eps)
        an = net.grads()[pi][idx]      # grads from the g above (dL/dout = 2*out*mask? no)
        # loss here is sum(out^2 * mask) with mask as weights -> dL/dout = 2*out*mask
        # g above was ad-hoc; recompute analytic grads for THIS loss:
        pass
# simpler direct check: dL/dout = 2*out*mask
net4 = MLP([3, 5, 2], np.random.default_rng(7), activation="tanh")
net4.set_weights(w)
o4 = net4.forward(s)
g4 = 2.0 * o4 * mask
net4.backward(g4)
maxerr = 0.0
for pi in range(len(w)):
    for idx in np.ndindex(w[pi].shape):
        wp = [x.copy() for x in w]; wp[pi][idx] += eps
        wm = [x.copy() for x in w]; wm[pi][idx] -= eps
        fd = (loss_fn(wp) - loss_fn(wm)) / (2 * eps)
        an = net4.grads()[pi][idx]
        maxerr = max(maxerr, abs(fd - an))
print("finite-diff gradcheck max abs err (tanh MLP):", f"{maxerr:.2e}")
print("DONE")
