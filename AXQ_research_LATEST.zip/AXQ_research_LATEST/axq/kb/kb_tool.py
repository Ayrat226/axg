#!/usr/bin/env python3
"""AXQ Knowledge Base: crash-safe persistence for multi-agent research data.

Crash-safety contract (WHY this exists)
---------------------------------------
Subagents die mid-task. Everything valuable they produce must already be
on disk the moment it is produced. Rules enforced here:

1. Collections are APPEND-ONLY JSONL files (one JSON record per line).
   Appends use a single os.write() on an O_APPEND descriptor -> atomic for
   lines < ~8 KB on local filesystems. A crashed agent can never corrupt
   or erase lines that were already saved.
2. Records are small (hard cap 8192 bytes). Long artifacts (reports,
   designs, tables) are stored as files under files/<task_id>/ and
   referenced by a small pointer record.
3. Heartbeats: status/<task_id>.json, written atomically (tmp + rename).
   Lets the orchestrator detect stalled agents; everything already in the
   collections survives by design.
4. Nothing is ever deleted or rewritten. Corrections are NEW records with
   an "amends": "<record-id>" field.

Collections
-----------
ideas, hypotheses, reviews, decisions, negative_results, experiments,
notes, subagent_reports.

CLI
---
  kb_tool.py add <coll> '<json>' [--task ID] [--agent NAME] [--amends ID]
  kb_tool.py add-file <coll> <filepath> '<meta-json>' [--task ID] [--agent NAME]
  kb_tool.py status <task_id> '<json>'
  kb_tool.py list <coll> [--task ID] [--last N]
  kb_tool.py stats
  kb_tool.py snapshot
"""
import argparse
import datetime as _dt
import json
import os
import shutil
import sys
import uuid

KB_ROOT = os.path.dirname(os.path.abspath(__file__))
COLL_DIR = os.path.join(KB_ROOT, "collections")
STATUS_DIR = os.path.join(KB_ROOT, "status")
FILES_DIR = os.path.join(KB_ROOT, "files")
SNAP_DIR = os.path.join(KB_ROOT, "snapshots")

COLLECTIONS = ["ideas", "hypotheses", "reviews", "decisions",
               "negative_results", "experiments", "notes",
               "subagent_reports"]
MAX_LINE_BYTES = 8192


def _now():
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _coll_path(collection):
    if collection not in COLLECTIONS:
        raise SystemExit("unknown collection %r; allowed: %s"
                         % (collection, ", ".join(COLLECTIONS)))
    return os.path.join(COLL_DIR, collection + ".jsonl")


def _read_records(collection):
    path = _coll_path(collection)
    if not os.path.exists(path):
        return []
    out = []
    with open(path, encoding="utf-8") as f:
        for ln, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                # Never crash on a torn line: skip and continue (the whole
                # point of the KB is that partial data stays readable).
                sys.stderr.write("WARN: torn line %d in %s (skipped)\n"
                                 % (ln, collection))
    return out


def _atomic_append(path, line):
    data = (line + "\n").encode("utf-8")
    if len(data) > MAX_LINE_BYTES:
        raise SystemExit(
            "record too large (%d bytes > %d): store the payload under "
            "files/<task_id>/ and add a pointer record instead"
            % (len(data), MAX_LINE_BYTES))
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
    try:
        os.write(fd, data)      # single append write: atomic on POSIX
    finally:
        os.close(fd)


def _parse_json(text, what):
    try:
        obj = json.loads(text)
    except json.JSONDecodeError as e:
        raise SystemExit("%s is not valid JSON: %s" % (what, e))
    if not isinstance(obj, dict):
        raise SystemExit("%s must be a JSON object" % what)
    return obj


# ---------------------------------------------------------------- commands
def cmd_add(args):
    payload = _parse_json(args.json, "payload")
    rec = {"id": uuid.uuid4().hex[:12], "ts": _now(),
           "task_id": args.task, "agent": args.agent, "payload": payload}
    if args.amends:
        rec["amends"] = args.amends
    _atomic_append(_coll_path(args.collection),
                   json.dumps(rec, ensure_ascii=False))
    print(rec["id"])


def cmd_add_file(args):
    meta = _parse_json(args.meta, "meta")
    src = os.path.abspath(args.filepath)
    if not os.path.isfile(src):
        raise SystemExit("no such file: %s" % src)
    dest_dir = os.path.join(FILES_DIR, args.task or "unassigned")
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, os.path.basename(src))
    tmp = dest + ".tmp"
    shutil.copyfile(src, tmp)
    os.replace(tmp, dest)
    rec = {"id": uuid.uuid4().hex[:12], "ts": _now(),
           "task_id": args.task, "agent": args.agent,
           "payload": {"type": "file", "path": dest, "meta": meta}}
    _atomic_append(_coll_path(args.collection),
                   json.dumps(rec, ensure_ascii=False))
    print(rec["id"] + " -> " + dest)


def cmd_status(args):
    payload = _parse_json(args.json, "status payload")
    doc = {"task_id": args.task_id, "ts": _now(), "payload": payload}
    os.makedirs(STATUS_DIR, exist_ok=True)
    path = os.path.join(STATUS_DIR, args.task_id + ".json")
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=1)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    print("ok")


def cmd_list(args):
    recs = _read_records(args.collection)
    if args.task:
        recs = [r for r in recs if r.get("task_id") == args.task]
    if args.last:
        recs = recs[-int(args.last):]
    for r in recs:
        print(json.dumps(r, ensure_ascii=False))


def cmd_stats(args):
    total = 0
    print("collections:")
    for c in COLLECTIONS:
        n = len(_read_records(c))
        total += n
        print("  %-18s %4d records" % (c, n))
    print("status (heartbeats):")
    if os.path.isdir(STATUS_DIR):
        for fn in sorted(os.listdir(STATUS_DIR)):
            if fn.endswith(".json"):
                p = os.path.join(STATUS_DIR, fn)
                try:
                    with open(p, encoding="utf-8") as f:
                        d = json.load(f)
                    print("  %-24s ts=%s phase=%s"
                          % (fn[:-5], d.get("ts"),
                             d.get("payload", {}).get("phase", "?")))
                except Exception as e:          # noqa: BLE001
                    print("  %-24s unreadable (%s)" % (fn[:-5], e))
    else:
        print("  (none)")
    print("total records: %d" % total)


def cmd_snapshot(args):
    os.makedirs(SNAP_DIR, exist_ok=True)
    snap = {"ts": _now(), "collections": {}}
    for c in COLLECTIONS:
        snap["collections"][c] = _read_records(c)
    path = os.path.join(SNAP_DIR, "kb_" + _now().replace(":", "") + ".json")
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(snap, f, ensure_ascii=False)
    os.replace(tmp, path)
    n = sum(len(v) for v in snap["collections"].values())
    print("snapshot: %s (%d records)" % (path, n))


def main():
    ap = argparse.ArgumentParser(description="AXQ crash-safe knowledge base")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("add")
    p.add_argument("collection")
    p.add_argument("json")
    p.add_argument("--task", default=None)
    p.add_argument("--agent", default=None)
    p.add_argument("--amends", default=None)
    p.set_defaults(fn=cmd_add)

    p = sub.add_parser("add-file")
    p.add_argument("collection")
    p.add_argument("filepath")
    p.add_argument("meta")
    p.add_argument("--task", default=None)
    p.add_argument("--agent", default=None)
    p.set_defaults(fn=cmd_add_file)

    p = sub.add_parser("status")
    p.add_argument("task_id")
    p.add_argument("json")
    p.set_defaults(fn=cmd_status)

    p = sub.add_parser("list")
    p.add_argument("collection")
    p.add_argument("--task", default=None)
    p.add_argument("--last", type=int, default=None)
    p.set_defaults(fn=cmd_list)

    p = sub.add_parser("stats")
    p.set_defaults(fn=cmd_stats)

    p = sub.add_parser("snapshot")
    p.set_defaults(fn=cmd_snapshot)

    for d in (COLL_DIR, STATUS_DIR, FILES_DIR, SNAP_DIR):
        os.makedirs(d, exist_ok=True)

    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
