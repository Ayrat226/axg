"""9-c re-analysis: mean-of-last-k-checkpoints metric vs single-checkpoint.

Read-only over results/; writes nothing outside reanalysis_lastk/.
Metrics per seed:
  old   = curve[-1][1]              (single-checkpoint final eval == final_mean_per_seed)
  last3 = mean(curve[-3:])
  last5 = mean(curve[-min(5, len(curve)):])
Statistics: axq.exp.stats.paired_compare (exact Wilcoxon + paired bootstrap CI).
"""
import json, os, sys
import numpy as np

sys.path.insert(0, '/home/z/my-project')
from axq.exp.stats import paired_compare

RES = '/home/z/my-project/axq/results'


def load_seed_metrics(exp_id):
    """exp dir with seed_k.json; returns {seed: dict(old,last3,last5,npts,curve)}"""
    d = os.path.join(RES, exp_id)
    out = {}
    for f in sorted(os.listdir(d)):
        if not (f.startswith('seed_') and f.endswith('.json')):
            continue
        j = json.load(open(os.path.join(d, f)))
        curve = [(int(p[0]), float(p[1])) for p in j['curve']]
        vals = [v for _, v in curve]
        n = len(vals)
        out[j['seed']] = {
            'old': vals[-1],
            'last3': float(np.mean(vals[-3:])),
            'last5': float(np.mean(vals[-min(5, n):])),
            'npts': n,
            'final_eval': float(j['final_eval']['mean']),
            'curve': curve,
        }
    return out


def load_e6_seed_metrics(n_maps):
    """e6-seeds/roomnav-dqn-n{N}-{k}.json; old = train_score (= final train eval),
    curve = train-split eval curve (5 pts @20k). test has NO curve (single checkpoint)."""
    out = {}
    d = os.path.join(RES, 'e6-seeds')
    for f in sorted(os.listdir(d)):
        if not f.startswith(f'roomnav-dqn-n{n_maps}-'):
            continue
        j = json.load(open(os.path.join(d, f)))
        vals = [float(p[1]) for p in j['curve']]
        assert abs(vals[-1] - j['train_score']) < 1e-9, (f, vals[-1], j['train_score'])
        out[j['seed']] = {
            'old': j['train_score'],
            'last3': float(np.mean(vals[-3:])),
            'last5': float(np.mean(vals[-min(5, len(vals)):])),
            'npts': len(vals),
            'test_score': j['test_score'],
            'curve': [(int(p[0]), float(p[1])) for p in j['curve']],
        }
    return out


def pair_stats(ma, mb, metric, label_a, label_b):
    """ma, mb: {seed: metrics}. Intersection of seeds; a=label_a arm."""
    seeds = sorted(set(ma) & set(mb))
    a = np.array([ma[s][metric] for s in seeds])
    b = np.array([mb[s][metric] for s in seeds])
    r = paired_compare(a, b)
    return {
        'metric': metric,
        'a': label_a, 'b': label_b,
        'seeds': seeds, 'n': len(seeds),
        'mean_a': float(a.mean()), 'mean_b': float(b.mean()),
        'per_seed_a': [round(float(v), 4) for v in a],
        'per_seed_b': [round(float(v), 4) for v in b],
        'wilcoxon_p': r['wilcoxon_p'],
        'mean_diff': r['mean_diff'],
        'ci': r['bootstrap_ci95_mean_diff'],
        'cohen_d': r['cohen_d_paired'],
        'rank_biserial': r['rank_biserial'],
        'significant_005': r['significant_005'],
        'note': r['note'],
    }


def verdict(st):
    if st['significant_005']:
        who = st['a'] if st['mean_diff'] > 0 else st['b']
        return f"{who} лучше (significant)"
    return "паритет (insufficient evidence; NOT equality)"


def run_pair(ma, mb, label_a, label_b, extra=None):
    res = {'a': label_a, 'b': label_b}
    for metric in ('old', 'last3', 'last5'):
        st = pair_stats(ma, mb, metric, label_a, label_b)
        st['verdict'] = verdict(st)
        res[metric] = st
    res['verdict_changed'] = (res['old']['verdict'] != res['last3']['verdict']
                              or res['old']['verdict'] != res['last5']['verdict'])
    if extra:
        res.update(extra)
    return res


if __name__ == '__main__':
    print('module ok')
