"""Shared testing utilities: env contract checks + scripted policies.

Every environment must pass ``check_env``. Env-specific tests additionally
verify task semantics (solvability by scripted/optimal policies).
"""
import numpy as np
from axq.core.env import EnvBase


class ScriptedPolicy:
    """Deterministic action sequence (repeats last action if exhausted)."""

    def __init__(self, actions):
        self.actions = list(actions)
        self._i = 0

    def __call__(self, obs=None):
        a = self.actions[min(self._i, len(self.actions) - 1)]
        self._i += 1
        return a

    def reset(self):
        self._i = 0


def check_env(env, n_episodes=3, check_invalid_action=True):
    """Contract checks every env must pass.

    1. reset/step types and obs validity
    2. strict determinism: same seed + same action sequence -> same trajectory
    3. episodes terminate within max_episode_steps
    4. invalid actions raise
    """
    assert isinstance(env, EnvBase), f"{type(env)} is not EnvBase"
    assert env.n_actions >= 1
    assert env.n_obs >= 1
    assert env.max_episode_steps >= 1
    assert env.obs_type in ("discrete", "vector")

    def _run_traj(seed):
        rng = np.random.default_rng(seed)
        traj = []
        obs = env.reset(seed)
        _assert_obs(env, obs)
        while True:
            a = int(rng.integers(env.n_actions))
            obs, r, term, trunc, info = env.step(a)
            assert isinstance(r, float), "reward must be float"
            assert isinstance(term, bool) and isinstance(trunc, bool)
            assert isinstance(info, dict)
            _assert_obs(env, obs)
            traj.append((a, float(r), term, trunc))
            assert len(traj) <= env.max_episode_steps, \
                "episode exceeded max_episode_steps"
            if term or trunc:
                break
        return traj

    t1 = _run_traj(0)
    t2 = _run_traj(0)
    assert t1 == t2, "env is not deterministic under identical seed+actions"
    for s in range(1, n_episodes):
        _run_traj(s)

    if check_invalid_action:
        env.reset(0)
        try:
            env.step(env.n_actions)
        except (ValueError, IndexError):
            pass
        else:
            raise AssertionError("env must reject out-of-range action")
    return env


def _assert_obs(env, obs):
    if env.obs_type == "discrete":
        assert isinstance(obs, (int, np.integer)), \
            f"discrete obs must be int, got {type(obs)}"
        assert 0 <= obs < env.n_obs, f"obs {obs} out of [0, {env.n_obs})"
    else:
        arr = np.asarray(obs, dtype=np.float64)
        assert arr.shape == (env.n_obs,), \
            f"vector obs shape {arr.shape} != ({env.n_obs},)"
