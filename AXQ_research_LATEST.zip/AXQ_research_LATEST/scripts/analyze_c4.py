"""Cycle-4 replication analysis (H14/H15) — preregistered endpoints.

Outputs (also printed verbatim for STATS_REGISTRY.md):
* H14: pass rates per env x arm x agent with Clopper-Pearson 95% CIs;
  primary test R1 (arm M1: tab pass<=3/12 AND dqn pass>=9/12 per env);
  side-by-side with original e5 results.
* H15: paired AUC diff (axq - dqn) on seeds 200-211, exact Wilcoxon,
  cohen_dz, bootstrap CI; side-by-side with original e3-sparse (seeds 0-7).
* RAW per-seed values for every endpoint (user requirement).
Family R Holm correction applied at the END (Task 19 combines R1/R2/R3).
"""
import json
import math
import sys

sys.path.insert(0, "/home/z/my-project")
import numpy as np

from axq.exp.stats import paired_compare

R = "/home/z/my-project/axq/results"
C4 = R + "/c4repl"
OUT = {}


def clopper_pearson(k, n, alpha=0.05):
    """Exact binomial CI (two-sided)."""
    from scipy.stats import beta as beta_dist
    lo = 0.0 if k == 0 else beta_dist.ppf(alpha / 2, k, n - k + 1)
    hi = 1.0 if k == n else beta_dist.ppf(1 - alpha / 2, k + 1, n - k)
    return float(lo), float(hi)


def load(job):
    p = f"{C4}/{job}/summary.json"
    if not __import__("os").path.exists(p):
        return None
    return json.load(open(p))


def h14():
    envs = ["deceptive_50", "credit_assignment", "gridworld_decoy"]
    arms = {
        "O": {"tab": "h14-O-tab-{e}", "dqn": "h14-O-dqn-{e}",
              "axq": "h14-O-axq-{e}"},
        "M1": {"tab": "h14-M1-tab-{e}", "dqn": "h14-O-dqn-{e}"},  # dedup
        "M2": {"tab": "h14-O-tab-{e}", "dqn": "h14-M2-dqn-{e}"},  # dedup
    }
    res = {}
    for e in envs:
        res[e] = {}
        for arm, agents in arms.items():
            for ag, tpl in agents.items():
                sm = load(tpl.format(e=e))
                if sm is None:
                    continue
                k = int(round(sm["pass_rate"] * len(sm["final_per_seed"])))
                n = len(sm["final_per_seed"])
                lo, hi = clopper_pearson(k, n)
                res[e][f"{arm}:{ag}"] = {
                    "k": k, "n": n, "pass_rate": sm["pass_rate"],
                    "cp95": [round(lo, 3), round(hi, 3)],
                    "final_per_seed": [round(x, 3)
                                       for x in sm["final_per_seed"]],
                    "large_events": sm.get("large_events", {}),
                }
    # primary test R1: under M1, per env: tab <= 3/12 AND dqn >= 9/12
    r1 = {}
    for e in envs:
        tab = res[e].get("M1:tab")
        dqn = res[e].get("M1:dqn")
        if tab and dqn:
            r1[e] = {"tab_ok": tab["k"] <= 3, "dqn_ok": dqn["k"] >= 9,
                     "R1_pass": tab["k"] <= 3 and dqn["k"] >= 9}
    OUT["H14"] = {"pass_rates": res, "primary_R1": r1}
    return res, r1


def h15():
    axq = load("h15-sparse-axq")
    dqn = load("h15-sparse-dqn")
    if not (axq and dqn):
        OUT["H15"] = {"status": "incomplete"}
        return None
    seeds = sorted(set(axq["seeds"]) & set(dqn["seeds"]))
    a = [axq["auc_per_seed"][axq["seeds"].index(s)] for s in seeds]
    d = [dqn["auc_per_seed"][dqn["seeds"].index(s)] for s in seeds]
    cmp_ = paired_compare(a, d)
    # original e3-sparse (seeds 0-7) for side-by-side
    orig_a, orig_d = None, None
    try:
        orig_a = json.load(open(f"{R}/e3-sparse-axq/summary.json"))
        orig_d = json.load(open(f"{R}/e3-sparse-dqn/summary.json"))
    except Exception:
        pass
    OUT["H15"] = {
        "seeds": seeds,
        "axq_auc_per_seed": [round(x, 4) for x in a],
        "dqn_auc_per_seed": [round(x, 4) for x in d],
        "paired_diff_per_seed": [round(x - y, 4) for x, y in zip(a, d)],
        "stats": {k: (round(v, 5) if isinstance(v, float) else v)
                  for k, v in cmp_.items() if not isinstance(v, str)},
        "note": cmp_.get("note", ""),
        "original_e3": ({
            "axq_auc": [round(x, 4) for x in orig_a["auc_per_seed"]],
            "dqn_auc": [round(x, 4) for x in orig_d["auc_per_seed"]],
            "seeds": orig_a["seeds"],
        } if orig_a and orig_d else None),
        "final_axq_per_seed": [round(x, 3) for x in axq["final_per_seed"]],
        "final_dqn_per_seed": [round(x, 3) for x in dqn["final_per_seed"]],
    }
    return OUT["H15"]


def h16_preview():
    """H16 lives in g1repl (run_continual2); preview retention if present."""
    import os
    d = R + "/g1repl"
    if not os.path.isdir(d):
        OUT["H16"] = {"status": "not_started"}
        return
    out = {}
    for arm in ("dqn-persist", "dqn-heads-persist"):
        rows = {}
        for fn in sorted(os.listdir(d)):
            if fn.startswith(f"{arm}_seed") and fn.endswith(".jsonl"):
                seed = int(fn.split("seed")[1].split(".")[0])
                lines = [json.loads(x) for x in open(os.path.join(d, fn))
                         if x.strip()]
                if len(lines) == 5:
                    rows[seed] = lines
        if rows:
            rets, acqs = [], []
            for seed, lines in sorted(rows.items()):
                M = np.array([l["row"] for l in lines])
                rets.append(float(M[-1, :-1].mean()))
                acqs.append(float(np.diag(M).mean()))
            out[arm] = {"n": len(rows),
                        "retention_per_seed": [round(x, 3) for x in rets],
                        "acquisition_per_seed": [round(x, 3) for x in acqs]}
    if len(out) == 2:
        a = out["dqn-heads-persist"]["retention_per_seed"]
        b = out["dqn-persist"]["retention_per_seed"]
        n = min(len(a), len(b))
        if n >= 5:
            cmp_ = paired_compare(a[:n], b[:n])
            out["paired"] = {k: (round(v, 5) if isinstance(v, float) else v)
                             for k, v in cmp_.items()
                             if not isinstance(v, str)}
    OUT["H16"] = out if out else {"status": "running"}


if __name__ == "__main__":
    res, r1 = h14()
    print("=" * 72)
    print("H14 — deceptive separation replication (seeds 200-211)")
    print("=" * 72)
    for e, arms in res.items():
        print(f"\n[{e}]  (V* pass bar; original e5: tab FAIL, dqn/axq PASS)")
        for k, v in arms.items():
            lo, hi = v["cp95"]
            print("  %10s: %d/%d pass (CP95 [%.2f, %.2f]) final/seed=%s"
                  % (k, v["k"], v["n"], lo, hi, v["final_per_seed"]))
    print("\nR1 primary test (M1 arm):")
    for e, v in r1.items():
        print(f"  {e}: tab_ok={v['tab_ok']} dqn_ok={v['dqn_ok']} "
              f"-> R1 {'PASS' if v['R1_pass'] else 'FAIL'}")

    h15()
    print("\n" + "=" * 72)
    print("H15 — sparse AUC edge replication (paired, seeds 200-211)")
    print("=" * 72)
    if OUT["H15"].get("stats"):
        s = OUT["H15"]
        print(f"  axq AUC/seed: {s['axq_auc_per_seed']}")
        print(f"  dqn AUC/seed: {s['dqn_auc_per_seed']}")
        print(f"  diff/seed:    {s['paired_diff_per_seed']}")
        st = s["stats"]
        print(f"  mean diff={st['mean_diff']:.4f}  dz={st['cohen_d_paired']:.3f}"
              f"  p={st['wilcoxon_p']:.5f}  CI={st['bootstrap_ci95_mean_diff']}")
        if s["original_e3"]:
            print(f"  original e3 (0-7): axq={s['original_e3']['axq_auc']}")
            print(f"                     dqn={s['original_e3']['dqn_auc']}")

    h16_preview()
    print("\n" + "=" * 72)
    print("H16 — g1 retention replication preview (g1repl)")
    print("=" * 72)
    print(json.dumps(OUT.get("H16", {}), indent=1)[:1500])

    with open(R + "/c4repl/ANALYSIS.json", "w") as f:
        json.dump(OUT, f, indent=2)
    print("\nsaved -> axq/results/c4repl/ANALYSIS.json")
