"""H18 sensitivity analysis: factorial pass-rate tables + registered
prediction verdicts (S1-S6, with KB amendment e349e51be77e).

Phase A (tabular family): delay x ratio x noise x slip x variant.
Phase B (dyna/dqn/axq reduced grid). Phase C (decoy trap levels).
Outputs: pivot tables (pass rates), prediction verdicts, raw JSON.
"""
import json
import os
import sys
from collections import defaultdict

sys.path.insert(0, "/home/z/my-project")
import numpy as np

D = "/home/z/my-project/axq/results/h18sens"
OUT = {"prereg": "H18 S1-S6 + KB amendment e349e51be77e (tab-count/EFE "
       "predicted to FAIL deceptive family)"}


def load_cells(phase):
    cells = defaultdict(list)
    if not os.path.isdir(D):
        return cells
    for dn in sorted(os.listdir(D)):
        if not dn.startswith(f"{phase}_"):
            continue
        p = os.path.join(D, dn, "summary.json")
        if not os.path.exists(p):
            continue
        sm = json.load(open(p))
        cells[(sm["cfg"].get("delay"), sm["cfg"].get("large_reward",
                                                     sm["cfg"].get(
                                                         "trap_reward")),
               sm["cfg"].get("n_noise_actions", 0),
               sm["cfg"].get("slip", 0.0), sm["variant"])] = sm
    return cells


def table(cells, title, axes):
    print(f"\n=== {title} ===")
    hdr = " | ".join(f"{a:>10s}" for a in axes + ["pass_rate", "final", "V*"])
    print(hdr)
    for key in sorted(cells, key=lambda k: tuple(
            (x is None, x) for x in k)):
        sm = cells[key]
        vals = [f"{key[i]:>10}" if key[i] is not None else "         -"
                for i in range(len(axes))]
        print(" | ".join(vals) + f" | {sm['pass_rate']:>10.2f}"
              f" | {sm['final_mean']:>8.3f} | {sm['V0']:>6.3f}")


def predictions(cells_a, cells_b, cc):
    """Registered prediction verdicts (direction predictions, descriptive)."""
    P = {}

    def get(delay, ratio, noise, slip, variant):
        return cells_a.get((delay, ratio, noise, slip, variant))

    # S1: tab-eps fails for ALL ratios >= 2 (baseline noise=0, slip=0)
    s1 = []
    for ratio in (2, 5, 10):
        sm = get(10, ratio, 0, 0.0, "tab-eps")
        if sm:
            s1.append(sm["pass_rate"] <= 0.2)
    P["S1_tab_eps_ratio_blind"] = {"cells": len(s1), "all_fail": all(s1)}

    # S2: rescue delay-dependence: tab-floor/tab-longdecay only delay<=5
    for variant in ("tab-floor", "tab-longdecay"):
        d5 = get(5, 10, 0, 0.0, variant)
        d20 = get(20, 10, 0, 0.0, variant)
        if d5 and d20:
            P[f"S2_{variant}"] = {
                "pass_d5": d5["pass_rate"], "pass_d20": d20["pass_rate"],
                "verdict_ok": d5["pass_rate"] > d20["pass_rate"]}
    # amendment: tab-optim passes all; tab-count FAILS deceptive family
    for variant, expect in (("tab-optim", True), ("tab-count", False)):
        ok, n = [], 0
        for delay in (5, 10, 20):
            sm = get(delay, 10, 0, 0.0, variant)
            if sm:
                n += 1
                ok.append((sm["pass_rate"] >= 0.8) if expect
                          else (sm["pass_rate"] <= 0.2))
        if n:
            P[f"amend_{variant}"] = {"cells": n,
                                     "prediction_holds": all(ok)}

    # S3: noise actions don't change pass class (tab-eps + dqn at ratio 10)
    for variant in ("tab-eps",):
        for delay in (10,):
            a = get(delay, 10, 0, 0.0, variant)
            b = get(delay, 10, 2, 0.0, variant)
            if a and b:
                P["S3_noise_invariant"] = {
                    "pass_n0": a["pass_rate"], "pass_n2": b["pass_rate"],
                    "same_class": (a["pass_rate"] <= 0.2) ==
                                  (b["pass_rate"] <= 0.2)}
    # S4: slip=0.2 flips optimum at delay10/ratio10 (V* < small=1):
    #     tab-eps 'accidentally optimal' (takes small); check V* + passes
    sm = get(10, 10, 0, 0.2, "tab-eps")
    if sm:
        P["S4_slip_flip"] = {"V0": sm["V0"],
                             "opt_pol0_take_small": sm.get("opt_pol0") == 0,
                             "tab_eps_pass": sm["pass_rate"],
                             "note": "if V0==1.0 the optimal is take-small; "
                                     "tab-eps taking small = accidentally "
                                     "optimal"}
    # S6: dyna-eps fails deceptive; dyna-optim passes
    for variant, expect in (("dyna-eps", False), ("dyna-optim", True)):
        cells = cells_b
        vals = []
        for delay in (5, 10, 20):
            key = (delay, 10.0, 0, 0.0, variant)
            sm = cells.get(key)
            if sm:
                vals.append((sm["pass_rate"] >= 0.8) if expect
                            else (sm["pass_rate"] <= 0.2))
        if vals:
            P[f"S6_{variant}"] = {"cells": len(vals),
                                  "prediction_holds": all(vals)}
    # S5: decoy — tab-eps fails all trap levels; tab-optim passes all
    for variant, expect in (("tab-eps", False), ("tab-optim", True)):
        vals = []
        for sm in cc.values():
            if sm["variant"] != variant:
                continue
            vals.append((sm["pass_rate"] >= 0.8) if expect
                        else (sm["pass_rate"] <= 0.2))
        if vals:
            P[f"S5_{variant}"] = {"cells": len(vals),
                                  "prediction_holds": all(vals)}
    return P


def main():
    ca, cb, cc = load_cells("a"), load_cells("b"), load_cells("c")
    OUT["n_cells"] = {"a": len(ca), "b": len(cb), "c": len(cc)}
    table(ca, "Phase A: tabular family (delay|ratio|noise|slip|variant)",
          ["delay", "ratio", "noise", "slip", "variant"])
    table(cb, "Phase B: dyna/dqn/axq (delay|ratio|noise|slip|variant)",
          ["delay", "ratio", "noise", "slip", "variant"])
    print(f"\n=== Phase C: decoy trap levels ===")
    print(f"{'trap':>10} | {'variant':>12} | {'pass_rate':>9} | "
          f"{'final':>7} | {'V*':>6}")
    for key in sorted(cc, key=lambda k: (str(k[1]), str(k[4]))):
        sm = cc[key]
        print(f"{key[1]:>10} | {key[4]:>12} | {sm['pass_rate']:>9.2f} | "
              f"{sm['final_mean']:>7.3f} | {sm['V0']:>6.3f}")
    OUT["predictions"] = predictions(ca, cb, cc)
    print("\n=== Registered prediction verdicts ===")
    for k, v in OUT["predictions"].items():
        print(f"  {k}: {v}")
    with open(os.path.join(D, "ANALYSIS.json"), "w") as f:
        json.dump(OUT, f, indent=2, default=str)
    print("saved -> axq/results/h18sens/ANALYSIS.json")


if __name__ == "__main__":
    main()
