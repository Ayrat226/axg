"""H19 analysis: SF/GPI vs dqn-persist on the shared-layout continual suite.

Reads axq/results/h19/*_seed*.jsonl (5-phase rows), computes g1 metrics
(acquisition / retention / final_avg / BWT / forgetting) per arm+seed,
paired SF vs dqn-persist on the shared suite, and the SF negative control
on the layout-varying suite. RAW per-seed values printed verbatim.
"""
import json
import os
import sys

sys.path.insert(0, "/home/z/my-project")
import numpy as np

from axq.exp.stats import paired_compare, summarize

D = "/home/z/my-project/axq/results/h19"
OUT = {"prereg": "H19, KB 25e3df387463 + amendments"}


def load_arm(arm):
    per_seed = {}
    for fn in sorted(os.listdir(D)):
        if not (fn.startswith(f"{arm}_seed") and fn.endswith(".jsonl")):
            continue
        seed = int(fn.split("seed")[1].split(".")[0])
        lines = [json.loads(x) for x in open(os.path.join(D, fn))
                 if x.strip()]
        if len(lines) != 5:
            continue          # incomplete run (audit 9-b convention)
        # restart-mixing guard: use only rows of the LAST run_id per phase
        by_phase = {}
        for l in lines:
            by_phase[l["phase"]] = l
        if len(by_phase) != 5:
            continue
        M = np.array([by_phase[i]["row"] for i in range(5)],
                     dtype=np.float64)
        per_seed[seed] = {
            "matrix": M.tolist(),
            "acquisition": float(np.diag(M).mean()),
            "retention": float(M[-1, :-1].mean()),
            "final_avg": float(M[-1].mean()),
            "bwt": float((M[-1, :-1] - np.diag(M)[:-1]).mean()),
            "avg_forgetting": float(np.mean(
                [M[j, j] - M[-1, j] for j in range(4)])),
        }
    return per_seed


def main():
    arms = ["sf-shared", "dqn-persist-sh", "sf-varying"]
    for arm in arms:
        per_seed = load_arm(arm)
        if not per_seed:
            OUT[arm] = {"status": "no complete runs yet"}
            continue
        rets = [v["retention"] for _, v in sorted(per_seed.items())]
        acqs = [v["acquisition"] for _, v in sorted(per_seed.items())]
        OUT[arm] = {
            "n": len(per_seed),
            "seeds": sorted(per_seed),
            "retention_per_seed": [round(x, 3) for x in rets],
            "acquisition_per_seed": [round(x, 3) for x in acqs],
            "retention_summary": summarize(rets),
            "acquisition_summary": summarize(acqs),
            "matrices": {s: v["matrix"] for s, v in sorted(per_seed.items())},
        }
    # paired SF vs dqn-persist on the shared suite
    sf = OUT.get("sf-shared", {})
    dp = OUT.get("dqn-persist-sh", {})
    if sf.get("n") and dp.get("n"):
        common = sorted(set(sf["seeds"]) & set(dp["seeds"]))
        if len(common) >= 5:
            a = [sf["retention_per_seed"][sf["seeds"].index(s)]
                 for s in common]
            b = [dp["retention_per_seed"][dp["seeds"].index(s)]
                 for s in common]
            cmp_ = paired_compare(a, b)
            OUT["paired_retention_sf_vs_dqn_persist"] = {
                "seeds": common, "sf": a, "dqn_persist": b,
                "stats": {k: (round(v, 5) if isinstance(v, float) else v)
                          for k, v in cmp_.items()
                          if not isinstance(v, str)},
            }
    print(json.dumps({k: v for k, v in OUT.items()
                      if k not in ("prereg",)}, indent=1)[:3000])
    with open(os.path.join(D, "ANALYSIS.json"), "w") as f:
        json.dump(OUT, f, indent=2)
    print("saved -> axq/results/h19/ANALYSIS.json")


if __name__ == "__main__":
    main()
