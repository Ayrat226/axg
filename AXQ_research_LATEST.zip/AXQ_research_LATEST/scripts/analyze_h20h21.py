"""H20/H21 analysis: Dyna benchmark + EFE parameter robustness.

H20 (N2): DynaQ sparse AUC paired vs EXISTING axq/dqn e3-sparse results
(same seeds 0-7, same config) — exact Wilcoxon + dz + CI; deceptive family
pass rates (S6); raw per-seed values.

H21 (N3): normalized score range across parameter grids:
  EFE range (tau_e in {0.5,1,2,4,8} x small) vs eps-family range
  ((eps_end, eps_decay) 12 configs) per env {chain_10, gridworld_sparse,
  deceptive_5}; claim: EFE range <= 0.5 x eps range.
"""
import json
import os
import sys
from collections import defaultdict

sys.path.insert(0, "/home/z/my-project")
import numpy as np

from axq.exp.stats import paired_compare, summarize

D = "/home/z/my-project/axq/results/h20h21"
R = "/home/z/my-project/axq/results"
OUT = {}


def load(job_prefix, suffix=""):
    rows = {}
    if not os.path.isdir(D):
        return rows
    for fn in sorted(os.listdir(D)):
        if fn.startswith(job_prefix) and fn.endswith(".json"):
            seed = int(fn.split("_s")[-1].split(".")[0])
            rows[seed] = json.load(open(os.path.join(D, fn)))
    return rows


def h20():
    # --- primary: sparse AUC paired vs existing axq/dqn (e3, seeds 0-7) ---
    dyna = load("h20-sparse-dyna")
    dyna_opt = load("h20-sparse-dyna-optim")
    try:
        axq = json.load(open(f"{R}/e3-sparse-axq/summary.json"))
        dqn = json.load(open(f"{R}/e3-sparse-dqn/summary.json"))
    except FileNotFoundError:
        axq = dqn = None
    out = {"dyna_n": len(dyna), "dyna_optim_n": len(dyna_opt)}
    if dyna and axq:
        seeds = sorted(set(dyna) & set(axq["seeds"]))
        if len(seeds) >= 6:
            a = [dyna[s]["auc"] for s in seeds]
            b = [axq["auc_per_seed"][axq["seeds"].index(s)] for s in seeds]
            cmp_ = paired_compare(a, b)
            out["dyna_vs_axq"] = {
                "seeds": seeds,
                "dyna_auc_per_seed": [round(x, 4) for x in a],
                "axq_auc_per_seed": [round(x, 4) for x in b],
                "stats": {k: (round(v, 5) if isinstance(v, float) else v)
                          for k, v in cmp_.items()
                          if not isinstance(v, str)}}
    if dyna and dqn:
        seeds = sorted(set(dyna) & set(dqn["seeds"]))
        if len(seeds) >= 6:
            a = [dyna[s]["auc"] for s in seeds]
            b = [dqn["auc_per_seed"][dqn["seeds"].index(s)] for s in seeds]
            cmp_ = paired_compare(a, b)
            out["dyna_vs_dqn"] = {
                "seeds": seeds,
                "dyna_auc_per_seed": [round(x, 4) for x in a],
                "dqn_auc_per_seed": [round(x, 4) for x in b],
                "stats": {k: (round(v, 5) if isinstance(v, float) else v)
                          for k, v in cmp_.items()
                          if not isinstance(v, str)}}
    # --- secondary: deceptive family ---
    for name in ("h20-decep50-dyna", "h20-decep50-dyna-optim",
                 "h20-credit-dyna", "h20-credit-dyna-optim",
                 "h20-decoy-dyna", "h20-decoy-dyna-optim",
                 "h20-chain10-dyna"):
        rows = load(name)
        if rows:
            fins = [r["final"] for s, r in sorted(rows.items())]
            out[name] = {"n": len(rows),
                         "final_per_seed": [round(x, 3) for x in fins],
                         "final_summary": summarize(fins)}
    OUT["H20"] = out


def h21():
    envs = ("chain_10", "gridworld_sparse", "deceptive_5")
    out = {}
    for env in envs:
        efe_scores, eps_scores = defaultdict(list), defaultdict(list)
        for fn in sorted(os.listdir(D)) if os.path.isdir(D) else []:
            if not fn.startswith(f"h21_{env}_"):
                continue
            data = json.load(open(os.path.join(D, fn)))
            score = data["auc"]
            if "_efe_" in fn:
                tau = data["params"]["tau_e"]
                efe_scores[round(tau, 3)].append(score)
            elif "_eps_" in fn:
                key = (data["params"]["eps_end"], data["params"]["eps_decay"])
                eps_scores[key].append(score)
        if not efe_scores or not eps_scores:
            continue
        efe_means = {k: float(np.mean(v)) for k, v in efe_scores.items()}
        eps_means = {k: float(np.mean(v)) for k, v in eps_scores.items()}
        efe_range = max(efe_means.values()) - min(efe_means.values())
        eps_range = max(eps_means.values()) - min(eps_means.values())
        scale = max(abs(max(efe_means.values())), abs(max(eps_means.values())),
                    1e-9)
        out[env] = {
            "efe_grid_means": {str(k): round(v, 4)
                               for k, v in sorted(efe_means.items())},
            "eps_grid_means": {f"end{k[0]}_decay{k[1]}": round(v, 4)
                               for k, v in sorted(eps_means.items())},
            "efe_range": round(efe_range, 4),
            "eps_range": round(eps_range, 4),
            "efe_range_norm": round(efe_range / scale, 4),
            "eps_range_norm": round(eps_range / scale, 4),
            "claim_efe_le_half_eps": bool(
                efe_range / scale <= 0.5 * eps_range / scale),
        }
    OUT["H21"] = out


if __name__ == "__main__":
    h20()
    h21()
    print(json.dumps(OUT, indent=1, default=str)[:4000])
    with open(os.path.join(D, "ANALYSIS.json"), "w") as f:
        json.dump(OUT, f, indent=2, default=str)
    print("saved -> axq/results/h20h21/ANALYSIS.json")
