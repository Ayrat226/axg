"""Aggregate ALL experiment results into a single analysis with statistics.

Outputs:
  axq/results/ANALYSIS.json  — machine-readable full analysis
  axq/results/summary_table.txt — human-readable table
Statistics: paired-by-seed Wilcoxon + bootstrap CI + effect size for every
agent pair sharing an env (same seeds), Holm correction within each env.
"""
import sys, os, json, glob
sys.path.insert(0, "/home/z/my-project")
import numpy as np

from axq.exp.stats import paired_compare, holm, summarize

RESULTS = "/home/z/my-project/axq/results"


def load_all():
    """exp_name -> summary dict, from results/*/summary.json."""
    out = {}
    for p in glob.glob(f"{RESULTS}/*/summary.json"):
        exp = os.path.basename(os.path.dirname(p))
        with open(p) as f:
            out[exp] = json.load(f)
    return out


def sample_efficiency(exp):
    """Steps to reach 90% of reference (tabular or best agent) per seed."""
    return None  # computed in pair analysis below


def main():
    all_runs = load_all()
    by_env = {}
    for exp, s in all_runs.items():
        env = s.get("env", "?")
        by_env.setdefault(env, []).append((exp, s))

    analysis = {"n_experiments": len(all_runs), "envs": {}}
    lines = []
    for env, runs in sorted(by_env.items()):
        lines.append(f"\n=== {env} ===")
        lines.append(f"{'experiment':34s} {'mean':>8s} {'median':>8s} "
                     f"{'std':>7s} {'min':>8s} {'fail%':>6s} {'wall_s':>8s}")
        env_rec = {}
        # per-experiment summary
        for exp, s in sorted(runs):
            su = s["final_mean_summary"]
            fr = s.get("failure_rate")
            frs = f"{fr*100:.0f}" if fr is not None else "-"
            lines.append(f"{exp:34s} {su['mean']:8.3f} {su['median']:8.3f} "
                         f"{su['std']:7.3f} {su['min']:8.3f} {frs:>6s} "
                         f"{s['total_wall_time_s']:8.0f}")
        # paired comparisons among agents with >= 3 common seeds
        comps = []
        pair_list = []
        for i in range(len(runs)):
            for j in range(i + 1, len(runs)):
                ea, sa = runs[i]
                eb, sb = runs[j]
                common = sorted(set(sa["seeds"]) & set(sb["seeds"]))
                if len(common) < 3:
                    continue
                va = dict(zip(sa["seeds"], sa["final_mean_per_seed"]))
                vb = dict(zip(sb["seeds"], sb["final_mean_per_seed"]))
                a = [float(va[s2]) for s2 in common]
                b = [float(vb[s2]) for s2 in common]
                c = paired_compare(a, b)
                c["a"] = ea
                c["b"] = eb
                pair_list.append(c)
        if pair_list:
            # Holm correction across all pairwise tests within this env
            pvals = [c["wilcoxon_p"] for c in pair_list]
            h = holm(pvals, alpha=0.05)
            for c, adj, rej in zip(pair_list, h["adjusted"], h["rejected"]):
                c["holm_p"] = adj
                c["significant_holm"] = rej
                comps.append(c)
                lines.append(
                    f"  PAIR {c['a']} vs {c['b']}: diff={c['mean_diff']:+.3f} "
                    f"p={c['wilcoxon_p']:.4f} holm_p={adj:.4f} d={c['cohen_d_paired']:.2f} "
                    f"sig={rej} CI95=[{c['bootstrap_ci95_mean_diff'][0]:.3f},"
                    f"{c['bootstrap_ci95_mean_diff'][1]:.3f}]")
        env_rec["experiments"] = {e: s for e, s in runs}
        env_rec["comparisons"] = comps
        analysis["envs"][env] = env_rec

    text = "\n".join(lines)
    with open(f"{RESULTS}/summary_table.txt", "w") as f:
        f.write(text)
    with open(f"{RESULTS}/ANALYSIS.json", "w") as f:
        json.dump(analysis, f, indent=2, default=str)
    print(text)
    print(f"\nsaved: {RESULTS}/ANALYSIS.json, summary_table.txt "
          f"({len(all_runs)} experiments)")


if __name__ == "__main__":
    main()
