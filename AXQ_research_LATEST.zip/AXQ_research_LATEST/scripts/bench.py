"""Benchmark steps/sec of agents on representative envs to calibrate budgets."""
import sys, time, json
sys.path.insert(0, "/home/z/my-project")
import numpy as np
from axq.envs import make
from axq.agents import make_agent
from axq.core.runner import train

RESULTS = {}

def bench(env_id, agent_name, steps, agent_params=None):
    env = make(env_id)
    eval_env = make(env_id)
    agent = make_agent(agent_name, env.n_obs, env.obs_type, env.n_actions,
                       seed=0, **(agent_params or {}))
    t0 = time.perf_counter()
    res = train(agent, env, total_steps=steps, eval_env=eval_env,
                eval_interval=max(steps, 1), eval_episodes=5)
    dt = time.perf_counter() - t0
    RESULTS[f"{agent_name}:{env_id}"] = {
        "steps_per_sec": round(res["steps_per_sec"], 1),
        "wall_s": round(dt, 2),
        "final_eval_mean": round(res["final_eval"]["mean"], 4),
    }
    print(f"{agent_name:14s} {env_id:22s} {res['steps_per_sec']:9.0f} steps/s  "
          f"final={res['final_eval']['mean']:8.3f}  ({dt:.1f}s)")

if __name__ == "__main__":
    bench("gridworld_dense", "dqn", 8000)
    bench("gridworld_dense", "axq", 8000)
    bench("gridworld_sparse", "tabular", 30000)
    bench("cartpole", "dqn", 10000)
    bench("cartpole", "axq", 10000)
    bench("memory_corridor_8", "history_dqn", 8000,
          {"history_len": 12, "hidden": (64, 64)})
    bench("deceptive_25", "dqn", 8000)
    with open("/home/z/my-project/axq/results/bench.json", "w") as f:
        json.dump(RESULTS, f, indent=2)
    print("saved -> axq/results/bench.json")
