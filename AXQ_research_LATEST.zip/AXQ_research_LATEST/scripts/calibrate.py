"""Empirical threshold calibration (trimmed, unbuffered-friendly)."""
import sys
sys.path.insert(0, "/home/z/my-project")
from axq.envs import make
from axq.agents import make_agent
from axq.core.runner import train

def run(env_id, agent, params, steps, ev=5000, ep=20):
    env = make(env_id)
    ag = make_agent(agent, env.n_obs, env.obs_type, env.n_actions, seed=0,
                    **params)
    res = train(ag, env, total_steps=steps, eval_env=make(env_id),
                eval_interval=ev, eval_episodes=ep)
    tail = [round(v, 2) for s, v in res["curve"][-3:]]
    print(f"{agent:13s} {env_id:22s} budget={steps:6d} tail={tail} "
          f"final={res['final_eval']['mean']:.3f}", flush=True)

if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    if which in ("all", "a"):
        run("memory_corridor_8", "dqn", {}, 30000)          # reactive cap
        run("memory_corridor_16", "history_dqn",
            dict(history_len=20), 50000)                     # memory solve
        run("cartpole", "dqn", {}, 60000, ev=10000)          # control solve
    if which in ("all", "b"):
        for s in range(3):
            run("gridworld_sparse", "axq", {}, 100000, ev=20000)  # H1 check
        run("gridworld_sparse", "dqn", {}, 100000, ev=20000)
