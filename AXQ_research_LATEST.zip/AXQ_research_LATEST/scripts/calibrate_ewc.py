"""EWC lambda calibration on held-out seeds (100, 101) - BEFORE the main
g1 run. Mini-suite: first 2 tasks of continual_gridworlds (gw1 -> gw2),
30k steps/phase (AMENDED 2026-10-09: originally 15k, but the reference arm
acquires NOTHING at 15k - floor - so ret1 cannot discriminate; amended
BEFORE any lambda comparison, before running any lambda arm; the 15k ref
files are archived under budget15k/), fresh buffer each phase (pure-EWC
regime).

Execution model: resumable chunks (sandbox kills background processes
between bash sessions). Every (arm, lambda, seed) run is atomic via
per-phase JSONL appends; completed runs are skipped on relaunch.

Pre-registered selection rule:
- reference arm: dqn-fresh (no EWC);
- candidates: lambda in {0.1, 1, 10, 100, 1000} (Fisher is normalized by
  its mean magnitude inside EWCDQN, so lambda is scale-free);
- metrics: ret1 = matrix[1][0] (gw1 score after the gw2 phase),
  acq2 = matrix[1][1] (gw2 acquisition);
- rule: eligible = lambdas with acq2 >= 0.5 * max(ref_acq2, 1e-9);
  lambda* = argmax ret1 among eligible; if none eligible, argmax ret1
  overall (flagged "no_acq_guard" - would indicate EWC cannot protect
  without blocking acquisition at any lambda).
"""
import importlib.util
import json
import os
import sys

sys.path.insert(0, "/home/z/my-project")

_HERE = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location(
    "run_continual2", os.path.join(_HERE, "run_continual2.py"))
rc2 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(rc2)

LAMBDAS = [0.1, 1.0, 3.0, 10.0, 100.0, 1000.0]   # 3.0 added (amendment
# 2026-10-09: the 0.1->10 range showed a sharp stability-plasticity cliff;
# lambda=3 localizes it. Registered in KB before the main g1 run.)
SEEDS = [100, 101]
PHASE = 30000
CAL_DIR = "/home/z/my-project/axq/results/g1/calib"
N_TASKS = 2


def _run_or_load(arm, seed, lam, tag):
    """Skip (arm, seed) runs whose jsonl already holds a complete run."""
    path = os.path.join(CAL_DIR, f"{arm}_seed{seed}{tag}.jsonl")
    m = rc2._complete_matrix(path, N_TASKS)
    if m is not None:
        print(f"[calib] SKIP {arm}{tag} seed={seed} (complete)", flush=True)
        return m
    return rc2.run_one(arm, seed, phase_steps=PHASE, ewc_lambda=lam,
                       n_tasks=N_TASKS, eval_episodes=20,
                       results_dir=CAL_DIR, tag=tag)["matrix"]


def main(budget_s=500.0):
    import time as _time
    os.makedirs(CAL_DIR, exist_ok=True)
    t0 = _time.time()

    def _left():
        return budget_s - (_time.time() - t0)

    ref_runs = {}
    for s in SEEDS:
        if _left() < 130.0:
            print("[calib] chunk budget reached (ref)", flush=True)
            return False
        ref_runs[s] = _run_or_load("dqn-fresh", s, 100.0, "_ref")
    ref_acq2 = float(sum(m[1][1] for m in ref_runs.values()) / len(ref_runs))
    ref_ret1 = float(sum(m[1][0] for m in ref_runs.values()) / len(ref_runs))
    print(f"[calib] reference dqn-fresh: acq2={ref_acq2:.3f} "
          f"ret1={ref_ret1:.3f}", flush=True)

    results = {}
    for lam in LAMBDAS:
        runs = {}
        for s in SEEDS:
            if _left() < 130.0:
                print("[calib] chunk budget reached "
                      f"(lambda={lam:g}, seed={s})", flush=True)
                return False
            runs[s] = _run_or_load("dqn-ewc-fresh", s, lam,
                                   f"_lam{lam:g}")
        results[lam] = {
            "ret1": float(sum(m[1][0] for m in runs.values()) / len(runs)),
            "acq2": float(sum(m[1][1] for m in runs.values()) / len(runs)),
            "per_seed": [{"seed": s, "matrix": m}
                         for s, m in sorted(runs.items())],
        }
        print(f"[calib] lambda={lam:g}: ret1={results[lam]['ret1']:.3f} "
              f"acq2={results[lam]['acq2']:.3f}", flush=True)

    guard = 0.5 * max(ref_acq2, 1e-9)
    eligible = [lam for lam in LAMBDAS if results[lam]["acq2"] >= guard]
    pool = eligible or LAMBDAS
    lam_star = max(pool, key=lambda l: results[l]["ret1"])
    out = {"seeds": SEEDS, "phase_steps": PHASE,
           "reference": {"acq2": ref_acq2, "ret1": ref_ret1},
           "acq_guard": guard, "eligible": eligible,
           "no_acq_guard": not bool(eligible),
           "lambda_star": lam_star, "results": results}
    path = os.path.join(CAL_DIR, "ewc_calibration.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"[calib] lambda* = {lam_star:g} (eligible={eligible}, "
          f"guard={guard:.3f}, saved {path})", flush=True)
    return True


if __name__ == "__main__":
    import sys as _sys
    _bud = float(_sys.argv[1]) if len(_sys.argv) > 1 else 500.0
    done = main(_bud)
    _sys.exit(0 if done else 3)   # exit 3 = chunk incomplete, relaunch
