"""Golden-trajectory capture BEFORE extending DeceptiveChoice (backward compat).

Run once before the edit; saves reference action-sequence -> reward streams
for all registered deceptive/credit envs under seeded RNG. The post-edit test
(test_chains_compat.py) replays these and requires byte-identical rewards.
"""
import sys
import json
import numpy as np

sys.path.insert(0, "/home/z/my-project")
from axq.envs import make

REF = {}
for env_id in ["deceptive_5", "deceptive_10", "deceptive_25", "deceptive_50",
               "credit_assignment", "chain_5", "chain_10", "chain_20",
               "chain_50"]:
    rows = []
    for seed in (0, 1, 7, 202):
        env = make(env_id)
        rng = np.random.default_rng(1000 + seed)
        obs = env.reset(seed)
        for t in range(120):
            a = int(rng.integers(env.n_actions))
            nobs, r, term, trunc, info = env.step(a)
            rows.append([a, float(r), bool(term), bool(trunc)])
            obs = nobs
            if term or trunc:
                obs = env.reset(seed + 1)
    REF[env_id] = rows

with open("/home/z/my-project/axq/results/golden_chains.json", "w") as f:
    json.dump(REF, f)
print("captured", {k: len(v) for k, v in REF.items()})
