"""Debug: why does DQN fail on gridworld_dense (trivial 4x4 shaped task)?"""
import sys
sys.path.insert(0, "/home/z/my-project")
import numpy as np
from axq.envs import make
from axq.agents import make_agent
from axq.core.runner import train

env = make("gridworld_dense")
print("env:", env.n_obs, "obs,", env.n_actions, "actions, max_steps",
      env.max_episode_steps, "step_reward", env.step_reward,
      "goal_reward", env.goal_reward)

# 1) Reference: tabular on dense
tab = make_agent("tabular", env.n_obs, env.obs_type, env.n_actions, seed=0,
                 eps_decay=5000)
res = train(tab, env, total_steps=15000, eval_env=make("gridworld_dense"),
            eval_interval=3000, eval_episodes=20)
print("tabular curve:", [(s, round(v, 3)) for s, v in res["curve"]])

# 2) DQN with longer budget + curve
dqn = make_agent("dqn", env.n_obs, env.obs_type, env.n_actions, seed=0)
res = train(dqn, env, total_steps=30000, eval_env=make("gridworld_dense"),
            eval_interval=3000, eval_episodes=20)
print("dqn curve:", [(s, round(v, 3)) for s, v in res["curve"]])

# 3) DQN smaller net + faster eps decay + more grad steps per env step?
dqn2 = make_agent("dqn", env.n_obs, env.obs_type, env.n_actions, seed=0,
                  hidden=(64, 64), eps_decay=4000, lr=2e-3)
res = train(dqn2, env, total_steps=30000, eval_env=make("gridworld_dense"),
            eval_interval=3000, eval_episodes=20)
print("dqn2 (eps_decay 4k, lr 2e-3):", [(s, round(v, 3)) for s, v in res["curve"]])

# 4) What does the greedy policy actually do? Roll out one episode.
obs = env.reset(123)
acts, states = [], [obs]
for t in range(30):
    a = dqn2.act(obs, greedy=True)
    obs, r, term, trunc, info = env.step(a)
    acts.append(a); states.append(obs)
    if term or trunc:
        break
print("greedy rollout: actions", acts[:30])
print("states:", states[:30])

# 5) Q values at start state
q0 = dqn2.net.forward(np.eye(env.n_obs)[[0]])[0]
print("Q(s=start):", np.round(q0, 3), "argmax:", int(np.argmax(q0)))
qg = dqn2.net.forward(np.eye(env.n_obs)[[15]])[0]
print("Q(s=goal-adjacent 14):", np.round(dqn2.net.forward(np.eye(env.n_obs)[[14]])[0], 3))
