"""Gap-fill runs identified by wave-1 reviews (audit 9-b, re-analysis 9-c).

Resumable chunked execution (sandbox kills background processes between
bash sessions): completed seeds are skipped via their seed_<s>.json; when
all seeds of a gap exist, the aggregate summary.json + journal record are
written once.

Usage: python3 scripts/fill_gaps.py <gap> [budget_seconds]
Gaps:
  corridor32-axq : e4-corridor32-axq (missing arm of the corridor family;
                   same protocol as e4-corridor32-dqn: 50k steps, seeds
                   0-4, eval_interval 10k, 50 eval episodes)
"""
import dataclasses
import json
import pathlib
import sys
import time

sys.path.insert(0, "/home/z/my-project")

from axq.exp.analysis import auc as _auc
from axq.exp.journal import ExperimentJournal, code_fingerprint
from axq.exp.protocol import ExperimentConfig, run_experiment
from axq.exp.stats import summarize as stat_summarize

RESULTS = "/home/z/my-project/axq/results"
JOURNAL = ExperimentJournal(RESULTS + "/journal.jsonl")

GAPS = {
    "corridor32-axq": ExperimentConfig(
        exp_id="e4-corridor32-axq", hypothesis_id="H3-memory",
        agent_name="axq", agent_params={}, env_id="memory_corridor_32",
        seeds=[0, 1, 2, 3, 4], budget_steps=50000, env_params={},
        eval_interval=10000, eval_episodes=50,
        notes="gap-fill: missing arm of the e4 corridor family "
              "(identical protocol to e4-corridor32-dqn)"),
}


def run_gap(cfg, budget_s=500.0):
    t0 = time.time()
    out_dir = pathlib.Path(RESULTS) / cfg.exp_id
    out_dir.mkdir(parents=True, exist_ok=True)
    est_s = 240.0                                  # AXQ 50k steps, measured
    for seed in cfg.seeds:
        f = out_dir / f"seed_{seed}.json"
        if f.exists():
            continue
        if time.time() - t0 + est_s > budget_s:
            print(f"[fill {cfg.exp_id}] budget reached before seed {seed}",
                  flush=True)
            return False
        single = dataclasses.replace(cfg, seeds=[seed])
        run_experiment(single, RESULTS)            # writes seed_<s>.json
        print(f"[fill {cfg.exp_id}] seed {seed} done", flush=True)
    # all seeds exist -> aggregate summary + one journal record
    finals, aucs, wall = [], [], 0.0
    for seed in cfg.seeds:
        with open(out_dir / f"seed_{seed}.json") as fh:
            rec = json.load(fh)
        finals.append(float(rec["final_eval"]["mean"]))
        aucs.append(float(_auc(rec["curve"], cfg.budget_steps)))
        wall += float(rec["wall_time_s"])
    summary = {
        "exp_id": cfg.exp_id, "hypothesis_id": cfg.hypothesis_id,
        "env": cfg.env_id, "agent": cfg.agent_name,
        "seeds": list(cfg.seeds), "budget_steps": cfg.budget_steps,
        "eval_interval": cfg.eval_interval,
        "eval_episodes": cfg.eval_episodes,
        "final_mean_per_seed": finals,
        "final_mean_summary": stat_summarize(finals),
        "auc_per_seed": aucs, "auc_summary": stat_summarize(aucs),
        "total_wall_time_s": wall,
        "config": {"agent_params": cfg.agent_params,
                   "env_params": cfg.env_params},
        "code_version": code_fingerprint(),
        "notes": cfg.notes,
    }
    with open(out_dir / "summary.json", "w") as fh:
        json.dump(summary, fh, indent=2)
    JOURNAL.append({
        "exp_id": cfg.exp_id, "hypothesis_id": cfg.hypothesis_id,
        "env": cfg.env_id, "agent": cfg.agent_name,
        "config": {"agent_params": cfg.agent_params,
                   "env_params": cfg.env_params},
        "seeds": list(cfg.seeds), "budget_steps": cfg.budget_steps,
        "status": "completed", "results_dir": RESULTS,
        "metrics": {"final_mean": summary["final_mean_summary"]["mean"],
                    "auc": summary["auc_summary"]["mean"]}})
    print(f"[fill {cfg.exp_id}] COMPLETE "
          f"final={summary['final_mean_summary']['mean']:.3f} "
          f"auc={summary['auc_summary']['mean']:.3f}", flush=True)
    return True


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else ""
    bud = float(sys.argv[2]) if len(sys.argv) > 2 else 500.0
    if which not in GAPS:
        raise SystemExit(__doc__)
    ok = run_gap(GAPS[which], bud)
    sys.exit(0 if ok else 3)
