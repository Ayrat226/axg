"""Pack the AXQ research project into a versioned zip in download/.

Included: axq/ (code+results+kb+docs), tests/, scripts/, worklog, configs, .git.
Excluded: skills/ (system), tool-results/ (junk), upload/, .env (secrets),
__pycache__, *.pyc, quarantine scratch.

Usage: python3 scripts/pack_project.py [tag]
Creates download/AXQ_research_<tag>.zip and refreshes download/AXQ_research_LATEST.zip.
Every final milestone MUST re-run this script (user rule, 2026-10-09).
"""
import json
import os
import sys
import time
import zipfile

ROOT = "/home/z/my-project"
DL = os.path.join(ROOT, "download")

INCLUDE_DIRS = ["axq", "tests", "scripts"]
INCLUDE_FILES = ["worklog.md", "conftest.py", "t1c.json", ".gitignore"]
EXCLUDE_PATTERNS = ("__pycache__", ".pyc", ".pytest_cache", "/quarantine/",
                    "tool-results", "/.env", "*.egg-info", ".coverage")


def want(path: str) -> bool:
    p = path.replace(os.sep, "/")
    if any(pat in p for pat in ("__pycache__", ".pytest_cache", ".pyc",
                                "quarantine", ".coverage")):
        return False
    return True


def iter_files():
    for d in INCLUDE_DIRS:
        base = os.path.join(ROOT, d)
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [x for x in dirnames
                           if x not in ("__pycache__", ".pytest_cache", "quarantine")]
            for fn in filenames:
                if fn.endswith((".pyc", ".pyo", ".coverage")):
                    continue
                fp = os.path.join(dirpath, fn)
                if want(fp):
                    yield os.path.relpath(fp, ROOT), fp
    for fn in INCLUDE_FILES:
        fp = os.path.join(ROOT, fn)
        if os.path.exists(fp):
            yield fn, fp
    # git history for full provenance (commits are part of the record)
    git = os.path.join(ROOT, ".git")
    for dirpath, dirnames, filenames in os.walk(git):
        dirnames[:] = [x for x in dirnames if x != "hooks"]
        for fn in filenames:
            fp = os.path.join(dirpath, fn)
            rel = os.path.relpath(fp, ROOT)
            if want(rel):
                yield rel, fp


def main():
    tag = sys.argv[1] if len(sys.argv) > 1 else time.strftime("%Y%m%dT%H%M%SZ")
    out = os.path.join(DL, f"AXQ_research_{tag}.zip")
    latest = os.path.join(DL, "AXQ_research_LATEST.zip")
    os.makedirs(DL, exist_ok=True)
    n = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for rel, fp in iter_files():
            z.write(fp, rel)
            n += 1
    # manifest with build info
    meta = {
        "tag": tag, "files": n, "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "purpose": "AXQ-Universal autonomous research project snapshot",
        "rule": "re-packed after every final code/doc milestone (user directive)",
    }
    with zipfile.ZipFile(out, "a", zipfile.ZIP_DEFLATED) as z:
        z.writestr("PACK_MANIFEST.json", json.dumps(meta, indent=2))
    if os.path.exists(latest):
        os.remove(latest)
    import shutil
    shutil.copyfile(out, latest)
    sz = os.path.getsize(out) / 1e6
    print(f"packed {n+1} files -> {out} ({sz:.1f} MB); LATEST refreshed")


if __name__ == "__main__":
    main()
