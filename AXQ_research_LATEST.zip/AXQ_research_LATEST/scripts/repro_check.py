"""Reproducibility check: independently re-run selected completed runs from
their persisted configs and verify the metrics match the stored results.

Picks the headline results and re-executes them in THIS process (fresh
interpreter state), comparing final eval means exactly.
"""
import sys, json, os
sys.path.insert(0, "/home/z/my-project")

RESULTS = "/home/z/my-project/axq/results"
from axq.envs import make
from axq.agents import make_agent
from axq.core.runner import train

CASES = [
    ("e3-sparse-axq", 0),
    ("e3-sparse-axq", 1),
    ("e3-sparse-dqn", 0),
    ("e4-corridor16-history_dqn", 0),
    ("e2-cartpole-dqn", 0),
    ("e5-decep50-tabular", 0),
]


def main():
    ok, fail = 0, 0
    os.makedirs(f"{RESULTS}/repro", exist_ok=True)
    for exp, seed in CASES:
        case_path = f"{RESULTS}/repro/{exp}_{seed}.json"
        if os.path.exists(case_path):
            rec = json.load(open(case_path))
            print(f"[repro] {exp} seed={seed}: cached "
                  f"{'MATCH' if rec['match'] else 'MISMATCH'}", flush=True)
            ok += rec["match"]
            fail += (not rec["match"])
            continue
        summary = json.load(open(f"{RESULTS}/{exp}/summary.json"))
        stored = json.load(open(f"{RESULTS}/{exp}/seed_{seed}.json"))
        env_id = summary["env"]
        params = summary["config"]["agent_params"]
        env_params = summary["config"]["env_params"]
        env = make(env_id, **env_params)
        agent = make_agent(summary["agent"], env.n_obs, env.obs_type,
                           env.n_actions, seed=seed, **params)
        res = train(agent, env, total_steps=summary["budget_steps"],
                    eval_interval=summary["eval_interval"],
                    eval_env=make(env_id, **env_params),
                    eval_episodes=summary["eval_episodes"], seed=seed)
        reproduced = res["final_eval"]["mean"]
        original = stored["final_eval"]["mean"]
        match = abs(reproduced - original) < 1e-9
        status = "MATCH" if match else "MISMATCH"
        print(f"[repro] {exp} seed={seed}: stored={original:.6f} "
              f"reproduced={reproduced:.6f} -> {status}", flush=True)
        with open(case_path, "w") as f:
            json.dump({"exp": exp, "seed": seed, "stored": original,
                       "reproduced": reproduced, "match": bool(match)}, f)
        ok += match
        fail += (not match)
    print(f"[repro] SUMMARY: {ok} match, {fail} mismatch", flush=True)
    with open(f"{RESULTS}/repro_check.json", "w") as f:
        json.dump({"cases": CASES, "match": ok, "mismatch": fail}, f, indent=2)


if __name__ == "__main__":
    main()
