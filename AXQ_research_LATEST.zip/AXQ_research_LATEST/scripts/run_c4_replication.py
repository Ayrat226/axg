"""Cycle-4 REPLICATION driver (H14 deceptive + H15 sparse AUC) — resumable.

Preregistered protocol: axq/docs/PREREG_CYCLE4.md (KB 25e3df387463).
NEW SEEDS 200-211 (disjoint from all previous 0-7 / 100-101 runs).

Arms (eps_decay dedup: tabular default=20000 => O==M2; dqn default=10000
=> O==M1; the driver stores each run ONCE under its canonical arm and the
analysis references it for both):
  h14-O-tab    : tabular, original e5 config (default eps_decay=20000) [= M2]
  h14-O-dqn    : dqn,     original e5 config (default eps_decay=10000) [= M1]
  h14-O-axq    : axq,     original e5 config
  h14-M1-tab   : tabular, eps_decay=10000 (matched DOWN to dqn)
  h14-M2-dqn   : dqn,     eps_decay=20000 (matched UP to tabular)
  h15-sparse-* : exact e3-sparse config (100k steps, ev 10000, ep 20)

Every run: per-seed JSON with curve, final eval, AUC, LARGE-REWARD EVENT
COUNT (training stream), episode outcome counts (passive env-side audit,
RNG untouched). SOFT deadline + exit 3 => relaunch until complete.
"""
import argparse
import json
import os
import sys
import time
import uuid

sys.path.insert(0, "/home/z/my-project")
import numpy as np

from axq.agents import make_agent
from axq.core.runner import train
from axq.envs import make
from axq.envs.antitests import value_iteration
from axq.exp.analysis import auc as curve_auc
from axq.exp.journal import ExperimentJournal, code_fingerprint
from axq.exp.stats import summarize

RESULTS = "/home/z/my-project/axq/results/c4repl"
GAMMA = 0.99
SEEDS = list(range(200, 212))
DECEP_ENVS = ["deceptive_50", "credit_assignment", "gridworld_decoy"]
LARGE_THRESH = {"deceptive_50": 5.0, "credit_assignment": 25.0,
                "gridworld_decoy": 0.6}   # decoy: goal reward 1.0 vs trap 0.5

SOFT_DEADLINE = float(os.environ.get("CHUNK_BUDGET", "540"))


class AuditEnv:
    """Passive env wrapper: counts large-reward events + episode outcomes.

    Delegates EVERYTHING to the wrapped env (same RNG object => trajectories
    byte-identical to unwrapped runs; counting is read-only).
    """

    def __init__(self, env, large_threshold):
        self._env = env
        self._thr = float(large_threshold)
        self.large_events = 0
        self.outcomes = {}

    def __getattr__(self, name):
        return getattr(self._env, name)

    def reset(self, seed=None):
        return self._env.reset(seed)

    def step(self, action):
        obs, r, term, trunc, info = self._env.step(action)
        if r >= self._thr:
            self.large_events += 1
        if term or trunc:
            oc = info.get("outcome", "timeout")
            self.outcomes[oc] = self.outcomes.get(oc, 0) + 1
        return obs, r, term, trunc, info


VSTAR = {}


def vstar(env_id):
    """V*(0) from the exact model (cached)."""
    if env_id not in VSTAR:
        env = make(env_id)
        P, R = env.mdp_model(GAMMA)
        V, Q, pol = value_iteration(P, R, GAMMA)
        VSTAR[env_id] = {"V0": float(V[0]),
                         "pass_bar": float(0.9 * V[0]),
                         "policy0": int(pol[0])}
    return VSTAR[env_id]


def jobs():
    """Ordered by priority (headline replication first)."""
    J = []
    # P1: H15 sparse AUC headline (exact e3 config)
    for ag in ("dqn", "axq"):
        J.append(dict(name=f"h15-sparse-{ag}", env="gridworld_sparse",
                      agent=ag, params={}, seeds=SEEDS, budget=100000,
                      ev=10000, ep=20))
    # P2: H14 arm O tabular (cheap, instant) [= M2]
    for e in DECEP_ENVS:
        J.append(dict(name=f"h14-O-tab-{e}", env=e, agent="tabular",
                      params={}, seeds=SEEDS, budget=60000, ev=10000, ep=50))
    # P3: H14 arm O dqn [= M1]
    for e in DECEP_ENVS:
        J.append(dict(name=f"h14-O-dqn-{e}", env=e, agent="dqn",
                      params={}, seeds=SEEDS, budget=60000, ev=10000, ep=50))
    # P4: H14 arm O axq
    for e in DECEP_ENVS:
        J.append(dict(name=f"h14-O-axq-{e}", env=e, agent="axq",
                      params={}, seeds=SEEDS, budget=60000, ev=10000, ep=50))
    # P5: H14 matched arms (the non-duplicated directions)
    for e in DECEP_ENVS:
        J.append(dict(name=f"h14-M1-tab-{e}", env=e, agent="tabular",
                      params={"eps_decay": 10000}, seeds=SEEDS,
                      budget=60000, ev=10000, ep=50))
    for e in DECEP_ENVS:
        J.append(dict(name=f"h14-M2-dqn-{e}", env=e, agent="dqn",
                      params={"eps_decay": 20000}, seeds=SEEDS,
                      budget=60000, ev=10000, ep=50))
    return J


def run_seed(j, seed):
    env = make(j["env"])
    aenv = AuditEnv(env, LARGE_THRESH.get(j["env"], float("inf")))
    eval_aenv = AuditEnv(make(j["env"]),
                         LARGE_THRESH.get(j["env"], float("inf")))
    agent = make_agent(j["agent"], env.n_obs, env.obs_type, env.n_actions,
                       seed=seed, **j["params"])
    res = train(agent, aenv, total_steps=j["budget"], eval_env=eval_aenv,
                eval_interval=j["ev"], eval_episodes=j["ep"], seed=seed)
    out = {
        "seed": seed, "agent": j["agent"], "env": j["env"],
        "params": j["params"], "budget": j["budget"],
        "curve": [[int(s), float(v)] for s, v in res["curve"]],
        "final_eval": res["final_eval"],
        "auc": curve_auc(res["curve"], j["budget"]),
        "large_events_train": aenv.large_events,
        "outcomes_train": aenv.outcomes,
        "episodes": res["episodes"],
        "steps_per_sec": round(res["steps_per_sec"], 1),
        "wall_s": round(res["wall_time_s"], 1),
        "vstar": vstar(j["env"]),
        "pass_final": bool(res["final_eval"]["mean"]
                           >= 0.9 * vstar(j["env"])["V0"]),
    }
    return out


def job_dir(j):
    return os.path.join(RESULTS, j["name"])


def summarize_job(j, journal):
    d = job_dir(j)
    seeds = sorted(int(f.split("_")[1].split(".")[0])
                   for f in os.listdir(d) if f.startswith("seed_"))
    if len(seeds) < len(j["seeds"]):
        return None
    rows = [json.load(open(os.path.join(d, f"seed_{s}.json")))
            for s in seeds]
    final = [r["final_eval"]["mean"] for r in rows]
    aucs = [r["auc"] for r in rows]
    summary = {
        "exp_id": j["name"], "env": j["env"], "agent": j["agent"],
        "params": j["params"], "budget": j["budget"], "seeds": seeds,
        "final_per_seed": final, "auc_per_seed": aucs,
        "final_summary": summarize(final), "auc_summary": summarize(aucs),
        "pass_rate": float(np.mean([r["pass_final"] for r in rows])),
        "large_events": {str(r["seed"]): r["large_events_train"]
                         for r in rows},
        "vstar": rows[0]["vstar"],
        "code_version": code_fingerprint(),
        "prereg": "H14/H15, KB 25e3df387463",
    }
    with open(os.path.join(d, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    journal.append({
        "exp_id": j["name"], "hypothesis_id": "H14/H15-replication",
        "env": j["env"], "agent": j["agent"],
        "config": {"params": j["params"], "ev": j["ev"], "ep": j["ep"]},
        "seeds": seeds, "budget_steps": j["budget"],
        "status": "done", "kind": "c4-replication",
        "pass_rate": summary["pass_rate"],
        "auc_mean": summary["auc_summary"]["mean"],
        "final_mean": summary["final_summary"]["mean"],
        "prereg": summary["prereg"],
    })
    return summary


def main(worker, n_workers):
    os.makedirs(RESULTS, exist_ok=True)
    journal = ExperimentJournal(os.path.join(RESULTS, "journal.jsonl"))
    t0 = time.time()
    all_jobs = jobs()
    mine = [j for i, j in enumerate(all_jobs) if i % n_workers == worker]
    print(f"[c4repl worker {worker}] {len(mine)} jobs, deadline {SOFT_DEADLINE}s")
    for j in mine:
        d = job_dir(j)
        os.makedirs(d, exist_ok=True)
        for s in j["seeds"]:
            fp = os.path.join(d, f"seed_{s}.json")
            if os.path.exists(fp):
                continue
            if time.time() - t0 > SOFT_DEADLINE:
                print(f"[worker {worker}] soft deadline; exit 3")
                return False
            t1 = time.time()
            out = run_seed(j, s)
            with open(fp, "w") as f:
                json.dump(out, f)
            print(f"[w{worker}] {j['name']} s{s}: final="
                  f"{out['final_eval']['mean']:.3f} auc={out['auc']:.3f} "
                  f"large_ev={out['large_events_train']} pass="
                  f"{out['pass_final']} ({time.time()-t1:.0f}s)", flush=True)
        sm = summarize_job(j, journal)
        if sm:
            print(f"[w{worker}] SUMMARY {j['name']}: pass_rate="
                  f"{sm['pass_rate']:.2f} final={sm['final_summary']['mean']:.3f}"
                  f" auc={sm['auc_summary']['mean']:.3f}", flush=True)
    print(f"[worker {worker}] all jobs complete")
    return True


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--worker", type=int, default=0)
    ap.add_argument("--n-workers", type=int, default=2)
    ap.add_argument("--budget", type=float, default=540.0)
    args = ap.parse_args()
    SOFT_DEADLINE = args.budget
    ok = main(args.worker, args.n_workers)
    sys.exit(0 if ok else 3)
