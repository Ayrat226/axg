"""L8 Continual-learning experiments: sequential task training, forgetting
matrices, positive/negative transfer. DQN vs AXQ (identical phase budgets).

Suites: continual_gridworlds (5 sparse layouts), continual_cartpole (3
variants). Metrics per suite: score matrix, per-task forgetting, average
forgetting, final average.
"""
import sys
sys.path.insert(0, "/home/z/my-project")
import json
import numpy as np

from axq.envs import make, multitask
from axq.agents import make_agent
from axq.exp.journal import ExperimentJournal

RESULTS = "/home/z/my-project/axq/results"
journal = ExperimentJournal(RESULTS + "/journal.jsonl")


def agent_factory_for(suite_name, agent_name, control=False):
    def factory(seed):
        env = multitask.SUITES[suite_name].tasks[0][1]()
        params = {"n_step": 3} if (control and agent_name in ("dqn", "axq")) \
            else {}
        return make_agent(agent_name, env.n_obs, env.obs_type, env.n_actions,
                          seed=seed, **params)
    return factory


def run_suite(suite_name, agent_name, seeds, phase_steps, control=False,
              fresh_buffer=False):
    """Continual suite. fresh_buffer=True drops the replay buffer at every
    phase boundary (weights persist) — isolates the rehearsal effect:
    persistent buffer == rehearsal, fresh buffer == pure sequential SGD."""
    matrices = []
    for seed in seeds:
        res = _task_sequence_with_buffer_mode(
            agent_factory_for(suite_name, agent_name, control),
            suite_name, phase_steps, eval_episodes=20, seed=seed,
            fresh_buffer=fresh_buffer)
        matrices.append(res["matrix"])
        f = multitask.forgetting(res["matrix"], res["phases"], res["phases"])
        print(f"[{suite_name}{'/fresh' if fresh_buffer else ''}] {agent_name} "
              f"seed={seed} "
              f"final_row={[round(x, 2) for x in res['matrix'][-1]]} "
              f"forgetting={ {k: round(v, 2) for k, v in f.items()} }",
              flush=True)
    M = np.asarray(matrices)                     # [seeds, phases, tasks]
    names = multitask.SUITES[suite_name].names()
    mean_m = M.mean(axis=0)
    forg = {n: float(mean_m[j, j] - mean_m[-1, j]) for j, n in enumerate(names)}
    mode = "fresh" if fresh_buffer else "persist"
    summary = {"suite": suite_name, "agent": agent_name, "mode": mode,
               "phase_steps": phase_steps, "seeds": list(seeds),
               "matrix_mean": mean_m.tolist(), "matrix_per_seed": M.tolist(),
               "phases": names, "forgetting": forg,
               "avg_forgetting": float(np.mean(list(forg.values()))),
               "final_avg": float(mean_m[-1].mean())}
    print(f"[{suite_name}/{mode}] {agent_name} SUMMARY avg_forgetting="
          f"{summary['avg_forgetting']:.3f} final_avg={summary['final_avg']:.3f}",
          flush=True)
    with open(f"{RESULTS}/e8-{suite_name}-{agent_name}-{mode}.json", "w") as f:
        json.dump(summary, f, indent=2)
    journal.append({
        "exp_id": f"e8-{suite_name}-{agent_name}-{mode}",
        "hypothesis_id": "H8-continual", "env": suite_name,
        "agent": agent_name, "config": {"phase_steps": phase_steps,
                                        "fresh_buffer": fresh_buffer},
        "seeds": list(seeds), "budget_steps": phase_steps * len(names),
        "status": "completed", "results_dir": RESULTS,
        "metrics": {"avg_forgetting": summary["avg_forgetting"],
                    "final_avg": summary["final_avg"]}})
    return summary


def _task_sequence_with_buffer_mode(agent_factory, suite_name, phase_steps,
                                    eval_episodes=20, seed=0,
                                    fresh_buffer=False,
                                    eval_base_seed=555555):
    """multitask.run_task_sequence + optional per-phase buffer reset."""
    from axq.core.runner import train, evaluate
    suite = multitask.SUITES[suite_name]
    agent = agent_factory(seed)
    matrix = []
    for i, (_, factory) in enumerate(suite.tasks):
        if fresh_buffer and hasattr(agent, "reset_buffer"):
            agent.reset_buffer()
        env = factory()
        train(agent, env, total_steps=phase_steps, eval_env=None,
              seed=seed + i)
        row = []
        for j, (_, eval_factory) in enumerate(suite.tasks):
            ev = evaluate(agent, eval_factory(), episodes=eval_episodes,
                          base_seed=eval_base_seed + 1009 * j, greedy=True)
            row.append(ev["mean"])
        matrix.append(row)
    return {"phases": suite.names(), "matrix": matrix}


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    S3 = [0, 1, 2]
    if which in ("all", "gw"):
        run_suite("continual_gridworlds", "dqn", S3, 20000)
        run_suite("continual_gridworlds", "axq", S3, 20000)
    if which in ("all", "cp"):
        run_suite("continual_cartpole", "dqn", S3, 20000, control=True)
        run_suite("continual_cartpole", "axq", S3, 20000, control=True)
