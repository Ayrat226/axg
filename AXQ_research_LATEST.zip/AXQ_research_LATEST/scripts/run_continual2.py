"""Cycle-3 flagship (g1): continual learning at adequate phase budgets.

Pre-registered design (registered in the KB BEFORE the main run):
- Suite: continual_gridworlds (5 sparse 8x8 layouts, gw1..gw5).
- Phase budget: 30k steps (>= the ~30k acquisition need measured in e8;
  e8's 20k/phase conflated forgetting with acquisition failure).
- Replay capacity 200k >= 5 x 30k total transitions -> NOTHING is evicted:
  'persist' arms are FULL rehearsal. (e8 used a 50k buffer which silently
  evicted early tasks -> partial rehearsal; documented difference, so
  g1 results are NOT directly comparable to e8 numbers.)
- Arms (identical budgets/seeds/eval protocol):
    dqn-persist       DQN, full-rehearsal buffer
    dqn-fresh         DQN, buffer dropped at each phase start
    dqn-ewc-fresh     EWC (calibrated lambda), no rehearsal
    dqn-ewc-persist   EWC + full rehearsal
    dqn-heads-persist task-IL per-task heads + trunk rehearsal
                      (task identity known at train & eval - standard
                      task-IL assumption, documented)
- Metrics per seed: acquisition (mean diag), retention (final row over
  tasks 0..T-2), final_avg (all tasks), avg_forgetting (tasks 0..T-2),
  BWT, FWT.
- Crash-safety: every phase row is appended to <arm>_seed<k>.jsonl the
  moment it is measured; summaries rebuild from those files, so a killed
  run loses at most one in-flight phase.
- Statistics: paired exact Wilcoxon (axq.exp.stats.paired_compare) vs
  baselines, Holm correction across the arm x metric family, n=5 seeds.
"""
import argparse
import json
import os
import sys
import time
import uuid

sys.path.insert(0, "/home/z/my-project")

import numpy as np

from axq.agents.continual import EWCDQN, MultiHeadDQN
from axq.agents.dqn import DQN
from axq.core.runner import evaluate, train
from axq.envs import multitask
from axq.exp.journal import ExperimentJournal, to_jsonable
from axq.exp.stats import holm, paired_compare
from axq.exp.stats import summarize as stat_summarize

RESULTS = "/home/z/my-project/axq/results/g1"
os.makedirs(RESULTS, exist_ok=True)
journal = ExperimentJournal("/home/z/my-project/axq/results/journal.jsonl")

BUFFER = 200000        # >= 5 phases x 30k transitions: full rehearsal
ARMS = ["dqn-persist", "dqn-fresh", "dqn-ewc-fresh", "dqn-ewc-persist",
        "dqn-heads-persist"]
METRICS = ("retention", "acquisition", "final_avg")


def build_agent(arm, seed, n_obs, obs_type, n_actions, ewc_lambda):
    common = dict(n_obs=n_obs, obs_type=obs_type, n_actions=n_actions,
                  seed=seed, buffer_size=BUFFER)
    if arm in ("dqn-persist", "dqn-fresh"):
        return DQN(**common)
    if arm in ("dqn-ewc-fresh", "dqn-ewc-persist"):
        return EWCDQN(ewc_lambda=float(ewc_lambda), **common)
    if arm == "dqn-heads-persist":
        return MultiHeadDQN(rehearsal_mix=0.5, **common)
    raise ValueError("unknown arm: %r" % arm)


def metrics_from_matrix(matrix):
    """acquisition / retention / final_avg / forgetting / BWT / FWT.

    retention & forgetting are computed over tasks 0..T-2 (the last task
    was just trained - it has no forgetting window by construction).
    """
    M = np.asarray(matrix, dtype=np.float64)
    T = M.shape[0]
    out = {"matrix": M.tolist(), "n_tasks": T}
    out["acquisition"] = float(np.mean(np.diag(M)))
    out["final_avg"] = float(M[-1].mean())
    if T > 1:
        out["retention"] = float(M[-1, :-1].mean())
        out["avg_forgetting"] = float(np.mean(
            [M[j, j] - M[-1, j] for j in range(T - 1)]))
        out["bwt"] = float(np.mean(M[-1, :-1] - np.diag(M)[:-1]))
        out["fwt"] = float(M[0, 1:].mean())
    else:
        out["retention"] = out["avg_forgetting"] = out["bwt"] = \
            out["fwt"] = float("nan")
    return out


def run_one(arm, seed, phase_steps=30000, ewc_lambda=100.0, n_tasks=5,
            eval_episodes=20, suite="continual_gridworlds", tag="",
            results_dir=RESULTS):
    """One (arm, seed) run over the first ``n_tasks`` phases. Appends each
    phase row to a per-run JSONL immediately (crash-safe), returns metrics."""
    suite_obj = multitask.SUITES[suite]
    tasks = suite_obj.tasks[:int(n_tasks)]
    first = tasks[0][1]()
    agent = build_agent(arm, seed, first.n_obs, first.obs_type,
                        first.n_actions, ewc_lambda)
    os.makedirs(results_dir, exist_ok=True)
    jsonl_path = os.path.join(results_dir, f"{arm}_seed{seed}{tag}.jsonl")
    run_id = uuid.uuid4().hex[:8]   # restarts never mix rows (audit 9-b M2)
    matrix = []
    for i, (tname, factory) in enumerate(tasks):
        if arm.endswith("-fresh"):
            agent.reset_buffer()          # drop ALL replay data, keep weights
        if isinstance(agent, MultiHeadDQN):
            agent.set_task(i)
        train(agent, factory(), total_steps=phase_steps, eval_env=None,
              seed=seed + i)
        row = []
        for j, (_, ef) in enumerate(tasks):
            if isinstance(agent, MultiHeadDQN):
                agent.set_task(j)
            ev = evaluate(agent, ef(), episodes=eval_episodes,
                          base_seed=555555 + 1009 * j, greedy=True)
            row.append(ev["mean"])
        if isinstance(agent, MultiHeadDQN):
            agent.set_task(i)
        matrix.append(row)
        with open(jsonl_path, "a") as f:   # crash-safe: save NOW
            f.write(json.dumps({
                "arm": arm, "seed": seed, "phase": i, "task": tname,
                "row": row, "phase_steps": phase_steps,
                "ewc_lambda": ewc_lambda, "n_tasks": len(tasks),
                "run_id": run_id,
                "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            }) + "\n")
        if isinstance(agent, EWCDQN):
            agent.consolidate()            # snapshot AFTER this task's data
        print(f"[g1:{arm}{tag} seed={seed}] phase {i} ({tname}) done "
              f"row={[round(v, 3) for v in row]}", flush=True)
    m = metrics_from_matrix(matrix)
    m.update({"arm": arm, "seed": seed, "phases": [n for n, _ in tasks],
              "phase_steps": phase_steps})
    print(f"[g1:{arm}{tag} seed={seed}] FINAL acq={m['acquisition']:.3f} "
          f"ret={m['retention']:.3f} final_avg={m['final_avg']:.3f} "
          f"bwt={m['bwt']:+.3f} fwt={m['fwt']:+.3f}", flush=True)
    return m


def _complete_matrix(path, n_tasks):
    """Matrix of the best COMPLETE run in a per-(arm,seed) jsonl, or None.

    Best = most distinct phases (ties: latest ts); complete = contiguous
    phases 0..n_tasks-1. Used by chunked drivers to skip finished jobs."""
    if not os.path.exists(path):
        return None
    runs = {}
    with open(path) as f:
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            try:
                r = json.loads(ln)
            except json.JSONDecodeError:
                continue          # torn tail line (audit 11-a #4)
            runs.setdefault(str(r.get("run_id", "legacy")), {})[
                r["phase"]] = r
    best, best_key = None, (-1, "")
    for rid, ph in runs.items():
        ts = max((row.get("ts", "") for row in ph.values()), default="")
        key = (len(ph), ts)
        if key > best_key:
            best, best_key = (rid, ph), key
    if best is None:
        return None
    _, ph = best
    phases = sorted(ph)
    if phases != list(range(n_tasks)):
        return None
    return [ph[i]["row"] for i in phases]


def chunk(worker=0, n_workers=2, phase_steps=30000, ewc_lambda=100.0,
          n_tasks=5, results_dir=RESULTS, budget_s=500.0,
          arms=None, seeds=None):
    """Resumable chunked execution of the flagship (arm, seed) grid.

    The sandbox kills background processes between bash sessions, so the
    g1 flagship runs in ~9-minute chunks: this worker takes its striped
    share of jobs, skips completed ones (complete jsonl run), starts a job
    only if the remaining chunk budget plausibly covers it, and exits
    cleanly. Every job is atomic at phase granularity (per-phase jsonl
    appends with run_id), so a killed chunk loses at most one phase.

    ``arms``/``seeds`` (comma-separated strings) select a subgrid - used
    by the pre-registered n=8 replication of the headline pair.
    """
    t0 = time.time()
    arm_list = list(ARMS) if not arms else \
        [a for a in arms.split(",") if a in ARMS]
    seed_list = list(range(5)) if not seeds else \
        [int(s) for s in seeds.split(",")]
    jobs = [(arm, seed) for arm in arm_list for seed in seed_list]
    mine = [j for i, j in enumerate(jobs) if i % int(n_workers) == int(worker)]
    # measured DQN-family throughput ~95 s / 100k env steps + eval/fisher
    # overhead (~90 s for 25 task-evals + 5 EWC consolidations); EWC jobs
    # measured slower (~160-190 s) - covered by the margin (audit 11-a #2)
    est_s = phase_steps * n_tasks * 95.0 / 100000.0 + 90.0
    remaining = 0
    for arm, seed in mine:
        path = os.path.join(results_dir, f"{arm}_seed{seed}.jsonl")
        if _complete_matrix(path, n_tasks):
            continue
        remaining += 1
        if time.time() - t0 + est_s > budget_s:
            print(f"[chunk w{worker}] budget reached, "
                  f"{remaining} job(s) still pending", flush=True)
            return False
        run_one(arm, seed, phase_steps=phase_steps, ewc_lambda=ewc_lambda,
                n_tasks=n_tasks, eval_episodes=20, results_dir=results_dir)
        remaining -= 1
    print(f"[chunk w{worker}] all my jobs complete "
          f"({len(mine)} total)", flush=True)
    return True


def summarize(arm, results_dir=RESULTS, suite="continual_gridworlds"):
    """Aggregate all completed seeds of an arm from its JSONL files.

    Restart-robust (audit 9-b M2): rows are grouped by run_id; for each
    seed the run with the MOST distinct phases wins (ties: latest ts);
    runs with non-contiguous phases or fewer phases than the first
    complete seed are dropped with a warning instead of mixed in.
    """

    def _best_run(path):
        runs = {}
        with open(path) as f:
            for ln in f:
                ln = ln.strip()
                if not ln:
                    continue
                try:
                    r = json.loads(ln)
                except json.JSONDecodeError:
                    continue      # torn tail line (audit 11-a #4)
                runs.setdefault(str(r.get("run_id", "legacy")), {})[
                    r["phase"]] = r
        best, best_key = None, (-1, "")
        for rid, ph in runs.items():
            ts = max((row.get("ts", "") for row in ph.values()),
                     default="")
            key = (len(ph), ts)
            if key > best_key:
                best, best_key = (rid, ph), key
        return best

    # pass 1: best run per seed + contiguity filter; pass 2: anchor the
    # expected phase count on the LONGEST complete run across seeds (NOT
    # the lowest seed - audit 11-a #1) and drop shorter ones with a WARN.
    cands = []
    for seed in range(1000):
        p = os.path.join(results_dir, f"{arm}_seed{seed}.jsonl")
        if not os.path.exists(p):
            continue
        best = _best_run(p)
        if best is None:
            continue
        rid, ph = best
        phases_sorted = sorted(ph)
        if phases_sorted != list(range(len(phases_sorted))):
            print(f"WARN: {arm} seed={seed} run={rid}: non-contiguous "
                  f"phases {phases_sorted} -> seed dropped", flush=True)
            continue
        cands.append((seed, rid, ph))
    if not cands:
        raise SystemExit(f"no jsonl results for arm {arm} in {results_dir}")
    expected = max(len(ph) for _, _, ph in cands)
    if expected < 5:
        print(f"WARN: {arm}: summarize on an incomplete grid "
              f"(max phases = {expected}); call after chunks exit 0",
              flush=True)
    per_seed = []
    for seed, rid, ph in cands:
        if len(ph) != expected:
            print(f"WARN: {arm} seed={seed} run={rid}: {len(ph)} "
                  f"phases != {expected} -> seed dropped", flush=True)
            continue
        phases_sorted = sorted(ph)
        matrix = [ph[i]["row"] for i in phases_sorted]
        m = metrics_from_matrix(matrix)
        m["seed"] = seed
        m["phase_steps"] = ph[0]["phase_steps"]
        m["ewc_lambda"] = ph[0].get("ewc_lambda")
        per_seed.append(m)
    if not per_seed:
        raise SystemExit(f"no complete runs for arm {arm} in {results_dir}")
    agg = {}
    for key in ("acquisition", "retention", "final_avg", "avg_forgetting",
                "bwt", "fwt"):
        agg[key] = stat_summarize([s[key] for s in per_seed])
    summary = {"arm": arm, "suite": suite, "n_seeds": len(per_seed),
               "n_tasks": per_seed[0]["n_tasks"],
               "phase_steps": per_seed[0]["phase_steps"],
               "buffer_capacity": BUFFER,
               "per_seed": per_seed, "aggregate": agg}
    path = os.path.join(results_dir, f"summary_{arm}.json")
    with open(path, "w") as f:
        json.dump(summary, f, indent=2, default=to_jsonable)
    journal.append({
        "exp_id": f"g1-{suite}-{arm}",
        "hypothesis_id": "H9-continual",
        "env": suite, "agent": arm,
        "config": {"phase_steps": summary["phase_steps"],
                   "buffer_size": BUFFER, "arm": arm,
                   "ewc_lambda": per_seed[0].get("ewc_lambda"),
                   "n_tasks": summary["n_tasks"]},
        "seeds": [s["seed"] for s in per_seed],
        "budget_steps": summary["phase_steps"] * summary["n_tasks"],
        "status": "completed", "results_dir": results_dir,
        "metrics": {k: v["mean"] for k, v in agg.items()}})
    print(f"[g1:summary {arm}] n={summary['n_seeds']} "
          + " ".join(f"{k}={v['mean']:.3f}" for k, v in agg.items()),
          flush=True)
    return summary


def compare(baseline="dqn-persist", results_dir=RESULTS):
    """Paired comparisons of every arm vs baseline on all metrics + Holm."""
    summaries = {}
    for arm in ARMS:
        p = os.path.join(results_dir, f"summary_{arm}.json")
        if os.path.exists(p):
            with open(p) as f:
                summaries[arm] = json.load(f)
    if baseline not in summaries:
        raise SystemExit(f"baseline summary missing: {baseline}")
    out = {"baseline": baseline, "comparisons": {}, "holm": None}
    pvals, labels = [], []
    for arm in ARMS:
        if arm == baseline or arm not in summaries:
            continue
        for met in METRICS:
            a = [s[met] for s in sorted(summaries[arm]["per_seed"],
                                        key=lambda s: s["seed"])]
            b = [s[met] for s in sorted(summaries[baseline]["per_seed"],
                                        key=lambda s: s["seed"])]
            if len(a) != len(b) or not a:
                continue
            r = paired_compare(a, b)
            key = f"{arm}_vs_{baseline}:{met}"
            out["comparisons"][key] = r
            pvals.append(r["wilcoxon_p"])
            labels.append(key)
    if pvals:
        h = holm(pvals)
        out["holm"] = {"labels": labels, "adjusted": h["adjusted"],
                       "rejected": h["rejected"]}
    with open(os.path.join(results_dir, "g1_stats.json"), "w") as f:
        json.dump(out, f, indent=2, default=to_jsonable)
    print(f"=== g1 paired comparisons (baseline={baseline}) ===")
    for k, r in out["comparisons"].items():
        print(f"{k:52s} diff={r['mean_diff']:+.3f} "
              f"p={r['wilcoxon_p']:.4f} d={r['cohen_d_paired']:+.2f} "
              f"sig={r['significant_005']} {r['note']}")
    if out["holm"]:
        print("--- Holm-adjusted (family=%d) ---" % len(labels))
        for lab, adj, rej in zip(labels, out["holm"]["adjusted"],
                                 out["holm"]["rejected"]):
            print(f"{lab:52s} adj_p={adj:.4f} rejected={rej}")
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("one", help="run one (arm, seed)")
    p.add_argument("arm", choices=ARMS)
    p.add_argument("seed", type=int)
    p.add_argument("--phase-steps", type=int, default=30000)
    p.add_argument("--lambda", dest="ewc_lambda", type=float, default=100.0)
    p.add_argument("--n-tasks", type=int, default=5)
    p.add_argument("--eval-episodes", type=int, default=20)
    p.add_argument("--tag", default="")
    p.add_argument("--results-dir", default=RESULTS)
    p.set_defaults(fn=lambda a: run_one(
        a.arm, a.seed, phase_steps=a.phase_steps, ewc_lambda=a.ewc_lambda,
        n_tasks=a.n_tasks, eval_episodes=a.eval_episodes, tag=a.tag,
        results_dir=a.results_dir))
    p = sub.add_parser("summarize", help="aggregate one arm")
    p.add_argument("arm", choices=ARMS)
    p.add_argument("--results-dir", default=RESULTS)
    p.set_defaults(fn=lambda a: summarize(a.arm, results_dir=a.results_dir))
    p = sub.add_parser("compare", help="stats across arms")
    p.add_argument("--baseline", default="dqn-persist")
    p.add_argument("--results-dir", default=RESULTS)
    p.set_defaults(fn=lambda a: compare(a.baseline, results_dir=a.results_dir))
    p = sub.add_parser("chunk", help="resumable chunked flagship run")
    p.add_argument("--worker", type=int, default=0)
    p.add_argument("--n-workers", type=int, default=2)
    p.add_argument("--phase-steps", type=int, default=30000)
    p.add_argument("--lambda", dest="ewc_lambda", type=float,
                   default=100.0)
    p.add_argument("--n-tasks", type=int, default=5)
    p.add_argument("--results-dir", default=RESULTS)
    p.add_argument("--budget", type=float, default=500.0)
    p.add_argument("--arms", default=None,
                   help="comma-separated subset of arms (default: all)")
    p.add_argument("--seeds", default=None,
                   help="comma-separated seeds (default: 0,1,2,3,4)")
    p.set_defaults(fn=lambda a: chunk(a.worker, n_workers=a.n_workers,
                                      phase_steps=a.phase_steps,
                                      ewc_lambda=a.ewc_lambda,
                                      n_tasks=a.n_tasks,
                                      results_dir=a.results_dir,
                                      budget_s=a.budget,
                                      arms=a.arms, seeds=a.seeds))
    args = ap.parse_args()
    ok = args.fn(args)
    if getattr(args, "cmd", "") == "chunk":
        sys.exit(0 if ok else 3)   # exit 3 = chunk incomplete, relaunch
