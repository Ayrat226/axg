"""L6 Generalization experiments.

(A) room_nav_gen: train on N procedural rooms (split=train), evaluate on the
    SAME train maps (in-distribution) and on held-out test maps (OOD).
    Includes the train-map-count sweep {5, 25, 100} (DQN) to measure the
    generalization gap as a function of training diversity.
(B) cartpole_vstart: train on standard starts, evaluate on wide unseen starts.

Provenance: everything journaled with the REQUIRED fields.
"""
import sys, os, json
sys.path.insert(0, "/home/z/my-project")
import numpy as np

from axq.envs import make
from axq.agents import make_agent
from axq.core.runner import train, evaluate
from axq.exp.journal import ExperimentJournal

RESULTS = "/home/z/my-project/axq/results"
os.makedirs(f"{RESULTS}/e6-seeds", exist_ok=True)
journal = ExperimentJournal(RESULTS + "/journal_l6.jsonl")


def run_room_nav(agent_name, n_train_maps, seeds, budget=100000):
    per_seed = []
    cache_key = f"{RESULTS}/e6-seeds/roomnav-{agent_name}-n{n_train_maps}"
    for seed in seeds:
        cache = f"{cache_key}-{seed}.json"
        if os.path.exists(cache):
            with open(cache) as f:
                per_seed.append(json.load(f))
            print(f"[room_nav n_train={n_train_maps:3d}] {agent_name:4s} "
                  f"seed={seed} (cached)", flush=True)
            continue
        env = make("room_nav_gen", split="train",
                   n_train_maps=n_train_maps, n_test_maps=1000)
        train_eval_env = make("room_nav_gen", split="train",
                              n_train_maps=n_train_maps, n_test_maps=1000)
        test_eval_env = make("room_nav_gen", split="test",
                             n_train_maps=n_train_maps, n_test_maps=1000)
        agent = make_agent(agent_name, env.n_obs, env.obs_type,
                           env.n_actions, seed=seed)
        res = train(agent, env, total_steps=budget, eval_env=train_eval_env,
                    eval_interval=20000, eval_episodes=20, seed=seed)
        test_ev = evaluate(agent, test_eval_env, episodes=50,
                           base_seed=777000 + seed * 13)
        rec = {"seed": seed,
               "train_score": res["final_eval"]["mean"],
               "test_score": test_ev["mean"],
               "gap": res["final_eval"]["mean"] - test_ev["mean"],
               "curve": res["curve"]}
        with open(cache, "w") as f:
            json.dump(rec, f)
        per_seed.append(rec)
        print(f"[room_nav n_train={n_train_maps:3d}] {agent_name:4s} "
              f"seed={seed} train={rec['train_score']:.3f} "
              f"test={rec['test_score']:.3f} gap={rec['gap']:.3f}",
              flush=True)
    tr = [r["train_score"] for r in per_seed]
    te = [r["test_score"] for r in per_seed]
    summary = {"agent": agent_name, "n_train_maps": n_train_maps,
               "budget": budget,
               "train_mean": float(np.mean(tr)), "train_std": float(np.std(tr)),
               "test_mean": float(np.mean(te)), "test_std": float(np.std(te)),
               "gap_mean": float(np.mean([r["gap"] for r in per_seed])),
               "per_seed": per_seed}
    journal.append({
        "exp_id": f"e6-roomnav-{agent_name}-n{n_train_maps}",
        "hypothesis_id": "H6-generalization", "env": "room_nav_gen",
        "agent": agent_name,
        "config": {"n_train_maps": n_train_maps, "budget": budget,
                   "agent_params": {}},
        "seeds": list(seeds), "budget_steps": budget, "status": "completed",
        "results_dir": RESULTS,
        "metrics": {"train_mean": summary["train_mean"],
                    "test_mean": summary["test_mean"],
                    "gap_mean": summary["gap_mean"]}})
    with open(f"{RESULTS}/e6-roomnav-{agent_name}-n{n_train_maps}.json",
              "w") as f:
        json.dump(summary, f, indent=2)
    return summary


def run_vstart(agent_name, seeds, budget=60000, agent_params=None):
    per_seed = []
    for seed in seeds:
        cache = f"{RESULTS}/e6-seeds/vstart-{agent_name}-{seed}.json"
        if os.path.exists(cache):
            with open(cache) as f:
                per_seed.append(json.load(f))
            continue
        env = make("cartpole_vstart", reset_dist="train")
        tr_env = make("cartpole_vstart", reset_dist="train")
        te_env = make("cartpole_vstart", reset_dist="test")
        agent = make_agent(agent_name, env.n_obs, env.obs_type, env.n_actions,
                           seed=seed, **(agent_params or {}))
        res = train(agent, env, total_steps=budget, eval_env=tr_env,
                    eval_interval=20000, eval_episodes=10, seed=seed)
        te = evaluate(agent, te_env, episodes=30, base_seed=888000 + seed * 7)
        rec = {"seed": seed,
               "train": res["final_eval"]["mean"],
               "test": te["mean"]}
        with open(cache, "w") as f:
            json.dump(rec, f)
        per_seed.append(rec)
        print(f"[vstart] {agent_name} seed={seed} "
              f"train={rec['train']:.1f} "
              f"test={rec['test']:.1f}", flush=True)
    summary = {"agent": agent_name, "per_seed": per_seed,
               "train_mean": float(np.mean([r["train"] for r in per_seed])),
               "test_mean": float(np.mean([r["test"] for r in per_seed]))}
    print(f"[vstart] {agent_name} SUMMARY train={summary['train_mean']:.1f} "
          f"test={summary['test_mean']:.1f}", flush=True)
    with open(f"{RESULTS}/e6-vstart-{agent_name}.json", "w") as f:
        json.dump(summary, f, indent=2)
    journal.append({
        "exp_id": f"e6-vstart-{agent_name}", "hypothesis_id": "H6-generalization",
        "env": "cartpole_vstart", "agent": agent_name,
        "config": {"agent_params": agent_params or {}}, "seeds": list(seeds),
        "budget_steps": budget, "status": "completed",
        "results_dir": RESULTS,
        "metrics": {"train_mean": summary["train_mean"],
                    "test_mean": summary["test_mean"]}})
    return summary


if __name__ == "__main__":
    part = sys.argv[1] if len(sys.argv) > 1 else "all"
    S5 = [0, 1, 2, 3, 4]
    if part in ("all", "sweep"):
        for n in (5, 25, 100):
            run_room_nav("dqn", n, S5)
        run_room_nav("axq", 100, [0, 1, 2])
    if part in ("all", "vstart"):
        run_vstart("dqn", S5, agent_params={"n_step": 3})
        run_vstart("axq", [0, 1, 2], agent_params={"n_step": 3})
