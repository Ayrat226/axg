"""H17c fill-in: rescue arms on the ORIGINAL deceptive envs at their
ORIGINAL reward scales (Phase A used small=1; deceptive_50 and credit have
their own scales), + H17b exploration-budget audit summary.

Arms (registered): tab-optim (optimistic = 2 x large), tab-count (bonus =
0.5 x small), on deceptive_50 (small=1, large=10), credit_assignment
(small=5, large=50), gridworld_decoy (optim 2.0 = 2 x goal reward — the
CORRECT scale, contrasting the Phase C 20.0 catastrophe).
"""
import json
import os
import sys

sys.path.insert(0, "/home/z/my-project")
import numpy as np

from axq.agents import make_agent
from axq.core.runner import train
from axq.envs import make
from axq.exp.journal import ExperimentJournal

RESULTS = "/home/z/my-project/axq/results/h17c"
os.makedirs(RESULTS, exist_ok=True)

JOBS = [
    ("deceptive_50", "tab-optim", {"optimistic_init": 20.0}, 10.0),
    ("deceptive_50", "tab-count", {"count_bonus": 0.5}, 10.0),
    ("credit_assignment", "tab-optim", {"optimistic_init": 100.0}, 50.0),
    ("credit_assignment", "tab-count", {"count_bonus": 2.5}, 50.0),
    ("gridworld_decoy", "tab-optim", {"optimistic_init": 2.0}, 0.755),
    ("gridworld_decoy", "tab-count", {"count_bonus": 0.5}, 0.755),
]
SEEDS = [0, 1, 2, 3, 4]

if __name__ == "__main__":
    out = {}
    for env_id, variant, params, vstar in JOBS:
        finals = []
        for s in SEEDS:
            env = make(env_id)
            ev = make(env_id)
            ag = make_agent("tabular", env.n_obs, env.obs_type,
                            env.n_actions, seed=s, **params)
            r = train(ag, env, total_steps=60000, eval_env=ev,
                      eval_interval=10000, eval_episodes=50, seed=s)
            finals.append(round(r["final_eval"]["mean"], 3))
        out[f"{env_id}:{variant}"] = {
            "finals": finals, "pass_rate": float(np.mean(
                [f >= 0.9 * vstar for f in finals])), "Vstar": vstar}
        print(f"{env_id:20s} {variant:10s}: finals={finals} "
              f"pass={out[f'{env_id}:{variant}']['pass_rate']:.1f}")
    # H17b: exploration-budget audit summary (analytic + measured)
    audit = {
        "eps_schedules": {
            "tabular (e5/H14-O=M2)": "1.0 -> 0.05 linear over 20000 steps",
            "dqn/axq (e5/H14-O=M1)": "1.0 -> 0.05 linear over 10000 steps",
            "interpretation": "tabular annealed 2x SLOWER (more per-step "
                              "exploration) yet failed deceptive; matched "
                              "arms M1/M2 flip nobody's outcome class "
                              "(H14).",
        },
        "large_events_training": {
            "tabular (H14 O)": 0,
            "dqn (H14 O)": "289-1668 per seed across envs",
            "axq (H14 O)": "376-2994 per seed",
            "dyna-eps (H20)": "0 on deceptive (locked); passes decoy via "
                              "planning",
        },
        "conclusion": "Comparable-or-greater exploration budget does NOT "
                      "rescue tabular on deceptive; failure is structural "
                      "(argmax-tie at aliased state + eps floor).",
    }
    out["H17b_audit"] = audit
    with open(os.path.join(RESULTS, "h17c_rescue.json"), "w") as f:
        json.dump(out, f, indent=2)
    print("saved -> axq/results/h17c/h17c_rescue.json")
