"""H18 Phase A — tabular-family factorial sensitivity grid (preregistered).

Full factorial over DeceptiveChoice configs x tabular exploration variants:
  delay {5,10,20} x ratio {2,5,10} x n_noise_actions {0,2} x slip {0,0.2}
  x agent {tab-eps, tab-optim, tab-count, tab-floor, tab-longdecay}
  x seeds {0..4}, budget 60k, eval 10k / 50 eps.

PASS = final greedy eval return >= 0.9 * V*(0) (V* from the exact true-state
model per config; with slip the optimal often flips to "take small" — S4).
Registered direction-predictions S1-S6 in PREREG_CYCLE4.md (amended by KB
e349e51be77e: tab-count now predicted to FAIL the deceptive family).

Phase B (NN/Dyna reduced grid) and Phase C (decoy trap levels) live in the
same driver: --phase a|b|c.
"""
import argparse
import json
import os
import sys
import time

sys.path.insert(0, "/home/z/my-project")
import numpy as np

from axq.agents import make_agent
from axq.core.runner import train
from axq.envs.chains import DeceptiveChoice
from axq.envs.antitests import DecoyGridWorld, value_iteration
from axq.exp.journal import ExperimentJournal, code_fingerprint
from axq.exp.stats import summarize

RESULTS = "/home/z/my-project/axq/results/h18sens"
GAMMA = 0.99
SMALL = 1.0
SEEDS = [0, 1, 2, 3, 4]
SOFT_DEADLINE = float(os.environ.get("CHUNK_BUDGET", "540"))

# agent variant -> constructor params (all are TabularQ-compatible)
VARIANTS = {
    "tab-eps": {},
    "tab-optim": {"optimistic_init": 20.0},       # 2 x large(10) registered
    "tab-count": {"count_bonus": 0.5},            # 0.5 x small registered
    "tab-floor": {"eps_end": 0.3},
    "tab-longdecay": {"eps_decay": 200000},
    "dyna-eps": {"k_plan": 20},
    "dyna-optim": {"k_plan": 20, "optimistic_init": 20.0},   # BUGFIX: was
    #   missing from VARIANTS => Phase B dyna-optim ran WITHOUT optimism
    #   (identical to dyna-eps); affected cells deleted + re-run.
}


def vstar(cfg):
    env = DeceptiveChoice(**cfg)
    V, Q, pol = value_iteration(*env.mdp_model(GAMMA), GAMMA)
    return float(V[0]), int(pol[0])


def run_cell(cfg, variant, agent_name, seed, budget=60000):
    env = DeceptiveChoice(**cfg)
    eval_env = DeceptiveChoice(**cfg)
    params = dict(VARIANTS.get(variant, {}))
    if agent_name == "dyna":
        params.setdefault("k_plan", 20)
    agent = make_agent(agent_name, env.n_obs, env.obs_type, env.n_actions,
                       seed=seed, **params)
    res = train(agent, env, total_steps=budget, eval_env=eval_env,
                eval_interval=10000, eval_episodes=50, seed=seed)
    V0, pol0 = vstar(cfg)
    return {"final": res["final_eval"]["mean"],
            "curve": [[int(a), float(b)] for a, b in res["curve"]],
            "V0": V0, "opt_pol0": pol0,
            "pass": bool(res["final_eval"]["mean"] >= 0.9 * V0)}


def phase_a_cells():
    for delay in (5, 10, 20):
        for ratio in (2, 5, 10):
            for noise in (0, 2):
                for slip in (0.0, 0.2):
                    for variant in VARIANTS:
                        cfg = dict(delay=delay, small_reward=SMALL,
                                   large_reward=float(ratio),
                                   n_noise_actions=noise, slip=slip)
                        yield cfg, variant, "tabular"


def phase_b_cells():
    for delay in (5, 10, 20):
        for noise in (0, 2):
            for slip in (0.0, 0.2):
                for variant, aname in (("dyna-eps", "dyna"),
                                       ("dyna-optim", "dyna")):
                    cfg = dict(delay=delay, small_reward=SMALL,
                               large_reward=10.0, n_noise_actions=noise,
                               slip=slip)
                    yield cfg, variant, aname
    # dqn reduced grid (ratio=10)
    for delay in (5, 10, 20):
        for noise in (0, 2):
            for slip in (0.0, 0.2):
                cfg = dict(delay=delay, small_reward=SMALL,
                           large_reward=10.0, n_noise_actions=noise,
                           slip=slip)
                yield cfg, "dqn", "dqn"
    # axq spot-check (registered)
    for delay in (10, 20):
        cfg = dict(delay=delay, small_reward=SMALL, large_reward=10.0,
                   n_noise_actions=2, slip=0.0)
        yield cfg, "axq", "axq"


def phase_c_cells():
    for trap in (0.3, 0.5, 0.7):
        for variant in ("tab-eps", "tab-optim", "tab-count"):
            yield dict(trap_reward=trap), variant, "decoy"
    for trap in (0.3, 0.5, 0.7):
        yield dict(trap_reward=trap), "dqn", "dqn-decoy"


def run_decoy(trap, variant, agent_name, seed, budget=60000):
    env = DecoyGridWorld(trap_reward=trap)
    eval_env = DecoyGridWorld(trap_reward=trap)
    params = dict(VARIANTS.get(variant, {}))
    agent = make_agent("tabular" if agent_name in ("decoy",) else agent_name,
                       env.n_obs, env.obs_type, env.n_actions, seed=seed,
                       **params)
    res = train(agent, env, total_steps=budget, eval_env=eval_env,
                eval_interval=10000, eval_episodes=50, seed=seed)
    V, Q, pol = value_iteration(*env.mdp_model(GAMMA), GAMMA)
    return {"final": res["final_eval"]["mean"], "V0": float(V[0]),
            "pass": bool(res["final_eval"]["mean"] >= 0.9 * float(V[0]))}


def cell_id(cfg, variant):
    return ("d{delay}_r{ratio:g}_n{noise}_s{slip:g}_{v}"
            if "delay" in cfg else "trap{ratio:g}_{v}").format(
        delay=cfg.get("delay", 0), ratio=cfg.get("large_reward",
                                                 cfg.get("trap_reward", 0)),
        noise=cfg.get("n_noise_actions", 0), slip=cfg.get("slip", 0),
        v=variant)


def main(phase, worker, n_workers):
    os.makedirs(RESULTS, exist_ok=True)
    journal = ExperimentJournal(os.path.join(RESULTS, "journal.jsonl"))
    cells = {"a": phase_a_cells, "b": phase_b_cells,
             "c": phase_c_cells}[phase]()
    todo = [(cfg, v, an) for cfg, v, an in cells]
    mine = todo[worker::n_workers]
    t0 = time.time()
    print(f"[h18-{phase} worker {worker}] {len(mine)} cells x {len(SEEDS)} seeds")
    for cfg, variant, aname in mine:
        cid = cell_id(cfg, variant)
        d = os.path.join(RESULTS, f"{phase}_{cid}")
        os.makedirs(d, exist_ok=True)
        for s in SEEDS:
            fp = os.path.join(d, f"seed_{s}.json")
            if os.path.exists(fp):
                continue
            if time.time() - t0 > SOFT_DEADLINE:
                print(f"[w{worker}] deadline; exit 3")
                return False
            if aname in ("decoy", "dqn-decoy"):
                out = run_decoy(cfg["trap_reward"], variant,
                                "tabular" if aname == "decoy" else "dqn", s)
            else:
                out = run_cell(cfg, variant, aname, s)
            out.update({"cell": cid, "variant": variant, "seed": s,
                        "cfg": cfg, "agent": aname})
            with open(fp, "w") as f:
                json.dump(out, f)
            print(f"[w{worker}] {cid} s{s}: final={out['final']:.3f} "
                  f"V*={out['V0']:.3f} pass={out['pass']}", flush=True)
        # cell summary
        rows = [json.load(open(os.path.join(d, f"seed_{s}.json")))
                for s in SEEDS]
        sm = {"cell": cid, "variant": variant, "cfg": cfg,
              "pass_rate": float(np.mean([r["pass"] for r in rows])),
              "final_mean": float(np.mean([r["final"] for r in rows])),
              "V0": rows[0]["V0"], "opt_pol0": rows[0].get("opt_pol0"),
              "code_version": code_fingerprint()}
        with open(os.path.join(d, "summary.json"), "w") as f:
            json.dump(sm, f, indent=2)
        journal.append({"exp_id": f"h18-{phase}-{cid}",
                        "hypothesis_id": "H18-sensitivity",
                        "env": "deceptive_param" if "delay" in cfg
                               else "gridworld_decoy",
                        "agent": variant,
                        "config": {k: v for k, v in cfg.items()},
                        "seeds": SEEDS, "budget_steps": 60000,
                        "status": "done", "pass_rate": sm["pass_rate"]})
    print(f"[w{worker}] phase {phase} complete")
    return True


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase", choices=["a", "b", "c"], default="a")
    ap.add_argument("--worker", type=int, default=0)
    ap.add_argument("--n-workers", type=int, default=2)
    ap.add_argument("--budget", type=float, default=540.0)
    args = ap.parse_args()
    SOFT_DEADLINE = args.budget
    ok = main(args.phase, args.worker, args.n_workers)
    sys.exit(0 if ok else 3)
