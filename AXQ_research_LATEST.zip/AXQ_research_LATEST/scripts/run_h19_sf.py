"""H19 — SF/GPI vs dqn-persist on the shared-layout continual suite.

Arms (suite continual_gridworlds_shared unless noted; 30k/phase x 5 phases;
seeds 0-7):
  sf-shared     : SFGPI + k-shot inference eval (3 w-only episodes)
  dqn-persist-sh: exact g1 dqn-persist config, standard eval protocol
  sf-varying    : SFGPI on the layout-varying suite (negative control)

Crash-safe: each phase appends one JSON line to
  axq/results/h19/<arm>_seed<seed>.jsonl  (run_id guards restart mixing).
Resume: a (arm, seed) job is skipped iff its jsonl has 5 phase rows.
Aggregation: scripts/analyze_h19.py (separate).
"""
import argparse
import json
import os
import sys
import time
import uuid

sys.path.insert(0, "/home/z/my-project")
import numpy as np

from axq.agents.dqn import DQN
from axq.agents.mbtl import MBTL
from axq.agents.sf import SFGPI
from axq.core.runner import evaluate, train
from axq.envs import multitask
from axq.exp.journal import ExperimentJournal

RESULTS = "/home/z/my-project/axq/results/h19"
PHASE_STEPS = 30000
EVAL_EPISODES = 20
INFER_EPISODES = 3
N_PHASES = 5
SUITES = {"sf-shared": "continual_gridworlds_shared",
          "dqn-persist-sh": "continual_gridworlds_shared",
          "sf-varying": "continual_gridworlds",
          "dyna-persist-sh": "continual_gridworlds_shared",
          "sf-shared-k10": "continual_gridworlds_shared",
          "mbtl-sh": "continual_gridworlds_shared"}
SOFT_DEADLINE = float(os.environ.get("CHUNK_BUDGET", "540"))


def build(arm, seed, n_obs, obs_type, n_actions):
    if arm.startswith("sf"):
        return SFGPI(n_obs=n_obs, obs_type=obs_type, n_actions=n_actions,
                     seed=seed, alpha=0.2, eps_decay=20000, bonus=1.0)
    if arm == "dqn-persist-sh":   # exact g1 dqn-persist config
        return DQN(n_obs=n_obs, obs_type=obs_type, n_actions=n_actions,
                   seed=seed, buffer_size=200000)
    if arm == "dyna-persist-sh":  # follow-up (b): model-based transfer
        from axq.agents.dyna import DynaQ
        return DynaQ(n_obs=n_obs, obs_type=obs_type, n_actions=n_actions,
                     seed=seed, k_plan=20, optimistic_init=0.0)
    if arm == "mbtl-sh":          # H23 capstone: model + task library + VI
        return MBTL(n_obs=n_obs, obs_type=obs_type, n_actions=n_actions,
                    seed=seed, k_plan=20, alpha=0.3, eps_decay=20000)
    raise ValueError(arm)


def kshot_eval(agent, factory, j):
    """Snapshot -> 3 inference episodes (SFGPI / MBTL) -> greedy eval.

    Standard agents skip the inference stage (no task-inference mechanism;
    protocol difference is the mechanism's requirement, registered).
    """
    if isinstance(agent, MBTL):
        snap = (agent._w.copy(), [w.copy() for w in agent._library],
                agent._task_switches)
        env = factory()
        agent.begin_inference()
        obs = env.reset(910000 + 13 * j)
        for _ in range(INFER_EPISODES):
            done = False
            while not done:
                a = agent.act(obs, greedy=False)
                nobs, r, term, trunc, _ = env.step(a)
                agent.observe(obs, a, r, nobs, term, trunc)
                obs = nobs
                done = term or trunc
            obs = env.reset(910000 + 13 * j + 7)
        agent.end_inference()
        diag = dict(agent.diagnostics())
        ev = evaluate(agent, factory(), episodes=EVAL_EPISODES,
                      base_seed=555555 + 1009 * j, greedy=True)
        agent._w = snap[0]
        agent._library = snap[1]
        agent._task_switches = snap[2]
        return ev["mean"], diag
    if not isinstance(agent, SFGPI):
        ev = evaluate(agent, factory(), episodes=EVAL_EPISODES,
                      base_seed=555555 + 1009 * j, greedy=True)
        return ev["mean"], {}
    snap = (agent._psi.copy(), agent._w.copy(),
            [(p.copy(), w.copy()) for p, w in agent._library],
            agent._task_switches)
    env = factory()
    agent.begin_inference()
    obs = env.reset(910000 + 13 * j)
    for _ in range(INFER_EPISODES):
        done = False
        while not done:
            a = agent.act(obs, greedy=False)
            nobs, r, term, trunc, _ = env.step(a)
            agent.observe(obs, a, r, nobs, term, trunc)
            obs = nobs
            done = term or trunc
        obs = env.reset(910000 + 13 * j + 7)
    agent.end_inference()
    diag = dict(agent.diagnostics())
    ev = evaluate(agent, factory(), episodes=EVAL_EPISODES,
                  base_seed=555555 + 1009 * j, greedy=True)
    # restore training state (eval-time inference is ephemeral)
    agent._psi, agent._w = snap[0], snap[1]
    agent._library = [(p, w) for p, w in snap[2]]
    agent._task_switches = snap[3]
    return ev["mean"], diag


def phases_done(arm, seed):
    p = os.path.join(RESULTS, f"{arm}_seed{seed}.jsonl")
    if not os.path.exists(p):
        return 0, p
    return sum(1 for line in open(p) if line.strip()), p


def run_one(arm, seed, journal):
    global INFER_EPISODES
    if arm == "sf-shared-k10":
        INFER_EPISODES = 10
    else:
        INFER_EPISODES = 3
    suite = multitask.SUITES[SUITES[arm]]
    tasks = suite.tasks[:N_PHASES]
    n_done, jsonl = phases_done(arm, seed)
    if n_done >= N_PHASES:
        return True
    if n_done > 0:
        print(f"[{arm} s{seed}] resuming from phase {n_done}")
    first = tasks[0][1]()
    agent = build(arm, seed, first.n_obs, first.obs_type, first.n_actions)
    run_id = uuid.uuid4().hex[:8]
    # NOTE: resume restarts training from scratch but keeps completed phase
    # rows; documented: partial-run rows carry a different run_id and the
    # analysis uses only complete 5-phase files (audit 9-b M2 convention).
    for i, (tname, factory) in enumerate(tasks):
        if i < n_done:
            continue
        train(agent, factory(), total_steps=PHASE_STEPS, eval_env=None,
              seed=seed + i)
        row, diags = [], []
        for j, (_, ef) in enumerate(tasks):
            v, d = kshot_eval(agent, ef, j)
            row.append(v)
            diags.append(d)
        with open(jsonl, "a") as f:
            f.write(json.dumps({
                "arm": arm, "seed": seed, "phase": i, "task": tname,
                "row": row, "diag": diags, "phase_steps": PHASE_STEPS,
                "infer_episodes": (INFER_EPISODES
                                   if isinstance(agent, SFGPI) else 0),
                "agent_diag": (dict(agent.diagnostics())
                               if hasattr(agent, "diagnostics") else {}),
                "run_id": run_id,
                "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            }) + "\n")
        print(f"[{arm} s{seed}] phase {i} ({tname}): "
              f"{[round(x, 2) for x in row]}", flush=True)
    journal.append({"exp_id": f"h19-{arm}-s{seed}",
                    "hypothesis_id": "H19-sf-gpi",
                    "env": SUITES[arm], "agent": arm,
                    "config": {"phase_steps": PHASE_STEPS,
                               "infer_episodes": INFER_EPISODES},
                    "seeds": [seed], "budget_steps": PHASE_STEPS * N_PHASES,
                    "status": "done"})
    return True


def main(worker, n_workers, arms):
    os.makedirs(RESULTS, exist_ok=True)
    journal = ExperimentJournal(os.path.join(RESULTS, "journal.jsonl"))
    t0 = time.time()
    jobs = [(a, s) for a in arms for s in range(8)]
    mine = jobs[worker::n_workers]
    print(f"[h19 w{worker}] jobs: {mine}")
    for arm, seed in mine:
        n, _ = phases_done(arm, seed)
        if n >= N_PHASES:
            continue
        if time.time() - t0 > SOFT_DEADLINE:
            print(f"[w{worker}] deadline; exit 3")
            return False
        run_one(arm, seed, journal)
    print(f"[w{worker}] complete")
    return True


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--worker", type=int, default=0)
    ap.add_argument("--n-workers", type=int, default=2)
    ap.add_argument("--arms", default="sf-shared,dqn-persist-sh,sf-varying")
    ap.add_argument("--budget", type=float, default=540.0)
    args = ap.parse_args()
    SOFT_DEADLINE = args.budget
    ok = main(args.worker, args.n_workers,
              [a for a in args.arms.split(",") if a])
    sys.exit(0 if ok else 3)
