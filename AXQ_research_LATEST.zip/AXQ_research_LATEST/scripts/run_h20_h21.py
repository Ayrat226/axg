"""H20/H21 — Dyna-Q benchmark + EFE parameter-robustness (preregistered).

H20 (Family N2): DynaQ(k=20) on gridworld_sparse, seeds 0-7, exact e3-sparse
config (100k steps, ev 10000, ep 20) => PAIRED comparison with existing
axq/dqn results (same seeds/configs). Arms: dyna-eps (baseline schedule),
dyna-optim (optimistic_init=2.0). Secondary: dyna on deceptive_50 /
credit_assignment / decoy (S6 predictions) + dyna on chain_10.

H21 (Family N3): EFE tau-robustness grid. For each env in {chain_10,
gridworld_sparse, deceptive_5}: tau_e in {0.5, 1, 2, 4, 8} x small_reward
(scaled grid, KB amendment) x 5 seeds vs eps-family grid: tabular with
(eps_end, eps_decay) in {0.05,0.1,0.2,0.3} x {5k,20k,60k} x 5 seeds.
Metric per env: normalized score range across the grid (max-min)/(max|score|)
=> claim: EFE range <= 0.5 x eps range.

Resumable per-seed JSON files; SOFT deadline; exit 3.
"""
import argparse
import json
import os
import sys
import time

sys.path.insert(0, "/home/z/my-project")
import numpy as np

from axq.agents import make_agent
from axq.core.runner import train
from axq.envs import make
from axq.exp.analysis import auc as curve_auc
from axq.exp.journal import ExperimentJournal, code_fingerprint

RESULTS = "/home/z/my-project/axq/results/h20h21"
SEEDS_H20 = list(range(8))
SEEDS_H21 = [0, 1, 2, 3, 4]
SOFT_DEADLINE = float(os.environ.get("CHUNK_BUDGET", "540"))

H20_JOBS = [
    # primary: sparse AUC (exact e3-sparse config for pairing)
    dict(name="h20-sparse-dyna", env="gridworld_sparse", agent="dyna",
         params={"k_plan": 20}, seeds=SEEDS_H20, budget=100000, ev=10000,
         ep=20),
    dict(name="h20-sparse-dyna-optim", env="gridworld_sparse", agent="dyna",
         params={"k_plan": 20, "optimistic_init": 2.0}, seeds=SEEDS_H20,
         budget=100000, ev=10000, ep=20),
    # secondary: deceptive family (S6) + chain
    dict(name="h20-decep50-dyna", env="deceptive_50", agent="dyna",
         params={"k_plan": 20}, seeds=SEEDS_H20, budget=60000, ev=10000,
         ep=50),
    dict(name="h20-decep50-dyna-optim", env="deceptive_50", agent="dyna",
         params={"k_plan": 20, "optimistic_init": 20.0}, seeds=SEEDS_H20,
         budget=60000, ev=10000, ep=50),
    dict(name="h20-credit-dyna", env="credit_assignment", agent="dyna",
         params={"k_plan": 20}, seeds=SEEDS_H20, budget=60000, ev=10000,
         ep=50),
    dict(name="h20-credit-dyna-optim", env="credit_assignment", agent="dyna",
         params={"k_plan": 20, "optimistic_init": 100.0}, seeds=SEEDS_H20,
         budget=60000, ev=10000, ep=50),
    dict(name="h20-decoy-dyna", env="gridworld_decoy", agent="dyna",
         params={"k_plan": 20}, seeds=SEEDS_H20, budget=60000, ev=10000,
         ep=50),
    dict(name="h20-decoy-dyna-optim", env="gridworld_decoy", agent="dyna",
         params={"k_plan": 20, "optimistic_init": 2.0}, seeds=SEEDS_H20,
         budget=60000, ev=10000, ep=50),
    dict(name="h20-chain10-dyna", env="chain_10", agent="dyna",
         params={"k_plan": 20}, seeds=SEEDS_H20, budget=60000, ev=10000,
         ep=50),
]

H21_ENVS = {
    "chain_10": dict(small=1.0, budget=60000, ev=10000, ep=50),
    "gridworld_sparse": dict(small=1.0, budget=100000, ev=10000, ep=20),
    "deceptive_5": dict(small=1.0, budget=60000, ev=10000, ep=50),
}
TAUS = [0.5, 1.0, 2.0, 4.0, 8.0]
EPS_ENDS = [0.05, 0.1, 0.2, 0.3]
EPS_DECAYS = [5000, 20000, 60000]


def run_basic(env_id, agent_name, params, seed, budget, ev, ep):
    env = make(env_id)
    eval_env = make(env_id)
    agent = make_agent(agent_name, env.n_obs, env.obs_type, env.n_actions,
                       seed=seed, **params)
    res = train(agent, env, total_steps=budget, eval_env=eval_env,
                eval_interval=ev, eval_episodes=ep, seed=seed)
    return {"final": res["final_eval"]["mean"],
            "auc": curve_auc(res["curve"], budget),
            "curve": [[int(a), float(b)] for a, b in res["curve"]],
            "steps_per_sec": round(res["steps_per_sec"], 1)}


def main(worker, n_workers):
    os.makedirs(RESULTS, exist_ok=True)
    journal = ExperimentJournal(os.path.join(RESULTS, "journal.jsonl"))
    t0 = time.time()
    # ---- build the flat job list: H20 first, then H21 grids ----
    jobs = []
    for j in H20_JOBS:
        for s in j["seeds"]:
            jobs.append(("h20", j, s))
    for env_id, cfg in H21_ENVS.items():
        for tau in TAUS:
            for s in SEEDS_H21:
                jobs.append(("h21", dict(env=env_id, kind="efe",
                                         tau=tau, cfg=cfg), s))
        for ee in EPS_ENDS:
            for ed in EPS_DECAYS:
                for s in SEEDS_H21:
                    jobs.append(("h21", dict(env=env_id, kind="eps",
                                             eps_end=ee, eps_decay=ed,
                                             cfg=cfg), s))
    mine = jobs[worker::n_workers]
    print(f"[h20h21 w{worker}] {len(mine)} jobs")
    for kind, j, s in mine:
        if kind == "h20":
            fp = os.path.join(RESULTS, f"{j['name']}_s{s}.json")
            if os.path.exists(fp):
                continue
            if time.time() - t0 > SOFT_DEADLINE:
                print("[w%d] deadline; exit 3" % worker)
                return False
            out = run_basic(j["env"], j["agent"], j["params"], s,
                            j["budget"], j["ev"], j["ep"])
            out.update({"job": j["name"], "seed": s})
            with open(fp, "w") as f:
                json.dump(out, f)
            print(f"[w{worker}] {j['name']} s{s}: final={out['final']:.3f} "
                  f"auc={out['auc']:.3f}", flush=True)
        else:
            fp = os.path.join(
                RESULTS, f"h21_{j['env']}_{j['kind']}_"
                f"{'tau' + str(j.get('tau')) if j['kind'] == 'efe' else 'e' + str(j['eps_end']) + 'd' + str(j['eps_decay'])}_s{s}.json")
            if os.path.exists(fp):
                continue
            if time.time() - t0 > SOFT_DEADLINE:
                print("[w%d] deadline; exit 3" % worker)
                return False
            if j["kind"] == "efe":
                params = {"tau_e": j["tau"] * j["cfg"]["small"]}
                agent_name = "efe"
            else:
                params = {"eps_end": j["eps_end"], "eps_decay": j["eps_decay"]}
                agent_name = "tabular"
            out = run_basic(j["env"], agent_name, params, s,
                            j["cfg"]["budget"], j["cfg"]["ev"],
                            j["cfg"]["ep"])
            out.update({"env": j["env"], "kind": j["kind"],
                        "params": params, "seed": s})
            with open(fp, "w") as f:
                json.dump(out, f)
            print(f"[w{worker}] h21 {j['env']} {params} s{s}: "
                  f"final={out['final']:.3f} auc={out['auc']:.3f}",
                  flush=True)
    print(f"[w{worker}] complete")
    return True


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--worker", type=int, default=0)
    ap.add_argument("--n-workers", type=int, default=2)
    ap.add_argument("--budget", type=float, default=540.0)
    args = ap.parse_args()
    SOFT_DEADLINE = args.budget
    ok = main(args.worker, args.n_workers)
    sys.exit(0 if ok else 3)
