"""L7 Robustness experiments: evaluate trained cartpole checkpoints under
adversarial conditions (obs noise, action delay, sticky actions, obs dropout,
action permutation). Robustness curves per agent family.

Requires: e2-cartpole-dqn / e2-cartpole-axq checkpoints (run_suite l0l1).
"""
import sys
sys.path.insert(0, "/home/z/my-project")
import json
import numpy as np

from axq.envs import make
from axq.envs.wrappers import (ObsNoiseWrapper, ActionDelayWrapper,
                               StickyActionsWrapper, ObsDropoutWrapper,
                               ActionPermutationWrapper)
from axq.agents import make_agent
from axq.core.runner import evaluate
from axq.exp.journal import ExperimentJournal

RESULTS = "/home/z/my-project/axq/results"
journal = ExperimentJournal(RESULTS + "/journal.jsonl")
CONTROL = {"n_step": 3}


def load_agent(agent_name, ckpt, seed):
    env = make("cartpole")
    agent = make_agent(agent_name, env.n_obs, env.obs_type, env.n_actions,
                       seed=seed, **CONTROL)
    agent.load(ckpt)
    return agent


def make_wrapped(kind, level):
    def f():
        base = make("cartpole")
        if kind == "baseline":
            return base
        if kind == "noise":
            return ObsNoiseWrapper(base, sigma=level)
        if kind == "delay":
            return ActionDelayWrapper(base, delay=int(level))
        if kind == "sticky":
            return StickyActionsWrapper(base, p=level)
        if kind == "dropout":
            return ObsDropoutWrapper(base, p=level)
        if kind == "perm":
            return ActionPermutationWrapper(base, perm_seed=999)
        raise ValueError(kind)
    return f


CONDITIONS = [("baseline", 0)] + \
    [("noise", v) for v in (0.01, 0.05, 0.1)] + \
    [("delay", v) for v in (1, 2, 5)] + \
    [("sticky", v) for v in (0.1, 0.25)] + \
    [("dropout", v) for v in (0.1, 0.3)] + \
    [("perm", 999)]


def main():
    out = {}
    for agent_name in ("dqn", "axq"):
        recs = {}
        for kind, level in CONDITIONS:
            scores = []
            for seed in [0, 1, 2, 3, 4]:
                ckpt = f"{RESULTS}/e2-cartpole-{agent_name}/agent_{agent_name}_seed{seed}.npz"
                try:
                    agent = load_agent(agent_name, ckpt, seed)
                except FileNotFoundError:
                    print(f"missing checkpoint {ckpt}; run l0l1 first",
                          flush=True)
                    return
                ev = evaluate(agent, make_wrapped(kind, level)(),
                              episodes=20, base_seed=4242000 + seed * 31)
                scores.append(ev["mean"])
            recs[f"{kind}={level}"] = {
                "mean": float(np.mean(scores)),
                "std": float(np.std(scores)),
                "per_seed": scores}
            print(f"[robustness {agent_name}] {kind}={level}: "
                  f"{recs[f'{kind}={level}']['mean']:.1f} "
                  f"(+/- {recs[f'{kind}={level}']['std']:.1f})", flush=True)
        base = recs["baseline=0"]["mean"]
        recs["auc_normalized"] = float(np.mean(
            [r["mean"] for k, r in recs.items() if k != "auc_normalized"]) / 500.0)
        out[agent_name] = recs
    with open(f"{RESULTS}/e7-robustness.json", "w") as f:
        json.dump(out, f, indent=2)
    journal.append({
        "exp_id": "e7-robustness", "hypothesis_id": "H7-robustness",
        "env": "cartpole+wrappers", "agent": "dqn vs axq",
        "config": {"conditions": [f"{k}={v}" for k, v in CONDITIONS]},
        "seeds": [0, 1, 2, 3, 4], "budget_steps": 0, "status": "completed",
        "results_dir": RESULTS, "metrics": out})


if __name__ == "__main__":
    main()
