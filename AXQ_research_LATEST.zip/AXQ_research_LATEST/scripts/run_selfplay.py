"""L9 Self-play / opponent-strength experiments on tic-tac-toe.

Stage A (fixed-opponent curriculum): DQN trained vs random bot, then vs
  heuristic bot; evaluated against random / heuristic / minimax.
Stage B (self-play): two DQN agents play each other; evaluated vs bots.

Metrics: win/draw/loss rates vs each bot kind. Hypothesis (H9): self-play
produces stronger, less exploitable policies than fixed-opponent training.
"""
import sys
sys.path.insert(0, "/home/z/my-project")
import json
import numpy as np

from axq.envs import make
from axq.envs.games import SelfPlaySession
from axq.agents import make_agent
from axq.core.runner import train, evaluate
from axq.exp.journal import ExperimentJournal

RESULTS = "/home/z/my-project/axq/results"
journal = ExperimentJournal(RESULTS + "/journal.jsonl")


def eval_vs_bots(agent, n=200):
    out = {}
    for bot in ("random", "heuristic", "minimax"):
        env = make(f"tictactoe_vs_{bot}")
        ev = evaluate(agent, env, episodes=n, base_seed=31337000)
        r = np.asarray(ev["rewards"])
        out[bot] = {"mean": float(r.mean()),
                    "win": float((r > 0.5).mean()),
                    "draw": float((r > -0.5).sum() - (r > 0.5).sum()) / n,
                    "loss": float((r < -0.5).mean())}
        out[bot]["draw"] = float(((r > -0.5) & (r <= 0.5)).mean())
    return out


def stage_a(seed, budget=80000):
    env = make("tictactoe_vs_random")
    agent = make_agent("dqn", env.n_obs, env.obs_type, env.n_actions,
                       seed=seed, eps_decay=20000)
    train(agent, env, total_steps=budget, eval_env=None, seed=seed)
    after_random = eval_vs_bots(agent, n=100)
    env = make("tictactoe_vs_heuristic")
    train(agent, env, total_steps=budget, eval_env=None, seed=seed + 1000)
    after_heuristic = eval_vs_bots(agent, n=100)
    return {"after_random": after_random, "after_heuristic": after_heuristic}


def stage_b(seed, n_games=6000):
    env = make("tictactoe_vs_random")
    ax = make_agent("dqn", env.n_obs, env.obs_type, env.n_actions,
                    seed=seed, eps_decay=20000)
    ao = make_agent("dqn", env.n_obs, env.obs_type, env.n_actions,
                    seed=seed + 500, eps_decay=20000)
    session = SelfPlaySession(ax, ao)
    checkpoints = []
    for phase in range(3):
        summ = session.play_and_train(n_games, base_seed=seed * 100 + phase)
        checkpoints.append(eval_vs_bots(ax, n=100))
        print(f"[selfplay seed={seed}] phase {phase + 1}/3 games="
              f"{(phase + 1) * n_games} vs_heuristic="
              f"{checkpoints[-1]['heuristic']['mean']:.3f} "
              f"vs_minimax={checkpoints[-1]['minimax']['mean']:.3f} "
              f"(summary={summ})", flush=True)
    return {"progression": checkpoints}


def main():
    out_a, out_b = {}, {}
    for seed in [0, 1, 2]:
        out_a[seed] = stage_a(seed)
        print(f"[stageA seed={seed}] vs heuristic after curriculum: "
              f"{out_a[seed]['after_heuristic']['heuristic']}", flush=True)
        out_b[seed] = stage_b(seed)
    summary = {"stage_a": out_a, "stage_b": out_b}
    with open(f"{RESULTS}/e9-selfplay.json", "w") as f:
        json.dump(summary, f, indent=2)
    journal.append({
        "exp_id": "e9-selfplay", "hypothesis_id": "H9-selfplay",
        "env": "tictactoe", "agent": "dqn (fixed-opponent vs self-play)",
        "config": {"budget_per_stage": 80000, "selfplay_games": 6000},
        "seeds": [0, 1, 2], "budget_steps": 160000, "status": "completed",
        "results_dir": RESULTS,
        "metrics": {"note": "see e9-selfplay.json for full matrices"}})


if __name__ == "__main__":
    main()
