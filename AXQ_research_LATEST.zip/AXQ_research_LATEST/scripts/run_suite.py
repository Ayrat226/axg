"""Phase 3 experiment suite driver — RESUMABLE, chunked for sandbox limits.

Design constraints: bash tool calls are killed at ~10 min; background
processes do not survive the spawning session. Therefore:
* work is flattened to (job, agent, seed) triples;
* each completed seed writes its own seed_<s>.json (crash-safe resume);
* when all seeds of a job exist, summary.json + journal record are written;
* a SOFT_DEADLINE makes the process exit cleanly before the hard kill;
* run two processes (different groups) per bash call for 2-core parallelism.

Usage: python scripts/run_suite.py <group> [worker_seconds]
Groups: l0l1 | l2 | l3l4l5 | all
"""
import sys, os, time, json
sys.path.insert(0, "/home/z/my-project")

SOFT_DEADLINE = 520.0   # seconds of wall clock before clean exit
HARD_MARGIN = 30.0      # startup overhead reserve
# Wall-clock budget for the chunk (seconds). Overridable via env for
# sequential multi-worker calls inside one bash invocation.
CHUNK_BUDGET = float(os.environ.get("CHUNK_BUDGET", "550"))
# Conservative per-agent seconds per 100k env steps (measured on this box;
# used ONLY for chunk scheduling, never for results).
SECONDS_PER_100K = {"random": 8.0, "tabular": 12.0, "dqn": 95.0,
                    "history_dqn": 150.0, "axq": 300.0, "gru_dqn": 250.0}
RESULTS = "/home/z/my-project/axq/results"
T0 = time.time()

from axq.envs import make
from axq.agents import make_agent
from axq.core.runner import train
from axq.exp.analysis import auc
from axq.exp.journal import ExperimentJournal, code_fingerprint
from axq.exp.stats import summarize
import numpy as np

SEEDS5 = [0, 1, 2, 3, 4]
SEEDS8 = [0, 1, 2, 3, 4, 5, 6, 7]


def get_journal(group):
    """Per-group journal to allow two workers to append concurrently."""
    return ExperimentJournal(RESULTS + f"/journal_{group}.jsonl")

AGENTS = {"random": {}, "tabular": {}, "dqn": {}, "axq": {},
          "history_dqn": {}, "gru_dqn": {}}
CONTROL_PARAMS = {"n_step": 3}

HISTORY_PARAMS = {
    "memory_corridor_8": dict(history_len=12),
    "memory_corridor_16": dict(history_len=20),
    "memory_corridor_32": dict(history_len=40),
    "memory_corridor_64": dict(history_len=70),
    "delayed_match_10_50": dict(history_len=60),
    "delayed_match_50_100": dict(history_len=110),
    "hidden_state": dict(history_len=6),
}


def job(exp, hyp, env_id, agents, seeds, budget, ev=5000, ep=20,
        ref=None, env_params=None, tags=(), save_agents=False, control=False,
        agent_override=None):
    return dict(exp_id=exp, hypothesis_id=hyp, env_id=env_id,
                env_params=env_params or {}, agents=agents, seeds=seeds,
                budget=budget, ev=ev, ep=ep, ref=ref, tags=list(tags),
                save_agents=save_agents, control=control,
                agent_override=agent_override or {})


JOBS = {
    # ---- Cycle 2 research jobs -------------------------------------------
    "c2": [
        # F1/F2: recurrent memory at long horizons (GRU vs history window)
        job("f1-corridor64", "H10-gru-memory", "memory_corridor_64",
            ["dqn", "history_dqn", "gru_dqn"], [0, 1, 2], 60000, ev=10000,
            ep=50,
            agent_override={"gru_dqn": {"hidden": 64, "update_every": 1,
                                       "batch_size": 8, "warmup": 500,
                                       "lr": 3e-3}}),
        job("f2-delayed-l", "H10-gru-memory", "delayed_match_50_100",
            ["gru_dqn", "history_dqn"], [0, 1, 2], 60000, ev=10000, ep=50,
            agent_override={"gru_dqn": {"hidden": 64, "update_every": 1,
                                       "batch_size": 8, "warmup": 500,
                                       "lr": 3e-3}}),
        # F3: aggregation ablation (median vs mean vs min) — novel
        job("f3-agg-mean", "H11-aggregation", "gridworld_sparse",
            ["axq"], [0, 1, 2], 100000, ev=10000, ref=0.9,
            agent_override={"axq": {"aggregation": "mean"}}),
        job("f3-agg-min", "H11-aggregation", "gridworld_sparse",
            ["axq"], [0, 1, 2], 100000, ev=10000, ref=0.9,
            agent_override={"axq": {"aggregation": "min"}}),
        # F4: random priors (Osband et al. 2018)
        job("f4-prior-sparse", "H12-priors", "gridworld_sparse",
            ["axq"], SEEDS5, 100000, ev=10000, ref=0.9,
            agent_override={"axq": {"use_prior": True}}),
        # F5: exact count-bonus exploration for DQN (MBIE-style)
        job("f5-count-sparse", "H13-count", "gridworld_sparse",
            ["dqn"], SEEDS5, 100000, ev=10000, ref=0.9,
            agent_override={"dqn": {"count_bonus": 0.1}}),
    ],
    "l0l1": [
        job("e1-one-step", "H0-baseline", "one_step_bandit",
            ["random", "tabular", "dqn", "axq"], SEEDS5, 10000, ep=50),
        job("e1-multi-armed", "H0-baseline", "multi_armed_bandit",
            ["random", "tabular", "dqn", "axq"], SEEDS5, 10000, ep=50),
        job("e1-contextual", "H0-baseline", "contextual_bandit",
            ["random", "tabular", "dqn", "axq"], SEEDS5, 10000, ep=50),
        job("e2-cartpole", "H2-control", "cartpole",
            ["random", "dqn", "axq"], SEEDS5, 60000, ev=10000, ep=20,
            ref=475.0, save_agents=True, tags=["checkpoints"], control=True),
        job("e2-mountaincar", "H2-control", "mountaincar",
            ["random", "dqn", "axq"], [0, 1, 2], 60000, ev=10000, ep=20,
            control=True),
        job("e2-acrobot", "H2-control", "acrobot",
            ["random", "dqn", "axq"], [0, 1, 2], 60000, ev=10000, ep=20,
            control=True),
        job("e2-pendulum", "H2-control", "pendulum_discrete",
            ["random", "dqn", "axq"], [0, 1, 2], 60000, ev=10000, ep=20,
            control=True),
    ],
    "l2": [
        job("e3-sparse", "H1-exploration", "gridworld_sparse",
            ["random", "tabular", "dqn", "axq"], SEEDS8, 100000, ev=10000,
            ref=0.9),
        job("e3-maze", "H1-exploration", "maze_random",
            ["tabular", "dqn", "axq"], SEEDS5, 100000, ev=10000, ref=0.9),
        job("e3-keysdoors", "H1-exploration", "keys_doors",
            ["tabular", "dqn", "axq"], SEEDS5, 100000, ev=10000, ref=0.9),
        job("e3-deadend", "H1-exploration", "deadend_maze",
            ["tabular"], SEEDS5, 100000, ev=10000, ref=0.9),
        job("e3-deadend-nn", "H1-exploration", "deadend_maze",
            ["dqn", "axq"], [0, 1, 2], 100000, ev=10000),
        job("e3-dynamic", "H1-exploration", "dynamic_obstacles",
            ["tabular"], SEEDS5, 100000, ev=10000, ref=0.9),
        job("e3-dynamic-nn", "H1-exploration", "dynamic_obstacles",
            ["dqn", "axq"], [0, 1, 2], 100000, ev=10000),
    ],
    "l3l4l5": [
        job("e4-corridor8", "H3-memory", "memory_corridor_8",
            ["dqn", "history_dqn", "axq"], SEEDS5, 60000, ev=10000, ep=50),
        job("e4-corridor16", "H3-memory", "memory_corridor_16",
            ["dqn", "history_dqn", "axq"], SEEDS5, 60000, ev=10000, ep=50),
        job("e4-corridor32", "H3-memory", "memory_corridor_32",
            ["dqn", "history_dqn"], SEEDS5, 50000, ev=10000, ep=50),
        job("e4-delayed", "H3-memory", "delayed_match_10_50",
            ["dqn", "history_dqn"], SEEDS5, 60000, ev=10000, ep=50),
        job("e4-hidden", "H3-memory", "hidden_state",
            ["dqn", "history_dqn", "axq"], SEEDS5, 60000, ev=10000, ep=50),
        job("e5-chain50", "H4-credit", "chain_50",
            ["tabular", "dqn", "axq"], SEEDS5, 60000, ev=10000, ep=50),
        job("e5-decep50", "H5-deceptive", "deceptive_50",
            ["tabular", "dqn", "axq"], SEEDS5, 60000, ev=10000, ep=50),
        job("e5-credit-nn", "H5-deceptive", "credit_assignment",
            ["dqn", "axq"], [0, 1, 2], 60000, ev=10000, ep=50),
        job("e5-credit", "H5-deceptive", "credit_assignment",
            ["tabular"], SEEDS5, 60000, ev=10000, ep=50),
        job("e5-decoy", "H5-antitest", "gridworld_decoy",
            ["tabular"], SEEDS5, 60000, ev=10000, ep=50, ref=0.8),
        job("e5-decoy-nn", "H5-antitest", "gridworld_decoy",
            ["dqn", "axq"], [0, 1, 2], 60000, ev=10000, ep=50),
    ],
}


def agent_params_for(j, agent_name):
    params = dict(AGENTS[agent_name])
    if agent_name == "history_dqn":
        params.update(HISTORY_PARAMS.get(j["env_id"], {}))
    if agent_name in j.get("agent_override", {}):
        params.update(j["agent_override"][agent_name])
    if j.get("control") and agent_name in ("dqn", "axq"):
        params.update(CONTROL_PARAMS)
    return params


def run_seed(j, agent_name, seed):
    """Run ONE (job, agent, seed); write seed_<s>.json. Crash-safe."""
    out_dir = os.path.join(RESULTS, f"{j['exp_id']}-{agent_name}")
    os.makedirs(out_dir, exist_ok=True)
    seed_path = os.path.join(out_dir, f"seed_{seed}.json")
    if os.path.exists(seed_path):
        return None
    env = make(j["env_id"], **j["env_params"])
    eval_env = make(j["env_id"], **j["env_params"])
    agent = make_agent(agent_name, env.n_obs, env.obs_type, env.n_actions,
                       seed=seed, **agent_params_for(j, agent_name))
    res = train(agent, env, total_steps=j["budget"],
                eval_interval=j["ev"], eval_env=eval_env,
                eval_episodes=j["ep"], seed=seed)
    if j["save_agents"] and hasattr(agent, "save"):
        agent.save(os.path.join(out_dir, f"agent_{agent_name}_seed{seed}.npz"))
    fe = res["final_eval"]
    rec = {"seed": int(seed),
           "curve": [[int(s), float(v)] for s, v in res["curve"]],
           "final_eval": {k: v for k, v in fe.items() if k != "rewards"},
           "rewards": [float(r) for r in fe["rewards"]],
           "episodes": int(res["episodes"]),
           "total_steps": int(res["total_steps"]),
           "steps_per_sec": float(res["steps_per_sec"]),
           "wall_time_s": float(res["wall_time_s"])}
    with open(seed_path, "w") as f:
        json.dump(rec, f)
    print(f"[seed] {j['exp_id']}-{agent_name} seed={seed} "
          f"final={rec['final_eval']['mean']:.3f} "
          f"({rec['wall_time_s']:.0f}s)", flush=True)
    return rec


def finalize_job(j, agent_name, journal=None):
    """If all seeds present: aggregate summary.json + journal record.
    Idempotent: skips cleanly if summary already finalized."""
    if journal is None:
        journal = globals().get("journal") or get_journal("main")
    out_dir = os.path.join(RESULTS, f"{j['exp_id']}-{agent_name}")
    if os.path.exists(os.path.join(out_dir, "summary.json")):
        return True
    out_dir = os.path.join(RESULTS, f"{j['exp_id']}-{agent_name}")
    finals, aucs, walls = [], [], 0.0
    for seed in j["seeds"]:
        p = os.path.join(out_dir, f"seed_{seed}.json")
        if not os.path.exists(p):
            return False
        with open(p) as f:
            rec = json.load(f)
        finals.append(rec["final_eval"]["mean"])
        aucs.append(auc(rec["curve"], j["budget"]))
        walls += rec["wall_time_s"]
    summary = {
        "exp_id": f"{j['exp_id']}-{agent_name}",
        "hypothesis_id": j["hypothesis_id"], "env": j["env_id"],
        "agent": agent_name, "seeds": list(j["seeds"]),
        "budget_steps": int(j["budget"]), "eval_interval": int(j["ev"]),
        "eval_episodes": int(j["ep"]),
        "final_mean_per_seed": finals,
        "final_mean_summary": summarize(finals),
        "auc_per_seed": aucs,
        "auc_summary": summarize(aucs) if all(a is not None for a in aucs)
                      else None,
        "total_wall_time_s": walls,
        "config": {"agent_params": agent_params_for(j, agent_name),
                   "env_params": j["env_params"]},
        "code_version": code_fingerprint(),
    }
    if j["ref"] is not None:
        fails = [f < j["ref"] for f in finals]
        summary["reference_score"] = float(j["ref"])
        summary["failures_per_seed"] = [bool(x) for x in fails]
        summary["failure_rate"] = float(np.mean(fails))
    with open(os.path.join(out_dir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    journal.append({
        "exp_id": f"{j['exp_id']}-{agent_name}",
        "hypothesis_id": j["hypothesis_id"], "env": j["env_id"],
        "agent": agent_name,
        "config": {"agent_params": agent_params_for(j, agent_name),
                   "env_params": j["env_params"]},
        "seeds": list(j["seeds"]), "budget_steps": int(j["budget"]),
        "status": "completed", "results_dir": out_dir,
        "metrics": {"final_mean_per_seed": finals,
                    "final_mean_summary": summary["final_mean_summary"],
                    "failure_rate": summary.get("failure_rate")}})
    s = summary["final_mean_summary"]
    print(f"[DONE {j['exp_id']:14s}] {agent_name:12s} mean={s['mean']:.3f} "
          f"med={s['median']:.3f} std={s['std']:.3f} min={s['min']:.3f} "
          f"wall={walls:.0f}s", flush=True)
    return True


def expected_seconds(j, agent_name):
    if agent_name in ("random", "tabular"):
        return SECONDS_PER_100K[agent_name]
    return SECONDS_PER_100K[agent_name] * j["budget"] / 100000.0


def main(group):
    journal = get_journal(group)
    globals()["journal"] = journal
    todo = JOBS[group] if group != "all" else \
        JOBS["l0l1"] + JOBS["l2"] + JOBS["l3l4l5"] + JOBS["c2"]
    # finalize everything already complete
    for j in todo:
        for agent_name in j["agents"]:
            finalize_job(j, agent_name, journal)
    # build the pending queue: (job, agent, seed, est_seconds)
    queue = []
    for j in todo:
        for agent_name in j["agents"]:
            for seed in j["seeds"]:
                out_dir = os.path.join(RESULTS, f"{j['exp_id']}-{agent_name}")
                if not os.path.exists(os.path.join(out_dir, f"seed_{seed}.json")):
                    queue.append((j, agent_name, seed,
                                  expected_seconds(j, agent_name)))
    n_done = 0
    # Optional speed filter: argv[2] "fast" (est<=150s) or "slow" (est>150s)
    speed_filter = sys.argv[2] if len(sys.argv) > 2 else None
    if speed_filter == "fast":
        queue = [q for q in queue if q[3] <= 150.0]
    elif speed_filter == "slow":
        queue = [q for q in queue if q[3] > 150.0]
    # Slow seeds first (they only fit at chunk start); fast seeds fill the
    # remaining window. Sorted = deterministic + minimal killed-tail waste.
    queue.sort(key=lambda item: -item[3])
    while queue:
        elapsed = time.time() - T0
        # pick the first pending item that fits into the hard kill window
        # (contention safety factor 1.5 on the estimate; hard limit ~590s)
        pick = None
        for item in queue:
            if elapsed + item[3] * 1.25 < CHUNK_BUDGET:
                pick = item
                break
        if pick is None:
            print(f"[{group}] no pending seed fits in remaining "
                  f"{CHUNK_BUDGET - elapsed:.0f}s (queue={len(queue)}); exiting",
                  flush=True)
            break
        j, agent_name, seed, _est = pick
        queue.remove(pick)
        if run_seed(j, agent_name, seed) is not None:
            n_done += 1
        finalize_job(j, agent_name, journal)
    print(f"[{group}] chunk done: {n_done} new seeds, {len(queue)} still "
          f"pending", flush=True)


if __name__ == "__main__":
    grp = sys.argv[1] if len(sys.argv) > 1 else "all"
    main(grp)
