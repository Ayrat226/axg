"""H17a — Tabular Q-learning correctness verification (preregistered).

CLAIM UNDER TEST: the e5 deceptive failures are BEHAVIORAL (exploration
strategy), not a learning-rule bug. Proof strategy: drive the agent with
experimenter-chosen behavior policies (off-policy; Q-learning is off-policy
by construction) and check (i) exact Q* convergence on the fully observable
env (decoy), (ii) greedy-policy optimality on the POMDP-aliased deceptive
envs (exact Q* unreachable there by ANY tabular agent -- aliasing argument
documented in PREREG_CYCLE4).

Behavior policies:
* uniform      : P(a) = 1/A everywhere (the classic sufficient-exploration
                 condition; chain completion rare for delay 20/50).
* hold_biased  : in hold phase P(hold)=0.9 (completes chains often) --
                 demonstrates the update rule learns the large-reward value
                 WHEN the data contains it.

Registered tolerances: decoy ||Q-Q*||_inf <= 5% max|Q*| (alpha decay
fallback); deceptive greedy eval return >= 0.9 * V*(0).
Output: axq/results/h17a_tabular_verification.json + console verdict.
"""
import sys
import json
import time

sys.path.insert(0, "/home/z/my-project")
import numpy as np

from axq.agents import make_agent
from axq.core.runner import evaluate
from axq.envs import make
from axq.envs.antitests import value_iteration

GAMMA = 0.99
RESULTS = {}


def run_offpolicy(env_id, behavior, steps, seed, alpha0=0.1,
                  alpha_decay=False, eval_env=None, large_threshold=None):
    """Train TabularQ with an experimenter-driven behavior policy."""
    env = make(env_id)
    agent = make_agent("tabular", env.n_obs, env.obs_type, env.n_actions,
                       seed=seed, alpha=alpha0, gamma=GAMMA)
    rng = np.random.default_rng(seed)
    eval_env = eval_env if eval_env is not None else make(env_id)
    if large_threshold is None:
        large_threshold = float("inf")
    obs = env.reset(seed)
    done = True
    n_large_events = 0
    t0 = time.perf_counter()
    for t in range(steps):
        if done:
            obs = env.reset(seed + 1000 + t)
        if behavior == "uniform":
            a = int(rng.integers(env.n_actions))
        elif behavior == "hold_biased":
            # obs 1 = hold phase (aliased); bias toward action 1 there
            if obs == 1 and rng.random() < 0.9:
                a = 1
            else:
                a = int(rng.integers(env.n_actions))
        else:
            raise ValueError(behavior)
        nobs, r, term, trunc, info = env.step(a)
        if r >= large_threshold:          # large-reward event counter
            n_large_events += 1
        if alpha_decay:                    # registered fallback schedule
            n_sa = agent.visits[obs, a] + 1
            agent.alpha = alpha0 / (1.0 + n_sa ** 0.3)
        agent.observe(obs, a, r, nobs, term, trunc, info)
        agent.update()
        obs = nobs
        done = term or trunc
    ev = evaluate(agent, eval_env, episodes=50, base_seed=987654)
    return agent, ev, n_large_events, time.perf_counter() - t0


def verify_decoy():
    env = make("gridworld_decoy")
    P, R = env.mdp_model(GAMMA)
    V, Qstar, pol = value_iteration(P, R, GAMMA)
    out = {"V0": float(V[0]), "max_abs_Q": float(np.abs(Qstar).max())}
    for behavior, alpha_decay in (("uniform", False), ("uniform", True)):
        agent, ev, _, dt = run_offpolicy(
            "gridworld_decoy", behavior, 500_000, seed=42,
            alpha_decay=alpha_decay)
        err = float(np.abs(agent.Q - Qstar).max())
        out[f"{behavior}_adecay{int(alpha_decay)}"] = {
            "Q_err_inf": round(err, 5),
            "tolerance": round(0.05 * float(np.abs(Qstar).max()), 5),
            "pass": bool(err <= 0.05 * float(np.abs(Qstar).max())),
            "greedy_eval": round(ev["mean"], 4),
            "V0": round(float(V[0]), 4),
            "wall_s": round(dt, 1),
        }
        print(f"decoy/{behavior}/adecay={alpha_decay}: ||Q-Q*||inf={err:.4f} "
              f"(tol {0.05*np.abs(Qstar).max():.4f}) greedy={ev['mean']:.3f} "
              f"V*={V[0]:.3f} [{'PASS' if err <= 0.05*np.abs(Qstar).max() else 'FAIL'}]")
    return out


def verify_deceptive(env_id, V0_pass_bar, large_reward):
    env = make(env_id)
    P, R = env.mdp_model(GAMMA)
    V, Q, pol = value_iteration(P, R, GAMMA)
    out = {"V0_true": float(V[0]), "pass_bar": 0.9 * V0_pass_bar}
    for behavior in ("uniform", "hold_biased"):
        agent, ev, n_large, dt = run_offpolicy(env_id, behavior, 500_000,
                                               seed=42,
                                               large_threshold=0.5 * large_reward)
        # greedy policy value from ALIASED Q (analytic): policy = argmax rows
        pi0 = int(np.argmax(agent.Q[0]))
        pi1 = int(np.argmax(agent.Q[1]))
        out[behavior] = {
            "large_events_in_training": n_large,
            "greedy_eval": round(ev["mean"], 4),
            "greedy_pass": bool(ev["mean"] >= 0.9 * V0_pass_bar),
            "Q_at_decision": [round(float(x), 3) for x in agent.Q[0]],
            "policy": [pi0, pi1],
            "wall_s": round(dt, 1),
        }
        print(f"{env_id}/{behavior}: large_events={n_large} "
              f"greedy_eval={ev['mean']:.3f} (bar {0.9*V0_pass_bar:.3f}) "
              f"Q(0)={agent.Q[0].round(2)} Q(1)={agent.Q[1].round(2)} "
              f"[{'PASS' if ev['mean'] >= 0.9*V0_pass_bar else 'FAIL'}]")
    return out


if __name__ == "__main__":
    print("=== H17a: tabular Q-learning correctness (off-policy) ===")
    res = {"gamma": GAMMA, "prereg": "axq/docs/PREREG_CYCLE4.md#H17"}
    res["gridworld_decoy"] = verify_decoy()
    # deceptive_50: delay=50, 1 vs 10 (V*(0) from TRUE model)
    env = make("deceptive_50")
    V, _, _ = value_iteration(*env.mdp_model(GAMMA), GAMMA)
    res["deceptive_50"] = verify_deceptive("deceptive_50", float(V[0]), 10.0)
    # credit_assignment: 5 vs 50, delay 20
    env = make("credit_assignment")
    V, _, _ = value_iteration(*env.mdp_model(GAMMA), GAMMA)
    res["credit_assignment"] = verify_deceptive("credit_assignment",
                                                float(V[0]), 50.0)

    verdicts = []
    d = res["gridworld_decoy"]
    for k in ("uniform_adecay0", "uniform_adecay1"):
        if k in d:
            verdicts.append(d[k]["pass"])
    for e in ("deceptive_50", "credit_assignment"):
        verdicts.append(res[e]["hold_biased"]["greedy_pass"])
    res["VERDICT"] = {
        "rule_correct": bool(all(verdicts)),
        "interpretation": ("Q-learning update rule VERIFIED correct: with "
                           "sufficient exploration the same update rule "
                           "reaches Q* (decoy) / optimal greedy policy "
                           "(deceptive). e5 failures are behavioral "
                           "(eps-greedy lock-in), NOT a learning-rule bug.")
        if all(verdicts) else
        "AT LEAST ONE CHECK FAILED -- inspect results before interpreting e5.",
    }
    print("\nVERDICT:", res["VERDICT"]["rule_correct"])
    with open("/home/z/my-project/axq/results/h17a_tabular_verification.json",
              "w") as f:
        json.dump(res, f, indent=2)
    print("saved -> axq/results/h17a_tabular_verification.json")
