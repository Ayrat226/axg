"""Agent correctness tests: RL semantics (terminated vs truncated), n-step
return math, convergence to analytic Q*, ensemble behaviour, memory, IO,
determinism.

All envs are defined LOCALLY in this file (no dependency on env modules
written by other agents in parallel).
"""
import numpy as np
import pytest

from axq.agents import AGENTS, make_agent
from axq.agents.axq import AXQ
from axq.agents.common import (EpsilonSchedule, ReplayBuffer, encode_obs,
                               one_hot_batch)
from axq.agents.dqn import DQN
from axq.agents.frame_stack import HistoryDQN
from axq.agents.tabular import TabularQ
from axq.core.env import EnvBase
from axq.core.runner import run_episode, train

G = 0.99   # gamma used throughout the analytic computations
# TwoRoomMDP optimal Q (rows s0,s1; cols a0,a1):
#   Q*(s0,a0)=1, Q*(s0,a1)=0.99*2=1.98, Q*(s1,a0)=2, Q*(s1,a1)=0.99*1.98
QSTAR_2ROOM = np.array([[1.0, G * 2.0], [2.0, G * G * 2.0]])


# ---------------------------------------------------------------------------
# Local deterministic test envs
# ---------------------------------------------------------------------------
class TwoRoomMDP(EnvBase):
    """2-state delayed-reward MDP.

    s0: a0 -> +1 terminal; a1 -> r=0 -> s1.
    s1: a0 -> +2 terminal; a1 -> r=0 -> s0.
    Optimal from s0: a1 then a0 (+2 delayed) beats a0 now (+1).
    """

    obs_type = "discrete"
    n_obs = 2
    n_actions = 2
    max_episode_steps = 50

    def _reset(self):
        self._s = 0
        return 0

    def _step(self, action):
        if self._s == 0:
            if action == 0:
                return 0, 1.0, True, False, {}
            self._s = 1
            return 1, 0.0, False, False, {}
        if action == 0:
            return 1, 2.0, True, False, {}
        self._s = 0
        return 0, 0.0, False, False, {}


class TruncChain(EnvBase):
    """3-state chain with forced mid-chain truncation (2-step episodes).

    a1: advance (r=0; from s2: +1 terminal). a0: stay (r=0).
    Starts uniform in {0,1,2}. With max_episode_steps=2 a greedy episode
    from s0 produces (s1, a1, r=0, s2, terminated=False, truncated=True):
    matching Q(s1,a1)=0.99 / Q(s2,a0)=0.99 / Q(s0,a1)=0.9801 is ONLY
    possible if that truncated transition bootstraps from s2. Storing
    done=truncated instead collapses those values toward 0 (y=0 labels).
    All 3 states appear as current states, so all 6 Q entries are trained.
    """

    obs_type = "discrete"
    n_obs = 3
    n_actions = 2
    max_episode_steps = 2

    def _reset(self):
        self._s = int(self._rng.integers(3))
        return self._s

    def _step(self, action):
        if action == 0:
            return self._s, 0.0, False, False, {}
        if self._s == 2:
            return 2, 1.0, True, False, {}
        self._s += 1
        return self._s, 0.0, False, False, {}


class HiddenMarker(EnvBase):
    """POMDP: a mode marker seen once must be remembered to the junction.

    Episode (3 steps, env rng picks mode m in {0,1} at reset):
      obs 0 (start; actions ignored) -> obs 1+m (marker), r=0
      marker state (actions ignored) -> obs 3 (junction), r=0
      junction: a == m -> +1 terminal; a != m -> -1 terminal.
    Obs 3 aliases both modes: a memoryless agent caps at ~0.5 success;
    with history_len >= 2 the marker is inside the net input at the
    junction (window [.., marker, 3]).
    """

    obs_type = "discrete"
    n_obs = 4
    n_actions = 2
    max_episode_steps = 5

    def _reset(self):
        self._mode = int(self._rng.integers(2))
        self._phase = 0
        return 0

    def _step(self, action):
        if self._phase == 0:
            self._phase = 1
            return 1 + self._mode, 0.0, False, False, {}
        if self._phase == 1:
            self._phase = 2
            return 3, 0.0, False, False, {}
        r = 1.0 if action == self._mode else -1.0
        return 3, r, True, False, {"success": bool(r > 0)}


def _assert_entries(actual, expected):
    """Compare buffer entries() against expected (obs, a, R, next, done, n)."""
    assert len(actual) == len(expected), (len(actual), len(expected))
    for got, want in zip(actual, expected):
        assert got[0] == want[0]
        assert got[1] == want[1]
        assert got[2] == pytest.approx(want[2], abs=1e-12)
        assert got[3] == want[3]
        assert got[4] == want[4]
        assert got[5] == want[5]


def _q_rows(agent, states):
    return agent.net.forward(one_hot_batch(np.asarray(states), agent.n_obs))


# ---------------------------------------------------------------------------
# 1-2: ReplayBuffer n-step math and flush semantics
# ---------------------------------------------------------------------------
def test_replay_buffer_n_step_math():
    """Hand-computed n-step returns, 5-step terminal episode, n=3, gamma=0.5."""
    buf = ReplayBuffer(capacity=10, n_step=3, gamma=0.5)
    rewards = [1.0, 2.0, 3.0, 4.0, 5.0]
    for t in range(4):
        buf.add(t, 10 + t, rewards[t], t + 1, False, False)
        assert not buf._pending or True   # no invariant leak on success
    buf.add(4, 14, 5.0, 99, True, False)   # terminal transition
    assert len(buf) == 5
    assert buf.is_ready(5) and not buf.is_ready(6)
    # (obs, action, R_n, next_obs, done, chain_len) in insertion order:
    #   t0: 1 + .5*2 + .25*3 = 2.75   (bootstrap state s3, not terminal)
    #   t1: 2 + .5*3 + .25*4 = 4.5    (bootstrap state s4, not terminal)
    #   t2: 3 + .5*4 + .25*5 = 6.25   (chain ends at terminal -> done)
    #   t3: 4 + .5*5       = 6.5      (2-step partial, done)
    #   t4: 5                        (1-step, done)
    _assert_entries(buf.entries(), [
        (0, 10, 2.75, 3, False, 3),
        (1, 11, 4.50, 4, False, 3),
        (2, 12, 6.25, 99, True, 3),
        (3, 13, 6.50, 99, True, 2),
        (4, 14, 5.00, 99, True, 1),
    ])
    # sample() contract: dtypes/shapes and membership in the stored set.
    rng = np.random.default_rng(5)
    b = buf.sample(4, rng)
    assert set(b) == {"obs", "actions", "rewards", "next_obs", "done",
                      "n_lens"}
    assert b["obs"].shape == (4,) and b["obs"].dtype == np.int64
    assert b["next_obs"].shape == (4,) and b["next_obs"].dtype == np.int64
    assert b["actions"].dtype == np.int64
    assert b["rewards"].dtype == np.float64
    assert b["done"].dtype == np.float64
    assert b["n_lens"].dtype == np.int64
    stored = set((e[0], e[1], e[3], e[4], e[5]) for e in buf.entries())
    for i in range(4):
        assert (int(b["obs"][i]), int(b["actions"][i]), int(b["next_obs"][i]),
                bool(b["done"][i]), int(b["n_lens"][i])) in stored
    # encoder helpers
    assert np.array_equal(one_hot_batch([1, 0], 3),
                          np.array([[0., 1., 0.], [1., 0., 0.]]))
    assert one_hot_batch([1], 3).dtype == np.float64
    assert np.array_equal(encode_obs(1, "discrete", 4), [[0., 1., 0., 0.]])
    assert encode_obs(1, "discrete", 4).shape == (1, 4)
    assert np.array_equal(encode_obs(np.array([1.5, 2.5]), "vector", 2),
                          [[1.5, 2.5]])


def test_buffer_flush_on_truncation_and_termination():
    """Truncated tails are stored with done=False (they must bootstrap)."""
    # (a) 4-step episode truncated at the step limit, n_step=3, gamma=0.5
    buf = ReplayBuffer(capacity=10, n_step=3, gamma=0.5)
    rewards = [1.0, 2.0, 3.0, 4.0]
    for t in range(3):
        buf.add(t, 7 + t, rewards[t], t + 1, False, False)
    buf.add(3, 11, 4.0, 40, False, True)    # truncated final step
    assert len(buf) == 2                     # t0, t1 emitted at full length
    buf.end_episode()                        # agent.end_episode() forwards here
    _assert_entries(buf.entries(), [
        (0, 7, 2.75, 3, False, 3),
        (1, 8, 4.50, 40, False, 3),
        (2, 9, 5.00, 40, False, 2),   # partial 2-step chain, done=False
        (3, 11, 4.00, 40, False, 1),  # partial 1-step chain, done=False
    ])
    # (b) short episode terminated before n transitions accumulated
    buf2 = ReplayBuffer(capacity=10, n_step=3, gamma=0.5)
    buf2.add(5, 20, 3.0, 6, False, False)
    buf2.add(6, 21, 4.0, 7, True, False)
    _assert_entries(buf2.entries(), [
        (5, 20, 5.00, 7, True, 2),   # 3 + .5*4, chain ends at terminal
        (6, 21, 4.00, 7, True, 1),
    ])
    # end_episode after termination is a no-op (pending already flushed)
    buf2.end_episode()
    assert len(buf2) == 2
    # new episode data must not merge into old chains
    buf2.add(8, 30, 1.0, 9, False, False)
    assert len(buf2) == 2 and len(buf2._pending) == 1


# ---------------------------------------------------------------------------
# 3-5: value convergence on the TwoRoomMDP
# ---------------------------------------------------------------------------
def test_tabular_converges_to_exact_q():
    agent = TabularQ(2, "discrete", 2, alpha=0.2, gamma=G,
                     eps_start=1.0, eps_end=0.05, eps_decay=1000, seed=0)
    train(agent, TwoRoomMDP(), total_steps=3000, seed=0)
    err = float(np.max(np.abs(agent.Q - QSTAR_2ROOM)))
    assert err < 0.1, f"max |Q - Q*| = {err:.4f}\nQ=\n{agent.Q}"


def test_tabular_requires_discrete():
    with pytest.raises(ValueError):
        TabularQ(3, "vector", 2)


def test_dqn_converges_to_exact_q():
    agent = DQN(2, "discrete", 2, hidden=(32,), lr=3e-3, gamma=G,
                buffer_size=50000, batch_size=32, target_sync=200,
                double=True, n_step=1, eps_start=1.0, eps_end=0.05,
                eps_decay=2000, update_every=1, warmup=500, grad_clip=10.0,
                seed=0)
    train(agent, TwoRoomMDP(), total_steps=6000, seed=0)
    q = _q_rows(agent, [0, 1])
    err = float(np.max(np.abs(q - QSTAR_2ROOM)))
    assert err < 0.15, f"max |Q - Q*| = {err:.4f}\nQ=\n{q}"


# ---------------------------------------------------------------------------
# 6: truncation semantics (only correct handling matches analytic Q)
# ---------------------------------------------------------------------------
def test_dqn_truncation_bootstraps():
    agent = DQN(3, "discrete", 2, hidden=(32,), lr=3e-3, gamma=G,
                buffer_size=50000, batch_size=32, target_sync=200,
                double=True, n_step=1, eps_start=1.0, eps_end=0.05,
                eps_decay=1500, update_every=1, warmup=400, grad_clip=10.0,
                seed=0)
    train(agent, TruncChain(), total_steps=5000, seed=0)
    # rows s0,s1,s2; cols a0,a1 (see TruncChain docstring)
    qstar = np.array([[G ** 3, G ** 2],
                      [G ** 2, G],
                      [G, 1.0]])
    q = _q_rows(agent, [0, 1, 2])
    err = float(np.max(np.abs(q - qstar)))
    assert err < 0.15, f"max |Q - Q*| = {err:.4f}\nQ=\n{q}"


# ---------------------------------------------------------------------------
# 7-8: AXQ ensemble behaviour
# ---------------------------------------------------------------------------
def _axq_disagreement(agent):
    return float(np.mean([np.mean(agent.q_diagnostics(s)["q_std"])
                          for s in (0, 1)]))


def test_axq_heads_disagree_then_agree():
    agent = AXQ(2, "discrete", 2, n_heads=6, head_hidden=(24,), lr=3e-3,
                gamma=G, buffer_size=50000, batch_size=32, target_sync=200,
                double=True, n_step=1, eps_start=1.0, eps_end=0.05,
                eps_decay=2000, beta_explore=1.0, minibag_frac=0.8,
                update_every=1, warmup=500, grad_clip=10.0, seed=0)
    d_init = _axq_disagreement(agent)
    assert d_init > 1e-3, f"heads unexpectedly agree at init: {d_init}"
    train(agent, TwoRoomMDP(), total_steps=6000, seed=0)
    d_final = _axq_disagreement(agent)
    assert d_final < d_init, \
        f"head disagreement did not shrink: {d_init} -> {d_final}"


def test_axq_solves_delayed():
    agent = AXQ(2, "discrete", 2, n_heads=6, head_hidden=(24,), lr=3e-3,
                gamma=G, buffer_size=50000, batch_size=32, target_sync=200,
                double=True, n_step=1, eps_start=1.0, eps_end=0.05,
                eps_decay=2000, beta_explore=1.0, minibag_frac=0.8,
                update_every=1, warmup=500, grad_clip=10.0, seed=0)
    train(agent, TwoRoomMDP(), total_steps=6000, seed=0)
    delayed = sum(1 for _ in range(100) if agent.act(0, greedy=True) == 1)
    finish = sum(1 for _ in range(100) if agent.act(1, greedy=True) == 0)
    assert delayed >= 95, f"greedy delayed choice only {delayed}/100"
    assert finish >= 95, f"greedy finish choice only {finish}/100"


# ---------------------------------------------------------------------------
# 9: HistoryDQN input encoding and memory
# ---------------------------------------------------------------------------
def test_history_dqn_input_and_memory():
    agent = HistoryDQN(4, "discrete", 2, history_len=3, hidden=(32,),
                       lr=3e-3, gamma=G, buffer_size=50000, batch_size=32,
                       target_sync=200, double=True, n_step=1, eps_start=1.0,
                       eps_end=0.05, eps_decay=1500, update_every=1,
                       warmup=400, grad_clip=10.0, seed=0)
    # unit: input dim, history fill and window contents (oldest first)
    assert agent.net.sizes[0] == 3 * 4
    agent.reset_state()
    x = agent._encode_single(2)          # first act after reset: [2,2,2]
    assert x.shape == (1, 12)
    assert np.array_equal(x, one_hot_batch([2, 2, 2], 4).reshape(1, -1))
    x = agent._encode_single(3)          # window slides: [2,2,3]
    assert np.array_equal(x, one_hot_batch([2, 2, 3], 4).reshape(1, -1))
    x = agent._encode_single(1)          # [2,3,1]
    assert np.array_equal(x, one_hot_batch([2, 3, 1], 4).reshape(1, -1))
    # learning: the marker must be remembered to the junction
    train(agent, HiddenMarker(), total_steps=8000, seed=0)
    env = HiddenMarker()
    wins = 0
    for i in range(200):
        total, _, info = run_episode(env, agent, greedy=True, learn=False,
                                     seed=500000 + i)
        wins += 1 if total > 0 else 0
    assert wins >= 180, f"greedy success only {wins}/200"


# ---------------------------------------------------------------------------
# 10: save / load roundtrip
# ---------------------------------------------------------------------------
def test_save_load_roundtrip(tmp_path):
    kw = dict(hidden=(32,), lr=3e-3, gamma=G, buffer_size=50000,
              batch_size=32, target_sync=100, double=True, n_step=1,
              eps_start=1.0, eps_end=0.05, eps_decay=800, update_every=1,
              warmup=200, grad_clip=10.0, seed=3)
    agent = DQN(2, "discrete", 2, **kw)
    train(agent, TwoRoomMDP(), total_steps=500, seed=0)
    path = str(tmp_path / "dqn_ckpt")      # extension-less on purpose
    agent.save(path)
    # save must NOT store the buffer: only net_*/target_*/config keys
    with np.load(path + ".npz", allow_pickle=False) as z:
        assert all(k.startswith(("net_", "target_")) or k == "config"
                   for k in z.files)
    fresh = DQN(2, "discrete", 2, **kw)
    fresh.load(path)                       # falls back to path + ".npz"
    rng = np.random.default_rng(11)
    for _ in range(50):
        o = int(rng.integers(2))
        assert agent.act(o, greedy=True) == fresh.act(o, greedy=True)
    x = one_hot_batch([0, 1], 2)
    assert np.array_equal(agent.net.forward(x), fresh.net.forward(x))
    assert np.array_equal(agent.target_net.forward(x),
                          fresh.target_net.forward(x))
    for w1, w2 in zip(agent.net.get_weights(), fresh.net.get_weights()):
        assert np.array_equal(w1, w2)


# ---------------------------------------------------------------------------
# 11: registry contract
# ---------------------------------------------------------------------------
def test_make_agent_contract():
    assert set(AGENTS) == {"random", "tabular", "dqn", "axq", "history_dqn",
                           "gru_dqn", "dqn_ewc", "dqn_heads",
                           "dyna", "dyna_optim", "efe", "sf", "mbtl", "a2c"}
    for name in ("tabular", "dqn", "axq", "history_dqn", "gru_dqn",
                 "dyna", "efe", "sf", "mbtl", "a2c"):
        a = make_agent(name, n_obs=4, obs_type="discrete", n_actions=3, seed=0)
        assert a.n_actions == 3 and a.name == name
    r = make_agent("random", n_obs=2, obs_type="vector", n_actions=5, seed=1)
    assert r.n_actions == 5 and r.name == "random"
    d = make_agent("dqn", n_obs=4, obs_type="discrete", n_actions=3, seed=0,
                   hidden=(8,), warmup=10)
    assert d.net.sizes[0] == 4 and d.net.sizes[-1] == 3
    v = make_agent("dqn", n_obs=3, obs_type="vector", n_actions=2, seed=0,
                   hidden=(8,))
    assert v.net.sizes[0] == 3
    h = make_agent("history_dqn", n_obs=4, obs_type="discrete", n_actions=3,
                   seed=0, history_len=3, hidden=(8,))
    assert h.net.sizes[0] == 12
    e = make_agent("dqn_ewc", n_obs=4, obs_type="discrete", n_actions=3,
                   seed=0, hidden=(8,), warmup=10, ewc_lambda=10.0)
    assert e.name == "dqn_ewc" and hasattr(e, "consolidate")
    mh = make_agent("dqn_heads", n_obs=4, obs_type="discrete", n_actions=3,
                    seed=0, hidden=(8,), warmup=10)
    assert mh.name == "dqn_heads" and len(mh.heads) == 1
    assert mh.net.sizes == [4, 8]      # trunk only; heads are separate MLPs
    with pytest.raises(KeyError):
        make_agent("nope", n_obs=4, obs_type="discrete", n_actions=3)
    # EpsilonSchedule spot checks
    es = EpsilonSchedule(1.0, 0.05, 100)
    assert es.value(0) == 1.0
    assert es.value(50) == pytest.approx(0.525)
    assert es.value(100) == pytest.approx(0.05)
    assert es.value(10_000) == pytest.approx(0.05)


# ---------------------------------------------------------------------------
# 12: determinism
# ---------------------------------------------------------------------------
class _TrackedDQN(DQN):
    """DQN that records the loss of every gradient update."""

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.losses = []

    def update(self):
        stats = super().update()
        if "loss" in stats:
            self.losses.append(stats["loss"])
        return stats


def test_determinism():
    agents, trajectories = [], []
    for _ in range(2):
        agent = _TrackedDQN(2, "discrete", 2, hidden=(32,), lr=3e-3, gamma=G,
                            buffer_size=50000, batch_size=32, target_sync=100,
                            double=True, n_step=1, eps_start=1.0, eps_end=0.05,
                            eps_decay=1000, update_every=1, warmup=300,
                            grad_clip=10.0, seed=7)
        train(agent, TwoRoomMDP(), total_steps=1500, seed=0)
        agents.append(agent)
        trajectories.append(agent.losses)
    assert len(trajectories[0]) >= 100     # warmup passed, real updates ran
    assert trajectories[0] == trajectories[1], "loss trajectories diverged"
    x = one_hot_batch([0, 1], 2)
    assert np.array_equal(agents[0].net.forward(x), agents[1].net.forward(x))
    assert np.array_equal(agents[0].target_net.forward(x),
                          agents[1].target_net.forward(x))
    for w1, w2 in zip(agents[0].net.get_weights(), agents[1].net.get_weights()):
        assert np.array_equal(w1, w2)
