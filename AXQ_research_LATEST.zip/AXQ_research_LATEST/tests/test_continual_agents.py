"""Cycle-3 continual agents: EWC penalty math (exact gradient identity),
Fisher estimation, deterministic drift-limiting, MultiHead routing/head
purity/backward-graph order (finite-difference), save/load roundtrip,
and a miniature end-to-end g1 run (crash-safe JSONL).

All synthetic data is generated locally; the smoke test uses the real
continual_gridworlds suite with tiny budgets.
"""
import importlib.util
import json
import os

import numpy as np

from axq.agents.common import one_hot_batch
from axq.agents.continual import EWCDQN, MultiHeadDQN


def _feed(agent, obs, action, reward, next_obs, term=False):
    agent.observe(obs, action, reward, next_obs, term, False)


# ===========================================================================
# EWCDQN
# ===========================================================================
def test_ewc_consolidate_fisher_positive():
    ag = EWCDQN(n_obs=8, obs_type="discrete", n_actions=3, hidden=(16,),
                batch_size=8, warmup=8, fisher_samples=40, seed=0)
    rng = np.random.default_rng(1)
    for _ in range(60):
        s = int(rng.integers(0, 8))
        _feed(ag, s, int(rng.integers(0, 3)), 1.0, int(rng.integers(0, 8)))
    ag.consolidate()
    assert len(ag._fishers) == 1 and len(ag._stars) == 1
    flat = np.concatenate([f.ravel() for f in ag._fishers[0]])
    assert np.all(flat >= 0.0)
    assert flat.max() > 0.0


def test_ewc_penalty_gradient_exact():
    """Penalty contribution must be EXACTLY lambda * F * (theta - theta*)."""
    lam = 7.5
    ag = EWCDQN(n_obs=8, obs_type="discrete", n_actions=3, hidden=(16,),
                batch_size=8, warmup=8, fisher_samples=40, ewc_lambda=lam,
                seed=0)
    rng = np.random.default_rng(2)
    for _ in range(60):
        s = int(rng.integers(0, 8))
        _feed(ag, s, int(rng.integers(0, 3)), 1.0, int(rng.integers(0, 8)))
    ag.consolidate()
    x = one_hot_batch(list(range(8)), 8)
    q = ag.net.forward(x)
    g = np.zeros_like(q)
    g[:, 0] = 1.0
    ag.net.backward(g)
    before = [p.copy() for p in ag.net.grads()]
    ag._apply_ewc_penalty()
    after = ag.net.grads()
    for b, a_, F, st, p in zip(before, after, ag._fishers[0], ag._stars[0],
                               ag.net.params()):
        np.testing.assert_allclose(a_, b + lam * F * (p - st),
                                   rtol=1e-12, atol=1e-14)


def test_ewc_penalty_limits_drift_deterministic():
    """Identical data/RNG streams; large lambda keeps the weights closer to
    theta* after the same number of updates (deterministic comparison)."""

    def run(lam):
        ag = EWCDQN(n_obs=8, obs_type="discrete", n_actions=3, hidden=(16,),
                    batch_size=8, warmup=8, fisher_samples=40,
                    ewc_lambda=lam, seed=3)
        rng = np.random.default_rng(4)
        for _ in range(80):
            s = int(rng.integers(0, 8))
            _feed(ag, s, int(rng.integers(0, 3)), 1.0,
                  int(rng.integers(0, 8)))
        ag.consolidate()
        star = ag.net.get_weights()
        for _ in range(120):
            s = int(rng.integers(0, 8))
            _feed(ag, s, int(rng.integers(0, 3)), 1.0,
                  int(rng.integers(0, 8)))
            ag.update()
        return sum(float(np.sum((p - st) ** 2)) for p, st in
                   zip(ag.net.params(), star))

    d0 = run(0.0)
    d_big = run(1000.0)
    assert d_big < d0, f"EWC failed to limit drift: {d_big} !< {d0}"


def test_ewc_update_smoke():
    ag = EWCDQN(n_obs=8, obs_type="discrete", n_actions=3, hidden=(16,),
                batch_size=8, warmup=8, fisher_samples=20, seed=0)
    rng = np.random.default_rng(6)
    for _ in range(60):
        s = int(rng.integers(0, 8))
        _feed(ag, s, int(rng.integers(0, 3)), 1.0, int(rng.integers(0, 8)))
    out = ag.update()
    assert out != {} and np.isfinite(out["loss"])


# ===========================================================================
# MultiHeadDQN
# ===========================================================================
def test_heads_routing_and_purity():
    ag = MultiHeadDQN(n_obs=8, obs_type="discrete", n_actions=3,
                      hidden=(16,), batch_size=8, warmup=8, seed=0)
    ag.set_task(1)
    rng = np.random.default_rng(5)
    for _ in range(200):
        s = int(rng.integers(0, 8))
        _feed(ag, s, int(rng.integers(0, 3)), 1.0, int(rng.integers(0, 8)))
    head0_before = ag.heads[0].get_weights()
    trunk_before = ag.net.get_weights()
    for _ in range(50):
        ag.update()
    # task-0 buffer is empty -> head 0 NEVER receives updates (purity),
    # while the trunk IS trained (on task-1 batches).
    assert all(np.array_equal(b, a_) for b, a_ in
               zip(head0_before, ag.heads[0].get_weights()))
    assert any(not np.array_equal(b, a_) for b, a_ in
               zip(trunk_before, ag.net.get_weights()))
    # observe routing: data under task 0 lands in buffer 0
    ag.set_task(0)
    n0 = len(ag.task_buffers[0])
    _feed(ag, 1, 1, 0.0, 2)
    assert len(ag.task_buffers[0]) == n0 + 1


def test_heads_backward_graph_order():
    """Finite-difference check of the composite trunk->head gradient
    (catches the 'backward differentiates the LAST forward' bug class)."""
    ag = MultiHeadDQN(n_obs=8, obs_type="discrete", n_actions=3,
                      hidden=(8,), batch_size=4, warmup=4, seed=0)
    S = np.array([0, 3, 5, 7])
    A = np.array([0, 1, 2, 0])
    x = one_hot_batch(S, 8)

    def loss():
        h = np.tanh(ag.net.forward(x))
        q = ag.heads[0].forward(h)
        return float(np.sum(q[np.arange(4), A] ** 2))

    z = ag.net.forward(x)
    h = np.tanh(z)
    q = ag.heads[0].forward(h)
    gq = np.zeros_like(q)
    gq[np.arange(4), A] = 2.0 * q[np.arange(4), A]
    g_h = ag.heads[0].backward(gq)
    ag.net.backward(g_h * (1.0 - h * h))
    gw_head = ag.heads[0].layers[0].dW.copy()
    gw_trunk = ag.net.layers[0].dW.copy()

    eps = 1e-6

    def fd(arr, i, j):
        old = arr[i, j]
        arr[i, j] = old + eps
        lp = loss()
        arr[i, j] = old - eps
        lm = loss()
        arr[i, j] = old
        return (lp - lm) / (2 * eps)

    np.testing.assert_allclose(gw_head[0, 0], fd(ag.heads[0].layers[0].W,
                                                 0, 0), rtol=1e-5,
                               atol=1e-8)
    np.testing.assert_allclose(gw_trunk[1, 2], fd(ag.net.layers[0].W, 1, 2),
                               rtol=1e-5, atol=1e-8)


def test_heads_act_and_update_smoke():
    ag = MultiHeadDQN(n_obs=8, obs_type="discrete", n_actions=3,
                      hidden=(16,), batch_size=8, warmup=8, seed=0)
    rng = np.random.default_rng(7)
    for _ in range(60):
        s = int(rng.integers(0, 8))
        a = ag.act(s)
        assert 0 <= a < 3
        _feed(ag, s, a, 1.0, int(rng.integers(0, 8)))
    out = ag.update()
    assert out != {} and np.isfinite(out["loss"])
    assert "task" in out and out["task"] == 0


def test_heads_save_load_roundtrip(tmp_path):
    ag = MultiHeadDQN(n_obs=8, obs_type="discrete", n_actions=3,
                      hidden=(16,), batch_size=8, warmup=8, seed=0)
    ag.set_task(2)                       # 3 heads exist
    p = str(tmp_path / "mh.npz")
    ag.save(p)
    ag2 = MultiHeadDQN(n_obs=8, obs_type="discrete", n_actions=3,
                       hidden=(16,), batch_size=8, warmup=8, seed=99)
    ag2.load(p)
    assert len(ag2.heads) == 3
    for t in range(3):
        ag.set_task(t)
        ag2.set_task(t)
        for obs in range(8):
            assert ag.act(obs, greedy=True) == ag2.act(obs, greedy=True)


# ===========================================================================
# end-to-end miniature g1 run (crash-safe JSONL + metrics)
# ===========================================================================
def _load_rc2():
    spec = importlib.util.spec_from_file_location(
        "run_continual2",
        "/home/z/my-project/scripts/run_continual2.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_run_one_smoke(tmp_path):
    rc2 = _load_rc2()
    for arm in ("dqn-heads-persist", "dqn-ewc-fresh"):
        m = rc2.run_one(arm, 0, phase_steps=150, ewc_lambda=1.0, n_tasks=2,
                        eval_episodes=3, results_dir=str(tmp_path))
        assert len(m["matrix"]) == 2 and len(m["matrix"][0]) == 2
        for key in ("acquisition", "retention", "final_avg", "avg_forgetting",
                    "bwt", "fwt"):
            assert np.isfinite(m[key])
        p = tmp_path / f"{arm}_seed0.jsonl"
        assert p.exists()
        rows = [json.loads(ln) for ln in p.read_text().splitlines() if ln]
        assert len(rows) == 2
        assert rows[0]["phase"] == 0 and rows[1]["phase"] == 1
