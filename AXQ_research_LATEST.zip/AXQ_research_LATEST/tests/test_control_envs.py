"""Tests for the L1 control environments and L7 robustness wrappers."""
import numpy as np
import pytest

from axq.core.agent import AgentBase, RandomAgent
from axq.core.env import EnvBase
from axq.core.runner import run_episode
from axq.envs import make
from axq.envs.control import (CartPole, CartPoleVStart, MountainCar, Acrobot,
                              PendulumDiscrete)
from axq.envs.wrappers import (ObsNoiseWrapper, ActionDelayWrapper,
                               StickyActionsWrapper, ObsDropoutWrapper,
                               ActionPermutationWrapper)
from axq.testing import check_env


# ---------------------------------------------------------------------------
# env contract
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("env_id",
                         ["cartpole", "mountaincar", "acrobot",
                          "pendulum_discrete"])
def test_control_contract(env_id):
    check_env(make(env_id))


@pytest.mark.parametrize("mode", ["train", "test"])
def test_cartpole_vstart_contract(mode):
    check_env(make("cartpole_vstart", reset_dist=mode))


# ---------------------------------------------------------------------------
# CartPole physics invariants
# ---------------------------------------------------------------------------
def test_cartpole_constant_force_moves_cart_monotonically():
    """Constant right force from the exact zero state: x increases strictly.

    This steps past episode termination on purpose: it is a pure physics
    invariant check (the pole tips over but the cart keeps accelerating
    right), not an episode-semantics check.
    """
    env = CartPole()
    env.reset(0)
    env._state = np.zeros(4)
    xs = []
    for _ in range(20):
        obs, _, _, _, _ = env.step(1)
        xs.append(obs[0])
    assert all(b > a for a, b in zip(xs, xs[1:])), xs
    assert xs[-1] > 0.0


def test_cartpole_pole_tips_against_push():
    """Small angle + right force: pole accelerates negative (tips left)."""
    env = CartPole()
    env.reset(0)
    env._state = np.zeros(4)
    obs1, *_ = env.step(1)
    assert obs1[3] < 0.0                     # theta_dot < 0 after right push
    obs2, *_ = env.step(1)
    obs3, *_ = env.step(1)
    assert obs3[2] < 0.0                     # theta tips negative


def test_cartpole_random_policy_falls_quickly():
    env = CartPole()
    agent = RandomAgent(env.n_actions, seed=0)
    lens = [run_episode(env, agent, learn=False, seed=100 + i)[1]
            for i in range(20)]
    assert float(np.mean(lens)) < 120


def test_cartpole_bangbang_survives():
    """Bang-bang stabilisation keeps the pole up from near-zero starts.

    Deviation note: pure sign(theta) feedback chatters and trips the angle
    limit after ~43 steps on average (undamped limit cycle), so the scripted
    bang-bang includes small cart-position and pole-rate terms:
    push right iff theta + 0.3*x + 0.1*theta_dot > 0.
    """
    class BangBang(AgentBase):
        def act(self, obs, greedy=False):
            x, _, theta, theta_dot = obs
            return 1 if (theta + 0.3 * x + 0.1 * theta_dot) > 0 else 0

    env = CartPole()
    agent = BangBang()
    lens = [run_episode(env, agent, learn=False, seed=100 + i)[1]
            for i in range(20)]
    assert float(np.mean(lens)) > 80.0, lens


def test_cartpole_vstart_distribution_shift():
    """The test-mode reset distribution really differs from train mode.

    Spec-ambiguity resolution: "abs mean of x" is implemented as
    mean(|x|); abs(mean(x)) would be ~0 for the symmetric U(-1.5, 1.5).
    """
    train_env = CartPoleVStart(reset_dist="train")
    test_env = CartPoleVStart(reset_dist="test")
    x_train = [train_env.reset(i)[0] for i in range(100)]
    x_test = [test_env.reset(i)[0] for i in range(100)]
    assert float(np.mean(np.abs(x_test))) > 0.5
    assert float(np.mean(np.abs(x_train))) < 0.1


# ---------------------------------------------------------------------------
# MountainCar
# ---------------------------------------------------------------------------
class PumpingPolicy(AgentBase):
    """Energy pumping: push along the current velocity (classic controller)."""

    def act(self, obs, greedy=False):
        return 2 if obs[1] > 0 else 0


class AlwaysRight(AgentBase):
    def act(self, obs, greedy=False):
        return 2


def test_mountaincar_random_never_reaches():
    env = MountainCar()
    agent = RandomAgent(env.n_actions, seed=0)
    wins = 0
    for i in range(50):
        _, _, info = run_episode(env, agent, learn=False, seed=400 + i)
        wins += int(info.get("goal_reached", False))
    assert wins == 0


def test_mountaincar_always_right_fails():
    """Constant right force cannot climb the potential barrier."""
    env = MountainCar()
    wins = 0
    for i in range(20):
        _, _, info = run_episode(env, AlwaysRight(), learn=False, seed=300 + i)
        wins += int(info.get("goal_reached", False))
    assert wins == 0


def test_mountaincar_pumping_succeeds():
    env = MountainCar()
    wins = 0
    n = 20
    for i in range(n):
        _, steps, info = run_episode(env, PumpingPolicy(), learn=False,
                                     seed=200 + i)
        wins += int(info.get("goal_reached", False))
    assert wins / n >= 0.30


# ---------------------------------------------------------------------------
# Acrobot
# ---------------------------------------------------------------------------
def test_acrobot_random_policy_long_episodes():
    env = Acrobot()
    agent = RandomAgent(env.n_actions, seed=0)
    rets = [run_episode(env, agent, learn=False, seed=900 + i)[0]
            for i in range(10)]
    assert float(np.mean(rets)) <= -80.0


def test_acrobot_scripted_policy_swingup():
    """A scripted torque sequence reaches the terminal height.

    Deviation note: the spec's candidate "constant +1 torque" does NOT swing
    up the standard Acrobot ODE (verified with both semi-implicit Euler and
    RK4 integration: 0/12 seeds within 500 steps) - constant elbow torque
    settles into a limit cycle below the goal energy. The scripted policy
    used instead is the classic energy-pumping controller: torque in the
    direction of the elbow velocity, which reaches the goal 10/10 in ~95
    steps.
    """
    class EnergyPump(AgentBase):
        def act(self, obs, greedy=False):
            return 2 if obs[3] > 0 else 0

    env = Acrobot()
    agent = EnergyPump()
    for i in range(5):
        total, steps, info = run_episode(env, agent, learn=False, seed=i)
        assert info.get("goal_reached") is True
        assert steps < 500


# ---------------------------------------------------------------------------
# PendulumDiscrete
# ---------------------------------------------------------------------------
def test_pendulum_random_policy_and_reward_bound():
    env = PendulumDiscrete()
    agent = RandomAgent(env.n_actions, seed=0)
    rets = [run_episode(env, agent, learn=False, seed=600 + i)[0]
            for i in range(10)]
    assert float(np.mean(rets)) < -2.0
    # every step reward is bounded above by 0 (pure cost)
    env.reset(0)
    for _ in range(50):
        _, r, term, trunc, _ = env.step(4)      # zero torque
        assert r <= 1e-9
        if term or trunc:
            break


# ---------------------------------------------------------------------------
# Test doubles for wrapper behaviour checks
# ---------------------------------------------------------------------------
class OneBitEnv(EnvBase):
    """Discrete test double: action 1 (once executed) sets obs to 1 forever."""

    obs_type = "discrete"
    n_obs = 2
    n_actions = 2
    max_episode_steps = 12

    def _reset(self):
        self._bit = 0
        return 0

    def _step(self, action):
        if action == 1:
            self._bit = 1
        return self._bit, float(self._bit), False, False, {}


class ActionRecorderEnv(EnvBase):
    """Discrete test double: records executed actions; obs constant 0."""

    obs_type = "discrete"
    n_obs = 1
    n_actions = 3
    max_episode_steps = 8

    def _reset(self):
        self.actions = []
        return 0

    def _step(self, action):
        self.actions.append(int(action))
        return 0, float(action), False, False, {}


# ---------------------------------------------------------------------------
# Wrapper contract: check_env around a vector env and a discrete env
# ---------------------------------------------------------------------------
WRAPPERS = [
    (ObsNoiseWrapper, {"sigma": 0.1}),
    (ActionDelayWrapper, {"delay": 2}),
    (StickyActionsWrapper, {"p": 0.3}),
    (ObsDropoutWrapper, {"p": 0.2}),
    (ActionPermutationWrapper, {"perm_seed": 5}),
]


@pytest.mark.parametrize("wrapper_cls,kwargs", WRAPPERS)
def test_wrapper_contract_vector(wrapper_cls, kwargs):
    check_env(wrapper_cls(CartPole(), **kwargs))


@pytest.mark.parametrize("wrapper_cls,kwargs", WRAPPERS)
def test_wrapper_contract_discrete(wrapper_cls, kwargs):
    check_env(wrapper_cls(make("contextual_bandit"), **kwargs))


def test_action_delay_executes_stale_actions():
    """With delay=2 the chosen action takes effect two steps later."""
    env = ActionDelayWrapper(OneBitEnv(), delay=2)
    obs = env.reset(0)
    assert obs == 0
    obs, *_ = env.step(1)                     # queue emits stale 0
    assert obs == 0
    obs, *_ = env.step(1)                     # still stale 0
    assert obs == 0
    obs, *_ = env.step(0)                     # first chosen 1 finally lands
    assert obs == 1

    recorder = ActionRecorderEnv()
    env2 = ActionDelayWrapper(recorder, delay=2)
    env2.reset(0)
    for a in [0, 1, 2, 0, 1]:
        env2.step(a)
    assert recorder.actions == [0, 0, 0, 1, 2]


def test_action_permutation_wrapper():
    inner = ActionRecorderEnv()
    env = ActionPermutationWrapper(inner, perm_seed=3)
    perm = env.permutation
    assert sorted(perm.tolist()) == [0, 1, 2]          # bijection
    env.reset(0)
    for a in [0, 1, 2, 0]:
        env.step(a)
    assert inner.actions == [int(perm[a]) for a in [0, 1, 2, 0]]
    # identical permutation for a fresh wrapper with the same perm_seed,
    # and stable across resets of the same instance
    env2 = ActionPermutationWrapper(ActionRecorderEnv(), perm_seed=3)
    assert np.array_equal(env2.permutation, perm)
    env.reset(1)
    assert np.array_equal(env.permutation, perm)


def test_sticky_actions_wrapper_extremes():
    inner = ActionRecorderEnv()
    env = StickyActionsWrapper(inner, p=0.0)
    env.reset(0)
    for a in [1, 2, 0, 1]:
        env.step(a)
    assert inner.actions == [1, 2, 0, 1]              # exact passthrough

    inner2 = ActionRecorderEnv()
    env2 = StickyActionsWrapper(inner2, p=1.0)
    env2.reset(0)
    for a in [1, 2, 0, 1]:
        env2.step(a)
    assert inner2.actions == [0, 0, 0, 0]             # always repeats action 0


def test_obs_dropout_wrapper():
    # p=0: exact passthrough vs an unwrapped twin env
    clean = CartPole()
    wrapped = ObsDropoutWrapper(CartPole(), p=0.0)
    assert np.allclose(clean.reset(5), wrapped.reset(5))
    for _ in range(10):
        c = clean.step(1)
        w = wrapped.step(1)
        assert np.allclose(c[0], w[0]) and c[1] == w[1]
    # p=1: vector obs all zeros; discrete obs index 0
    env = ObsDropoutWrapper(CartPole(), p=1.0)
    obs = env.reset(0)
    assert isinstance(obs, np.ndarray) and obs.shape == (4,)
    assert np.all(obs == 0.0)
    obs, *_ = env.step(1)
    assert np.all(obs == 0.0)
    denv = ObsDropoutWrapper(make("contextual_bandit"), p=1.0)
    assert denv.reset(0) == 0


def test_obs_noise_wrapper_passthrough_and_bounds():
    # sigma=0: exact passthrough vs an unwrapped twin env
    clean = CartPole()
    wrapped = ObsNoiseWrapper(CartPole(), sigma=0.0)
    assert np.allclose(clean.reset(5), wrapped.reset(5))
    for _ in range(10):
        c = clean.step(1)
        w = wrapped.step(1)
        assert np.allclose(c[0], w[0]) and c[1] == w[1]

    # sigma=0.2: deviation stays within 6*sigma*std_i over 500 steps
    sigma = 0.2
    env = ObsNoiseWrapper(CartPole(), sigma=sigma)
    env.reset(42)
    std = env._std.copy()
    assert np.all(std > 0)
    clean = CartPole()
    clean.reset(42)
    rng = np.random.default_rng(7)
    for _ in range(500):
        a = int(rng.integers(2))
        obs_n, _, t_n, tr_n, _ = env.step(a)
        obs_c, _, t_c, tr_c, _ = clean.step(a)
        assert np.all(np.abs(obs_n - obs_c) <= 6.0 * sigma * std + 1e-12)
        if t_n or tr_n:
            env.reset(43)
            clean.reset(43)
