"""Core correctness tests: MLP gradients (finite differences), env contract,
runner semantics. These are the foundation tests of the whole framework."""
import numpy as np
import pytest

from axq.core.nn import MLP
from axq.core.agent import RandomAgent
from axq.core.runner import run_episode, evaluate, train
from axq.core.env import EnvBase
from axq.envs import make
from axq.testing import check_env


# ---------------------------------------------------------------------------
# MLP gradient checks (the most correctness-critical piece in the framework)
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("activation", ["tanh", "relu"])
def test_mlp_gradient_check(activation):
    """Analytic backward() vs central finite differences, per-parameter."""
    rng = np.random.default_rng(0)
    net = MLP([5, 8, 6, 3], rng, activation=activation)
    x = rng.normal(size=(4, 5))
    R = rng.normal(size=(4, 3))          # loss = sum(out * R)

    out = net.forward(x)
    assert out.shape == (4, 3)
    net.backward(R)
    analytic = [g.copy() for g in net.grads()]

    eps = 1e-6
    for li, layer in enumerate(net.layers):
        for pname in ("W", "b"):
            param = getattr(layer, pname)
            flat_idx = list(np.ndindex(param.shape))
            rng2 = np.random.default_rng(li * 100 + len(pname))
            check_idx = rng2.permutation(len(flat_idx))[:12] \
                if len(flat_idx) > 12 else list(range(len(flat_idx)))
            for k in check_idx:
                pos = flat_idx[k]
                orig = param[pos]
                param[pos] = orig + eps
                lp = float((net.forward(x) * R).sum())
                param[pos] = orig - eps
                lm = float((net.forward(x) * R).sum())
                param[pos] = orig
                numeric = (lp - lm) / (2 * eps)
                ana = analytic[2 * li + (0 if pname == "W" else 1)][pos]
                denom = max(1e-8, abs(numeric) + abs(ana))
                assert abs(numeric - ana) / denom < 1e-5, \
                    f"grad mismatch {pname}[{pos}]: {numeric} vs {ana}"


def test_mlp_adam_reduces_loss():
    rng = np.random.default_rng(1)
    net = MLP([4, 16, 2], rng)
    X = rng.normal(size=(64, 4))
    y = rng.normal(size=(64, 2))
    first = None
    for _ in range(200):
        out = net.forward(X)
        loss = float(((out - y) ** 2).mean())
        if first is None:
            first = loss
        net.backward(2.0 * (out - y) / X.shape[0])
        net.adam_step(lr=1e-2)
    out = net.forward(X)
    last = float(((out - y) ** 2).mean())
    assert last < first * 0.5, f"Adam failed: {first} -> {last}"


def test_mlp_copy_soft_update():
    rng = np.random.default_rng(2)
    a = MLP([3, 5, 2], rng)
    b = MLP([3, 5, 2], rng)
    b.soft_update(a, tau=1.0)
    assert all(np.allclose(pa, pb) for pa, pb in
               zip(a.get_weights(), b.get_weights()))
    c = MLP([3, 5, 2], np.random.default_rng(3))
    w0 = c.get_weights()
    c.soft_update(a, tau=0.1)
    for w_before, w_after, w_a in zip(w0, c.get_weights(), a.get_weights()):
        assert np.allclose(w_after, 0.9 * w_before + 0.1 * w_a)


def test_mlp_weights_roundtrip():
    rng = np.random.default_rng(4)
    a = MLP([3, 5, 2], rng)
    ws = a.get_weights()
    b = MLP([3, 5, 2], np.random.default_rng(5))
    b.set_weights(ws)
    x = rng.normal(size=(6, 3))
    assert np.allclose(a.forward(x), b.forward(x))


# ---------------------------------------------------------------------------
# Env contract for the reference bandit envs
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("env_id", ["one_step_bandit", "multi_armed_bandit",
                                    "contextual_bandit"])
def test_bandit_contract(env_id):
    check_env(make(env_id))


def test_multi_armed_bandit_regret_and_best_arm():
    env = make("multi_armed_bandit")
    best = int(np.argmax(env._mu))
    # Always pulling best arm: near-zero regret (noise can't create regret
    # because regret is measured against mu, not samples).
    env.reset(0)
    total, steps, info = 0.0, 0, {}
    while True:
        obs, r, term, trunc, info = env.step(best)
        total += r
        steps += 1
        if term or trunc:
            break
    assert steps == 100
    assert info["regret"] == pytest.approx(0.0, abs=1e-9)
    # Always pulling worst arm: large regret
    env.reset(0)
    worst = int(np.argmin(env._mu))
    while True:
        obs, r, term, trunc, info = env.step(worst)
        if term or trunc:
            break
    assert info["regret"] > 0.5 * 100


def test_contextual_bandit_requires_context():
    """A context-blind agent caps well below an oracle."""
    env = make("contextual_bandit")
    rng = np.random.default_rng(0)
    blind, oracle = 0.0, 0.0
    for i in range(2000):
        ctx = env.reset(i)
        best = int(np.argmax(env._p[ctx]))
        a_blind = int(rng.integers(env.n_actions))
        _, r, t, _, _ = env.step(a_blind)
        blind += r
        env.reset(i)
        _, r2, t2, _, _ = env.step(best)
        oracle += r2
    assert oracle > blind * 1.15


# ---------------------------------------------------------------------------
# Runner semantics
# ---------------------------------------------------------------------------
def test_runner_train_and_eval_smoke():
    env = make("multi_armed_bandit")
    eval_env = make("multi_armed_bandit")
    agent = RandomAgent(env.n_actions, seed=0)
    res = train(agent, env, total_steps=2000, eval_env=eval_env,
                eval_interval=1000, eval_episodes=10)
    assert res["total_steps"] >= 2000
    assert len(res["curve"]) >= 2
    assert res["steps_per_sec"] > 0
    assert "mean" in res["final_eval"]
    # Determinism of the eval protocol: two FRESH identically-seeded agents
    # must produce identical evals (an agent whose RNG advanced during
    # training is a different policy - correct, not a bug).
    ev1 = evaluate(RandomAgent(env.n_actions, seed=42), eval_env,
                   episodes=10, base_seed=987654)
    ev2 = evaluate(RandomAgent(env.n_actions, seed=42), eval_env,
                   episodes=10, base_seed=987654)
    assert ev1["mean"] == ev2["mean"]


def test_run_episode_does_not_mutate_agent_on_eval():
    class CountingAgent(RandomAgent):
        def __init__(self, n, seed):
            super().__init__(n, seed)
            self.observed = 0

        def observe(self, *a, **k):
            self.observed += 1

    env = make("multi_armed_bandit")
    agent = CountingAgent(env.n_actions, 0)
    run_episode(env, agent, greedy=True, learn=False, seed=0)
    assert agent.observed == 0


def test_invalid_action_raises():
    env = make("one_step_bandit")
    env.reset(0)
    with pytest.raises(ValueError):
        env.step(10)
