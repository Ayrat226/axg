"""Tests for the L9 tic-tac-toe games and the L8 multitask protocol."""
import numpy as np
import pytest

from axq.core.agent import RandomAgent
from axq.core.runner import evaluate
from axq.envs import make
from axq.envs.games import (TicTacToeVsOpponent, SelfPlaySession, BotAgent,
                            winner, encode, decode, X, O)
from axq.envs.multitask import (SUITES, CartPoleWideStart,
                                run_task_sequence, forgetting)
from axq.testing import check_env


# ---------------------------------------------------------------------------
# env contract
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("env_id", ["tictactoe_vs_random",
                                    "tictactoe_vs_heuristic",
                                    "tictactoe_vs_minimax"])
def test_tictactoe_contract(env_id):
    check_env(make(env_id))


# ---------------------------------------------------------------------------
# rules: win lines, draw, illegal moves
# ---------------------------------------------------------------------------
ALL_LINES = [(0, 1, 2), (3, 4, 5), (6, 7, 8), (0, 3, 6), (1, 4, 7),
             (2, 5, 8), (0, 4, 8), (2, 4, 6)]


@pytest.mark.parametrize("a,b,c", ALL_LINES)
@pytest.mark.parametrize("player", [X, O])
def test_all_win_lines_detected(a, b, c, player):
    cells = [0] * 9
    cells[a] = cells[b] = cells[c] = player
    assert winner(cells) == player


def test_no_line_means_no_winner():
    # a full drawn board (verified: no line for either player)
    drawn = [X, O, X, X, O, O, O, X, X]
    assert winner(drawn) == 0
    assert all(winner([0] * 9) == 0 for _ in [0])


def test_encode_decode_roundtrip_and_perspective():
    cells = (X, O, 0, 0, X, O, 0, 0, X)
    assert decode(encode(cells, X)) == (1, 2, 0, 0, 1, 2, 0, 0, 1)
    assert decode(encode(cells, O)) == (2, 1, 0, 0, 2, 1, 0, 0, 2)
    assert 0 <= encode(cells, X) < 3 ** 9


def test_tictactoe_win_through_env():
    """Agent plays a winning column while the opponent stays harmless."""
    opp = iter([3, 5])                          # opponent cells, in order
    env = TicTacToeVsOpponent(opponent=lambda obs: next(opp))
    env.reset(0)
    obs, r, term, trunc, info = env.step(0)     # X: 0, O: 3
    assert not term
    obs, r, term, trunc, info = env.step(1)     # X: 1, O: 5
    assert not term
    obs, r, term, trunc, info = env.step(2)     # X: 2 -> column 0,1,2
    assert term and r == 1.0 and info["result"] == "win"


def test_tictactoe_loss_through_env():
    """The opponent's winning move ends the episode with agent reward -1."""
    agent_moves = iter([8, 6, 3])               # harmless corner/side cells
    opp_moves = iter([0, 1, 2])                 # opponent completes a row
    env = TicTacToeVsOpponent(opponent=lambda obs: next(opp_moves))
    env.reset(0)
    obs, r, term, trunc, info = env.step(next(agent_moves))   # X: 8, O: 0
    assert not term
    obs, r, term, trunc, info = env.step(next(agent_moves))   # X: 6, O: 1
    assert not term
    obs, r, term, trunc, info = env.step(next(agent_moves))   # X: 3, O: 2 -> O wins
    assert term and r == -1.0 and info["result"] == "loss"


def test_tictactoe_draw_through_env():
    """Scripted draw: X={0,2,3,7,8}, O={1,4,5,6} - full board, no line."""
    opp_moves = iter([1, 4, 5, 6])
    env = TicTacToeVsOpponent(opponent=lambda obs: next(opp_moves))
    env.reset(0)
    last = None
    for a in [0, 2, 3, 7, 8]:
        last = env.step(a)
    obs, r, term, trunc, info = last
    assert term and r == 0.0 and info["result"] == "draw"


def test_tictactoe_illegal_move_forfeits():
    env = TicTacToeVsOpponent(opponent=lambda obs: 4)
    env.reset(0)
    env.step(0)                                 # X takes cell 0, O takes 4
    obs, r, term, trunc, info = env.step(0)     # illegal: cell 0 occupied
    assert r == -1.0 and term and info["result"] == "forfeit"


# ---------------------------------------------------------------------------
# opponent strength ordering
# ---------------------------------------------------------------------------
def test_minimax_never_loses_to_random():
    """Random X vs minimax O: minimax never loses (wins + draws == 200)."""
    env = make("tictactoe_vs_minimax")
    agent = RandomAgent(9, seed=0)
    res = evaluate(agent, env, episodes=200, base_seed=1000)
    wins = sum(1 for r in res["rewards"] if r > 0)      # random-agent wins
    draws = sum(1 for r in res["rewards"] if r == 0)
    losses = sum(1 for r in res["rewards"] if r < 0)    # minimax wins
    assert wins == 0                            # random never beats minimax
    assert losses + draws == 200                # minimax wins + draws == 200


def test_heuristic_never_beats_minimax():
    env = make("tictactoe_vs_minimax")
    agent = BotAgent("heuristic", seed=7)
    res = evaluate(agent, env, episodes=200, base_seed=2000)
    assert all(r <= 0.0 for r in res["rewards"])


def test_heuristic_beats_random():
    """Heuristic O vs random X: heuristic win rate (X's loss rate) > 0.6."""
    env = make("tictactoe_vs_heuristic")
    agent = RandomAgent(9, seed=3)
    res = evaluate(agent, env, episodes=300, base_seed=3000)
    loss_rate = sum(1 for r in res["rewards"] if r < 0) / 300
    assert loss_rate > 0.6


# ---------------------------------------------------------------------------
# self-play session
# ---------------------------------------------------------------------------
def test_selfplay_random_vs_random():
    session = SelfPlaySession(RandomAgent(9, seed=0), RandomAgent(9, seed=1))
    results = set()
    for i in range(50):
        rec = session.play_game(session.agent_x, session.agent_o, rng_seed=i)
        assert rec["x_reward"] in (-1.0, 0.0, 1.0)
        assert rec["o_reward"] == -rec["x_reward"]
        assert rec["result"] in ("x_win", "o_win", "draw",
                                 "x_forfeit", "o_forfeit")
        results.add(rec["result"])
    assert len(results) >= 2                    # some variety across games


def test_selfplay_play_and_train_and_eval_vs_bot():
    session = SelfPlaySession(RandomAgent(9, seed=0), RandomAgent(9, seed=1))
    summary = session.play_and_train(20, base_seed=100)
    assert summary["games"] == 20
    assert summary["agent_x_win_rate"] + summary["agent_o_win_rate"] \
        + summary["draw_rate"] == pytest.approx(1.0)
    stats = session.eval_vs_bot(session.agent_x, "random", n_games=30,
                                base_seed=200)
    assert stats["win"] + stats["draw"] + stats["loss"] == pytest.approx(1.0)
    assert stats["wins"] + stats["draws"] + stats["losses"] == 30


def test_minimax_agent_never_loses_as_x():
    """Minimax as the X side (via BotAgent) also never loses vs the bot."""
    session = SelfPlaySession(RandomAgent(9, seed=0), RandomAgent(9, seed=1))
    stats = session.eval_vs_bot(BotAgent("minimax", seed=11), "heuristic",
                                n_games=50, base_seed=400)
    assert stats["loss"] == 0.0


# ---------------------------------------------------------------------------
# multitask / continual learning protocol
# ---------------------------------------------------------------------------
def test_suite_envs_contract():
    for name, factory in SUITES["continual_gridworlds"].tasks:
        env = factory()
        check_env(env)
    check_env(CartPoleWideStart())
    for name, factory in SUITES["continual_cartpole"].tasks:
        check_env(factory())


def test_gridworld_layouts_differ_and_have_paths():
    envs = [factory() for _, factory in SUITES["continual_gridworlds"].tasks]
    # all five fixed layouts are distinct
    assert len({frozenset(e.walls) for e in envs}) == 5
    # a start->goal path exists in every layout (inherited BFS check)
    for env in envs:
        assert env.reachable()
    # sparse rewards: +1 at the goal, 0 elsewhere
    env = envs[0]
    env.reset(0)
    obs, r, term, trunc, info = env.step(1)     # (0,0) -> (0,1)
    assert r == 0.0 and not term


def test_run_task_sequence_matrix_shape_and_determinism():
    def agent_factory(seed):
        return RandomAgent(2, seed=seed)

    out1 = run_task_sequence(agent_factory, "continual_cartpole",
                             phase_steps=1000, seed=0)
    out2 = run_task_sequence(agent_factory, "continual_cartpole",
                             phase_steps=1000, seed=0)
    assert out1["phases"] == ["cp_normal", "cp_wide", "cp_normal2"]
    matrix = out1["matrix"]
    assert len(matrix) == 3                     # n_phases
    assert all(len(row) == 3 for row in matrix)  # n_tasks
    assert matrix == out2["matrix"]             # deterministic given seed


def test_run_task_sequence_eval_uses_held_out_seeds():
    """Eval scores of a random agent are near the population mean (~22 steps)."""
    def agent_factory(seed):
        return RandomAgent(2, seed=seed)

    out = run_task_sequence(agent_factory, "continual_cartpole",
                            phase_steps=200, seed=0, eval_episodes=5)
    for row in out["matrix"]:
        for score in row:
            assert 5.0 < score < 120.0          # sane cart-pole random return


def test_forgetting_metric():
    matrix = [[10.0, 0.0, 5.0],
              [4.0, 8.0, 1.0],
              [6.0, 2.0, 9.0]]
    phases = ["a", "b", "c"]
    tasks = ["a", "b", "c"]
    f = forgetting(matrix, phases, tasks)
    assert f == {"a": 10.0 - 6.0, "b": 8.0 - 2.0, "c": 9.0 - 9.0}


def test_forgetting_from_run_task_sequence():
    """forgetting() consumes run_task_sequence output directly."""
    def agent_factory(seed):
        return RandomAgent(2, seed=seed)

    out = run_task_sequence(agent_factory, "continual_cartpole",
                            phase_steps=200, seed=0, eval_episodes=3)
    f = forgetting(out["matrix"], out["phases"], out["phases"])
    assert set(f) == set(out["phases"])
    assert all(np.isfinite(v) for v in f.values())
