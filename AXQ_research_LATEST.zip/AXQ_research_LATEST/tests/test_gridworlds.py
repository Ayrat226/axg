"""Tests for the GridWorld env family (task 1-a).

Covers: env contract (check_env) on every registered id, value-iteration
solvability, random-policy hardness bounds, maze connectivity, key/door
semantics, frozen-lake slip model, dynamic-obstacle risk, train/test map
splits and the decoy anti-test. All tests are deterministic (fixed seeds);
comments record the measured values each assertion is based on.
"""
import numpy as np
import pytest

from axq.core.agent import AgentBase, RandomAgent
from axq.core.runner import run_episode
from axq.envs import make
from axq.envs.antitests import value_iteration
from axq.testing import check_env

ENV_IDS = [
    "gridworld_dense", "gridworld_sparse", "maze_random", "keys_doors",
    "deadend_maze", "dynamic_obstacles", "frozenlake_4x4",
    "frozenlake_slippery", "room_nav_gen", "gridworld_decoy",
]


# ---------------------------------------------------------------------------
# shared helpers
# ---------------------------------------------------------------------------
class VIPolicy(AgentBase):
    """Follows a precomputed tabular policy: act(obs) -> policy[obs]."""
    name = "vi_policy"

    def __init__(self, policy):
        self.policy = np.asarray(policy, dtype=np.int64)

    def act(self, obs, greedy=False):
        return int(self.policy[int(obs)])


class BeelineAgent(AgentBase):
    """Walks down to the bottom row, then right to the goal; ignores
    obstacles (obs = cell index only)."""
    name = "beeline"

    def __init__(self, size=8):
        self.size = int(size)

    def act(self, obs, greedy=False):
        r, c = divmod(int(obs), self.size)
        return 2 if r < self.size - 1 else 1


def run_episodes(env, agent, episodes, base_seed, greedy=True):
    """Run fixed-seed eval episodes; returns (returns, successes, infos)."""
    rets, succ, infos = [], [], []
    for i in range(episodes):
        r, n, info = run_episode(env, agent, greedy=greedy, learn=False,
                                 seed=base_seed + i)
        rets.append(r)
        succ.append(bool(info.get("success", False)))
        infos.append(info)
    return rets, succ, infos


def vi_policy_for(env, gamma):
    """Reset-seed-0 layout -> exact VI policy for the CURRENT layout."""
    env.reset(0)
    P, R = env.mdp_model(gamma)
    V, Q, pol = value_iteration(P, R, gamma)
    return V, Q, pol


# ---------------------------------------------------------------------------
# contracts
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("env_id", ENV_IDS)
def test_env_contract(env_id):
    check_env(make(env_id), n_episodes=3)


def test_env_contract_room_nav_test_split():
    check_env(make("room_nav_gen", split="test"), n_episodes=3)


# ---------------------------------------------------------------------------
# value_iteration solver
# ---------------------------------------------------------------------------
def test_value_iteration_known_mdp():
    # 2-state chain: a0 -> terminal s1 with +1; a1 -> stay with 0
    S, A = 2, 2
    P = np.zeros((S, A, S))
    R = np.zeros((S, A, S))
    P[0, 0, 1] = 1.0
    R[0, 0, 1] = 1.0
    P[0, 1, 0] = 1.0
    P[1, :, 1] = 1.0
    V, Q, pol = value_iteration(P, R, gamma=0.5)
    assert V[0] == pytest.approx(1.0)
    assert V[1] == pytest.approx(0.0)
    assert pol[0] == 0 and pol[1] == 0

    # stochastic variant: a0 reaches s1 (r=1) w.p. 0.5, else stays
    P = np.zeros((S, A, S))
    R = np.zeros((S, A, S))
    P[0, 0, 1] = 0.5
    R[0, 0, 1] = 1.0
    P[0, 0, 0] = 0.5
    P[0, 1, 0] = 1.0
    P[1, :, 1] = 1.0
    V, Q, pol = value_iteration(P, R, gamma=0.5)
    # V0 = 0.5*1 + 0.5*(0 + 0.5*V0)  =>  V0 = 2/3
    assert V[0] == pytest.approx(2.0 / 3.0, abs=1e-8)
    assert pol[0] == 0


def test_mdp_models_are_distributions():
    ids = ["gridworld_dense", "gridworld_sparse", "frozenlake_slippery",
           "gridworld_decoy", "keys_doors"]
    for env_id in ids:
        env = make(env_id)
        env.reset(0)
        P, R = env.mdp_model(0.99)
        assert P.shape == (env.n_obs, env.n_actions, env.n_obs)
        assert R.shape == P.shape
        assert np.allclose(P.sum(axis=2), 1.0), env_id
        assert np.all(P >= 0.0) and np.all(P <= 1.0), env_id


def test_frozenlake_slip_transition_probabilities():
    """From the top-left corner, `up` slips to a perpendicular or stays."""
    env = make("frozenlake_slippery")
    env.reset(0)
    P, R = env.mdp_model(0.99)
    # intended up (OOB -> stay) w.p. 0.7; slip left (OOB -> stay) 0.15;
    # slip right -> (0,1) w.p. 0.15
    assert P[0, 0, 0] == pytest.approx(0.85)
    assert P[0, 0, 1] == pytest.approx(0.15)
    # entering the goal pays +1 (the goal's own absorbing self-loop pays 0)
    goal = 3 * 4 + 3
    for a in range(4):
        for s in range(16):
            if s != goal and P[s, a, goal] > 0:
                assert R[s, a, goal] == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# gridworld_dense / gridworld_sparse
# ---------------------------------------------------------------------------
def test_gridworld_dense_vi_optimal():
    env = make("gridworld_dense")
    V, Q, pol = vi_policy_for(env, 1.0)
    # 6-step optimal path: 5 intermediate steps at -0.01, goal entry +1.0
    assert V[0] == pytest.approx(1.0 - 0.01 * 5, abs=1e-8)
    rets, succ, _ = run_episodes(env, VIPolicy(pol), 50, 123456)
    assert float(np.mean(rets)) >= 0.8          # measured 0.95
    assert all(succ)


def test_gridworld_sparse_vi_solves():
    env = make("gridworld_sparse")
    # gamma<1 breaks the (every-goal-reaching-policy-is-optimal) ties that
    # occur with zero step costs and gamma=1
    V, Q, pol = vi_policy_for(env, 0.99)
    # 14-step optimal path; reward arrives on the 14th transition
    assert V[0] == pytest.approx(0.99 ** 13, abs=1e-8)
    _, succ, _ = run_episodes(env, VIPolicy(pol), 100, 123456)
    assert float(np.mean(succ)) >= 0.95         # measured 1.00


def test_gridworld_sparse_random_is_hard():
    env = make("gridworld_sparse")
    _, succ, _ = run_episodes(env, RandomAgent(4, seed=7), 100, 654321,
                              greedy=False)
    # measured 0.20 on this exact fixed-seed sample (population 0.16 by
    # exact chain computation at 96 steps)
    assert float(np.mean(succ)) < 0.35


# ---------------------------------------------------------------------------
# maze_random / deadend_maze
# ---------------------------------------------------------------------------
def test_maze_random_connectivity():
    env = make("maze_random")
    for seed in range(50):
        env.reset(seed)
        assert env.start not in env.walls and env.goal not in env.walls
        assert env.reachable(env.start, env.goal), f"seed {seed} not connected"


def test_maze_random_random_policy_is_hard():
    env = make("maze_random")
    _, succ, _ = run_episodes(env, RandomAgent(4, seed=11), 200, 24680,
                              greedy=False)
    # measured 0.145 on this exact fixed-seed sample (population ~0.11)
    assert float(np.mean(succ)) < 0.2


def test_deadend_maze_corridors_are_dead_ends():
    env = make("deadend_maze")
    counts = []
    for seed in range(50):
        env.reset(seed)
        counts.append(len(env._bait_corridors))
        for branch, cells in env._bait_corridors:
            # corridor cells are carved (enterable) ...
            assert all(c not in env.walls for c in cells)
            # ... and sealing ONLY the branch cell makes them unreachable
            sealed = set(env.walls) | {branch}
            assert env.bfs_path(env.start, cells[-1], sealed) is None
        # the maze itself must remain solvable
        assert env.reachable(env.start, env.goal)
    # exactly 3 bait corridors every time (measured over 100 resets)
    assert min(counts) >= 3


def test_deadend_maze_dead_end_visits_counting():
    env = make("deadend_maze")
    env.reset(0)
    branch, cells = next(c for c in env._bait_corridors if c[0] != env.goal)
    env._pos = branch
    entered = False
    for a in range(4):
        dr, dc = env.MOVES[a]
        if (branch[0] + dr, branch[1] + dc) == cells[0]:
            env.step(a)
            entered = True
            break
    assert entered
    assert env._pos == cells[0]
    assert env._dead_end_visits == 1


# ---------------------------------------------------------------------------
# keys_doors
# ---------------------------------------------------------------------------
def test_keys_doors_vi_solves():
    env = make("keys_doors")
    succ, got = [], []
    for i in range(50):
        env.reset(1000 + i)                     # fixes the layout
        P, R = env.mdp_model(0.99)
        pol = value_iteration(P, R, 0.99)[2]
        r, n, info = run_episode(env, VIPolicy(pol), greedy=True,
                                 learn=False, seed=1000 + i)
        succ.append(bool(info["success"]))
        got.append(bool(info["got_key"]))
    assert float(np.mean(succ)) >= 0.9          # measured 1.00
    assert all(got)


def test_keys_doors_random_is_hard():
    env = make("keys_doors")
    _, succ, _ = run_episodes(env, RandomAgent(4, seed=3), 200, 13579,
                              greedy=False)
    # measured 0.075 on this exact fixed-seed sample
    assert float(np.mean(succ)) < 0.15


def test_keys_doors_door_requires_key():
    env = make("keys_doors")
    env.reset(0)
    d = env.door_cell
    left = (d[0], d[1] - 1)
    assert left not in env.walls                # free cell before the door
    env._pos, env._has_key = left, False
    env.step(1)                                 # try to walk right into door
    assert env._pos == left                     # blocked without the key
    env.step(1)
    assert env._pos == left                     # still blocked
    env._has_key = True
    env.step(1)
    assert env._pos == d                        # passes with the key
    assert env._has_key                         # flag persists


def test_keys_doors_key_pickup_and_obs_encoding():
    env = make("keys_doors")
    env.reset(0)
    k = env.key_cell
    assert k not in env.walls and k not in (env.start, env.goal)
    # find a free neighbour of the key cell to approach from
    src = None
    for a in range(4):
        dr, dc = env.MOVES[a]
        n = (k[0] - dr, k[1] - dc)
        if n not in env.walls and env._in_bounds(*n):
            src, act = n, a
            break
    assert src is not None
    env._pos, env._has_key = src, False
    assert env._obs() % 2 == 0                  # no key -> even obs
    obs, r, term, trunc, info = env.step(act)   # step onto the key
    assert env._pos == k and env._has_key
    assert env._obs() % 2 == 1                  # has key -> odd obs
    assert r == 0.0                             # pickup pays nothing


# ---------------------------------------------------------------------------
# frozenlake
# ---------------------------------------------------------------------------
def test_frozenlake_slippery_vi_beats_random():
    env = make("frozenlake_slippery")
    V, Q, pol = vi_policy_for(env, 0.99)
    _, vi_succ, _ = run_episodes(env, VIPolicy(pol), 200, 555001)
    _, rnd_succ, _ = run_episodes(env, RandomAgent(4, seed=5), 200, 555001,
                                  greedy=False)
    # measured: VI 0.775, random 0.010
    assert float(np.mean(vi_succ)) >= 0.35
    assert float(np.mean(rnd_succ)) <= 0.15


def test_frozenlake_4x4_vi_solves():
    env = make("frozenlake_4x4")
    V, Q, pol = vi_policy_for(env, 0.99)
    _, succ, _ = run_episodes(env, VIPolicy(pol), 100, 777001)
    assert float(np.mean(succ)) >= 0.9          # measured 1.00


# ---------------------------------------------------------------------------
# dynamic_obstacles
# ---------------------------------------------------------------------------
def test_dynamic_obstacles_beeline():
    """The env is solvable but risky: an obstacle-blind beeline succeeds."""
    env = make("dynamic_obstacles")
    _, succ, _ = run_episodes(env, BeelineAgent(8), 600, 314159)
    # measured 0.367 on this exact fixed-seed sample
    assert float(np.mean(succ)) > 0.3


def test_dynamic_obstacles_collision_semantics():
    env = make("dynamic_obstacles")
    rets, succ, infos = run_episodes(env, RandomAgent(4, seed=13), 200,
                                     271828, greedy=False)
    coll = [i for i in infos if i.get("collision")]
    assert len(coll) >= 1                      # measured 199/200
    for r, i in zip(rets, infos):
        if i.get("collision"):
            # step rewards are 0, so the episode total is exactly -1.0
            assert r == pytest.approx(-1.0)
            assert i["steps"] <= env.max_episode_steps


# ---------------------------------------------------------------------------
# room_nav_gen
# ---------------------------------------------------------------------------
def test_room_nav_train_test_pools_disjoint():
    tr = make("room_nav_gen", split="train")
    te = make("room_nav_gen", split="test")
    tr_seeds, te_seeds = set(), set()
    for i in range(100):
        tr.reset(i)
        tr_seeds.add(tr.current_map_seed)
        te.reset(i)
        te_seeds.add(te.current_map_seed)
    assert not (tr_seeds & te_seeds)            # measured intersection 0
    assert all(10_000_000 <= s < 10_000_000 + 100 for s in tr_seeds)
    assert all(20_000_000 <= s < 20_000_000 + 1000 for s in te_seeds)


def test_room_nav_map_signature_deterministic():
    env = make("room_nav_gen")
    env.reset(42)
    sig = env.current_map_signature()
    obs = env.step(1)[0]                        # move around
    obs = env.step(2)[0]
    assert 0 <= obs < env.n_obs
    assert env.current_map_signature() == sig   # stable within episode
    env.reset(42)
    assert env.current_map_signature() == sig   # same sampled map seed
    env2 = make("room_nav_gen")
    env2.reset(42)
    assert env2.current_map_signature() == sig  # across instances


def test_room_nav_maps_valid_and_obs_encoding():
    env = make("room_nav_gen")
    for seed in range(30):
        obs = env.reset(seed)
        assert env.reachable(env.start, env.goal)
        assert (abs(env.start[0] - env.goal[0])
                + abs(env.start[1] - env.goal[1])) >= env.size
        assert env.start not in env.walls and env.goal not in env.walls
        # obs = pos*16 + wallbits (bit0 up, bit1 right, bit2 down, bit3 left)
        r, c = env._pos
        size = env.size
        bits = ((1 if (r == 0 or (r - 1, c) in env.walls) else 0)
                | (2 if (c == size - 1 or (r, c + 1) in env.walls) else 0)
                | (4 if (r == size - 1 or (r + 1, c) in env.walls) else 0)
                | (8 if (c == 0 or (r, c - 1) in env.walls) else 0))
        assert obs == (r * size + c) * 16 + bits


# ---------------------------------------------------------------------------
# gridworld_decoy (anti-test)
# ---------------------------------------------------------------------------
def test_decoy_vi_ignores_trap():
    env = make("gridworld_decoy")
    V, Q, pol = vi_policy_for(env, 1.0)
    # 14-step path: 13 intermediate steps at -0.01, goal entry +1.0
    assert V[0] == pytest.approx(1.0 - 0.01 * 13, abs=1e-8)
    rets, succ, infos = run_episodes(env, VIPolicy(pol), 100, 424242)
    assert float(np.mean(rets)) >= 0.8          # measured 0.87
    assert all(succ)
    assert not any(i["trap_taken"] for i in infos)   # 0/100


def test_decoy_random_sometimes_takes_trap():
    env = make("gridworld_decoy")
    _, _, infos = run_episodes(env, RandomAgent(4, seed=17), 100, 98765,
                               greedy=False)
    # measured 91/100 on this exact fixed-seed sample
    assert sum(i["trap_taken"] for i in infos) >= 5
