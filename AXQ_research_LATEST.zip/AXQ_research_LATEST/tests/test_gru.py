"""GRU-DQN correctness tests: finite-difference BPTT check + learning."""
import numpy as np
import pytest

from axq.agents.gru_dqn import GRUWeights, GRUDQN
from axq.agents import make_agent
from axq.envs import make
from axq.core.runner import train


def test_gru_full_sequence_gradient_check():
    """Analytic BPTT vs central finite differences on a whole sequence."""
    rng = np.random.default_rng(0)
    net = GRUWeights(4, 6, 2, rng)
    T, B = 5, 3
    xs = rng.normal(size=(T, B, 4))
    R = rng.normal(size=(T, B, 2))       # loss = sum(q * R) over all steps

    qs, _, cache = net.forward_seq(xs)
    dqs = R.copy()
    grads = net.backward_seq(dqs, cache)
    names = ["Wr", "Ur", "br", "Wz", "Uz", "bz", "Wn", "Un", "bn",
             "Wq", "bq"]

    eps = 1e-6
    for pi, name in enumerate(names):
        param = net.params()[pi]
        flat = list(np.ndindex(param.shape))
        rng2 = np.random.default_rng(pi)
        picks = rng2.permutation(len(flat))[:6] if len(flat) > 6 \
            else list(range(len(flat)))
        for k in picks:
            pos = flat[k]
            orig = param[pos]
            param[pos] = orig + eps
            lp = float((net.forward_seq(xs)[0] * R).sum())
            param[pos] = orig - eps
            lm = float((net.forward_seq(xs)[0] * R).sum())
            param[pos] = orig
            num = (lp - lm) / (2 * eps)
            ana = grads[pi][pos]
            assert abs(num - ana) / max(1e-8, abs(num) + abs(ana)) < 1e-5, \
                f"{name}{pos}: numeric {num} vs analytic {ana}"


def test_gru_dqn_solves_memory_corridor_16():
    """The capability test: recurrent memory solves a POMDP that reactive
    DQN provably cannot (reactive ceiling 0.5)."""
    env = make("memory_corridor_16")
    agent = make_agent("gru_dqn", env.n_obs, env.obs_type, env.n_actions,
                       seed=0, hidden=32, update_every=1, batch_size=8,
                       warmup=1000)
    res = train(agent, env, total_steps=40000, eval_env=make("memory_corridor_16"),
                eval_interval=10000, eval_episodes=50)
    assert res["final_eval"]["mean"] >= 0.9, res["final_eval"]


def test_gru_dqn_determinism_and_roundtrip(tmp_path):
    env = make("memory_corridor_8")
    a1 = make_agent("gru_dqn", env.n_obs, env.obs_type, env.n_actions,
                    seed=3, hidden=16, warmup=200, update_every=1)
    a2 = make_agent("gru_dqn", env.n_obs, env.obs_type, env.n_actions,
                    seed=3, hidden=16, warmup=200, update_every=1)
    r1 = train(a1, make("memory_corridor_8"), total_steps=3000, eval_env=None,
               seed=0)
    r2 = train(a2, make("memory_corridor_8"), total_steps=3000, eval_env=None,
               seed=0)
    assert r1["total_steps"] == r2["total_steps"]
    # act identically after training (reset recurrent state first: act() is
    # stateful by design; the runner always calls reset_state() at ep start)
    a1.reset_state(); a2.reset_state()
    for obs in range(env.n_obs):
        assert a1.act(obs, greedy=True) == a2.act(obs, greedy=True)
    a1.save(tmp_path / "gru.npz")
    a3 = make_agent("gru_dqn", env.n_obs, env.obs_type, env.n_actions,
                    seed=99, hidden=16, warmup=200, update_every=1)
    a3.load(tmp_path / "gru.npz")
    a1.reset_state(); a3.reset_state()
    for obs in range(env.n_obs):
        assert a3.act(obs, greedy=True) == a1.act(obs, greedy=True)


def test_episode_buffer_capacity_and_sampling():
    from axq.agents.gru_dqn import EpisodeBuffer
    buf = EpisodeBuffer(capacity=100)
    for ep in range(5):
        buf.start_episode()
        for t in range(3):
            buf.add(t, 0, 0.0, t + 1, False)
        buf.end_episode()
    assert len(buf) == 15 and buf.n_episodes() == 5
    rng = np.random.default_rng(0)
    sample = buf.sample(3, rng)
    assert len(sample) == 3 and all(len(e) == 3 for e in sample)
    # eviction: adding episodes beyond capacity drops the oldest
    buf2 = EpisodeBuffer(capacity=10)
    for ep in range(10):
        buf2.start_episode()
        for t in range(3):
            buf2.add(t, 0, 0.0, t + 1, False)
        buf2.end_episode()
    assert buf2.n_episodes() <= 4          # ~10 cap / 3 per episode
    assert buf2._n <= 10
    assert all(len(e) == 3 for e in buf2.episodes)
