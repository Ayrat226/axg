"""Cross-module INTEGRATION learning tests: full-stack learnability.

These verify that envs (built by env subagents) + agents (built by the agent
subagent) + runner + protocol compose correctly and that each benchmark level
is LEARNABLE by the appropriate agent class. Hypotheses (e.g. AXQ > DQN on
sparse exploration) are NOT tested here — those are experiments, not tests.
Thresholds calibrated empirically (scripts/calibrate.py, scripts/bench.py).
"""
import numpy as np
import pytest

from axq.envs import make
from axq.agents import make_agent
from axq.core.runner import train


def _train_eval(env_id, agent_name, steps, params=None, eval_episodes=20,
                seed=0, eval_interval=None):
    env = make(env_id)
    agent = make_agent(agent_name, env.n_obs, env.obs_type, env.n_actions,
                       seed=seed, **(params or {}))
    res = train(agent, env, total_steps=steps,
                eval_env=make(env_id),
                eval_interval=eval_interval or max(steps // 4, 1),
                eval_episodes=eval_episodes, seed=seed)
    return res


# --------------------------------------------------------------------------- L0/L2
def test_dqn_solves_gridworld_dense():
    res = _train_eval("gridworld_dense", "dqn", 30000)
    assert res["final_eval"]["mean"] >= 0.8, res["final_eval"]


def test_axq_solves_gridworld_dense():
    res = _train_eval("gridworld_dense", "axq", 30000)
    assert res["final_eval"]["mean"] >= 0.75, res["final_eval"]


def test_tabular_solves_gridworld_sparse():
    res = _train_eval("gridworld_sparse", "tabular", 30000)
    assert res["final_eval"]["mean"] >= 0.9, res["final_eval"]


# --------------------------------------------------------------------------- L1
def test_dqn_solves_cartpole():
    # Documented control config: n_step=3 + built-in running obs
    # normalization (identical for DQN and AXQ; see run_suite CONTROL_PARAMS).
    res = _train_eval("cartpole", "dqn", 60000, params=dict(n_step=3),
                      eval_episodes=10, eval_interval=10000)
    assert res["final_eval"]["mean"] >= 300, res["final_eval"]


# --------------------------------------------------------------------------- L3
def test_dqn_reactive_cap_on_memory_corridor():
    """Feedforward DQN is reactive BY CONSTRUCTION on this POMDP: the
    choice-phase obs is identical for both symbols, so no reactive policy can
    exceed 0.5 expected reward. Learning must NOT break this ceiling."""
    res = _train_eval("memory_corridor_8", "dqn", 30000)
    assert res["final_eval"]["mean"] < 0.65, res["final_eval"]


def test_history_dqn_solves_memory_corridor_16():
    res = _train_eval("memory_corridor_16", "history_dqn", 50000,
                      params=dict(history_len=20))
    assert res["final_eval"]["mean"] >= 0.85, res["final_eval"]


# --------------------------------------------------------------------------- protocol
def test_run_experiment_end_to_end(tmp_path):
    from axq.exp.protocol import (ExperimentConfig, run_experiment,
                                  compare_runs)
    from axq.exp.journal import ExperimentJournal

    journal = ExperimentJournal(tmp_path / "journal.jsonl")
    cfg_a = ExperimentConfig(
        exp_id="it-dqn", hypothesis_id="H-integration",
        agent_name="dqn", agent_params=dict(hidden=(32,)),
        env_id="one_step_bandit", env_params=dict(),
        seeds=[0, 1], budget_steps=3000, eval_interval=1500,
        eval_episodes=10, tags=["integration"])
    cfg_b = ExperimentConfig(
        exp_id="it-rand", hypothesis_id="H-integration",
        agent_name="random", agent_params=dict(),
        env_id="one_step_bandit", env_params=dict(),
        seeds=[0, 1], budget_steps=3000, eval_interval=1500,
        eval_episodes=10, tags=["integration"])
    sa = run_experiment(cfg_a, tmp_path, journal=journal, save_agents=True)
    sb = run_experiment(cfg_b, tmp_path, journal=journal)
    assert (tmp_path / "it-dqn" / "agent_dqn_seed0.npz").exists()
    assert len(sa["final_mean_per_seed"]) == 2
    cmp = compare_runs(tmp_path, "it-dqn", "it-rand")
    assert "wilcoxon_p" in cmp and cmp["n"] == 2
    # DQN must extract near-optimal arm on the bandit (optimal mean ~ +1.x)
    assert sa["final_mean_summary"]["mean"] > sb["final_mean_summary"]["mean"]
    records = journal.load()
    assert len(records) == 2
    assert records[0]["code_version"] == records[1]["code_version"]
