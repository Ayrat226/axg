"""Tests for the L3 memory environments and L4/L5 chain environments."""
import numpy as np
import pytest

from axq.core.agent import AgentBase
from axq.core.runner import run_episode
from axq.envs import make
from axq.envs.memory import MemoryCorridor, DelayedMatch, HiddenStateTask
from axq.envs.chains import ChainEnv, DeceptiveChoice, CreditAssignmentTask
from axq.testing import check_env

CORRIDORS = [("memory_corridor_8", 8), ("memory_corridor_16", 16),
             ("memory_corridor_32", 32), ("memory_corridor_64", 64)]
DELAYED = [("delayed_match_10_50", 10, 50), ("delayed_match_50_100", 50, 100)]


# ---------------------------------------------------------------------------
# scripted policies
# ---------------------------------------------------------------------------
class RememberAndMatch(AgentBase):
    """Store the symbol seen at t=0; emit it at the choice marker."""

    def __init__(self, n_symbols, marker_id):
        self.n_symbols = n_symbols
        self.marker = marker_id
        self.symbol = 0

    def reset_state(self):
        self.symbol = 0

    def act(self, obs, greedy=False):
        o = int(obs)
        if o < self.n_symbols:                # symbol presentation phase
            self.symbol = o
            return 0
        if o == self.marker:                  # choice phase
            return self.symbol
        return 0                              # uninformative filler phases


class RememberBit(AgentBase):
    """Store the hidden bit; play it in every room."""

    def reset_state(self):
        self.bit = 0

    def act(self, obs, greedy=False):
        if int(obs) in (0, 1):
            self.bit = int(obs)
        return self.bit


class AlwaysAdvance(AgentBase):
    def act(self, obs, greedy=False):
        return 0


class PatientPolicy(AgentBase):
    """Choose the delayed option and hold until the large reward."""

    def act(self, obs, greedy=False):
        return 1


class MyopicPolicy(AgentBase):
    """Take the small immediate reward."""

    def act(self, obs, greedy=False):
        return 0


# ---------------------------------------------------------------------------
# env contract
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("env_id", [eid for eid, _ in CORRIDORS]
                         + [eid for eid, _, _ in DELAYED] + ["hidden_state"])
def test_memory_envs_contract(env_id):
    check_env(make(env_id))


@pytest.mark.parametrize("env_id,L",
                         [("chain_5", 5), ("chain_10", 10),
                          ("chain_20", 20), ("chain_50", 50)])
def test_chain_envs_contract(env_id, L):
    check_env(make(env_id))


@pytest.mark.parametrize("env_id,delay",
                         [("deceptive_5", 5), ("deceptive_10", 10),
                          ("deceptive_25", 25), ("deceptive_50", 50),
                          ("deceptive_100", 100)])
def test_deceptive_envs_contract(env_id, delay):
    check_env(make(env_id))


def test_credit_assignment_env_contract():
    check_env(make("credit_assignment"))


# ---------------------------------------------------------------------------
# memory envs are solvable by a memory policy and NOT by reactive policies
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("env_id,L", CORRIDORS)
def test_memory_corridor_solved_by_memory_policy(env_id, L):
    env = make(env_id)
    agent = RememberAndMatch(n_symbols=2, marker_id=2 + L)
    rewards, corrects = [], []
    for i in range(100):
        total, steps, info = run_episode(env, agent, learn=False, seed=i)
        rewards.append(total)
        corrects.append(info.get("correct", False))
    assert float(np.mean(rewards)) == 1.0
    assert all(corrects)
    assert all(steps == L + 2 for steps in
               [run_episode(env, agent, learn=False, seed=i)[1]
                for i in range(5)])


@pytest.mark.parametrize("env_id,dmin,dmax", DELAYED)
def test_delayed_match_solved_by_memory_policy(env_id, dmin, dmax):
    env = make(env_id)
    agent = RememberAndMatch(n_symbols=2, marker_id=3)
    rewards = []
    for i in range(100):
        total, steps, info = run_episode(env, agent, learn=False, seed=i)
        rewards.append(total)
        assert dmin + 2 <= steps <= dmax + 2
        assert info.get("correct", False)
    assert float(np.mean(rewards)) == 1.0


def test_hidden_state_solved_by_memory_policy():
    env = HiddenStateTask(n_phases=4)
    agent = RememberBit()
    for i in range(100):
        total, steps, info = run_episode(env, agent, learn=False, seed=i)
        assert total == pytest.approx(1.0)
        assert info["score"] == 4
        assert steps == 4


def test_memory_corridor_reactive_cap():
    """Random reactive (per-obs lookup) policies cap near chance on corridor_8.

    The choice-step observation is identical for both symbols, so a reactive
    policy fixes its door in advance and wins with probability 1/2.  With
    300 evaluation episodes per policy, the max over 200 random policies
    stays well below 0.65 (expected max ~0.575).
    """
    env = MemoryCorridor(corridor_len=8)
    rng = np.random.default_rng(0)
    best = 0.0
    for _ in range(200):
        table = rng.integers(0, 2, size=env.n_obs)
        wins = 0
        for i in range(300):
            obs = env.reset(777_000 + i)
            while True:
                obs, r, term, trunc, info = env.step(int(table[obs]))
                if term or trunc:
                    break
            wins += int(r > 0.5)
        best = max(best, wins / 300)
    assert best < 0.65


def test_memory_corridor_choice_obs_is_symbol_blind():
    """Everything observable after t=0 is identical across symbols (POMDP)."""
    env = MemoryCorridor(corridor_len=8)
    seqs = []
    for i in range(20):
        symbol = env.reset(5_000 + i)
        seq = []
        while True:
            obs, r, term, trunc, info = env.step(0)
            seq.append(obs)
            if term or trunc:
                break
        seqs.append((symbol, seq))
    # the observation sequence never depends on the symbol (all identical)
    ref = seqs[0][1]
    for _, seq in seqs:
        assert seq == ref
    # and both symbols occur in the sample
    assert {s for s, _ in seqs} == {0, 1}
    # the reward under a fixed action 0 is exactly (symbol == 0)
    for symbol, seq in seqs:
        assert len(seq) == 10


# ---------------------------------------------------------------------------
# chain envs: analytic optimum
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("env_id,L",
                         [("chain_5", 5), ("chain_10", 10),
                          ("chain_20", 20), ("chain_50", 50)])
def test_chain_always_advance_is_optimal(env_id, L):
    env = make(env_id)
    agent = AlwaysAdvance()
    for i in range(10):
        total, steps, info = run_episode(env, agent, learn=False, seed=i)
        assert steps == L                      # exactly L advances
        assert total == 1.0                    # single terminal +1
        assert info["reached_goal"] is True
        assert info["falls"] == 0


def test_chain_50_optimal_mean_reward_exactly_one():
    env = ChainEnv(length=50)
    agent = AlwaysAdvance()
    totals = [run_episode(env, agent, learn=False, seed=i)[0] for i in range(20)]
    assert float(np.mean(totals)) == 1.0


def test_chain_fall_back_resets_progress():
    env = ChainEnv(length=5)
    env.reset(0)
    env.step(0)                                # state 1
    obs, r, term, trunc, info = env.step(1)    # fall back
    assert obs == 0 and r == 0.0 and not term
    env.step(0); env.step(0); env.step(0); env.step(0)   # 1..4
    obs, r, term, trunc, info = env.step(0)    # advance to goal
    assert obs == 5 and r == 1.0 and term
    assert info["falls"] == 1


# ---------------------------------------------------------------------------
# deceptive / credit-assignment envs
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("env_id,delay",
                         [("deceptive_5", 5), ("deceptive_10", 10),
                          ("deceptive_25", 25), ("deceptive_50", 50),
                          ("deceptive_100", 100)])
def test_deceptive_patient_policy_gets_large_reward(env_id, delay):
    env = make(env_id)
    agent = PatientPolicy()
    for i in range(10):
        total, steps, info = run_episode(env, agent, learn=False, seed=i)
        assert total == 10.0
        assert info["outcome"] == "large"
        assert steps == delay + 1              # 1 entry + `delay` holds


@pytest.mark.parametrize("env_id", ["deceptive_5", "deceptive_50"])
def test_deceptive_myopic_policy_gets_small_reward(env_id):
    env = make(env_id)
    agent = MyopicPolicy()
    for i in range(10):
        total, steps, info = run_episode(env, agent, learn=False, seed=i)
        assert total == 1.0
        assert steps == 1
        assert info["outcome"] == "small"


def test_deceptive_quit_earns_nothing():
    env = DeceptiveChoice(delay=5)
    env.reset(0)
    env.step(1)                                # enter hold phase
    obs, r, term, trunc, info = env.step(0)    # quit
    assert obs == 1 and r == 0.0 and term
    assert info["outcome"] == "quit"


def test_credit_assignment_rewards():
    env = CreditAssignmentTask()
    for i in range(5):
        total, _, info = run_episode(env, PatientPolicy(), learn=False, seed=i)
        assert total == 50.0 and info["outcome"] == "large"
        total, _, info = run_episode(env, MyopicPolicy(), learn=False, seed=i)
        assert total == 5.0 and info["outcome"] == "small"
    assert env.delay == 20
