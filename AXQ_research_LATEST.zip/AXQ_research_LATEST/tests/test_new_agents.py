"""Cycle-4 new-agent tests: DynaQ, EFEAgent, SFGPI.

Critical properties:
* DynaQ: k=0 == TabularQ EXACTLY (same trajectory, same Q); planning
  propagates value through the learned model (1-step env, value jumps);
  planning never advances eps schedule / visits.
* EFEAgent: reduction proof — action selection identical to TabularQ with
  count_bonus=tau_e and eps=0 (random MDP battery, seeded).
* SFGPI: (i) single-task SFQL converges to Q* on a small deterministic MDP
  (verified vs value iteration); (ii) task switch freezes library and GPI
  recovers an old task's value after w re-inference (the H19 mechanism);
  (iii) infer_mode updates w only.
"""
import sys

import numpy as np
import pytest

sys.path.insert(0, "/home/z/my-project")
from axq.agents import make_agent
from axq.agents.dyna import DynaQ
from axq.agents.efe import EFEAgent
from axq.agents.sf import SFGPI
from axq.agents.tabular import TabularQ
from axq.core.runner import train, evaluate
from axq.envs import make
from axq.envs.antitests import value_iteration
from axq.envs.chains import DeceptiveChoice


# ---------------------------------------------------------------- DynaQ
class TestDynaQ:
    def test_k0_equals_tabular_exactly(self):
        """k_plan=0 => identical trajectory + Q as TabularQ (same seed)."""
        for seed in (0, 3):
            env1, env2 = make("gridworld_dense"), make("gridworld_dense")
            a1 = make_agent("tabular", env1.n_obs, env1.obs_type,
                            env1.n_actions, seed=seed)
            a2 = DynaQ(env2.n_obs, env2.obs_type, env2.n_actions,
                       seed=seed, k_plan=0)
            r1 = train(a1, env1, total_steps=4000, eval_env=None, seed=seed)
            r2 = train(a2, env2, total_steps=4000, eval_env=None, seed=seed)
            assert r1["episodes"] == r2["episodes"]
            assert np.allclose(a1.Q, a2.Q, atol=0)

    def test_planning_propagates_value(self):
        """1-state env: after a single reward, planning sweeps push Q to the
        fixed point within a few update() calls (no more real data needed)."""
        env = DeceptiveChoice(delay=1, small_reward=1.0, large_reward=10.0)
        ag = DynaQ(env.n_obs, env.obs_type, env.n_actions, seed=0, k_plan=50,
                   alpha=1.0)
        # one episode: take small reward (action 0 at obs 0)
        obs = env.reset(0)
        ag.act(obs)
        nobs, r, term, trunc, _ = env.step(0)
        ag.observe(obs, 0, r, nobs, term, trunc)
        # now a hold chain: enter hold, hold once -> large
        obs = env.reset(1)
        a = ag.act(obs)
        nobs, r, term, trunc, _ = env.step(1)
        ag.observe(obs, 1, r, nobs, term, trunc)
        a = ag.act(nobs)
        nobs2, r2, term2, trunc2, _ = env.step(1)
        ag.observe(nobs, 1, r2, nobs2, term2, trunc2)
        for _ in range(200):
            ag.update()
        # Q(0, take)=1; Q(0, enter)=gamma*max Q(1,.); Q(1,hold)=10
        assert ag.Q[0, 0] == pytest.approx(1.0, abs=1e-9)
        assert ag.Q[1, 1] == pytest.approx(10.0, abs=1e-9)
        assert ag.Q[0, 1] == pytest.approx(0.99 * 10.0, abs=1e-9)
        assert ag.Q[1, 0] == pytest.approx(0.0, abs=1e-9)

    def test_planning_no_schedule_side_effects(self):
        env = make("gridworld_dense")
        ag = DynaQ(env.n_obs, env.obs_type, env.n_actions, seed=0, k_plan=10)
        obs = env.reset(0)
        for _ in range(50):
            a = ag.act(obs)
            nobs, r, t, tr, _ = env.step(a)
            ag.observe(obs, a, r, nobs, t, tr)
            ag.update()
            obs = nobs
            if t or tr:
                obs = env.reset(0)
        v_before = ag.visits.sum()
        s_before = ag._step_count
        for _ in range(100):
            ag.update()
        assert ag.visits.sum() == v_before
        assert ag._step_count == s_before


# ---------------------------------------------------------------- EFE
class TestEFE:
    def test_efe_reduction_to_count_bonus(self):
        """H21 verification: with eps=0, EFE action selection == TabularQ
        count_bonus selection on a random MDP battery (identical formulas)."""
        rng = np.random.default_rng(0)
        for trial in range(200):
            S, A = int(rng.integers(2, 6)), int(rng.integers(2, 5))
            efe = EFEAgent(S, "discrete", A, seed=trial, tau_e=0.7,
                           eps_start=0.0, eps_end=0.0)
            tab = TabularQ(S, "discrete", A, seed=trial, count_bonus=0.7,
                           eps_start=0.0, eps_end=0.0)
            efe.Q = rng.normal(size=(S, A))
            tab.Q = efe.Q.copy()
            efe.visits = rng.integers(0, 40, size=(S, A))
            tab.visits = efe.visits.copy()
            for s in range(S):
                for greedy in (False, True):
                    a1 = efe.act(s, greedy=greedy)
                    if greedy:
                        # eval: TabularQ pure argmax; EFE keeps epistemic term
                        # (documented design difference — no assertion here)
                        continue
                    a2 = tab.act(s, greedy=greedy)
                    assert a1 == a2, (trial, s, greedy, a1, a2)

    def test_efe_deceptive_boundary(self):
        """H21 FALSIFIED PRE-RUN (unit test, KB amendment before H17c/H18):
        1-step epistemic value (EFE == count-bonus reduction) does NOT
        escape the deceptive tie-lock: bonus decays with visits, equal-count
        ties break toward quit (argmax convention), so the hold chain never
        completes at ANY tau_e. Passing requires a persistent value prior
        (optimistic init) or multi-step planning. Registered prediction
        amended accordingly.
        """
        for tau_e in (0.5, 3.0, 20.0):
            env = make("deceptive_10")
            ag = EFEAgent(env.n_obs, env.obs_type, env.n_actions, seed=1,
                          tau_e=tau_e)
            train(ag, env, total_steps=30000, eval_env=None, seed=1)
            ev = evaluate(ag, make("deceptive_10"), episodes=20)
            assert ev["mean"] <= 2.0, (tau_e, ev["mean"])

    def test_efe_works_where_bonus_suffices(self):
        """On chain_10 (no competing small reward, no tie-trap) EFE with a
        moderate tau learns the chain (bonus drives systematic advance)."""
        env = make("chain_10")
        ag = EFEAgent(env.n_obs, env.obs_type, env.n_actions, seed=2,
                      tau_e=1.0)
        train(ag, env, total_steps=60000, eval_env=None, seed=2)
        ev = evaluate(ag, make("chain_10"), episodes=30)
        assert ev["mean"] >= 0.5, ev["mean"]


# ---------------------------------------------------------------- SF
class TestSFGPI:
    def _small_grid(self):
        env = make("gridworld_dense")   # 6x6 dense reward gridworld
        P, R = env.mdp_model(0.99)
        V, Q, pol = value_iteration(P, R, 0.99)
        return env, V, Q, pol

    def test_sfql_single_task_converges(self):
        """SFQL Q = psi.w must approach Q* on a fully observable dense MDP."""
        env, V, Qstar, pol = self._small_grid()
        ag = SFGPI(env.n_obs, env.obs_type, env.n_actions, seed=0,
                   bonus=0.0, alpha=0.2, eps_decay=15000)
        train(ag, env, total_steps=120000, eval_env=None, seed=0)
        Q = np.array([[ag.q_gpi(s)[a] for a in range(env.n_actions)]
                      for s in range(env.n_obs)])
        # dense env: reward on every step -> psi.w approximates Q closely
        err = np.abs(Q - Qstar).max()
        assert err < 0.5 * np.abs(Qstar).max(), (err, np.abs(Qstar).max())

    def test_task_switch_freezes_and_gpi_recovers(self):
        """H19 mechanism unit: after learning task A, switch to task B
        (mismatch), learn B; the A-entry stays in the library and GPI with
        re-inferred w_A recovers A's value WITHOUT retraining."""
        envA = make("gridworld_decoy")  # reward: goal +1 / trap +0.5
        # task B: same dynamics, swapped rewards -> use reward params
        from axq.envs.antitests import DecoyGridWorld
        envB = DecoyGridWorld(step_reward=0.0, goal_reward=0.5,
                              trap_reward=0.0)   # different w, same dynamics
        ag = SFGPI(envA.n_obs, envA.obs_type, envA.n_actions, seed=0,
                   bonus=0.5, alpha=0.3, eps_decay=8000)
        train(ag, envA, total_steps=40000, eval_env=None, seed=0)
        evA1 = evaluate(ag, make("gridworld_decoy"), episodes=20)
        # ---- switch to task B (mismatch triggers freeze) ----
        train(ag, envB, total_steps=40000, eval_env=None, seed=1)
        assert ag._task_switches >= 1
        assert len(ag._library) >= 1
        evB = evaluate(ag, DecoyGridWorld(step_reward=0.0, goal_reward=0.5,
                                          trap_reward=0.0), episodes=20)
        # ---- k-shot re-inference of w_A, then GPI must recover task A ----
        ag.begin_inference()
        envA2 = make("gridworld_decoy")
        obs = envA2.reset(77)
        for _ in range(60):           # inference episodes (w-only updates)
            a = ag.act(obs, greedy=False)
            nobs, r, t, tr, _ = envA2.step(a)
            ag.observe(obs, a, r, nobs, t, tr)
            obs = nobs
            if t or tr:
                obs = envA2.reset(78)
        ag.end_inference()
        evA2 = evaluate(ag, make("gridworld_decoy"), episodes=20)
        # task A value recovered through GPI + re-inferred w (>= 80% of the
        # directly-trained performance; sparse goal => generous tolerance)
        assert evA2["mean"] >= 0.8 * max(evA1["mean"], 1e-9), \
            (evA1["mean"], evA2["mean"], evB["mean"], ag.diagnostics())

    def test_infer_mode_w_only(self):
        ag = SFGPI(4, "discrete", 2, seed=0)
        ag._psi[:] = 1.0
        ag._w[2] = 1.0                    # consistent reward -> no switch
        ag.begin_inference()
        ag.observe(0, 1, 1.0, 2, True, False)
        ag.end_inference()
        assert ag._w[2] == 1.0
        assert np.all(ag._psi == 1.0)      # psi untouched
        assert ag.visits.sum() == 0        # visits untouched
        # mismatch during inference DOES trigger the task switch (freeze)
        n_lib = len(ag._library)
        ag.begin_inference()
        ag.observe(0, 1, 1.0, 3, True, False)   # r=1 vs w[3]=0 -> switch
        ag.end_inference()
        assert len(ag._library) == n_lib + 1
        assert ag._task_switches == 1


# ---------------------------------------------------------------- MBTL
class TestMBTL:
    def test_single_task_vi_optimal(self):
        """Greedy act = VI on the learned model => optimal once covered."""
        from axq.agents.mbtl import MBTL
        from axq.envs.antitests import value_iteration
        env = make("gridworld_dense")
        P, R = env.mdp_model(0.99)
        V, Qstar, pol = value_iteration(P, R, 0.99)
        ag = MBTL(env.n_obs, env.obs_type, env.n_actions, seed=0, k_plan=10,
                  alpha=0.3)
        train(ag, env, total_steps=30000, eval_env=None, seed=0)
        ev = evaluate(ag, make("gridworld_dense"), episodes=20)
        # VI-planned greedy policy must be optimal (model complete)
        assert ev["mean"] >= 0.95 * (Qstar[0].max() * (1 - 0.99)
                                     + ev["mean"] * 0.99) - 0.15 or \
               ev["mean"] >= 0.9, ev["mean"]
        # direct check: VI Q on the learned model ~ Q* (model complete).
        # Terminal rows (goal) are excluded: the agent never acts from the
        # goal, so the model has no entries there and the self-loop default
        # is garbage-but-harmless (never propagates: term=True boot=0).
        Qvi = ag._vi(ag._w)
        env2 = make("gridworld_dense")
        goal_idx = env2.goal[0] * 4 + env2.goal[1]
        mask = np.arange(Qvi.shape[0]) != goal_idx
        diff = np.abs(Qvi[mask] - Qstar[mask]).max()
        assert diff < 0.05, diff

    def test_switch_freezes_library_and_kshot_recovers(self):
        """H23 mechanism: A -> B switch freezes w_A; k-shot inference on A
        identifies w_A and VI planning recovers optimal return."""
        from axq.agents.mbtl import MBTL
        from axq.envs.antitests import DecoyGridWorld
        envA = make("gridworld_decoy")
        envB = DecoyGridWorld(step_reward=0.0, goal_reward=0.5,
                              trap_reward=0.0)
        ag = MBTL(envA.n_obs, envA.obs_type, envA.n_actions, seed=0,
                  k_plan=10, alpha=0.3)
        train(ag, envA, total_steps=30000, eval_env=None, seed=0)
        evA1 = evaluate(ag, make("gridworld_decoy"), episodes=20)
        train(ag, envB, total_steps=30000, eval_env=None, seed=1)
        assert ag._task_switches >= 1 and len(ag._library) >= 1
        # k-shot inference on task A (belief elimination, exact VI)
        ag.begin_inference()
        e = make("gridworld_decoy")
        obs = e.reset(77)
        for _ in range(3):
            done = False
            while not done:
                a = ag.act(obs, greedy=False)
                nobs, r, term, trunc, _ = e.step(a)
                ag.observe(obs, a, r, nobs, term, trunc)
                obs = nobs
                done = term or trunc
            obs = e.reset(78)
        ag.end_inference()
        evA2 = evaluate(ag, make("gridworld_decoy"), episodes=20)
        assert evA2["mean"] >= 0.9 * max(evA1["mean"], 1e-9), \
            (evA1["mean"], evA2["mean"])

    def test_infer_mode_no_learning(self):
        from axq.agents.mbtl import MBTL
        ag = MBTL(4, "discrete", 2, seed=0, k_plan=5)
        ag.Q[:] = 1.0
        ag.begin_inference()
        ag.observe(0, 1, 1.0, 2, True, False)
        ag.end_inference()
        assert ag._w[2] == 1.0
        assert np.all(ag.Q == 1.0)          # no TD during inference
        assert len(ag._model) == 0          # no model update either
