"""Tests for axq.exp: statistics, journal, protocol, analysis.

Scope guard (parallel development): uses ONLY the existing envs
(one_step_bandit / multi_armed_bandit / contextual_bandit) and the
"random" agent via run_experiment's factory resolution -- never axq.agents
directly.
"""
import json
import math
import re

import numpy as np
import pytest

from axq.exp.analysis import (auc, forgetting_matrix, generalization_gap,
                              robustness_curve, sample_efficiency,
                              steps_to_threshold)
from axq.exp.journal import ExperimentJournal, code_fingerprint
from axq.exp.protocol import (ExperimentConfig, compare_runs,
                              run_experiment)
from axq.exp.stats import (bootstrap_ci, fdr_bh, holm, min_detectable_note,
                           paired_compare, summarize)


# ---------------------------------------------------------------------------
# 1. paired_compare: known shift
# ---------------------------------------------------------------------------
def test_paired_compare_known_shift():
    rng = np.random.default_rng(2)   # fixed seed: all 20 diffs positive
    b = rng.normal(0.0, 1.0, size=20)
    # Shift +2 with unit-scale method-specific noise: diff ~ N(2, 1), so
    # cohen_d_paired is finite and ~2. (A CONSTANT shift a = b + 2 would give
    # std(diff) == 0 -> d = inf by definition; that guard is tested below.)
    a = b + 2.0 + rng.normal(0.0, 1.0, size=20)
    r1 = paired_compare(a, b, seed=7)
    r2 = paired_compare(a, b, seed=7)
    assert r1 == r2                              # deterministic given seed
    assert r1["n"] == 20
    assert abs(r1["mean_diff"] - 2.0) < 0.5
    assert r1["wilcoxon_p"] < 0.01
    assert 1.7 <= r1["cohen_d_paired"] <= 2.3
    lo, hi = r1["bootstrap_ci95_mean_diff"]
    assert lo <= 2.0 <= hi
    assert r1["significant_005"] is True
    assert r1["rank_biserial"] == pytest.approx(1.0)   # all diffs positive
    # one-sided alternative must be at least as significant
    r_g = paired_compare(a, b, seed=7, alternative="greater")
    assert r_g["wilcoxon_p"] <= r1["wilcoxon_p"]


def test_paired_compare_constant_shift_guards():
    """Zero-variance and all-zero-difference edge cases."""
    b = np.arange(1.0, 11.0)
    r = paired_compare(b + 2.0, b, seed=0)       # constant diff of +2
    assert r["mean_diff"] == 2.0
    assert r["cohen_d_paired"] == math.inf
    assert r["wilcoxon_p"] == pytest.approx(2.0 * 0.5 ** 10)  # all one sign
    assert r["bootstrap_ci95_mean_diff"] == [2.0, 2.0]
    assert r["rank_biserial"] == 1.0
    assert r["significant_005"] is True
    # identical arrays -> all-zero differences
    r0 = paired_compare(b, b.copy(), seed=0)
    assert r0["wilcoxon_p"] == 1.0
    assert r0["cohen_d_paired"] == 0.0
    assert r0["rank_biserial"] == 0.0
    assert r0["significant_005"] is False
    assert "insufficient evidence" in r0["note"]
    # rank-biserial hand-check with a tie in |diff|:
    # diffs = [1, -1, 2] -> ranks(|d|) = [1.5, 1.5, 3]
    # r = (4.5 - 1.5) / 6 = 0.5
    rt = paired_compare([2.0, 0.0, 3.0], [1.0, 1.0, 1.0], seed=0)
    assert rt["rank_biserial"] == pytest.approx(0.5)
    # input validation
    with pytest.raises(ValueError):
        paired_compare([1.0, 2.0], [1.0])        # length mismatch
    with pytest.raises(ValueError):
        paired_compare([1.0], [1.0])             # n < 2
    with pytest.raises(ValueError):
        paired_compare([1.0, 2.0], [1.0, 2.0], alternative="bogus")


# ---------------------------------------------------------------------------
# 2. paired_compare under the null
# ---------------------------------------------------------------------------
def test_paired_compare_null():
    """True null: significant in at most 1/10 seeds; seed 0 not significant."""
    n_sig = 0
    for s in range(10):
        rng = np.random.default_rng(1000 + s)
        a = rng.normal(0.0, 1.0, size=30)
        b = rng.normal(0.0, 1.0, size=30)
        n_sig += int(paired_compare(a, b, seed=s)["significant_005"])
    assert n_sig <= 1                             # allow one rare false positive
    rng = np.random.default_rng(1000)
    a0 = rng.normal(0.0, 1.0, size=30)
    b0 = rng.normal(0.0, 1.0, size=30)
    r0 = paired_compare(a0, b0, seed=0)
    p_null = r0["wilcoxon_p"]                     # reported p for seed 0
    assert 0.0 <= p_null <= 1.0
    assert r0["significant_005"] is False
    assert "insufficient evidence" in r0["note"]


# ---------------------------------------------------------------------------
# 3. small-n warning
# ---------------------------------------------------------------------------
def test_small_n_note():
    rng = np.random.default_rng(5)
    b = rng.normal(0.0, 1.0, size=5)
    a = b + rng.normal(0.3, 1.0, size=5)
    r = paired_compare(a, b, seed=0)
    assert r["n"] == 5
    assert "0.0625" in r["note"]
    assert "suggestive" in r["note"]
    assert r["significant_005"] is False          # impossible at n=5 two-sided
    assert "0.0625" in min_detectable_note(5)
    assert "n>=6" in min_detectable_note(5)
    assert "0.0625" not in min_detectable_note(6)
    assert min_detectable_note(6).startswith("n=6")


# ---------------------------------------------------------------------------
# 4./5. multiple comparisons
# ---------------------------------------------------------------------------
def test_holm():
    out = holm([0.01, 0.04, 0.03], alpha=0.05)
    assert out["rejected"] == [True, False, False]
    assert out["adjusted"] == pytest.approx([0.03, 0.06, 0.06])
    # step-down stops after the first failure
    out2 = holm([0.20, 0.01, 0.30], alpha=0.05)
    assert out2["rejected"] == [False, True, False]
    assert out2["adjusted"][1] == pytest.approx(0.03)
    assert holm([], alpha=0.05) == {"adjusted": [], "rejected": []}
    with pytest.raises(ValueError):
        holm([0.5, 1.5])


def test_fdr_bh():
    out = fdr_bh([0.01, 0.04, 0.03], alpha=0.05)
    assert out["rejected"] == [True, True, True]
    assert out["adjusted"] == pytest.approx([0.03, 0.04, 0.04])
    assert fdr_bh([0.5, 0.5, 0.5], alpha=0.05)["rejected"] == [False] * 3
    assert fdr_bh([], alpha=0.05) == {"adjusted": [], "rejected": []}
    # consistency: BH never rejects where adjusted > alpha
    out3 = fdr_bh([0.01, 0.02, 0.5, 0.6], alpha=0.05)
    for adj, rej in zip(out3["adjusted"], out3["rejected"]):
        assert rej == (adj <= 0.05)


# ---------------------------------------------------------------------------
# 6. bootstrap CI sanity + empirical coverage
# ---------------------------------------------------------------------------
def test_bootstrap_ci_coverage():
    x = np.arange(1.0, 6.0)                       # mean 3, in [1, 5]
    lo, hi = bootstrap_ci(x, stat="mean", B=2000, seed=0)
    assert 1.0 <= lo < 3.0 < hi <= 5.0
    assert bootstrap_ci(x, stat="mean", B=2000, seed=0) == [lo, hi]
    med = bootstrap_ci(x, stat="median", B=2000, seed=0)
    assert med[0] <= 3.0 <= med[1]
    # empirical coverage of the true mean near nominal 95%
    master = np.random.default_rng(2024)
    reps, covered = 1000, 0
    for i in range(reps):
        sample = master.normal(5.0, 1.0, size=30)
        lo, hi = bootstrap_ci(sample, stat="mean", B=1000, seed=i)
        covered += int(lo <= 5.0 <= hi)
    coverage = covered / reps
    assert 0.90 <= coverage <= 0.99, f"bootstrap CI coverage={coverage}"


# ---------------------------------------------------------------------------
# 7. journal roundtrip
# ---------------------------------------------------------------------------
def test_journal_roundtrip(tmp_path):
    jpath = tmp_path / "nested" / "journal.jsonl"
    j = ExperimentJournal(jpath)
    assert jpath.exists()
    id1, id2 = j.next_id(), j.next_id()
    assert id1 != id2
    assert re.fullmatch(r"exp-\d{8}-\d{6}-001", id1)
    assert id2.endswith("-002")
    base = {"hypothesis_id": "H1", "env": "multi_armed_bandit",
            "agent": "random", "config": {"seeds": [0, 1]}, "seeds": [0, 1],
            "budget_steps": 1000, "status": "completed"}
    j.append({"exp_id": id1, **base})
    j.append({"exp_id": id2, **base, "hypothesis_id": "H2"})
    recs = j.load()
    assert len(recs) == 2
    for rec in recs:
        for f in ExperimentJournal.REQUIRED:
            assert f in rec
        assert len(rec["code_version"]) == 64
    # a fresh instance over the same file sees the same records
    assert ExperimentJournal(jpath).load() == recs
    # missing required field -> ValueError listing it
    bad = {k: v for k, v in base.items() if k != "hypothesis_id"}
    with pytest.raises(ValueError) as exc:
        j.append({"exp_id": "x", **bad})
    assert "hypothesis_id" in str(exc.value)
    # code fingerprint: stable, sha256 hex, only tracks axq/**/*.py
    fp1, fp2 = code_fingerprint(), code_fingerprint()
    assert fp1 == fp2 and len(fp1) == 64
    (tmp_path / "unrelated.py").write_text("x = 1\n")   # outside axq/
    assert code_fingerprint() == fp1


# ---------------------------------------------------------------------------
# 8. run_experiment end-to-end (random agent on an existing env)
# ---------------------------------------------------------------------------
def test_run_experiment_random_agent(tmp_path):
    results = tmp_path / "results"
    journal = ExperimentJournal(tmp_path / "journal.jsonl")
    cfg = ExperimentConfig(
        exp_id="t-random", hypothesis_id="H-rand", agent_name="random",
        agent_params={}, env_id="multi_armed_bandit", env_params={},
        seeds=[0, 1], budget_steps=1000, eval_interval=500,
        eval_episodes=5, tags=["smoke"])
    summary = run_experiment(cfg, results, journal=journal)
    out = results / "t-random"
    assert (out / "summary.json").exists()
    assert (out / "seed_0.json").exists() and (out / "seed_1.json").exists()

    s0 = json.loads((out / "seed_0.json").read_text())
    assert s0["seed"] == 0
    assert len(s0["curve"]) == 2                  # evals at 500 and 1000
    assert len(s0["rewards"]) == 5                # eval_episodes
    assert "rewards" not in s0["final_eval"]      # hoisted to top level
    assert s0["final_eval"]["mean"] == pytest.approx(
        float(np.mean(s0["rewards"])))

    assert len(summary["final_mean_per_seed"]) == 2
    assert summary["final_mean_summary"]["n"] == 2
    assert summary["final_mean_summary"]["mean"] == pytest.approx(
        float(np.mean(summary["final_mean_per_seed"])))
    assert "failure_rate" not in summary          # no reference_score set

    recs = journal.load()
    assert len(recs) == 1
    for f in ExperimentJournal.REQUIRED:
        assert f in recs[0]
    assert recs[0]["metrics"]["final_mean_per_seed"] == \
        summary["final_mean_per_seed"]

    # determinism: identical rerun reproduces identical numbers
    cfg2 = ExperimentConfig(
        exp_id="t-random-2", hypothesis_id="H-rand", agent_name="random",
        agent_params={}, env_id="multi_armed_bandit", env_params={},
        seeds=[0, 1], budget_steps=1000, eval_interval=500, eval_episodes=5)
    summary2 = run_experiment(cfg2, tmp_path / "results2")
    assert summary2["final_mean_per_seed"] == summary["final_mean_per_seed"]
    assert summary2["auc_per_seed"] == summary["auc_per_seed"]

    # reference_score -> failure bookkeeping (reference between the two
    # per-seed finals => exactly one failing seed)
    finals = summary["final_mean_per_seed"]
    ref = 0.5 * (min(finals) + max(finals))
    cfg3 = ExperimentConfig(
        exp_id="t-random-3", hypothesis_id="H-rand", agent_name="random",
        agent_params={}, env_id="multi_armed_bandit", env_params={},
        seeds=[0, 1], budget_steps=1000, eval_interval=500,
        eval_episodes=5, reference_score=ref)
    summary3 = run_experiment(cfg3, tmp_path / "results3")
    assert summary3["failure_rate"] == pytest.approx(0.5)
    assert sorted(summary3["failures_per_seed"]) == [False, True]
    assert summary3["reference_score"] == pytest.approx(ref)


# ---------------------------------------------------------------------------
# 9. analysis functions on hand-computed data
# ---------------------------------------------------------------------------
def test_analysis_functions():
    curve = [(0, 0.0), (1000, 0.5), (2000, 1.0)]
    assert steps_to_threshold(curve, 0.75) == pytest.approx(1500.0)
    assert steps_to_threshold(curve, 1.5) is None
    assert steps_to_threshold(curve, -0.1) == 0.0   # above at first point
    assert steps_to_threshold([], 0.5) is None

    # sample_efficiency: 1 of 2 runs reaches the target
    flat = [(0, 0.2), (2000, 0.2)]
    se = sample_efficiency([curve, flat], 1.0, fracs=(0.5, 1.0))
    assert se[0.5]["success_rate"] == pytest.approx(0.5)
    assert se[0.5]["n_reached"] == 1 and se[0.5]["n_runs"] == 2
    assert se[0.5]["median_steps"] == pytest.approx(1000.0)
    assert se[1.0]["median_steps"] == pytest.approx(2000.0)
    assert se[1.0]["success_rate"] == pytest.approx(0.5)
    se_all_fail = sample_efficiency([flat], 10.0, fracs=(0.5,))
    assert se_all_fail[0.5]["median_steps"] is None
    assert se_all_fail[0.5]["success_rate"] == 0.0

    # auc: flat curve == its value; linear ramp == half the top
    assert auc([(0, 0.6), (250, 0.6), (1000, 0.6)], 1000) == pytest.approx(0.6)
    assert auc([(0, 0.0), (1000, 1.0)], 1000) == pytest.approx(0.5)
    assert auc([], 1000) is None
    assert auc([(500, 0.7)], 1000) == pytest.approx(0.7)   # single point

    # forgetting matrix hand-check (2 phases x 2 tasks)
    fm = forgetting_matrix([[0.9, 0.2], [0.7, 0.8]], ["A", "B"])
    assert fm["forgetting"]["A"] == pytest.approx(0.2)    # 0.9 - 0.7
    assert fm["forgetting"]["B"] == pytest.approx(0.0)    # 0.8 - 0.8
    assert fm["mean_forgetting"] == pytest.approx(0.1)
    assert fm["positive_transfer"] == {"A": False, "B": True}
    with pytest.raises(ValueError):
        forgetting_matrix([[0.9, 0.2]], ["A", "B"])

    assert generalization_gap(0.9, 0.7) == pytest.approx(0.2)
    assert generalization_gap([0.9, 0.9], [0.7, 0.5]) == pytest.approx(0.3)

    rc = robustness_curve({0: 1.0, 1: 0.8, 2: 0.6})
    assert rc["slope"] < 0
    assert rc["slope"] == pytest.approx(-0.2)
    assert rc["intercept"] == pytest.approx(1.0)
    assert rc["area"] == pytest.approx(0.8)
    assert rc["mean"] == pytest.approx(0.8)
    rc_up = robustness_curve({0: 0.2, 1: 0.4})
    assert rc_up["slope"] > 0

    # summarize: population std
    s = summarize([1.0, 2.0, 3.0])
    assert s["n"] == 3 and s["mean"] == 2.0 and s["median"] == 2.0
    assert s["std"] == pytest.approx(np.sqrt(2.0 / 3.0))   # ddof=0
    assert s["min"] == 1.0 and s["max"] == 3.0


# ---------------------------------------------------------------------------
# 10. compare_runs over two tiny experiments
# ---------------------------------------------------------------------------
def test_compare_runs(tmp_path):
    results = tmp_path / "results"
    common = dict(agent_name="random", agent_params={},
                  env_id="multi_armed_bandit", seeds=[0, 1],
                  budget_steps=500, eval_interval=500, eval_episodes=3,
                  hypothesis_id="H-cmp")
    cfg_a = ExperimentConfig(exp_id="cmp-a", env_params={}, **common)
    cfg_b = ExperimentConfig(exp_id="cmp-b",
                             env_params={"seed_means": 8}, **common)
    run_experiment(cfg_a, results)
    run_experiment(cfg_b, results)

    journal = ExperimentJournal(tmp_path / "cmp_journal.jsonl")
    out = compare_runs(results, "cmp-a", "cmp-b", journal=journal)
    assert "wilcoxon_p" in out
    assert out["n"] == 2
    assert out["seeds"] == [0, 1]
    assert 0.0 <= out["wilcoxon_p"] <= 1.0
    assert out["metric"] == "final_mean"
    assert len(journal.load()) == 1
    out_auc = compare_runs(results, "cmp-a", "cmp-b", metric="auc")
    assert out_auc["n"] == 2

    # different seeds -> no pairing possible -> clear error
    cfg_c = ExperimentConfig(exp_id="cmp-c", env_params={}, seeds=[2, 3],
                             agent_name="random", agent_params={},
                             env_id="multi_armed_bandit", budget_steps=500,
                             eval_interval=500, eval_episodes=3)
    run_experiment(cfg_c, results)
    with pytest.raises(ValueError):
        compare_runs(results, "cmp-a", "cmp-c")
    with pytest.raises(ValueError):
        compare_runs(results, "cmp-a", "cmp-b", metric="bogus")


# ---------------------------------------------------------------------------
# exact Wilcoxon: DP enumeration vs brute force + published regression
# (audits 9-b/9-c: scipy method="exact" differs from the project's
# sign-flip convention on tied data)
# ---------------------------------------------------------------------------
def test_exact_wilcoxon_matches_brute_force():
    import itertools
    from scipy import stats as st
    from axq.exp.stats import _exact_wilcoxon_p
    rng = np.random.default_rng(42)
    checked = 0
    for _ in range(40):
        n = int(rng.integers(1, 11))
        d = rng.choice([-3.0, -1.0, -0.5, 0.0, 0.5, 1.0, 3.0], size=n)
        nz = d[d != 0.0]
        if nz.size == 0:
            continue
        ranks = st.rankdata(np.abs(nz))
        w_obs = float(np.sum(np.sign(nz) * ranks))
        ws = np.array([sum(s * r for s, r in zip(signs, ranks))
                       for signs in itertools.product([1, -1],
                                                      repeat=nz.size)])
        p_brute = float(np.mean(np.abs(ws) >= abs(w_obs) - 1e-12))
        p_dp = _exact_wilcoxon_p(nz)
        assert abs(p_dp - p_brute) < 1e-12, (nz, p_dp, p_brute)
        checked += 1
    assert checked >= 25


def test_paired_compare_published_regression():
    """e3-sparse AUC diffs must give the published exact p = 0.03125."""
    diffs = np.array([0.05, 0.1, 0.2, 0.0, 0.15, 0.15, 0.15, 0.0])
    r = paired_compare(diffs, np.zeros_like(diffs), seed=0)
    assert r["n"] == 8
    assert r["wilcoxon_p"] == pytest.approx(0.03125)
    # partial zeros do not silently change the convention:
    # n_eff=6, all positive -> two-sided p = 2 * (1/64) = 0.03125
    assert r["significant_005"] is True
