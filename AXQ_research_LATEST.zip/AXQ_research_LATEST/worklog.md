# AXQ-Universal Research Worklog

Multi-agent research log. APPEND-ONLY. Every agent appends its section with Task ID.
Protocol per user spec: hypothesis -> theory -> implementation -> code audit ->
experiment -> statistical analysis -> independent critique -> regression ->
reproduction -> decision.

---
Task ID: 0-init
Agent: main-orchestrator (Super Z)
Task: Session init, environment recon, plan, core contracts

Work Log:
- Recon: Python 3.12.14, numpy 2.1.3, scipy 1.14.1, numba 0.61.0, pytest 9.0.2.
  NO torch, NO gymnasium available. Hardware: 2 CPU cores, 4 GB RAM.
  Decision: pure-NumPy implementation. Own MLP+Adam (verified by finite-difference
  gradient checks), own Gymnasium-like env API (axq/core/env.py).
- No prior code in project (fresh start). Session start: 2026-10-08T19:22Z UTC.
- AXQ OPERATIONALIZATION (AXQ-DEF-1, documented assumption): no prior AXQ code
  exists in repo; AXQ-6 defined as K=6 head ensemble DQN: independent Q-MLPs,
  median aggregation for action selection, ensemble-disagreement exploration
  bonus, per-head target networks, per-head minibag subsampling (Bootstrapped
  DQN / SUNRISE line of work). To be validated vs DQN baseline, not assumed.
- Wrote core contracts (FROZEN for subagents):
  axq/core/env.py (EnvBase), axq/core/agent.py (AgentBase, RandomAgent),
  axq/core/runner.py (run_episode/evaluate/train, fixed eval seeds),
  axq/core/nn/mlp.py (MLP+Adam, grad-check tested), axq/envs/registry.py,
  axq/envs/bandits.py (L0 reference envs), axq/testing.py (check_env),
  conftest.py, tests/test_core.py.
- Benchmark ladder mapping (user L0..L21 -> feasible CPU set):
  L0 bandits/frozenlake/tiny gridworld, L1 control (own physics), L2 sparse
  exploration family, L3 memory family, L4 long-horizon chains, L5 deceptive
  rewards, L6 generalization split envs, L7 robustness wrappers (eval-time),
  L8 multitask/continual, L9 self-play/opponents (tic-tac-toe), plus antitests
  (decoy/reward-hacking probes) and unified stats protocol.
- Dispatched 4 parallel implementation subagents:
  A=1-a gridworld family, B=1-b control+wrappers+memory+chains+multitask+games,
  C=1-c agents (tabular/DQN/AXQ/History), D=1-d stats+protocol+journal.

Stage Summary:
- Contracts frozen; baseline test suite expected green before dispatch.
- Next: integration audit by main agent (Phase 2), experiments (Phase 3+).

---
Task ID: 1-d
Agent: subagent-D (Statistics & Experiment Infrastructure Engineer)
Task: axq/exp package (stats, journal, protocol, analysis) + tests/test_stats.py

Work Log:
- Read frozen contracts first (core/env.py, core/agent.py, core/runner.py,
  envs/registry.py, envs/bandits.py); no core files modified.
- axq/exp/stats.py: summarize (population std); paired_compare (Wilcoxon
  signed-rank + PAIRED-by-seed bootstrap percentile CIs for mean and median
  of the diff, cohen_d_paired with zero-variance guard -> inf/0, matched-pairs
  rank-biserial with tie-averaged ranks and zero-diff exclusion;
  significant_005 = p<0.05 AND 0 outside the mean-diff CI); independent_compare
  (Mann-Whitney U analogue); holm (step-down, monotone adjusted p) and fdr_bh
  (step-up, reverse-running-min adjusted p); bootstrap_ci; min_detectable_note
  (min two-sided Wilcoxon p = 2^(1-n); alpha=0.05 reachable only from n>=6).
- Spec deviation (scipy 1.14.1): stats.wilcoxon takes method="auto" (the
  renamed `mode` param); all-zero-differences edge case -> p=1.0 via guarded
  except. Test-1 spec "a = b + 2.0 gives d in [1.7,2.3]" is mathematically
  impossible (constant diff -> std=0 -> d=inf), so the known-shift test uses
  shift+unit noise (d~2.03, p~2e-6) and a separate test pins the constant
  guard (d=inf, CI=[2,2]).
- axq/exp/journal.py: code_fingerprint = sha256 over axq/**/*.py contents in
  sorted relative-path order (versioned header; verified: changes on edit,
  reverts on revert); ExperimentJournal = append-only JSONL, auto-stamps UTC
  ts + code_version, validates REQUIRED (ValueError lists all missing),
  next_id = prefix-YYYYmmdd-HHMMSS-CCC (per-instance counter + collision
  check), numpy/dataclass/set/Path-safe JSON encoding.
- axq/exp/protocol.py: LEVEL_BUDGETS per spec; ExperimentConfig dataclass
  (required fields keyword-only to keep the declared field order; unique
  seeds enforced); run_experiment (per-seed FRESH train env + FRESH eval env
  + agent seeded by the run seed; train() called WITH eval_env so curves and
  final_eval exist; persists seed_<s>.json + summary.json with per-seed
  finals, summarize(), AUCs, failure info vs reference_score, config dump,
  code fingerprint; journal record with all REQUIRED fields); compare_runs
  (paired-by-seed over summary.json, >=2 common seeds enforced, metrics
  final_mean|auc, journal comparison record).
- axq/exp/analysis.py: steps_to_threshold (linear interpolation, first-point
  rule documented), sample_efficiency (median over runs that reached + plain
  success_rate over all runs), auc (trapezoid/budget; flat curve -> its
  value), forgetting_matrix (forgetting_j = M[j][j]-M[-1][j];
  positive_transfer_j = M[-1][j] > M[0][j]), generalization_gap,
  robustness_curve (polyfit slope + level-span-normalized trapezoid area).
- make_agent integration: lazy import INSIDE run_experiment with a
  random-only fallback on axq.core.agent.RandomAgent; axq/agents is currently
  an empty placeholder namespace dir, so the fallback is active until
  Subagent C's make_agent lands (then it is used automatically, no change
  needed here).
- Tests: tests/test_stats.py, 11 deterministic tests, 2.1 s total: known
  shift; zero-variance/all-zero-diff guards; rank-biserial tie hand-check
  (diffs [1,-1,2] -> 0.5); null control (10 seeds, <=1 false positive, seed-0
  p reported; observed one raw Wilcoxon FP killed by the CI criterion);
  n=5 "0.0625" note; Holm hand-case [0.01,0.04,0.03] -> [T,F,F], adjusted
  [0.03,0.06,0.06]; BH hand-case all rejected, adjusted [0.03,0.04,0.04];
  bootstrap CI empirical coverage 0.925 in [0.90,0.99] (1000 reps, B=1000);
  journal roundtrip + missing-field ValueError + fingerprint stability;
  run_experiment end-to-end on multi_armed_bandit + random agent (seed files,
  summary, journal record, exact rerun determinism, failure_rate=0.5 vs
  reference); analysis hand-checks (1500 interpolation, AUC flat/ramp,
  2x2 forgetting matrix, robustness slope -0.2/area 0.8); compare_runs (n==2,
  aligned seeds, disjoint-seed and bad-metric errors).
- Verified: python -m pytest tests/test_stats.py -q -> 11 passed in 2.1 s;
  tests/test_core.py stays green (13 passed); combined 24 passed in 2.3 s.

Stage Summary:
- Statistics/protocol/journal/analysis infrastructure delivered and green;
  trust anchor for all Phase 3 experimental claims is in place.
- Notes for main agent (NOT fixed by me, core untouched): (1) train() only
  emits curve/final_eval when eval_env is passed — protocol.py always passes
  a fresh eval env; (2) train() overshoots total_steps at episode boundaries
  (documented in runner.py, budget-neutral since all methods share the loop);
  (3) axq/agents is an empty dir — protocol runs on the random-only fallback
  until Subagent C delivers make_agent.

---
Task ID: 1-c
Agent: subagent-C (Agent Engineer)
Task: axq/agents package (common, tabular, dqn, axq, frame_stack, registry)
      + tests/test_agents.py

Work Log:
- Read frozen contracts first (core env/agent/runner/mlp, envs registry,
  bandits); core untouched. Only assigned files written.
- axq/agents/common.py: ReplayBuffer (ring buffer on python lists, lazy numpy
  packing preserving obs dtype/shape; done=terminated ONLY; n-step windows
  never cross episode bounds: terminal -> flush chains of length 1..n all
  ending at the terminal (done=True); truncation -> end_episode() flushes
  partial chains with done=False); EpsilonSchedule (linear then constant);
  one_hot_batch; encode_obs. Each stored row carries its chain length
  ("n_lens" key in sample()); agents bootstrap with gamma**n_lens per
  sample — identical to gamma**n_step for every FULL chain, and the only
  mathematically correct discount for partial chains flushed at truncation
  (verified: forcing gamma**n_step blindly on partial chains gives wrong Q).
- tabular.py: TabularQ — Q update in observe (1-step TD, bootstrap on
  terminated only); update() returns {"td_error"}; count bonus
  count/sqrt(1+visits[s,a]) applies to the TRAINING deterministic branch
  only; greedy=True is the pure argmax of Q so evaluate() measures the true
  greedy policy (same convention in AXQ: no disagreement bonus under
  greedy). Requires discrete obs (ValueError otherwise).
- dqn.py: Double DQN. Internal ordering note: the online net's S2 forward
  (double action selection) is executed BEFORE the main S forward, because
  MLP.backward differentiates the LAST forward call's graph — the spec
  pseudocode order would backprop through the wrong graph. update_every
  gating on update() calls; warmup gate via is_ready(max(warmup,batch));
  target copy every target_sync GRADIENT steps; stats {loss, td_error_mean,
  q_mean}; save/load = npz weights (net+target) + json config, never the
  buffer; load falls back to path+".npz".
- axq.py: AXQ-6 — K head nets + K target nets (shared rng, deterministic
  order); act: per-action median across heads; greedy -> argmax median;
  training deterministic branch -> argmax(median + beta_explore * population
  std across heads); update: ONE shared batch, per-head minibag
  max(8,int(frac*B)) via rng.choice(replace=False), per-head double-DQN loss,
  backward+adam, all-head target sync every target_sync grad steps;
  q_diagnostics(obs); save/load all heads+targets.
- frame_stack.py: HistoryDQN(DQN) — discrete obs only; window of last
  history_len obs (oldest first, one-hot concat, dim=history_len*n_obs);
  reset_state clears a flag, first act after reset fills the whole window
  with the current obs; the replay buffer stores ready-made stacked rows
  (H_t, H_{t+1}) built from the agent's window, so sampled batches need no
  re-encoding (encode hooks overridden).
- axq/agents/__init__.py: AGENTS registry {random, tabular, dqn, axq,
  history_dqn}; make_agent with the exact frozen contract (random ignores
  n_obs/obs_type; unknown name raises KeyError). NOTE for 1-d/main: make_agent
  has landed — the random-only fallback in axq/exp/protocol.py is now
  superseded (it will pick up the real registry automatically).
- tests/test_agents.py: 12 tests, all with locally defined envs (TwoRoomMDP
  2-state delayed reward; TruncChain 3-state chain with forced mid-chain
  truncation; HiddenMarker POMDP) — zero dependency on parallel env work.
  Negative control verified: storing done=truncated collapses TruncChain Q
  to ~0.25-0.52 vs analytic ~0.97-1.0 (test fails as designed).
- Extra validation beyond the 12 tests (scripted runs): n_step=3 on
  TruncChain converges to 0.0035 max |Q-Q*| (partial-chain machinery exact);
  vector-obs DQN path (float64 [B,dim] packing) converges to machine
  precision; AXQ n_step=2/3 save/load roundtrips bit-identical; HistoryDQN
  save/load roundtrip identical actions.
- KNOWN BEHAVIOUR (not a bug, textbook n-step property): n_step>1 targets
  are behavior-policy returns inside the window (no importance sampling,
  Rainbow-style). On TwoRoomMDP, retained early-exploration rows give Q
  biased low (max err 0.40 at n_step=2, shrinking to 0.20 with faster eps
  decay). Exact-value experiments on tiny MDPs should use n_step=1 or
  decouple exploration data (fast eps decay / smaller buffer).
- Tests: python -m pytest tests/test_agents.py -q -> 12 passed in ~16 s
  (limit 180 s), stable across repeated runs; tests/test_core.py stays
  green (13 passed). Convergence margins are large: tabular ~1e-11,
  dqn/trunc-chain ~1e-16 vs tolerances 0.1/0.15; AXQ/HistoryDQN pass
  200/200 and 3/3 seeds.

Stage Summary:
- All five agents + registry delivered and green; RL semantics
  (terminated-vs-truncated, n-step partial chains, double-DQN selection,
  ensemble minibags) unit- and end-to-end verified against analytic Q*.
- No core bugs found; two handled-by-design notes: MLP.backward uses the
  LAST forward's cache (agents order forwards accordingly), and
  EnvBase.step sets truncated=True even when terminated=True (agents use
  terminated only, so the overlap is harmless).
- Next (main agent): integration audit + learning-curve tests on the
  gridworld/memory/chain envs once 1-a/1-b land.

---
Task ID: 1-a
Agent: subagent-A (Environment Engineer — GridWorld family)
Task: axq/envs/{gridworld,frozenlake,generalization,antitests}.py
      + tests/test_gridworlds.py

Work Log:
- Read frozen contracts first (core env/agent/runner, envs registry/bandits,
  testing.py); core untouched. Only assigned files written.
- axq/envs/gridworld.py: GridWorld base (obs=r*size+c, walls, absorbing goal,
  final-step diagnostics unique_states/success/steps, exact mdp_model(gamma)
  -> (P,R) [S,A,S] with goal self-loop at 0 reward, bfs_path/reachable
  helpers, _blocked/_obs/_after_move extension points), MazeRandom (perfect
  maze via randomized DFS on odd cells, regenerated per reset),
  DeadendMaze (strict dead-end bait corridors carved only where no corridor
  cell touches any free cell except its branch point; dead_end_visits
  counter + bait corridor records), KeysDoors (boundary column size//2-1
  sealed except one door; key in start half; obs=pos*2+has_key; augmented
  2S-state mdp_model; door blocked without key), DynamicObstacles (4
  unobserved obstacles, collision -1, "collision" info flag).
- axq/envs/frozenlake.py: classic 4x4 SFFF/FHFH/FFFH/HFFG; slip -> uniform
  random perpendicular; exact stochastic mdp_model.
- axq/envs/generalization.py: RoomNav — per-reset map seed sampled from
  split pool (train 10M..10M+99, test 20M..20M+999, disjoint), map built
  deterministically from default_rng(map_seed+offset) with BFS retry,
  start/goal Manhattan >= size; obs=(pos)*16+wallbits (border=wall);
  current_map_signature() hashable layout.
- axq/envs/antitests.py: DecoyGridWorld (trap (1,1) +0.5 terminal vs goal
  +1; trap_taken info; trap absorbing in mdp_model) + generic
  value_iteration(P,R,gamma) -> (V,Q,policy), lowest-index tie-break.
- Registered: gridworld_dense (L0), gridworld_sparse, maze_random,
  keys_doors, deadend_maze, dynamic_obstacles (L2), frozenlake_4x4 (L0),
  frozenlake_slippery (L2), room_nav_gen (L6), gridworld_decoy (L5).
- SPEC DEVIATIONS (all documented in code comments, driven by the spec's
  OWN hardness tests; population values measured at n=500..4000):
  (1) gridworld_sparse max_episode_steps 256->96: exact Markov-chain
      computation gives random-walk hit prob 0.501 at 256 steps, violating
      the spec's "random success < 0.35"; at 96 steps it is 0.160 (VI
      still solves: 14-step path, success 1.0).
  (2) maze_random 400->160: random success 0.38 at 400 vs spec bound 0.2;
      0.11 at 160.
  (3) keys_doors 256->160: random success 0.148 at 256 sits exactly AT the
      spec bound 0.15; 0.073 at 160 (optimal key->door->goal ~30 steps).
  (4) deadend_maze 200: inherited 400 gives random 0.28; kept as hard as
      the other L2 envs (0.084 at 200).
  (5) dynamic_obstacles: obstacles may STAY (lazy random walk) and spawn at
      Manhattan dist >=3 from start / >=2 from goal; beeline population
      success 0.35->0.40 (spec requires > 0.3 with margin; fixed-seed test
      sample measures 0.367 over 600 episodes).
  (6) deadend geometry: in a 9x9 odd-cell maze true length-3+ dead-end
      corridors only exist along the border ring; exactly 3 corridors are
      placed on every reset (verified 100/100), effective length 3-4
      (spec target 3-5), branching off the solution path first, then off
      free cells adjacent to it.
  (7) keys_doors start/goal were unspecified -> (0,0)/(7,7); key forced to
      the start half (otherwise unsolvable).
  (8) Reward semantics: entering the goal pays goal_reward ONLY (no step
      cost on the entering step), so optimal returns are 1-0.01*(steps-1):
      dense V*=0.95, decoy V*=0.87 (spec's "1-0.01*14~0.86" is the same
      optimum rounded differently).
- Tests: tests/test_gridworlds.py, 34 deterministic tests, ~1.0 s total:
  check_env on all 10 ids (+room_nav test split); VI hand-MDP (det+stoch);
  P-sums-to-1 on all mdp_model users; frozenlake slip probabilities exact
  (0.85/0.15 corner case); dense V[0]=0.95 & eval>=0.8; sparse VI success
  1.0 vs random 0.20 (<0.35); maze connectivity 50 resets + random 0.145
  (<0.2); keys VI 1.0 (per-episode layouts) + random 0.075 (<0.15) +
  door/key white-box semantics + obs parity; lake VI 0.775 vs random 0.010;
  dynamic beeline 0.367 (>0.3) + collision return exactly -1; room_nav
  pools disjoint + signature determinism (same seed -> identical layout,
  stable within episode, across instances) + obs wallbit encoding; decoy VI
  mean 0.87, trap 0/100, random trap 91/100 (>=5); deadend corridors are
  true dead ends (sealing the branch cell isolates them) + visit counting.
  Stable across PYTHONHASHSEED 0/1/42.
- Verified: python -m pytest tests/test_gridworlds.py -q -> 34 passed in
  ~1.0 s; tests/test_core.py stays green (13 passed).

Stage Summary:
- GridWorld family (10 envs across L0/L2/L5/L6) delivered, contract-clean,
  exactly solvable where required (VI margins: sparse/keys/lake/decoy all
  at their optima) and genuinely hard for random policies (documented
  fixed-seed sample values with population estimates).
- No core bugs found. Notes for other agents: (a) with gamma=1.0 and zero
  step costs, VI ties among ALL goal-reaching policies and argmax picks
  action 0 — use gamma<1 (e.g. 0.99) when extracting VI policies for
  gridworld_sparse/frozenlake (dense/decoy are tie-broken by their step
  costs); (b) mdp_model(gamma) ignores gamma — the tabular model itself is
  undiscounted; (c) DynamicObstacles.mdp_model intentionally models only
  the agent chain (VI on it = obstacle-blind beeline policy); (d) VI tests
  on per-reset-layout envs (keys_doors) must rebuild the model after each
  reset — same reset seed reproduces the same layout.

---
Task ID: 1-b
Agent: subagent-B (Environment Engineer — Control/Memory/Chains/Games)
Task: axq/envs/{control,wrappers,memory,chains,multitask,games}.py
      + tests/{test_control_envs,test_memory_chains,test_games_multitask}.py

Work Log:
- Read frozen contracts first (core env/agent/runner, envs registry/bandits,
  testing.py); core untouched. Only assigned files written.
- axq/envs/control.py (L1): CartPole (exact Barto/Sutton/Gymnasium equations,
  +1/step incl. terminal, |x|>2.4 / |theta|>0.2095 termination, U(-0.05,0.05)
  reset), CartPoleVStart (train=standard, test=x~U(-1.5,1.5), x_dot~U(-1,1),
  theta~U(-0.15,0.15), theta_dot~U(-1,1)), MountainCar (Gymnasium dynamics;
  vel clamped BEFORE position update as in Gymnasium), Acrobot (standard
  d1/d2/phi1/phi2 equations, theta=0 hanging convention, angles wrapped to
  [-pi,pi), vel bounds 4pi/9pi, semi-implicit "Verlet-style" Euler dt=0.2
  per spec, goal -cos(t1)-cos(t1+t2)>1), PendulumDiscrete (9 torques
  linspace(-2,2,9), thdot clamp [-8,8], quadratic cost).
- Acrobot physics validation (ad-hoc, not in suite): energy conserved to
  1.1e-4 relative over 2 s at dt=5e-4 with tau=0; dE matches the torque work
  integral int(tau*theta2dot)dt to 6e-4; hanging equilibrium stable;
  Lagrangian derivation cross-checked against the classic phi1/phi2
  formulation term by term (gym phi1 = negated row-1 RHS).
- axq/envs/wrappers.py (L7, eval-time, NOT registered): base Wrapper
  (delegates statics; separate RNG stream default_rng([seed,7919]) re-derived
  on seeded reset); ObsNoiseWrapper (vector: N(0, sigma*std_i) with std_i
  from a lazy 200-step random-rollout calibration cached per instance;
  discrete: w.p. sigma replace index with uniform), ActionDelayWrapper
  (FIFO of `delay` stale actions, init 0s), StickyActionsWrapper (w.p. p
  repeat previous executed), ObsDropoutWrapper (w.p. p -> zeros vector /
  index 0), ActionPermutationWrapper (fixed bijection from perm_seed,
  .permutation property). All pass check_env around cartpole (vector) and
  contextual_bandit (discrete).
- axq/envs/memory.py (L3): MemoryCorridor (symbol at t=0, L blank corridor
  steps, choice marker, +1 iff match; choice obs symbol-blind by design),
  DelayedMatch (random delay U[min,max] inclusive fillers, then choice),
  HiddenStateTask (hidden bit governs 4 identical rooms, +0.25 each).
  Registered memory_corridor_8/16/32/64, delayed_match_10_50,
  delayed_match_50_100, hidden_state.
- axq/envs/chains.py (L4/L5): ChainEnv (advance L times for one terminal +1,
  4L budget), DeceptiveChoice (1 now vs 10 after `delay` holds; quit=0),
  CreditAssignmentTask (5 vs 50 after 20). Registered chain_5/10/20/50,
  deceptive_5/10/25/50/100, credit_assignment.
- axq/envs/multitask.py (L8): SparseGridLayoutEnv — REUSES GridWorld from
  1-a (subclass; deterministic wall layouts from layout_seeds 101..105,
  ~25% interior walls, BFS-retry until reachable, sparse step_reward=0,
  150 steps); CartPoleWideStart (U(-0.3,0.3) all dims); TaskSequenceSuite;
  SUITES continual_gridworlds (5 tasks) + continual_cartpole (cp_normal,
  cp_wide, cp_normal2); run_task_sequence (one persistent agent, train()
  per phase, greedy eval on ALL tasks after each phase with held-out seeds
  eval_base_seed+1009*j; returns {"phases", "matrix"}); forgetting()
  (M[j][j]-M[-1][j], same convention as 1-d's forgetting_matrix).
- axq/envs/games.py (L9): TicTacToeVsOpponent (agent=X moves first, base-3
  obs from own perspective, n_obs=19683, illegal move=-1 forfeit, win +1/
  draw 0/ loss -1 delivered on the ending step incl. opponent's winning
  move; bots random/heuristic(win-block-center-corner)/minimax(memoized
  negamax, module-level value cache, random tie-break via env RNG));
  BotAgent (bot as AgentBase); SelfPlaySession (play_game collects
  transitions for BOTH agents from own perspectives, flushed at game end
  with the terminal reward on each agent's last move, observe+update in
  move order; illegal=forfeit, symmetric with the env; play_and_train
  alternates X/O roles; eval_vs_bot -> win/draw/loss rates). Registered
  tictactoe_vs_random/heuristic/minimax.
- SPEC AMBIGUITY RESOLUTIONS / DEVIATIONS (all documented in docstrings):
  (1) CartPole bang-bang test: pure push-in-direction-of-theta survives only
      ~43 steps mean (undamped chatter trips the angle limit; physics is
      exact Gymnasium), so the scripted bang-bang uses theta+0.3x+0.1*thd
      (mean ~498 steps > the required 80). Cart x still never exits first.
  (2) Acrobot scripted swing-up: constant +1 torque does NOT reach the goal
      height within 500 steps — verified under BOTH semi-implicit Euler and
      RK4 integration of the same ODE (0/12 seeds; constant elbow torque
      settles into a limit cycle below goal energy), so the test uses the
      classic energy-pumping controller tau=sign(theta2dot): 10/10 seeds in
      ~95 steps. Spec also said Gymnasium uses Verlet-style integration —
      actual Gymnasium uses RK4; followed the spec's explicit Verlet-style
      instruction (dynamics identical, integrator differs).
  (3) Acrobot obs: spec mandates 4-dim raw angles (Gymnasium exposes 6-dim
      cos/sin); followed spec.
  (4) cartpole_vstart distribution test: "abs mean of x" implemented as
      mean(|x|) — abs(mean(x)) concentrates at ~0 for symmetric U(-1.5,1.5)
      and would fail the spec's own thresholds.
  (5) MountainCar velocity-clamp order: Gymnasium clamps velocity before
      the position update; spec prose lists it after; followed Gymnasium
      per the "EXACTLY Gymnasium" instruction.
  (6) Reactive-cap test statistics: 200 policies x 300 episodes each
      (per-policy std 0.029) so max stays ~0.53 < 0.65 with large margin;
      with fewer episodes/policy the spec's threshold would flake.
  (7) DelayedMatch N ~ randint[min,max] read as INCLUSIVE (total steps
      N+2 <= delay_max+2 fits exactly at N=delay_max).
  (8) MemoryCorridor n_obs = 2S+L per spec (tight bound would be S+L+1;
      spec's value is a valid superset, marker id = S+L).
  (9) External (callable/AgentBase) opponent returning an illegal cell
      forfeits: agent +1, info "opponent_forfeit" (unspecified in spec;
      symmetric with the agent's own forfeit rule).
- Tests: test_control_envs.py 32 passed 0.7 s; test_memory_chains.py 41
  passed 1.4 s; test_games_multitask.py 37 passed 0.5 s (110 total, ~2.7 s;
  far under the 150 s budget), deterministic across repeated runs;
  tests/test_core.py stays green (13 passed; 123 combined).
  Coverage highlights: check_env on all 25 new env ids (+both vstart modes);
  CartPole physics invariants (monotone x under constant force, pole tips
  against push); random<120 vs bang-bang>80; MountainCar random/always-
  right 0 successes vs pumping >=30% (measured 20/20); Acrobot random mean
  return -495 <= -80 and pump swing-up 5/5; Pendulum random -1099 < -2 and
  step rewards <= 0; wrapper semantics via test doubles (OneBitEnv,
  ActionRecorderEnv) + noise bound |delta| <= 6*sigma*std over 500 steps;
  memory policies 1.0 on all corridor/delayed envs (100 eps each) and
  hidden_state score 4/4; reactive cap max 0.53 < 0.65 over 200 lookup
  policies x 300 eps; POMDP symbol-blindness property; chain optimum
  exactly L steps / reward exactly 1.0 (chain_50 mean 1.0); deceptive
  patient=10.0 (delay+1 steps) vs myopic=1.0 vs quit=0; credit_assignment
  50/5; tic-tac-toe: 8 win lines both players, env-level win/loss/draw,
  illegal forfeit, minimax never loses to random (0/200 random wins) nor
  to heuristic (0/200), heuristic beats random 0.997 > 0.6 over 300,
  minimax-as-X also unbeaten, SelfPlaySession 50 games with rewards in
  {-1,0,1}; multitask: all suite envs pass check_env, 5 distinct
  reachable layouts, run_task_sequence 3x3 matrix + bit-identical
  determinism, forgetting() hand-checked and end-to-end.

Stage Summary:
- 25 envs (L1 control x5, L3 memory x7, L4/L5 chains x10, L9 games x3)
  + 5 robustness wrappers + L8 continual-learning protocol delivered,
  contract-clean, seeded-deterministic, with physics validated beyond the
  suite (energy conservation, torque-work identity, RK4 cross-check).
- No core bugs found. Notes for other agents: (a) C: L3 memory envs are the
  HistoryDQN testbed — choice marker obs = n_symbols+corridor_len (corridor)
  / n_symbols+1 (delayed match); the t=0 symbol must survive the frame
  window (corridor_64 needs history_len >= 66 for pure frame stacking —
  recurrent/memory-augmented or long-window policies required there).
  (b) tictactoe obs space is 19683 (one-hot infeasible for tabular; use
  function approximation) and agents play X=first-mover; SelfPlaySession-
  trained agents drop straight into TicTacToeVsOpponent (identical
  perspective encodings). (c) D: wrappers are NOT registered envs — wrap
  any registered env at eval time for L7 robustness curves (sweep
  sigma/p/delay); run_task_sequence output feeds analysis.forgetting_matrix
  directly (same M[j][j]-M[-1][j] convention). (d) multitask imports
  axq.envs.gridworld (1-a) — if that module's GridWorld constructor
  signature ever changes, SparseGridLayoutEnv is the single touch point.

---
Task ID: 5-a
Agent: code-auditor (independent Code Auditor / Codebase Critic)
Task: Full adversarial audit of the scientific core: core/nn/mlp.py, core/runner.py,
      agents/{common,tabular,dqn,axq,frame_stack}.py, exp/{stats,protocol,journal}.py,
      envs/wrappers.py. READ/TEST-ONLY (throwaway verification scripts under
      /home/z/audit_tmp/, never in the project). Empirical verification, not
      just code reading.

Work Log:
- Baseline: python -m pytest tests/ -q -> 180 passed in 44.64 s, 0 failures.
- mlp.py: full-parameter central-difference gradient checks on 10
  seed/arch/activation configs (tanh+relu, 1-3 hidden layers): rel err <= 9e-10.
  Adam step matches an independent bias-corrected reference BIT-EXACTLY over 50
  steps; global-norm clip feeds clipped grads into the moments (verified via
  stored m); copy_from/set_weights/get_weights alias-free; soft_update math
  exact; backward uses the last forward's cache exactly as documented.
- common.py ReplayBuffer: hand-checked 3-step chains at termination (full+partial,
  done=True) and truncation (done=False, bootstraps from the truncation state);
  gamma^k exponents correct; chains never cross episode bounds; FIFO wraparound
  and eviction respected by sample(); randomized differential test vs a naive
  reference over 2000 trials (n_step 1..5, capacity 1..40, mixed term/trunc):
  0 mismatches. (An initial 32 "mismatches" were last-ulp float artifacts of
  Python 3.12's compensated sum() in MY reference, not library errors.)
- frame_stack.py HistoryDQN: scripted-episode proof that stored (H_t, H_{t+1})
  windows EXACTLY equal the windows act() sees at t and t+1; burn-in
  [obs0]*history_len; buffer rows hand-checked; end-to-end train determinism.
- dqn.py: instrumented forwards confirm order [target(S2), online(S2), online(S)]
  (the deliberate ordering for MLP's last-forward-cache backward); reported
  loss/td/q_mean reproduce exact double-DQN semantics (online selects, target
  evaluates) to 1e-12 on the exact sampled batch; backward grad == FD gradient
  of the double-DQN loss (rel 3.7e-10); grad scale 2/B*td; target sync exactly
  every target_sync GRADIENT steps under update_every gating; gamma_eff =
  gamma**n_lens; DQN converges to analytic Q* (err 0.0000, self-loop MDP with
  hand-solved Q*) and to exact time-limit-bootstrapped values [0.81, 0.9, 1.0]
  on a truncation chain; learns registered gridworld_dense to the VI optimum
  0.95 (bench.json's -1.0 is a default-hyperparameter artifact: eps_decay=10000
  > 8000-step bench budget).
- axq.py: minibag m = min(max(8, int(frac*B)), B) incl. B<8 cap; per-head
  subsampling without replacement, distinct bags; act = argmax(median) greedy /
  argmax(median + beta*population std) training branch (eps=0 forced); AXQ
  median-of-heads converges to analytic Q* (err 0.0000).
- tabular.py: TD hand-verified (bootstrap iff not terminated; truncation
  bootstraps); count bonus only on the training deterministic branch, greedy =
  pure argmax; discrete-obs guard; eps driven by observe() counter.
- runner.py: evaluate(greedy=True) leaves the agent RNG state and counters
  untouched for every learning agent; train() bit-identical across reruns;
  budget overshoot bounded by one episode; curve evals use fixed eval seeds.
- stats.py: wilcoxon_p == scipy direct (two-sided + greater); all-zero-diff path
  p=1.0 (scipy 1.14 raises; guard fires correctly); rank-biserial matches hand
  computation ([1,-1,2] -> 0.5); paired bootstrap CI reproduces manual
  pair-index resampling exactly; chunked bootstrap stream-identical to one draw;
  holm and fdr_bh match independent references over 200 random trials each plus
  hand cases; min-p 2^(1-n) note correct; MW U/rank-biserial/CI correct.
- protocol.py/journal.py: fingerprint stable/sensitive/reversible; journal
  REQUIRED validation lists all missing fields; next_id unique; run_experiment
  exact-rerun determinism; compare_runs pairs BY SEED VALUE (verified with
  reversed seed order in run B); duplicate/empty seeds rejected.
- wrappers.py: all 5 wrappers pass check_env on vector+discrete envs incl. a
  4-deep nested stack; same-seed determinism across instances; noise
  calibration deterministic + cached + identical across instances and does NOT
  disturb inner-env dynamics or per-reset maps (verified on room_nav_gen);
  noise is obs-only; delay FIFO init [0]*delay; sticky repeats previous
  EXECUTED action; dropout -> zeros/index 0; permutation is a fixed bijection
  from perm_seed, independent of reset seed.

FINDINGS (CONFIRMED BUGS — all LOW severity; no high/medium bugs in the
scientific core; nothing fixed per audit-only mandate):
1. exp/protocol.py:239-243 — dead None-guard in compare_runs: `float(va[s])`
   raises TypeError before the intended ValueError ("metric unavailable") can
   fire. Repro: auc_per_seed containing None (empty curve, e.g. budget <
   eval_interval) + metric="auc" -> raw TypeError. Fix: test None before float().
2. core/nn/mlp.py:84 — MLP.backward docstring says "Accumulates param grads"
   but Linear.backward REPLACES (dW = _x.T @ grad_out; verified: second
   backward overwrites, 10x grad -> exactly 10x norm, not 11x). Harmless for
   all current callers (backward->adam_step->zero_grad) but a docstring trap
   for gradient accumulation. Fix docstring (or use +=).
3. core/runner.py:7 — docstring "Eval never touches the training RNG stream"
   is false for RandomAgent (act() consumes RNG even when greedy). Holds for
   all learning agents (verified empirically). train() determinism unaffected.
SUSPICIOUS / NEEDS-TEST (not bugs today):
- mlp.py copy_from/set_weights do NOT reset Adam moments (verified _adam_t
  unchanged); stale-moment hazard ONLY if load() is ever called into an
  already-trained net (fresh-agent load, the documented path, is safe).
- protocol.py:89-102 _resolve_make_agent ImportError fallback silently degrades
  to random-only (dead code now; masks a broken axq.agents import only for
  agent_name="random").
- runner.py:81 curve x-values are NOMINAL eval_interval multiples; the actual
  step count at eval time can overshoot by up to one episode (fair across
  algorithms, slightly misleading as wall-clock progress labels).
- axq.py:7 "independent bootstraps of the data" overstates head independence
  (shared buffer + shared batch, per-head subsamples = minibag variant, a
  legitimate but weaker scheme than per-head replay masks).
- stats.py:145-149/217-221 exception-message matching ("zero"/"identical" in
  str(exc)) is scipy-version fragile (works on the pinned 1.14.1, verified).
- axq/results/bench.json dqn:gridworld_dense final_eval_mean=-1.0 is a
  hyperparameter artifact, not a learning failure (see DQN check above) — do
  not cite it as a capability result.

Stage Summary:
- VERDICT: scientific core is sound. All RL semantics (terminated-vs-truncated,
  n-step chains incl. partial-chain discounts, double-DQN selection/evaluation
  split, frame-stack window alignment, ensemble median/minibag), the NumPy
  MLP+Adam math, the paired statistics stack, and the L7 wrappers verified
  positively and empirically, including against analytic Q* values and
  independent reference implementations. 3 confirmed LOW-severity defects (1
  dead guard, 2 docstring inaccuracies) — recommend fixing in a cleanup pass
  before Phase 3 experiments; none blocks experimentation. Test suite: 180/180
  green. Throwaway audit scripts live in /home/z/audit_tmp/ (7 scripts, not
  part of the repo).

---
Task ID: 6-scout
Agent: research-scout
Task: Cycle-2 literature scout — verify established vs contested knowledge for
      planned targets (recurrent memory, count bonuses, continual learning,
      prioritized replay) + attribution audit of current AXQ-6 design. RESEARCH
      ONLY: 24 web searches + direct fetches of primary sources (arXiv/ar5iv/
      ICLR/PNAS pages; raw search artifacts in tool-results/scout/).

Work Log:
- Primary sources fetched and grepped verbatim: bootdqn (arXiv 1602.04621v3
  full HTML incl. App. D), SUNRISE (arXiv 2007.04938v4 full HTML), R2D2 (ICLR
  2019 virtual page + OpenReview forum + DI-engine docs; ar5iv mirror serves a
  WRONG paper for 1807.01239 — do not use that ID), C51 (ar5iv 1707.06887 incl.
  erratum), Rainbow (ar5iv 1710.02298), EWC (ar5iv 1612.00796 full RL section),
  Procgen (arXiv 1912.01588v2 full), plus search results for the rest.

RESEARCH BRIEF (established / implication for us):

1. Bootstrapped DQN, random priors, SUNRISE.
- Osband et al. NeurIPS 2016: K=10 heads on a shared trunk; online bootstrap via
  per-head Bernoulli masks (p=0.5 = double-or-nothing). Chain didactic result:
  any dithering (eps-greedy) strategy needs >= 2^(N-11) episodes; only
  boot-DQN scales gracefully -> our chain_20/50 + deceptive envs are a direct
  replication setup. CRITICAL APPENDIX FACT (Sec. 6.1 + App. D): in the final
  Atari experiments they set p=1 — masks OFF, plain ensemble — because
  "the algorithm performed similarly irrespective of p"; diversity came from
  random init + per-head target nets. Shared trunk needed 1/K gradient
  normalization (else premature convergence). Known instabilities: Frostbite
  crash; Montezuma reaches first key but fails to learn from it.
- Osband, Aslanides, Cassirer NeurIPS 2018 (Randomized Prior Functions):
  plain ensembles can be insufficiently diverse for deep exploration (heads
  share features and agree); untrainable random prior per head is the
  principled fix (approx. posterior sampling). Parallel: Pearce et al. 2018
  (anchored ensembles). So "minibag vs mask vs nothing" was empirically
  INERT on Atari-2016, while "no prior at all" is known to fail in other
  settings — contested, domain-dependent.
- SUNRISE (Lee, Laskin, Srinivas, Abbeel; ICML 2021): exactly two ingredients:
  (a) variance-weighted Bellman backups (per-head TD loss re-weighted by
  ensemble variance; biggest gains under NOISY rewards), (b) UCB action
  selection (mean + std) at inference; diversity via bootstrap with random
  init; compatible with SAC and Rainbow. VERIFIED: SUNRISE full text contains
  ZERO occurrences of "median" — it does NOT use median aggregation.
- Reproduction: no canonical open-source Boot-DQN reproduction; Henderson et
  al. AAAI 2018 ("Deep RL That Matters") documents seed/codebase variance;
  "Curse of Diversity" (Lin, D'Oro, Nikishin, Courville; ICLR 2024): diverse
  data-sharing ensembles can HARM individual members — caveat for
  disagreement-bonus exploration.
- IMPLICATION: AXQ-6 (separate nets + per-head minibags + disagreement bonus,
  NO random priors) sits in the "plain ensemble" regime. Expect parity on
  shallow-exploration tasks; the deep-exploration gain on chains/sparse mazes
  may REQUIRE random priors — add a random-prior flag before concluding
  "ensembles don't help". Osband-chain replication = expected win; median vs
  mean vs min aggregation = novel check (see 9).

2. Frame-stacking vs recurrent.
- Hausknecht & Stone 2015 (DRQN): with equal history length, recurrency is a
  viable alternative to stacking and is more robust to missing observations.
- R2D2 (Kapturowski et al. ICLR 2019): training RNNs from replay suffers
  "representational drift" and "recurrent state staleness" (parameter lag);
  fixes: store hidden state in replay + burn-in (unroll without loss);
  n-step double Q (n=5) + PER; first agent above human level on 52/57 Atari;
  memory leveraged in "unexpected ways" (incl. compensating for eps-greedy
  exploration), memory horizons on the order of hundreds of steps.
- Procgen (Cobbe et al. ICML 2020, App. H): single-frame ~ frame-stack-4 ~
  LSTM on most of 16 games (LSTM helps only where long memory is needed,
  e.g. Jumper) — a short window is enough when the task's memory horizon
  fits in the window.
- IMPLICATION: memory_corridor_8/16/32 are the frame-stack regime (window >=
  corridor+2 -> HistoryDQN should suffice = replication); corridor_64 (needs
  window >= 66) and delayed_match_50_100 are the recurrent regime where the
  GRU-DQN should win. For the NumPy GRU-DQN: store hidden state in the replay
  buffer (our buffer already stores ready-made rows — cheap) or accept and
  MEASURE staleness; burn-in is the established mitigation. HistoryDQN-vs-GRU
  at matched parameter count on corridor_64 is a clean novel comparison.

3. Count-based exploration.
- Tabular: Strehl & Littman 2008 (MBIE, JCSS): bonus ~ beta/sqrt(N(s,a)) is
  PAC-efficient; R-max (Brafman & Tennenholtz 2002) same family. Established
  as near-optimal tabular exploration.
- Deep: Tang et al. NeurIPS 2017 (#Exploration): hash states (SimHash) ->
  bucket counts -> bonus beta/sqrt(N); near-SOTA on hard-exploration Atari
  and gains in continuous control. Known issues: bonus coefficient beta is
  reward-scale sensitive; hash collisions; does not solve Montezuma.
- Critical counterpoint: Taiga, Fedus, Machado, Courville, Bellemare (NeurIPS
  2019 benchmark, arXiv 1908.02388): with the learner fixed, recent bonuses do
  NOT significantly beat baselines on Montezuma/hard-exploration set and
  often HURT performance on easy games (worse than eps-greedy).
- IMPLICATION: tabular count-bonus agent is a straightforward replication
  (should help on sparse maze/keys). Our obs are DISCRETE -> we can do EXACT
  state counts for the DQN (Tang et al.'s recipe without the hashing
  confound) — a clean instance of the method; expect possible DEGRADATION on
  dense-reward envs (Taiga) — report as predicted negative result, not a bug;
  normalize bonus by reward scale, sweep beta.

4. n-step returns in DQN.
- Established: multi-step targets trade bias for faster propagation; Rainbow
  used UNCORRECTED off-policy n=3; Rainbow ablation (Hessel et al. AAAI 2018):
  PER and multi-step were "the two most crucial components"; removing
  multi-step hurt early AND final performance.
- Hernandez-Garcia & Sutton 2019 (arXiv 1901.07510): systematic study of n,
  off-policy correction, target-update frequency — uncorrected off-policy
  n-step works well in practice; correction matters less than n and its
  interaction with target-update frequency.
- IMPLICATION: our uncorrected Rainbow-style n-step (1-c already verified the
  behavior-policy-window bias on TwoRoomMDP) is the standard convention —
  keep it; the known Q-bias-low effect from retained early-exploration rows
  is a textbook property; if exact-value claims are made on tiny MDPs, use
  n_step=1 or fast eps decay (already our documented practice).

5. Prioritized replay.
- Schaul et al. ICLR 2016: TD-error prioritization + importance-sampling
  weights (annealed beta) speeds learning across 49 Atari games; PER-DDQN
  median 124% vs DDQN 118% human-normalized (C51 paper table) — large mean
  gains, modest median gains.
- Rainbow ablation: PER among the two most crucial components (data
  efficiency); but Ceron et al. 2021 ("Revisiting Rainbow") report component
  importance shifts in reproductions/other environments — effect sizes are
  context-dependent.
- Criticism: Pan et al. (UAI 2022; arXiv 2007.09569): PER's benefits come
  with (1) OUTDATED priorities (stale TD errors, rare transitions
  under-corrected) and (2) insufficient sample-space coverage; alpha/beta are
  extra hyperparameters.
- IMPLICATION: PER is a low-risk sample-efficiency upgrade; at our small
  budgets expect gains concentrated on sparse/crash-heavy envs; our small
  buffers + fast-changing policies are exactly the "outdated priorities"
  regime — log sampled-transition age as a diagnostic (novel measurement).

6. Catastrophic forgetting / continual RL.
- French 1999 (TiCS review): catastrophic interference is intrinsic to
  distributed superposed representations; rehearsal (replaying old data) is
  the classical effective countermeasure — a conclusion that has held for
  25+ years.
- Kirkpatrick et al. PNAS 2017 (EWC), RL section, verified verbatim: 10 Atari
  games, randomized revisits; the EWC agent USED per-task short-term replay
  buffers AND per-game biases/gains; EWC "does not reach the score that would
  have been obtained by training ten separate DQNs"; oracle task ID only
  modestly better than inferred. I.e., EWC was never shown to work WITHOUT
  replay in RL, and never matched per-task specialists.
- Rolnick et al. NeurIPS 2019 (CLEAR / "Experience Replay for Continual
  Learning"): replay + behavior cloning greatly reduces forgetting in
  multi-task RL; even SMALL replay buffers retain most of the benefit.
- Setting matters: task-incremental with known boundaries (our suites) is the
  easy setting; domain-shift (CartPoleVStart/WideStart) is harder.
- IMPLICATION: expect rehearsal buffer > EWC in our continual suites — this
  is established; if EWC-without-replay beats rehearsal, suspect a bug. Novel
  checks: does AXQ-6's per-head structure change forgetting (head
  specialization) at our scale; transfer/forgetting matrix under domain
  shift rather than clean task switches.

7. Double DQN.
- van Hasselt 2010 (tabular): max-operator causes systematic overestimation;
  van Hasselt, Guez, Silver AAAI 2016: confirmed at scale in DQN; decoupled
  selection (online) / evaluation (target) reduces bias, improves stability;
  DDQN median 118% vs DQN 79% human-normalized (C51 paper table).
- Caveat: double estimators can UNDERestimate (Zhu et al. NeurIPS 2021).
- IMPLICATION: already implemented (selection/eval split verified in audit) —
  replication-safe. NOVEL CHECK unique to us: since our gridworlds expose
  exact Q* via VI, we can measure the over/under-estimation gap directly
  (mean max-Q vs Q*) — most papers cannot.

8. Distributional RL (C51).
- Bellemare, Dabney, Munos ICML 2017: categorical return distribution (51
  atoms); median human-normalized 178% vs DDQN 118%, PER-DDQN 124%, DQN 79%
  (57-game table; erratum: mean corrected 1010% -> 701% on evaluation
  protocol). One of the largest single-component effects in the DQN line.
  In Rainbow's ablation, distributional ranked mid (below PER/multi-step).
  Costs: |A| x 51 outputs + KL machinery + Vmin/Vmax tuning; QR-DQN (Dabney
  et al. 2018) improves further.
- IMPLICATION: biggest headroom after PER/multi-step, but 51 atoms x 6 AXQ
  heads is expensive on CPU; a scoped novel check is a small-support variant
  (5-11 atoms / few quantiles) on 2-3 envs; our O(1) reward scale makes
  Vmin/Vmax easy.

9. Median aggregation in ensembles.
- FACT (attribution audit): no standard deep-RL ensemble method uses
  median-of-Q-heads as its aggregator. Boot-DQN: per-head policies + majority
  vote at evaluation. SUNRISE: variance-weighted Bellman backups + UCB (mean
  + std) — no median anywhere (verified). Maxmin Q-learning (Lan, Pan, Fyshe,
  White; ICLR 2020) uses MIN to control estimation bias (handles both over-
  and under-estimation). EDL (Osband et al. 2023) uses mean + variance.
  Median-of-heads is supported only by the robust-statistics tradition
  (50% breakdown point; median-of-means: Alon et al. 1999, Lugosi &
  Mendelson 2019), not by an RL ablation.
- IMPLICATION: do NOT attribute median to SUNRISE/Osband in write-ups (0-init
  worklog already says "documented assumption" — keep it that way). Our
  median-vs-mean-vs-min ablation (K=6) is a genuinely novel check:
  hypothesis from robust stats = median ~ mean on clean envs, median wins
  when individual heads destabilize (noisy-obs wrappers are the testbed).

10. Negative results / capability-ladder benchmarks.
- bsuite (Osband et al. ICLR 2020): closest published analogue of our ladder
  — capability experiments with difficulty knobs (deep-exploration chains,
  memory-length corridors essentially isomorphic to our memory_corridor,
  noise, generalization, credit assignment, scale), scalar capability scores.
  Known headline: standard agents degrade sharply as memory length /
  exploration depth grows.
- Procgen — ATTRIBUTION FIX: the papers are COBBE et al. ("Quantifying
  Generalization in RL", ICML 2019; "Leveraging Procedural Generation...",
  ICML 2020; arXiv 1912.01588), not Cohen. Findings: PPO strongly overfits
  small level sets; recommended protocol = train on 500 levels, test
  held-out; closing the gap requires up to 10,000 levels; training
  performance roughly insensitive to level count while test performance
  grows (opposite of supervised learning).
- Epsilon-greedy at our scales: theory says dithering needs time EXPONENTIAL
  in the required horizon (Osband 2016 chain bound 2^(N-11); Kearns & Singh
  2002 line) -> chain_20/50 and deceptive_50/100 should be UNSOLVABLE by
  eps-greedy DQN at any tuned decay (a replication expectation, not a novel
  claim). On SMALL sparse gridworlds (<= ~100 states, random-hit prob >= ~5%
  per episode) eps-greedy solves them, just slowly — no published result
  contradicts that. Counter-warning: Dabney et al. 2020 (TiVA, arXiv
  2006.01782): temporally-extended eps-greedy matches sophisticated
  exploration on many domains; Taiga et al. 2019 (above): bonuses often fail
  to beat eps-greedy. Our room_nav_gen with 100 train layouts sits deep in
  the overfitting regime — expect LARGE train/test gaps (often most of the
  achievable return) per Procgen.
- IMPLICATION: DQN-fails-long-memory, big generalization gaps, ensemble-helps-
  chains are all REPLICATIONS (cite bsuite/Procgen/Osband). The novel
  territory is the interaction grid: median-aggregated boot-DQN x full
  capability ladder x robustness wrappers x self-play on CPU-scale pure
  NumPy — no published work covers that combination.

FLAGS (design-vs-literature contradictions to avoid):
- F1: Claiming "bootstrapped ensembles don't improve deep exploration" from
  AXQ-6 WITHOUT a random-prior arm is contradicted by Osband 2018 — add the
  flag (untrainable random prior per head) to axq.py before Phase-3 sparse
  conclusions.
- F2: EWC without replay beating rehearsal buffers would contradict
  Kirkpatrick 2017 (EWC used replay) and Rolnick 2019 — bug-suspect.
- F3: Median-aggregation citations must not say "SUNRISE median" — cite
  robust statistics + our own ablation.
- F4: Procgen citations must say Cobbe et al., not Cohen.
- F5: Rainbow component effect sizes are 200M-frame Atari effects; at 10^4-
  10^6-step budgets expect shrinkage (cf. Ceron et al. 2021) — power the
  comparisons accordingly (our stats protocol's MDD note applies).
- F6: Exploration bonuses hurting dense-reward envs is an EXPECTED published
  result (Taiga et al. 2019) — pre-register it as a predicted negative.

Stage Summary:
- All 10 topics resolved to primary sources; 6 flags for the main agent (F1
  random-prior arm is the highest-value design change before Phase-3 sparse
  exploration claims; F2-F6 are reporting/attribution guards).
- Cycle-2 priorities ranked by (established effect size x CPU feasibility):
  (1) count-bonus for DQN on discrete obs (exact counts — clean Tang et al.
  replication, trivial in our obs space), (2) rehearsal buffers for continual
  suites (established winner; cheap), (3) stored-state GRU-DQN (+burn-in
  optional) for corridor_64/delayed_match (R2D2 recipe), (4) PER with
  staleness logging, (5) median/mean/min + prior/none ablations (novel),
  (6) scoped small-support distributional head (novel, costliest).
- Artifacts: tool-results/scout/*.json (24 searches) + fetched primary-source
  HTML/PDF + this brief. No project files modified except this worklog entry.

---
Task ID: 4-final
Agent: statistician (independent verification)
Task: Statistical verification of all experiment claims (H1-H13), PAIR-table
audit, L6/L7/L8 assessment, verdict table, corrections for final report.
READ/ANALYZE ONLY (throwaway scripts under /tmp/statrev/; no project files
modified except this worklog entry).

Work Log:
- Verified headline H1 data: e3-sparse-axq final [1x8] (0 failures),
  e3-sparse-dqn final [1,1,1,1,1,0,1,1] (1 failure, seed 5); failure flags in
  summaries consistent with per-seed finals; pairing genuinely by seed value.
- Binomial assessment of 0-vs-1 failures at n=8: exact McNemar (1 discordant
  pair) p=1.0; Fisher exact two-sided p=1.0; Clopper-Pearson 95% CI on failure
  rates: AXQ 0/8 -> [0.000, 0.369], DQN 1/8 -> [0.003, 0.527]; Newcombe 95% CI
  on the failure-rate difference [-0.47, +0.22] (includes 0). Conclusion:
  8/8-vs-7/8 is DESCRIPTIVE ONLY, within noise; detecting 0% vs 12.5% at 80%
  power needs ~58 seeds/arm; McNemar needs >=6 discordant pairs for p<0.05.
- Found the one defensible significant AXQ-vs-DQN difference: AUC on
  gridworld_sparse at n=8: diff +0.10, exact Wilcoxon p=0.03125, bootstrap CI
  [0.05, 0.15] (excl 0), paired d=1.32; survives Holm in a 3-pair primary
  family (adj p=0.026) but NOT a 2-metric (final+AUC) Holm (0.0625).
- AUDIT BUG (reporting): stats.paired_compare uses scipy method="auto"; with
  zero/tied paired differences scipy silently substitutes a tie-corrected
  NORMAL APPROXIMATION (warning suppressed in aggregate output). Verified
  anti-conservative cases by brute-force exact permutation: chain_50 AXQ vs
  DQN reported p=0.0833 vs exact 0.25 (3 discordant + 2 zero diffs; Fisher
  exact two-sided 0.167, one-sided 0.083); sparse AXQ vs DQN final reported
  p=0.3173 vs exact 1.0 (single discordant pair). No sig verdict flips (all
  affected p>=0.05), but exact p-values must replace approximations in the
  report.
- PAIR-table census (81 pairs): 27 at n=3 (significance IMPOSSIBLE, floor
  p=0.25; includes d=64 acrobot-vs-random rows that read as "no difference");
  48 at n=5 (floor 0.0625); 6 at n=8; 7 rows with d=+/-inf (constant diffs ->
  "all seeds differ by exactly X", not infinite effect); 41 rows CI-excludes-0
  with p>=0.05 (= protocol "suggestive", effect consistent, power-limited);
  3 rows with raw p<0.05 (all sparse sanity checks: axq>random p=0.0078 =
  the n=8 floor) killed by Holm only because the family is ALL 21 pairs within
  env; in a 3-pair pre-registered family axq>random survives (adj p=0.0234).
  Family definition must be stated; no cross-hypothesis correction exists.
- L6 roomnav (n=5/point; 15/15 per-seed shards match aggregates): train
  0.926+/-0.005 / -2.144+/-0.833 / -2.421+/-0.203; test -2.532+/-0.034 /
  -2.546+/-0.028 / -2.560+/-0.000; gap 3.458+/-0.035 / 0.403+/-0.840 /
  0.139+/-0.203 at n_train_maps 5/25/100. Train-vs-test at n=5: exact p=0.0625
  (5/5 seeds). Test NEVER improves (floor ~-2.56); the "gap shrinks" trend is
  a floor artifact of train-side collapse (4/5 and 3/5 seeds fail to learn
  train maps at 25/100); MW gap 5->25 p=0.011, 25->100 p=0.556.
- L8 continual (persist n=3 vs fresh n=2): per-seed final_avg persist
  [0.2, 0.4, 0.0] vs fresh [0.0, 0.2]; MW p=0.76 (floor at 3v2 is 0.20);
  avg_forgetting IDENTICAL 0.4 vs 0.4; gw3 never learned in either arm (diag
  0) so forgetting[gw3]=0 is vacuous. "Rehearsal helps retention" NOT
  supported; anecdotal only.
- L7 robustness (n=5, paired): no condition significant (all exact p>=0.63);
  AXQ nominally worse at noise=0.1 (-30), delay=1 (-43), sticky=0.25 (-29),
  each driven by the single seed-2 checkpoint (baseline 492 vs others' 500);
  dropout=0.3 nominally better (+15, n.s.); auc_normalized 0.835 vs 0.818.
  FOUND: perm=999 is an IDENTITY permutation for 2 actions (rng(999) sample)
  -> the action-permutation condition is a NO-OP; permutation robustness was
  never actually tested.
- Cross-checks: repro_check 6/6 exact matches confirmed; H13 count arm ran
  seeds 0-4 only, where vanilla DQN is also 5/5 (its sole failure, seed 5,
  untested) -> paired diff 0, p=1.0; f4-prior (random-prior) arm has 3 seed
  files final=1.0 but NO summary.json -> not in ANALYSIS.json, must not be
  cited; f1-corridor64-history_dqn solved seed_0 (final 1.0) but n=1 and
  incomplete -> "GRU required at L=64" not established (only GRU vs memoryless
  DQN is suggestive: 3/3=1.0 vs 0.47+/-0.08, exact p=0.25, CI [-0.58,-0.42]).

Stage Summary:
- VERDICT TABLE (status at current n; protocol: sig = p<0.05 AND CI excl 0):
  H1 reliability SUGGESTIVE (8/8 vs 7/8 descriptive, McNemar p=1.0; AUC
  significant p=0.031); H2 parity SUGGESTIVE/parity-not-rejected (n=3, no
  equivalence test); H3 memory SUGGESTIVE (25/25 replications, p=0.0625
  floor, d 5.5-7.7); H4 chains NOT SUPPORTED (exact p=0.25, Fisher 0.167);
  H5 deceptive SUGGESTIVE (deterministic direction, sig impossible at n);
  H6 overfitting SUGGESTIVE, gap-closing NOT SUPPORTED (floor artifact);
  H7 robustness INCONCLUSIVE (perm condition invalid/no-op); H8 forgetting
  NOT SUPPORTED (identical avg_forgetting, MW p=0.76); H10 GRU SUGGESTIVE
  vs DQN, inconclusive vs HistoryDQN (n=1); H13 count-bonus INCONCLUSIVE
  (untested on the seeds where DQN fails).
- Corrections the report MUST incorporate: (1) 0-vs-1 failures = suggestive,
  report exact binomial/McNemar p=1.0 with CIs [0,37%]/[0.3,53%]; (2) AUC
  sparse result is the only significant AXQ-vs-DQN difference - label
  "significant uncorrected, borderline after 2-metric Holm"; (3) replace
  normal-approximation Wilcoxon p-values with exact ones (chain_50 0.0833 ->
  0.25; sparse 0.3173 -> 1.0); (4) tag all n=3 rows "descriptive, sig
  impossible" and d=inf rows "constant diffs"; (5) state the Holm family
  (within-env all-pairs, 21 in sparse) explicitly; (6) H6: test score flat at
  floor, gap trend is train-collapse artifact; (7) H7: drop/redo perm
  condition; (8) H8/H13 need more seeds (H8 >=5/arm; H13 needs seeds 5-7);
  (9) CartPole parity at score ceiling is uninformative; (10) finish or
  de-cite f4-prior and f1-history arms.

---
Task ID: 5-final
Agent: experiment-critic-redteam (Experiment Critic / Red Team)
Task: Adversarial review of the 7 headline findings before the final report.
      READ/VERIFY-ONLY on the project; throwaway scripts in /home/z/rt_tmp/
      (claim2_tabular.py, decep_dqn_seeds.py) + inline probes. Only this
      worklog entry appended.

Work Log:
- Inputs read: results/summary_table.txt, ANALYSIS.json, all seed_*.json and
  summary.json for the claim experiments, e6/e7/e8 JSONs, journal_*.jsonl
  (code-version timeline), scripts/{run_suite,run_generalization,
  run_continual,repro_check}.py, axq/envs/{chains,antitests,gridworld,
  generalization,memory,multitask}.py, axq/agents/{dqn,axq,tabular,gru_dqn}.py,
  axq/core/{runner,env}.py, docs/BENCHMARK.md.

CLAIM-BY-CLAIM VERDICTS (evidence in final message; short form):

1. AXQ 8/8 vs DQN 7/8 on gridworld_sparse — UPHELD, NEEDS REFRAMING.
   Numbers correct (e3-sparse-{dqn,axq}/summary.json: finals [1x8] vs
   [1,1,1,1,1,0,1,1]). Config parity verified: same budget 100k, ev 10k,
   ep 20, env_params {}, seeds 0-7, agent_params {} (class defaults; lr/
   gamma/buffer/batch/target_sync/eps-schedule/warmup identical). NOT an
   eval artifact: eval is greedy, deterministic env, 20 identical episodes;
   DQN seed_5 was 1.0 at 70/80/90k and 0.0 exactly at the 100k checkpoint
   (lengths all 96) = genuine transient policy collapse, NOT failure to
   learn (all 8 DQN seeds reached 1.0 at some point; mean-of-last-3-evals
   DQN 0.917 vs AXQ 1.000). Mid-training dips also in DQN seeds 2/3/6.
   Statistics: paired final Wilcoxon p=0.317, sig=False; AUC diff +0.100,
   p=0.026 raw (would NOT survive Holm in the 21-comparison family).
   Caveats: AXQ ran under a different code fingerprint (b94e39 vs de621b)
   — neutralized by repro_check 6/6 exact matches incl. e3-sparse-dqn s0
   and e3-sparse-axq s0/s1; AXQ per-head (48,48) vs DQN (64,64), total
   params 34,008 vs 8,580 (~4x), wall 2791s vs 426s (~6.5x compute).

2. Tabular myopic failures — UPHELD (genuine). Exact VI on the fully
   observed MDPs (env's own semantics, gamma=0.99): deceptive_50
   Q*(decision)={take-small:1.0, hold:6.05} -> hold optimal (10 > 1
   undiscounted); credit_assignment {5.0 vs 40.9} -> hold optimal (50 > 5);
   gridworld_decoy V*(start)=0.755 (goal) vs trap-path 0.49. So the myopic/
   trap choice is NOT optimal under the agent's own gamma — the failure
   claim stands. Mechanism proven by rerun with instrumentation: large
   reward experienced 0 times in 60k steps (deceptive_50, credit);
   decoy: goal reached 19 / 24,387 episodes (0.08%) vs trap 24,368 —
   eps-greedy lock-in (Osband dithering bound), not budget/eval-eps/gamma
   artifact. Nuance: deceptive/credit are POMDPs w.r.t. the hold counter,
   but memoryless-always-hold is still optimal — POMDP structure is not an
   excuse. Bonus probe: DQN escapes the attractor in 10/10 FRESH seeds
   (5..14) by 40k (total 15/15) — systematic, not seed luck; tabular cannot
   (exact Q ties -> action 0).

3. GRU corridor64 3/3 vs DQN 0.47 — UPHELD as capability claim, REFRAME.
   Budgets equal (60k both, summaries). GRU config tuned (hidden 64,
   lr 3e-3, batch 8, warmup 500) vs DQN defaults — but DQN's cap is
   STRUCTURAL: choice obs is symbol-blind by construction, reactive ceiling
   1/n_symbols = 0.5 (BENCHMARK.md + 200-reactive-policy test); DQN finals
   [0.58, 0.42, 0.42] = fixed-door policies on the 50 fixed eval episodes.
   "Caps at 0.47" is wrong wording — the cap is 0.5; 0.473 is the n=3
   sample mean. n=3 -> p=0.25, suggestive only. history_dqn arm incomplete:
   f1-corridor64-history_dqn has ONE stray seed_0.json from a different
   protocol (45,012 steps, 9k eval interval) — must not be pooled with f1.

4. count-bonus 5/5 vs plain DQN 7/8 — BROKEN as an advantage claim.
   Configs verified to differ ONLY in count_bonus=0.1 (summary.json
   agent_params {"count_bonus":0.1} vs {}; same env/budget/eval). BUT the
   seed sets differ (f5: 0-4; e3: 0-7). On common seeds 0-4 plain DQN is
   ALSO 5/5; own paired analysis: diff=+0.000, p=1.0. AUC 0.78 vs 0.75
   (negligible). f5 seed_0 itself dips to 0.0 at 30k — the bonus does not
   fix the endpoint instability. The 5/5-vs-7/8 contrast is a seed-set
   artifact.

5. e8 catastrophic forgetting with persistent replay (final_avg 0.2/0.1) —
   NEEDS REFRAMING (half acquisition, half forgetting). Matrices: gw2
   diag 1.0 -> final 0.0 and gw4 diag 1.0 -> final 0.33 = GENUINE
   forgetting despite persistent replay (and gw2 already erodes to 0.67
   during gw3's phase = forward interference). But gw3 was NEVER learned
   by ANY seed (diag 0.0 in 3/3), gw1 in 2/3 seeds (diag 0.33), gw5 in
   1/3 (diag 0.67) — acquisition failures: 20k steps/phase is below DQN's
   ~20-30k need on sparse layouts (cf. e3-sparse curves). The forgetting
   metric M[j][j]-M[-1][j] reports gw3 forgetting = 0 (blind to never-
   learned). persist n=3 vs fresh n=2, different seed sets — rehearsal
   comparison only suggestive (final_avg 0.2 vs 0.1).

6. L6 overfit/underfit — UPHELD with numbers corrected. Reward scale
   verified: -2.56 = exactly 256 steps x -0.01 (room_nav max_episode_steps
   256) = never reaching goal; test n5 mean -2.532 (3/5 seeds at the
   -2.56 floor, 2/5 with exactly 1/50 successful test episodes ~0.89).
   train n5 = 0.926 = at the 0.93 optimum (start/goal Manhattan >= 8) —
   full fit of 5 maps; test essentially 0 -> Procgen-style overfit.
   n25/n100 train means -2.144/-2.421 = mostly timeout on TRAIN maps =
   underfit at 100k. Eval counts: train score = final_eval over 20
   episodes on the train split (fixed seeds, same for all agents), test =
   50 episodes. For n5 (5 maps x 20 eps) tight; for n100 the train score
   is a 20-episode subsample of 100 maps — coarse; report as success
   rates. Train scores have checkpoint fragility too (n5 seeds 0/1/4 dip
   to -0.815 mid-training). Missing planned arms that must NOT be cited:
   e6 axq-n100, e6 vstart (dirs empty), f2-delayed-l (empty dir),
   f4-prior (3/5 seeds, no summary).

7. Eval-seed leakage — CLEAN / UPHELD. room_nav pools disjoint by
   construction: train seeds 10,000,000+[0,n), test 20,000,000+[0,1000);
   BFS-retry offsets <= 999 cannot bridge the 10M gap;
   test_room_nav_train_test_pools_disjoint passes (rerun: 5 passed).
   Training uses split="train" only; test split touched only by the final
   evaluate(). Fixed eval seeds shared across agents = intended pairing
   (documented). No leakage found.

SYSTEMIC FLAGS for the final report:
- n=3/n=5 claims (GRU, decoy-nn, credit-nn, e6, e8, f5) are below the
  project's own "n=8 for headline" rule -> label suggestive; even n=8
  sparse results die under Holm in the 21-comparison family (min raw
  p=0.0078 < required 0.0024) — report as descriptive.
- Single-checkpoint final_eval is fragile for DQN family (documented dips:
  e3-sparse dqn s5, f5 s0, e6-n5 train) — recommend mean-of-last-k evals
  as robustness metric in future.
- Code fingerprints drifted across runs (de621b -> b94e39 -> ec7c3be) and
  axq/ is untracked in git (single commit 18:40 covers .env only);
  mitigated by repro 6/6 — commit code per run going forward.
- AXQ compute asymmetry (6.5x wall, 4x params) intrinsic to the method —
  disclose in every AXQ-vs-DQN comparison.
- Incomplete/stray artifacts: f1-corridor64-history_dqn/seed_0.json
  (foreign protocol), f4-prior-sparse-axq (3/5, no summary), empty
  f2-delayed-l-gru_dqn dir, no e8 axq/cartpole arms, no e6 axq/vstart.

Stage Summary:
- 4 claims upheld (2 with reframing), 1 broken (count-bonus 5/5-vs-7/8),
  1 needs reframing (e8 forgetting = forgetting + acquisition mix).
- No eval-seed or train/test leakage found; core experimental hygiene
  (pairing, fixed eval seeds, config dumps, exact repro) verified sound.
- 10 concrete corrections for the final report (see final message).
- Nothing in the project modified except this worklog entry; verification
  scripts left in /home/z/rt_tmp/.

---
Task ID: 7-final
Agent: main-orchestrator (Super Z)
Task: Final documentation, corrections from reviews, session close

Work Log:
- Statistician (4-final): 81 pairs re-verified; exact Wilcoxon mandated
  (normal approx anti-conservative at ties: chain50 0.083->0.25); verdict
  table for 13 hypotheses; AUC sparse p=0.031 = only significant AXQ edge.
- Red Team (5-final): 7 claims attacked -> 3 upheld, 2 reframed (DQN seed5 =
  endpoint collapse not learning failure; e8 = forgetting + acquisition
  failure mix), 1 broken (count-bonus seed-set artifact), perm=999 invalid.
- Applied corrections: stats.py -> exact Wilcoxon w/ fallback (tests green);
  quarantined stray f1-history file (foreign 45k protocol); finalized
  f4-prior as honest n=3 job; refreshed ANALYSIS.json.
- Wrote docs: FINAL_REPORT.md, HYPOTHESES.md (verdict table), NEGATIVE_RESULTS.md
  (10 sections incl. unrun arms), PROTOCOL.md, RESEARCH_LOG.md, BENCHMARK.md.
- Final state: 192 tests passed; 66 experiments + specials (e6 sweep, e7
  robustness, e8 continual persist/fresh, repro 6/6); 6 agents; 38 envs.

Stage Summary:
- Session ~14h continuous. Headline: AXQ-6 = DQN everywhere except sample
  efficiency (AUC p=0.031 exact); structural findings (memory necessity,
  deceptive lock-in of tabular, catastrophic forgetting despite rehearsal,
  procedural-map overfitting, action-delay fragility) consistent in 100% of
  seeds but at the n=5 'suggestive' floor. Bottleneck ranking for cycle 3:
  continual learning > generalization-at-budget > deep exploration (n>=8).

---
Task ID: 8-kb
Agent: main-orchestrator (Super Z)
Task: Cycle-3 start; crash-safe Knowledge Base (user directive: subagent
data must survive agent crashes)

Work Log:
- Resumed from cycle 1-2 close-out (67 experiments, 192 tests, final docs).
- User directive: continuous autonomous research; parallel opus subagents on
  independent tasks (idea scouting/filtering, code review, testing); ALL
  useful subagent data must survive agent crashes.
- Built axq/kb/kb_tool.py: atomic O_APPEND JSONL collections (ideas,
  hypotheses, reviews, decisions, negative_results, experiments, notes,
  subagent_reports), 8KB line cap, heartbeat statuses (tmp+rename),
  snapshots, file-pointer protocol for long artifacts, add-file command.
  Self-test green.
- Wrote axq/docs/SUBAGENT_PROTOCOL.md: mandatory save-early-save-often
  protocol (read worklog -> register -> save EACH item immediately ->
  heartbeats -> final worklog append via >>).
- Cycle-3 plan (data-driven from FINAL_REPORT priorities): g1 flagship =
  continual learning (EWC / per-task heads / rehearsal, 30k steps/phase,
  n=5 seeds, acquisition+retention metrics); g2 = deep exploration n=8;
  g3 = GRU vs History on delayed_match_50_100; parallel subagent wave 1 =
  ideas scout (9-a), adversarial code audit (9-b), last-k metric
  re-analysis (9-c).

Stage Summary:
- Crash-safe KB online. Wave-1 opus subagents launching next; cycle-3
  implementation (agents/continual.py, run_continual2.py, EWC calibration)
  proceeds in parallel with subagents.

---
Task ID: 9-c
Agent: reanalyst (Re-Analysis Analyst)
Task: Независимый пересчёт ключевых сравнений с метрикой mean-of-last-k-checkpoints; вердикт какие выводы циклов 1-2 выживают

Work Log:
- Зарегистрировался по SUBAGENT_PROTOCOL; изучил схему seed-файлов: у всех
  e1-e5/f* есть curve=[(step,mean)...]; final_mean_per_seed == curve[-1][1]
  (0 расхождений); e6-seeds: 5-точечные train-кривые + test без кривых.
- 7 групп сравнений пересчитаны (old/last3/last5; paired_compare, n и сиды
  по пересечению): e3-sparse (n=8), e2-cartpole, corridors 8/16/32 (axq на
  32 НЕТ — задокументировано), chain50, decep50, f5-vs-e3 (пересечение 0-4),
  e6 n5/n25/n100. Каждый результат немедленно в KB (11 notes).
- Пересчёт AUC p=0.031 воспроизведён точно: zero-drop exact Wilcoxon
  (p=0.03125); paired_compare даёт 0.026 (anti-conservative при нулях).
- Отчёт: results/reanalysis_lastk/report.md + res_*.json per comparison.

Stage Summary:
- НИ ОДИН статистический вердикт не перевернулся (significant/parity
  идентичны при old/last3/last5) — выводы циклов 1-2 устойчивы к метрике.
- Уточнены 4 описательных утверждения: (1) chains «AXQ 3/5 vs 0/5» —
  чекпоинт-артефакт, при last-k разрыв исчезает (0.2 vs 0.133, rb 1.0->0.33);
  (2) e6-n5 train 0.926 — на деле пик с поздней нестабильностью 3/5 сидов
  (last3=0.579); (3) corridor8 AXQ 0.548 — шум финального чекпоинта
  (дизеринг 0.42/0.58), last-k возвращает к потолку 0.5; (4) надёжность
  e3-sparse: 8/8 vs 7/8 -> 8/8 vs 6/8 при last3>=0.9 (хрупкость в обе
  стороны: seed5 штраф old-метрикой избыточно, seed6 - недостаточно).
- Выжили полностью: AUC-эдж AXQ (p=0.031, единственный значимый результат);
  memory-сепарации; deceptive-прохождение NN; CartPole-паритет;
  count-bonus-негатив (артефакт сидов подтверждён на честном пересечении).
- Рекомендация для цикла 3: last3 (mean of last-3 checkpoints) как primary
  endpoint + AUC для sample efficiency + final как legacy-колонка один
  цикл; ≥3 чекпоинтов в последних 30% бюджета; secondary max-of-last-k для
  фазовых переходов; починить zero-handling в paired_compare (дроп нулевых
  диффов до exact-теста; сейчас p anti-conservative: chain50 0.083 vs exact
  0.25, AUC 0.026 vs 0.031).

---
Task ID: 9-a
Agent: idea-scout (Idea Scout, cycle-3 wave)
Task: независимый поиск и фильтрация идей для цикла 4 (continual / generalization / deep exploration)

Work Log:
- Читал протокол, FINAL_REPORT, NEGATIVE_RESULTS, последние ~100 строк worklog;
  код: agents/ (common/dqn/axq/continual), envs/ (multitask/chains/
  generalization/gridworld), scripts/run_continual2.py (g1-руки), bench.
- Сгенерировал и сохранил 19 идей в kb/ideas (по одной, немедленно):
  continual 7 (PackNet, task-inference domain-IL, LwF, pseudo-replay,
  OGD-lite + 2 scouted), generalization 6 (D4-aug, featurization, weight
  decay, curriculum, AXQ-на-room_nav + 1 scouted-диагностика), exploration
  6 (bootstrapped-commit, optimistic init, RND, Dyna-lite, variance-head
  + 1 scouted epistemic-VF). Все прошли фильтр: (a) CPU, (b) не дублируют
  NEGATIVE_RESULTS и g1-набор, (c) фальсифицируемые предсказания.
- Отклонены на фильтре (decisions): SI, Progressive nets, auto-aug policy
  search (RA2), eps-restarts, hypernetwork-heads.
- Web-поиск: 6 запросов (2024-2026), 4 релевантных scouted-записи с
  ссылками (arXiv 2609.35525, 2609.32532, ICML 2025 world-models,
  arXiv 2106.02940).
- Отбор top-5 по E×P/C + портфельное решение (5-е место, задокументировано
  в decisions); написал kb/files/9-a/top5.md: таблица скоринга 19 идей,
  детальные спецификации top-5 (файлы, алгоритмы, LOC, планы экспериментов,
  ожидаемые цифры, kill-criteria), fallback-иерархия, бюджет ~2.5 ч CPU.
- Зарегистрировал файл через add-file; статус done.

Stage Summary:
- 19 идей в KB; top-5 для цикла 4: (1) optimistic init (score 2.60,
  лечит документированный tabular lock-in: deceptive_50 1.0->10.0,
  chain_50 DQN >=3/8); (2) PackNet маски (2.40; retention >=0.7 без
  rehearsal); (3) bootstrapped-commit (1.80; chain_50 >=5/8 через
  по-эпизодный коммит головы AXQ); (4) task-inference domain-IL (1.65;
  MultiHead без task-ID, inference acc >=80%); (5) D4-симметрии (1.25;
  room_nav test -2.53 -> >0, портфельное место).
- Главный вывод: цикл 4 должен (а) дёшево закрыть два документированных
  структурных провала (tabular lock-in, map-overfit) механизмами, которых
  нет в g1, и (б) сделать step task-IL -> domain-IL, который превращает
  флагман continual в честный continual без оракула задачи.
- Быстрейший сигнал: optimistic init — ~15 мин CPU на весь блок.

---
Task ID: 9-b
Agent: code-auditor (adversarial review)
Task: Adversarial-аудит 9 файлов (dqn, common, mlp, runner, multitask,
run_continual, stats, journal, gridworld) перед циклом-3 флагманом g1.

Work Log:
- Протокол соблюдён: регистрация, 12 findings в KB reviews немедленно
  (по мере подтверждения), heartbeat, отчёт-файл, статус done.
- Прочитаны построчно все 9 файлов + доп. покрытие, критичное для g1:
  agents/continual.py, scripts/run_continual2.py, calibrate_ewc.py,
  spot-check forward/backward порядка в axq.py/gru_dqn.py, core/env.py.
- Числопроверки (kb/files/9-b/, без обучения, секунды CPU):
  verify_nstep.py (n-step chains vs brute-force; FIFO-симуляция e8),
  verify_stats_mlp.py (exact Wilcoxon vs sign-flip при ties; holm/fdr vs R;
  gradcheck MLP; LAST-graph semantics), verify_env.py (layout-детерминизм,
  вырожденность eval).
- Findings: 0 CRITICAL / 2 HIGH / 3 MEDIUM / 7 LOW.

Stage Summary:
- HIGH-1: e8 "persist" = ЧАСТИЧНЫЙ rehearsal: FIFO 50k < 100k переходов,
  gw1/gw2 полностью вытеснены к фазам 4-5 (симуляция: финал буфера
  {gw1:0, gw2:0, gw3:10k, gw4:20k, gw5:20k}). FINAL_REPORT §2.2 и H8
  требуют рефрейминга: чистый «forgetting despite rehearsal» подтверждён
  только для gw4 (1.0->0.33) и эрозии gw2 в фазе 3 (1.0->0.67); финал gw2
  0.0 — забывание БЕЗ rehearsal. g1 (буфер 200k) ловушку обходит.
- HIGH-2 (новое, g1-блокер): MultiHeadDQN trunk с LINEAR выходом +
  линейные головы = эффективная сеть с ОДНИМ tanh-слоем (у DQN — два).
  Arm dqn-heads-persist архитектурно слабее — сравнение arms сконфаундировано.
- MEDIUM: code_fingerprint слеп к scripts/*.py и чувствителен к
  axq/kb/*.py; run_continual2 рестарт-микс строк матрицы из разных попыток;
  eps не пере-аннелируется между фазами (конфаунд acquisition).
- Верифицировано SOUND: n-step семантика, Double-DQN порядок (все агенты),
  MLP (gradcheck 7e-11), exact Wilcoxon (ties == sign-flip, all-zero -> 1.0),
  Holm/BH (совпадают с R), bootstrap, layout-детерминизм, eval/train-сид
  гигиена, межпрогоновый детерминизм.
- Вердикт для g1: УСЛОВНО ГОТОВ — закрыть топ-3 (heads trunk tanh;
  restart-устойчивый summarize; fingerprint+scripts) до запуска. Детали:
  kb/files/9-b/audit_report.md.

---
Task ID: 11-a
Agent: re-reviewer (Code Re-Reviewer, adversarial re-audit)
Task: Повторный adversarial-ревью исправлений цикла 3 (H2/M2/M1 + chunk/DP/λ/fill_gaps) после аудита 9-b, вердикт для флагмана g1.

Work Log:
- Протокол соблюдён: регистрация, heartbeat, все находки в KB немедленно
  (8 reviews + 2 notes), верификационные скрипты + отчёт в kb/files/11-a/.
- A (continual.py tanh): FD-градиентная проверка всех параметров пути
  update() при double=True (max rel err 1.1e-6, фактор (1-h²) на месте,
  порядок графа корректен); паритет глубины/параметров с DQN (2 tanh +
  linear, 8580=8580); pytest 9/9. VERIFIED.
- B (run_continual2 chunk): stripe 2/3 воркера покрывает 25 (arm,seed)
  ровно раз; _complete_matrix/summarize edge-cases синтетически; замеры
  длительности по ts: DQN-джоб ~115 c, EWC ~160-190 c vs est_s=64.5 c
  (MEDIUM: риск kill последнего джоба чанка при timeout 570); summarize
  expected-якорь: неполный нижний сид → необработанный ValueError
  (MEDIUM, воспроизведён; не наступает при дисциплине summarize-after-
  exit-0); torn line → JSONDecodeError (LOW-MEDIUM); legacy-строки без
  run_id рестарт-миксятся (LOW; в g1/calib legacy-строк нет).
- C (stats.py DP): brute-force 900 проверок (3 альтернативы, ties,
  w_obs=0) — 0 расхождений; n=25 float64-точно (2/2^25); n_eff-note
  корректен; pytest 13/13. VERIFIED.
- D (journal fingerprint): стабилен, kb/ исключён, scripts/*.py (13)
  включён; хэш e4-corridor32-axq summary совпадает. VERIFIED.
- E (fill_gaps): формат summary.json = референс e4-corridor32-dqn;
  analyze_results.py совместим; артефакт полон (final 0.452 vs dqn
  0.484, AUC 0.352 vs 0.381, 5 сидов, code_version текущий). VERIFIED.
- F (λ): пересчёт по поправленному правилу из ewc_calibration.json —
  λ*=3 детерминирован (ret1: 0.1→0, 1→0, 3→1), подгонки нет (держаут
  100/101, регистрация до прогона); g1 действительно идёт с λ=3 во всех
  строках. НАХОДКА: calibrate_ewc.py/JSON содержат старое правило
  (lambda_star=0.1) — артефактное противоречие (MEDIUM, документационное);
  chunk default λ=100 ≠ 3 — мина тихого mixed-λ при рестартах без
  --lambda 3 (MEDIUM, процедурный).

Stage Summary:
- Вердикт для g1: GO-WITH-NOTES. Ни одна находка не инвалидирует
  собранные/будущие данные; руки пересчитывать не нужно. Условия:
  (1) summarize только после chunk exit 0; (2) все рестарты чанков строго
  с --lambda 3; (3) после прогона — amend-запись правила λ в calib;
  torn-line/legacy/expected-фиксы — backlog цикла 4.
- Все 3 must-fix аудита 9-b (H2 trunk-tanh, M2 run_id-summarize, M1
  fingerprint) реализованы корректно и верифицированы независимо.
- Ops-наблюдение: на 11:57Z 7/25 джобов g1 готово (persist s0-3, fresh
  s0/2/4), активных чанков не видно с 11:49 — оркестратору перезапустить
  (resume скипнет готовое) с --lambda 3.
- Отчёт: kb/files/11-a/review.md (+ verify_edge_cases.py,
  verify_head_grad_fd.py, verify_wilcoxon_bruteforce.py).

---
Task ID: 10-11 (orchestrator)
Agent: main-orchestrator (Super Z)
Task: Cycle-3 flagship g1 implementation, audits, calibration, execution

Work Log:
- Wave-1 subagents (opus, parallel): 9-a ideas (19 saved, top-5 specs),
  9-b adversarial audit (12 findings: H2 trunk-collapse, H1 e8 partial
  rehearsal, M1 fingerprint, M2 summarize mixing), 9-c last-k re-analysis
  (no statistical verdict flipped; AUC edge reproduces p=0.03125; chains
  result was a checkpoint artifact).
- Applied must-fixes: tanh trunk (H2) + FD-test, run_id summarize (M2),
  fingerprint scripts/+no-kb (M1), own DP exact Wilcoxon (scipy
  method=exact tie-distribution diverges from sign-flip convention:
  0.0260 vs 0.03125), n_eff notes. 203 tests green.
- EWC calibration (seeds 100-101, 30k/phase): sharp stability-plasticity
  cliff between lambda=1 (ret1=0) and lambda=3 (ret1=1.0, acq2=0);
  pre-registered guard rule degenerate (lambda*=0.1, zero protection) ->
  AMENDED rule (smallest lambda with ret1>=0.5) -> lambda*=3, registered
  in KB before main run.
- Chunked execution model (sandbox kills background processes): resumable
  drivers, per-phase JSONL, run_id, exit-code 3 protocol.
- g1 flagship COMPLETE (25/25 runs, 5 arms x 5 seeds x 30k x 5 phases):
  heads-persist dominates (ret 0.65 vs 0.10, d=+1.48, BWT +0.20, negative
  forgetting); full rehearsal does NOT help retention (H9a refuted) and
  hurts acquisition; EWC lambda=3 = perfect stability / zero plasticity
  (acq collapse -0.40, 5/5 seeds, p=0.0625); ewc-persist = worst of both.
- Gap-fill e4-corridor32-axq complete (final 0.452 vs dqn 0.484 - parity).
- Wave-2 re-review (11-a, opus): GO-WITH-NOTES; fixes verified
  (FD-gradcheck 1.1e-6, DP-Wilcoxon 0/900 mismatches, fingerprint stable);
  4 procedural findings applied (est_s, summarize anchor, torn lines,
  lambda pinning).
- n=8 replication of headline pair (dqn-persist, dqn-heads-persist seeds
  5-7) launched; red-team 12-a (opus) attacking g1 conclusions in
  parallel.

Stage Summary:
- g1 n=5 done: task-IL heads + trunk rehearsal is the only arm with real
  retention (0.65) and positive backward transfer; full rehearsal is net
  harmful at this budget; EWC shows a replication-stable stability-
  plasticity cliff. All at n=5 suggestive floor; n=8 extension running.

---
Task ID: 12-a
Agent: red-team (Failure Analyst)
Task: Adversarial-атаки на выводы g1 (continual, n=5 + n=8) до финального
отчёта: альтернативные объяснения, нарушения протокола, ошибки интерпретации.

Work Log:
- Протокол: регистрация, heartbeat, все находки немедленно в KB (5 reviews +
  3 notes + 1 amend), отчёт + верификационные скрипты в kb/files/12-a/.
- Прочитаны: пререгистрация H9 (hypotheses), поправка λ-правила (decisions),
  код continual.py / run_continual2.py / runner / multitask / gridworld,
  ewc_calibration.json, все 40 jsonl g1 + calib.
- verify_g1.py: integrity (run_id/фазы/бюджеты/λ/torn lines), recompute всех
  summary-метрик из jsonl, cross-arm phase-0 детерминизм, BFS hardness
  layout-ов, статус расширения. stats_n8.py: n=8 статистика (модуль проекта)
  + brute-force Wilcoxon + Fisher + Holm-математика. Детерминизм-чек:
  повторный phase-0 прогон воспроизводит grid байт-в-байт.

Stage Summary:
- (1) Heads-«победа»: валидна ТОЛЬКО как task-IL vs task-free верхняя
  граница; НОВАЯ находка: сьют = shared-obs конфликт (оптимальные действия
  конфликтуют на 28-62% общих клеток; единственные multi-task финалы —
  наименее конфликтная пара gw4+gw5) => domain-IL retention структурно
  ограничен сьютом. H9b-конъюнкция не подтверждена (acquisition хуже 5/8).
- (2) «H9a refuted» — OVERCLAIM: kill-criterion не выполнен (знаки 1+/1-/3
  нулей, p=1.0); честный вердикт not supported / inconclusive at floor.
  Retention на приобретённых: persist 1/11 vs fresh 2/15 — gw3-пол нуль не
  спасает; механизм — conflicting targets uniform-replay.
- (3) EWC: acquisition блокируется ПЕРВОЙ консолидацией (0/20 задач 1-4),
  не суммой якорей; «perfect stability» — только финального состояния (gw1
  транзиентно теряется в 3/4 удержанных сидов, avg_forgetting=0 вводит в
  заблуждение); Fisher-on-mixed-buffer реализован, но почти не влияет.
- (4) Отрицательное забывание heads: НЕ шум (детерминизм), но 100% событий
  = late acquisition проваливших фазу задач через per-head replay (вкл.
  единственное устойчивое решение gw3); контрапункт: heads s6 (n=8) —
  полная потеря через trunk-drift.
- (5) Гигиена CLEAN: summaries точно воспроизводятся; phase-0 строки
  идентичны по 4 DQN-рукам; eval/train-сиды без утечек; eviction нет.
  Косметика: ewc_lambda в не-EWC jsonl (инертно), 2 устаревшие journal-записи,
  драйвер отредактирован между grid и расширением (dad4c7d→43eb8228;
  эквивалентность run_one доказана воспроизведением).
- (6) Мощность: при n=5 NOTHING significant возможно (пол 0.0625 > 0.05);
  Holm-12 недостижим и при n=8 (нужно n_eff>=9). ГЛАВНОЕ: n=8 расширение
  УЖЕ ЗАВЕРШЕНО (6/6 прогонов) — пересчёт: retention diff +0.469, exact
  p=0.03125 raw (6+/1-/1 tie, d=1.14, CI [0.19,0.72]), Holm-3 adj=0.094 —
  НЕ significant после честной поправки; seed 6 разворачивает знак.
  Task-level 12/14 vs 2/18 (Fisher 3.7e-05, кластеризовано — descriptive).
- Требования к отчёту: перегенерировать summarize/compare (устарели, n=5);
  указать семейство m=1/m=3 и оба fingerprint; убрать «refuted»/«significant»
  без квалификации; ограничения: бинарный эвал, gw3-потолок, eps, бимодальный
  gw1, shared-obs конфликт.
- Отчёт: kb/files/12-a/redteam.md (+ verify_g1.py, stats_n8.py, rt_check/).

---
Task ID: 13-close
Agent: main-orchestrator (Super Z)
Task: Cycle-3 close-out: docs, KB, verification

Work Log:
- n=8 headline re-summarized: retention 0.562 vs 0.094 (+0.469, exact
  p=0.03125 at m=1, d=1.14, CI [0.19;0.72]; Holm-3 adj=0.094 not
  significant); acquisition cost -0.15 (p=0.48, ns).
- Red-team 12-a (opus) verdicts adopted: H9a "refuted" -> "NOT SUPPORTED /
  INCONCLUSIVE at floor" (kill criterion unmet); heads win framed as
  task-IL upper bound (oracle + shared-obs conflict 28-62%); EWC
  stability is final-state-only (transient gw1 losses 3/4 seeds).
- Docs updated: FINAL_REPORT section 6-7 (cycle-3 results + cycle-4
  priorities), HYPOTHESES H9a-d verdict rows, NEGATIVE_RESULTS sections
  11-12, RESEARCH_LOG cycle-3 chronology.
- KB final state: 80 records (19 ideas / 29 reviews / 8 decisions /
  21 notes / 2 experiments / 1 hypothesis pre-registration), snapshot
  kb_2026-10-09T125012Z.json; all wave heartbeats 'done'.
- Targeted test suites green (47 passed: stats/continual/agents/core).

Stage Summary:
- Cycle 3 COMPLETE. Headline: task-IL heads + per-head replay = only arm
  with real retention (p=0.03125 raw, d=1.14); full-buffer rehearsal not
  supported & likely harms acquisition; EWC replicates a sharp
  stability-plasticity cliff (0/20 later-task acquisitions at protective
  lambda). Bottleneck refined: task-inference without oracle + conflict-
  aware suite. Cycle-4 queue: task-inference domain-IL, PackNet,
  optimistic init, continual-suite v2.

---
Task ID: 14-18 (orchestrator)
Agent: main-orchestrator (Super Z)
Task: Cycle 4: zip packaging, preregistration, tabular correctness proof,
replication (H14/H15/H16), sensitivity + new architectures

Work Log:
- Task 14: scripts/pack_project.py; AXQ_research_cycle3-final.zip (5.4MB,
  1428 files) + LATEST; rule: re-pack after every final milestone.
- Task 15: PREREG_CYCLE4.md + KB 25e3df387463 BEFORE runs (families R/S/N,
  power analysis, kill criteria). Confound found pre-run: tabular
  eps_decay=20000 vs dqn/axq=10000 in e5.
- Task 16 (H17a): VERIFIED tabular Q-learning correctness off-policy:
  decoy ||Q-Q*||inf=0.0000 (alpha=0.1, 500k steps); deceptive_50/credit
  hold_biased behavior learns optimal 10.0/50.0; uniform: 0 large events in
  500k (math: (eps/2)^(d+1)). e5 failure = exploration-strategy property,
  NOT a bug. h17a_tabular_verification.json.
- New agents: DynaQ (k_plan=20, planning never touches schedule/visits;
  k=0 == TabularQ byte-identical), EFEAgent (reduction to count-bonus proven
  on 200 random MDPs), SFGPI (SFQL + task library + GPI + belief-masked
  Bayesian hypothesis elimination during k-shot inference). 224 tests green.
- FALSIFIED PRE-RUN (KB e349e51be77e): count-bonus/EFE cannot escape
  deceptive tie-lock at ANY tau (bonus decay + argmax-tie->quit); passing
  requires persistent value prior (optimism) or planning. EFE tau-grid
  rescaled by reward (registered).
- Env extensions: DeceptiveChoice(n_noise_actions, slip, mdp_model on TRUE
  unaliased state space) + golden byte-compat test; shared-layout continual
  suite (layout_seed=202, goal_override decoupled from wall roll — g1
  layouts byte-identical).
- H14 COMPLETE (seeds 200-211, n=12, arms O/M1/M2): tab 0/12 ALL envs ALL
  arms; dqn 12/12 (O=M1), 11/12 (M2 x2 envs); axq 12/12; R1 primary PASS
  3/3 envs. Instrumented: dqn large_events ~300-1600/seed; tab 0.
- H15 COMPLETE: AUC edge REPLICATES in direction but SHRINKS: diff +0.067
  (orig +0.100), dz=0.73 (orig 1.32), raw p=0.0469 (orig 0.031), CI
  [0.017;0.117], 6+/1-/5=0; NOT Holm-3 robust (adj 0.14). Original d
  likely upward-biased (seed-family luck).
- H16 running (g1repl, seeds 200-207, 2 arms): dqn-persist s200-201
  ret 0.25/0.00 (consistent with original 0.094 floor; gw3 floor replicates).

Stage Summary:
- Independent confirmation protocol executed exactly as user demanded:
  pre-registered, new seeds, raw per-seed data saved+published. Structural
  deceptive separation CONFIRMED (R1 3/3); AUC edge confirmed-in-direction
  with honest shrinkage; tabular correctness proven (failure = strategy
  property). H16 + H18/H19/H20/H21 in flight.

---
Task ID: 19-23 (orchestrator)
Agent: main-orchestrator (Super Z)
Task: Cycle 4 close-out: stats registry, new-architecture follow-ups
(MBTL capstone, A2C), docs, zips

Work Log:
- Task 19: docs/STATS_REGISTRY.md — полный реестр: все гипотезы H1-H23,
  семейства R/S/N (+ addendum), сырые per-seed значения всех эндпоинтов,
  raw + Holm-adjusted p, dz, CI, power-таблица, аудит мультипликативности
  (~20 сравнений в циклах 1-3; конфирматорный статус выносят репликации
  Family R).
- Follow-up (a): SF k=10 == k=3 байт-в-байт — пассивная идентификация НЕ
  масштабируется с бюджетом эпизодов (детерминированные повторы) =>
  нужна активная. Follow-up (b): dyna-persist-sh acquisition 1.000 /
  retention 0.000 — чистая диссоциация переносимости модели vs
 	task-специфичности Q.
- H23 MBTL (KB 7ee39337a91c, ДО реализации): Dyna-модель + библиотека
  reward-векторов + belief-GPI (активная идентификация точными VI-
  политиками) + VI-планирование. Результат: retention 0.625 (4x1.0/4x0.25),
  acquisition 1.000 — ЛУЧШИЙ no-oracle continual-агент проекта; kill-
  критерии пройдены; prediction >= 0.5 выполнен; бимодальность = k=3
  идентификация при 5 гипотезах (единственное остаточное узкое место).
- H22 A2C (KB 72ce5469f53c, с smoke-наблюдениями до батча): deceptive_50
  4/5 PASS — ПОДТВЕРЖДЕНИЕ теории argmax-tie (softmax не фиксируется при
  delay=50, где eps-greedy шанс ~0); cartpole 8.75 (коллапс untuned
  on-policy — честный негатив); chain_10 0/3. Таксономия расширена.
- 227 тестов зелёные (было 203 на входе в цикл 4). Доки финализированы
  (FINAL_REPORT 8.5-8.6, HYPOTHESES H22-H23, RESEARCH_LOG).
- Zip-дисциплина соблюдена: cycle3-final, cycle4-milestone1/2/3,
  cycle4-FINAL (90.8 MB, 5959 файлов) + LATEST.

Stage Summary:
- Cycle 4 COMPLETE. Требования пользователя выполнены полностью:
  (1) независимая репликация с пре-регистрацией и новыми сидами — R1 3/3,
  R2 направление+сжатие (dz 1.32->0.73, честно), R3 усиление (p=0.0156,
  Holm-устойчиво); (2) корректность tabular доказана off-policy, провал =
  свойство стратегии исследования (механизмная таксономия 2x2: optimism/
  planning/NN-асимметрия); (3) чувствительность: delay-режимы, luck,
  scale-калибровка, slip/trap/noise; (4) статистическая гигиена: реестр
  со всеми сырыми значениями; (5) новые архитектуры: Dyna-Q (новый лидер
  sample-efficiency), MBTL (новый лидер no-oracle continual), SF/GPI
  (частично, identification-limited), EFE (негатив, редукция доказана),
  A2C (подтверждение теории, негатив на control). Полной замены стека
  нет; иерархия инструментов уточнена и задокументирована.
